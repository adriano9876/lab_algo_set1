﻿using System;
using System.Collections.Generic;

namespace SqlAndEf.DbFirst.DataAccess.Models;

public partial class Shipment
{
    public int ShipmentsId { get; set; }

    public int? BookingId { get; set; }

    public int? VesselId { get; set; }

    public DateTime? BookingDate { get; set; }

    public string DepartureDate { get; set; }

    public string ArrivalDate { get; set; }

    public decimal? CargoWeight { get; set; }

    public decimal? ShippingCost { get; set; }

    public virtual Booking Booking { get; set; }

    public virtual Vessel Vessel { get; set; }
}
