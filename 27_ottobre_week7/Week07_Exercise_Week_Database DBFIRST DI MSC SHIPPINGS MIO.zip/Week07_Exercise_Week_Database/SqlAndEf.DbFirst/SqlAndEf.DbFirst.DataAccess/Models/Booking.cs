﻿using System;
using System.Collections.Generic;

namespace SqlAndEf.DbFirst.DataAccess.Models;

public partial class Booking
{
    public int BookingId { get; set; }

    public int? CustomerId { get; set; }

    public DateTime? BookingDate { get; set; }

    public string DeparturePort { get; set; }

    public string ArrivalPort { get; set; }

    public string StatusBooking { get; set; }

    public string Notes { get; set; }

    public virtual Customer Customer { get; set; }

    public virtual Shipment Shipment { get; set; }
}
