﻿using System;
using System.Collections.Generic;

namespace SqlAndEf.DbFirst.DataAccess.Models;

public partial class Vessel
{
    public int VesselId { get; set; }

    public string VesselName { get; set; }

    public DateOnly? YearBuilt { get; set; }

    public int? Capacity { get; set; }

    public virtual ICollection<Shipment> Shipments { get; set; } = new List<Shipment>();
}
