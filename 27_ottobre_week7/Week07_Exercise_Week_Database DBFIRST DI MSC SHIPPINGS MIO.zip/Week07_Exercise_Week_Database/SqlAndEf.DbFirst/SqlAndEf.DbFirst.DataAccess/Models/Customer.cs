﻿using System;
using System.Collections.Generic;

namespace SqlAndEf.DbFirst.DataAccess.Models;

public partial class Customer
{
    public int CustomerId { get; set; }

    public string CompanyName { get; set; }

    public string Email { get; set; }

    public string Phone { get; set; }

    public string Adress { get; set; }

    public DateTime? CreatedData { get; set; }

    public virtual ICollection<Booking> Bookings { get; set; } = new List<Booking>();
}
