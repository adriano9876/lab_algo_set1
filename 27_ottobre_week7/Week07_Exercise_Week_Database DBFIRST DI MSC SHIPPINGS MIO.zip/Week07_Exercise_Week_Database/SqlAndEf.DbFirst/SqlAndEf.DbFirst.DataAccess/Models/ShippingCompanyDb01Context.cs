﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace SqlAndEf.DbFirst.DataAccess.Models;

public partial class ShippingCompanyDb01Context : DbContext
{
    public ShippingCompanyDb01Context()
    {
    }

    public ShippingCompanyDb01Context(DbContextOptions<ShippingCompanyDb01Context> options)
        : base(options)
    {
    }

    public virtual DbSet<Booking> Bookings { get; set; }

    public virtual DbSet<Customer> Customers { get; set; }

    public virtual DbSet<Shipment> Shipments { get; set; }

    public virtual DbSet<Vessel> Vessels { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=HQAPEW1C966-AAQ;Database=ShippingCompanyDb01;User Id=sa;Password=SQL2019;TrustServerCertificate=True;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Booking>(entity =>
        {
            entity.HasKey(e => e.BookingId).HasName("PK__Bookings__73951AED896957F1");

            entity.Property(e => e.ArrivalPort).HasMaxLength(255);
            entity.Property(e => e.BookingDate).HasColumnType("datetime");
            entity.Property(e => e.DeparturePort).HasMaxLength(255);
            entity.Property(e => e.Notes).HasMaxLength(255);
            entity.Property(e => e.StatusBooking).HasMaxLength(255);

            entity.HasOne(d => d.Customer).WithMany(p => p.Bookings)
                .HasForeignKey(d => d.CustomerId)
                .HasConstraintName("FK__Bookings__Custom__48CFD27E");
        });

        modelBuilder.Entity<Customer>(entity =>
        {
            entity.HasKey(e => e.CustomerId).HasName("PK__Customer__A4AE64D85EC58887");

            entity.Property(e => e.Adress).HasMaxLength(255);
            entity.Property(e => e.CompanyName).HasMaxLength(255);
            entity.Property(e => e.CreatedData)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Email).HasMaxLength(255);
            entity.Property(e => e.Phone).HasMaxLength(255);
        });

        modelBuilder.Entity<Shipment>(entity =>
        {
            entity.HasKey(e => e.ShipmentsId).HasName("PK__Shipment__7884DD6D1D3256B5");

            entity.HasIndex(e => e.BookingId, "UQ__Shipment__73951AEC611829B0").IsUnique();

            entity.Property(e => e.ArrivalDate).HasMaxLength(255);
            entity.Property(e => e.BookingDate).HasColumnType("datetime");
            entity.Property(e => e.CargoWeight).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.DepartureDate).HasMaxLength(255);
            entity.Property(e => e.ShippingCost).HasColumnType("decimal(18, 2)");

            entity.HasOne(d => d.Booking).WithOne(p => p.Shipment)
                .HasForeignKey<Shipment>(d => d.BookingId)
                .HasConstraintName("FK__Shipments__Booki__4D94879B");

            entity.HasOne(d => d.Vessel).WithMany(p => p.Shipments)
                .HasForeignKey(d => d.VesselId)
                .HasConstraintName("FK__Shipments__Vesse__4CA06362");
        });

        modelBuilder.Entity<Vessel>(entity =>
        {
            entity.HasKey(e => e.VesselId).HasName("PK__Vessels__9148DE83A76E147F");

            entity.Property(e => e.VesselName).HasMaxLength(255);
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
