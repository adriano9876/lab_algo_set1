﻿using Microsoft.Extensions.DependencyInjection;
using SqlAndEf.DbFirst.ConsoleUi.Helpers;

namespace SqlAndEf.DbFirst.ConsoleUi;

public class App
{
    private readonly IServiceProvider _serviceProvider;

    public App(IServiceProvider serviceProvider)
    {
        _serviceProvider = serviceProvider;
    }

    public async Task RunAsync()
    {
        bool canContinue = true;

        while (canContinue)
        {
            using var scope = _serviceProvider.CreateScope();

            var commands = GetAvailableCommands(scope.ServiceProvider);
            Console.Clear();

            ShowTitle();
            ShowAvailableCommands(commands);

            canContinue = TryGetInputCommand(out string input);

            if (canContinue)
            {
                await ExecuteCommand(commands, input);

                Console.Error.Write("\nPRESS ENTER..");
                _ = Console.ReadLine();
            }
        }
    }

    private static List<ICommand> GetAvailableCommands(IServiceProvider sp)
    {
        var commands = sp.GetService<IEnumerable<ICommand>>()
            .OrderBy(com => com.DisplayName)
            .ToList();
        var allShortcuts = commands.Select(com => com.Shortcut).ToHashSet();
        if (allShortcuts.Count < commands.Count)
            throw new InvalidOperationException("Registering multiple commands with the same shortcut");
        if (allShortcuts.Any(string.IsNullOrWhiteSpace))
            throw new InvalidOperationException("Registering commands with invalid shortcut");

        return commands;
    }

    private static void ShowTitle()
    {
        Console.WriteLine("╔════════════════════════════════════════════════════╗");
        Console.WriteLine("║    ShippingCompany Bookings Console Application    ║");
        Console.WriteLine("╚════════════════════════════════════════════════════╝\n");
    }

    private static void ShowAvailableCommands(List<ICommand> commands)
    {
        Console.WriteLine("CHOOSE FROM:\n");

        foreach (var command in commands)
        {
            Console.WriteLine($"- {command.DisplayName} (shortcut: {command.Shortcut.ToUpperInvariant()})");
        }

        Console.WriteLine();
        Console.WriteLine();
    }

    private static bool TryGetInputCommand(out string input)
    {
        Console.WriteLine("TYPE THE COMMAND YOU WANT TO EXECUTE -- OR 'QUIT' TO CLOSE THE PROGRAM");
        input = Console.ReadLine()?.Trim().ToUpperInvariant();
        return !string.IsNullOrEmpty(input)
            && !input.Equals("q", StringComparison.InvariantCultureIgnoreCase)
            && !input.Equals("quit", StringComparison.InvariantCultureIgnoreCase);
    }

    private static async Task ExecuteCommand(List<ICommand> commands, string input)
    {
        var selectedCommand = commands.FirstOrDefault(com =>
            com.DisplayName.Equals(input, StringComparison.InvariantCultureIgnoreCase)
            || com.Shortcut.Equals(input, StringComparison.InvariantCultureIgnoreCase));

        try
        {
            if (selectedCommand is null)
            {
                ConsoleErrorHelper.Print("INVALID COMMAND");
                return;
            }

            await selectedCommand.Execute();
        }
        catch (Exception ex)
        {
            ConsoleErrorHelper.Print($"ERROR EXECUTING THE COMMAND '{selectedCommand.DisplayName}'");
            ConsoleErrorHelper.Print(ex);
        }
    }
}
