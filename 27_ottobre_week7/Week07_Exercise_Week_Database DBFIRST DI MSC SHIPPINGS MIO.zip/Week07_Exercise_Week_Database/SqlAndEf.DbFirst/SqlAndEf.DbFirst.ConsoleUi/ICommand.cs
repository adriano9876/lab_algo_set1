﻿namespace SqlAndEf.DbFirst.ConsoleUi;

public interface ICommand
{
    public string DisplayName { get; }
    public string Shortcut { get; }
    Task Execute();
}
