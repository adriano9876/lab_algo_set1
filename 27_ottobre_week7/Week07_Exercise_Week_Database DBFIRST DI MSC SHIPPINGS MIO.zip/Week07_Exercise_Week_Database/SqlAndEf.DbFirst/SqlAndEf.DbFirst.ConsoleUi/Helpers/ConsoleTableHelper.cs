﻿
namespace SqlAndEf.DbFirst.ConsoleUi.Helpers;

public static class ConsoleTableHelper
{
    public static void PrintHeader(string title, int width = 80)
    {
        Console.WriteLine();
        Console.WriteLine("=".PadRight(width, '='));
        Console.WriteLine(title);
        Console.WriteLine("=".PadRight(width, '='));
        Console.WriteLine();
    }

    public static void PrintEmptyResult(string message)
    {
        Console.WriteLine($"No results found. {message}");
    }

    public static void PrintCount(int count, string itemName)
    {
        var plural = count != 1 ? "s" : string.Empty;
        Console.WriteLine($"Found {count} {itemName}{plural}");
        Console.WriteLine();
    }

    public static void PrintSuccess(string message)
    {
        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine($"✅ {message}");
        Console.ResetColor();
        Console.WriteLine();
    }
}
