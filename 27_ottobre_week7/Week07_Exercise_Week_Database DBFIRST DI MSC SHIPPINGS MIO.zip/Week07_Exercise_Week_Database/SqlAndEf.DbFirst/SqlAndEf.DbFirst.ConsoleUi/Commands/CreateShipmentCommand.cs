﻿using SqlAndEf.DbFirst.BusinessLogic.Models;
using SqlAndEf.DbFirst.BusinessLogic.Services;
using SqlAndEf.DbFirst.ConsoleUi.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlAndEf.DbFirst.ConsoleUi.Commands;

public class CreateShipmentCommand : ICommand
{
    private readonly IShipmentService _shipmentService;
    private readonly IBookingService _bookingService;
    private readonly IVesselService _vesselService;

    public string DisplayName => "Create New Shipment";
    public string Shortcut => "CNS";

    public CreateShipmentCommand(
        IShipmentService shipmentService,
        IBookingService bookingService,
        IVesselService vesselService)
    {
        _shipmentService = shipmentService;
        _bookingService = bookingService;
        _vesselService = vesselService;
    }

    public async Task Execute()
    {
        ConsoleTableHelper.PrintHeader("CREATE NEW SHIPMENT");

        // Mostra bookings confermati senza shipment
        var allBookings = await _bookingService.GetAllBookingsAsync();
        var availableBookings = allBookings
            .Where(b => b.Status == "Confirmed" && !b.HasShipment)
            .ToList();

        if (availableBookings.Count == 0)
        {
            ConsoleErrorHelper.Print("No confirmed bookings available for shipment.");
            return;
        }

        Console.WriteLine("Available bookings:");
        foreach (var b in availableBookings)
        {
            Console.WriteLine($"  [{b.BookingId}] {b.CustomerName} - {b.DeparturePort} → {b.ArrivalPort}");
        }
        Console.WriteLine();

        var bookingId = ConsoleInputHelper.ReadInt("Booking ID", min: 1);

        if (!availableBookings.Any(b => b.BookingId == bookingId))
        {
            ConsoleErrorHelper.Print("Invalid booking ID or booking not available.");
            return;
        }

        // Mostra navi disponibili
        var vessels = await _vesselService.GetAllVesselsAsync();
        Console.WriteLine("\nAvailable vessels:");
        foreach (var v in vessels)
        {
            Console.WriteLine($"  [{v.VesselId}] {v.VesselName} - Available: {v.AvailableCapacity:N0}/{v.Capacity:N0} tons");
        }
        Console.WriteLine();

        var vesselId = ConsoleInputHelper.ReadInt("Vessel ID", min: 1);

        var vessel = await _vesselService.GetVesselByIdAsync(vesselId);
        if (vessel == null)
        {
            ConsoleErrorHelper.Print("Invalid vessel ID.");
            return;
        }

        Console.WriteLine($"\nMaximum available capacity: {vessel.AvailableCapacity:N2} tons");
        var cargoWeight = ConsoleInputHelper.ReadDecimal(
            "Cargo Weight (tons)",
            min: 0.01m,
            max: vessel.AvailableCapacity);

        var canAccommodate = true; // TODO
        if (!canAccommodate)
        {
            ConsoleErrorHelper.Print($"Vessel cannot accommodate {cargoWeight:N2} tons. Available capacity: {vessel.AvailableCapacity:N2} tons.");
            return;
        }

        var shippingCost = ConsoleInputHelper.ReadDecimal("Shipping Cost (€)", min: 0);

        if (!ConsoleInputHelper.Confirm($"\nCreate shipment for {cargoWeight:N2} tons on {vessel.VesselName}?"))
        {
            ConsoleErrorHelper.Print("Shipment creation cancelled.");
            return;
        }

        try
        {
            var shipment = new ShipmentDto(); // TODO 

            ConsoleTableHelper.PrintSuccess($"Shipment #{shipment.ShipmentId} created successfully!");
            ConsoleCardHelper.PrintShipmentCard(shipment);
        }
        catch (InvalidOperationException ex)
        {
            ConsoleErrorHelper.Print($"Validation failed: {ex.Message}");
        }
        catch (Exception ex)
        {
            ConsoleErrorHelper.Print($"Failed to create shipment: {ex.Message}");
        }
    }
}
