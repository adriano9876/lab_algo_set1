﻿using SqlAndEf.DbFirst.BusinessLogic.Services;
using SqlAndEf.DbFirst.ConsoleUi.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlAndEf.DbFirst.ConsoleUi.Commands;

public class CompleteShipmentCommand : ICommand
{
    private readonly IShipmentService _shipmentService;

    public string DisplayName => "Complete Shipment";
    public string Shortcut => "CS";

    public CompleteShipmentCommand(IShipmentService shipmentService)
    {
        _shipmentService = shipmentService;
    }

    public async Task Execute()
    {
        ConsoleTableHelper.PrintHeader("COMPLETE SHIPMENT");

        var allShipments = await _shipmentService.GetAllShipmentsAsync();
        var inTransit = allShipments
            .Where(s => s.DepartureDate.HasValue && !s.ArrivalDate.HasValue)
            .ToList();

        if (inTransit.Count == 0)
        {
            ConsoleTableHelper.PrintEmptyResult("No shipments in transit.");
            return;
        }

        Console.WriteLine("Shipments in transit:");
        foreach (var s in inTransit)
        {
            Console.WriteLine($"  [{s.ShipmentId}] {s.VesselName} - (Departed: {s.DepartureDate:yyyy-MM-dd})");
        }
        Console.WriteLine();

        var shipmentId = ConsoleInputHelper.ReadInt("Shipment ID", min: 1);

        if (!inTransit.Any(s => s.ShipmentId == shipmentId))
        {
            ConsoleErrorHelper.Print("Invalid shipment ID or shipment not in transit.");
            return;
        }

        var arrivalDate = ConsoleInputHelper.ReadDateTime("Arrival Date");

        try
        {
            var success = true; // TODO

            if (success)
            {
                ConsoleTableHelper.PrintSuccess($"Shipment #{shipmentId} completed successfully!");
            }
            else
            {
                ConsoleErrorHelper.Print("Failed to complete shipment.");
            }
        }
        catch (Exception ex)
        {
            ConsoleErrorHelper.Print($"Error: {ex.Message}");
        }
    }
}
