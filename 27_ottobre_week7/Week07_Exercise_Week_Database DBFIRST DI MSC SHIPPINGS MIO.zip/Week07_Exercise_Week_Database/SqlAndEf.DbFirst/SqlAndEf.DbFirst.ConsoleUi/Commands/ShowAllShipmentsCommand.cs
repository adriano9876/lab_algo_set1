﻿using SqlAndEf.DbFirst.BusinessLogic.Services;
using SqlAndEf.DbFirst.ConsoleUi.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlAndEf.DbFirst.ConsoleUi.Commands;

public class ShowAllShipmentsCommand : ICommand
{
    private readonly IShipmentService _shipmentService;

    public string DisplayName => "Show All Shipments";
    public string Shortcut => "SAS";

    public ShowAllShipmentsCommand(IShipmentService shipmentService)
    {
        _shipmentService = shipmentService;
    }

    public async Task Execute()
    {
        ConsoleTableHelper.PrintHeader("ALL SHIPMENTS");

        var shipments = await _shipmentService.GetAllShipmentsAsync();

        if (shipments.Count == 0)
        {
            ConsoleTableHelper.PrintEmptyResult("No shipments found.");
            return;
        }

        ConsoleTableHelper.PrintCount(shipments.Count, "shipment");

        foreach (var shipment in shipments)
        {
            ConsoleCardHelper.PrintShipmentCard(shipment);
        }
    }
}
