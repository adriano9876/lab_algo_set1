﻿using SqlAndEf.DbFirst.BusinessLogic.Models;
using SqlAndEf.DbFirst.BusinessLogic.Services;
using SqlAndEf.DbFirst.ConsoleUi.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlAndEf.DbFirst.ConsoleUi.Commands;

public class AddCustomerCommand : ICommand
{
    private readonly ICustomerService _customerService;

    public string DisplayName => "Add New Customer";
    public string Shortcut => "ANC";

    public AddCustomerCommand(ICustomerService customerService)
    {
        _customerService = customerService;
    }

    public async Task Execute()
    {
        ConsoleTableHelper.PrintHeader("ADD NEW CUSTOMER");

        var companyName = ConsoleInputHelper.ReadString("Company Name", required: true);
        var email = ConsoleInputHelper.ReadString("Email", required: true);
        var phone = ConsoleInputHelper.ReadString("Phone", required: false);
        var address = ConsoleInputHelper.ReadString("Address", required: false);

        try
        {
            // TODO: Add customer
            CustomerDto customer = new()
            {
                CompanyName = companyName,
                Email = email,
                Phone = phone,
                Address = address
                               
            };
            Task <int> ret  = _customerService.CreateCustomersAsync(customer);

            ConsoleTableHelper.PrintSuccess($"Customer '{customer.CompanyName}'" +
                $" added successfully with ID #{ret}");
            ConsoleCardHelper.PrintCustomerCard(customer);
        }
        catch (Exception ex)
        {
            ConsoleErrorHelper.Print($"Failed to add customer: {ex.Message}");
        }
    }
}
