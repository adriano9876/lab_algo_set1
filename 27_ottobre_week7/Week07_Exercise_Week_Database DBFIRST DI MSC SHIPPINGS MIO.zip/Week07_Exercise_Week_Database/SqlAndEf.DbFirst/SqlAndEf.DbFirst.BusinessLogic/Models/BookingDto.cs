﻿namespace SqlAndEf.DbFirst.BusinessLogic.Models;

public class BookingDto
{
    public int BookingId { get; set; }
    public int CustomerId { get; set; }
    public string CustomerName { get; set; }
    public DateTime? BookingDate { get; set; }
    public string DeparturePort { get; set; }
    public string ArrivalPort { get; set; }
    public string? Status { get; set; }
    public string Notes { get; set; }
    public bool HasShipment { get; set; }
}
