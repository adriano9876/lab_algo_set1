﻿namespace SqlAndEf.DbFirst.BusinessLogic.Models;

public class ShipmentDto
{
    public int ShipmentId { get; set; }
    public int BookingId { get; set; }
    public string CustomerName { get; set; }
    public int VesselId { get; set; }
    public string VesselName { get; set; }
    public DateTime? DepartureDate { get; set; }
    public DateTime? ArrivalDate { get; set; }
    public decimal CargoWeight { get; set; }
    public decimal? ShippingCost { get; set; }
    public int? TripDuration => ArrivalDate.HasValue && DepartureDate.HasValue
        ? (ArrivalDate.Value - DepartureDate.Value).Days
        : null;
}
