﻿using SqlAndEf.DbFirst.DataAccess.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlAndEf.DbFirst.BusinessLogic.Models
{
    public class CreateCustomerDto
    {      
        public string CompanyName { get; set; }

        public string Email { get; set; }

        public string Phone { get; set; }

        public string Adress { get; set; }   


    }
}
