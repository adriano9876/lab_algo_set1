﻿namespace SqlAndEf.DbFirst.BusinessLogic.Models;

public class CustomerDto
{
    public int CustomerId { get; set; }
    public string CompanyName { get; set; }
    public string Email { get; set; }
    public string Phone { get; set; }
    public string Address { get; set; }
    public DateTime CreatedDate { get; set; }
    public int TotalBookings { get; set; }
}
