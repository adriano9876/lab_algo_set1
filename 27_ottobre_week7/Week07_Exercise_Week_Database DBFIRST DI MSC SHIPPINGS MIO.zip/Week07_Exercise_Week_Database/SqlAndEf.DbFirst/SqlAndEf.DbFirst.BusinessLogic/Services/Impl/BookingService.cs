﻿using Microsoft.EntityFrameworkCore;
using SqlAndEf.DbFirst.BusinessLogic.Models;
using SqlAndEf.DbFirst.DataAccess.Models;

namespace SqlAndEf.DbFirst.BusinessLogic.Services.Impl;

public class BookingService : IBookingService
{
    /* public Task<List<BookingDto>> GetAllBookingsAsync()
    {
        return Task.FromResult(new List<BookingDto>
        {
            new()
            {
                BookingId = 1,
                CustomerId = 1,
                BookingDate = DateTime.Now,
                CustomerName = "Company 1",
                Status = "Pending",
                DeparturePort = "Caracas",
                ArrivalPort = "Genoa",
                HasShipment = true,
            },
            new()
            {
                BookingId = 2,
                CustomerId = 2,
                BookingDate = DateTime.Now,
                CustomerName = "Company B",
                Status = "Pending",
                DeparturePort = "Helsinki",
                ArrivalPort = "Antwerp",
                HasShipment = false,
            }
        });
    }  */
    private readonly ShippingCompanyDb01Context _context;
    public BookingService (ShippingCompanyDb01Context context)
    {
        _context = context;
    }

    public async Task<int> CreatebookingAsync(BookingDto dto)
    {
        var bookingNew = _context.Bookings.Add( new Booking
        {
            CustomerId = dto.CustomerId,
            ArrivalPort = dto.ArrivalPort,  
            DeparturePort = dto.DeparturePort,
            Notes = dto.Notes,
        } ).Entity;
        await _context.SaveChangesAsync();
        return bookingNew.BookingId;
        //throw new NotImplementedException();
    }

    public async Task<List<BookingDto>> GetAllBookingsAsync()
    {
        var bookings = _context.Bookings.AsNoTracking()//.Include(c => new Customer())
            .Select(b => new BookingDto
        {
            BookingId = b.BookingId,
            CustomerId = b.CustomerId.Value,
            CustomerName = b.Customer.CompanyName,
            BookingDate = b.BookingDate.Value,
            DeparturePort = b.DeparturePort,
            ArrivalPort = b.ArrivalPort,
            Status = b.StatusBooking,
            Notes = b.Notes            
        });
        return bookings.ToList();

    }

    public Task<List<BookingDto>> GetPendingBookingsAsync()
    {
        return Task.FromResult(new List<BookingDto>());
    }
}
