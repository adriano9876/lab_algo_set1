﻿using Microsoft.EntityFrameworkCore;
using SqlAndEf.DbFirst.BusinessLogic.Models;
using SqlAndEf.DbFirst.DataAccess.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlAndEf.DbFirst.BusinessLogic.Services.Impl;

public class ShipmentService : IShipmentService
{
    private readonly ShippingCompanyDb01Context _context;
    public ShipmentService(ShippingCompanyDb01Context context)
    {
        _context = context;
    }

    public async Task<List<ShipmentDto>> GetAllShipmentsAsync()
    {
        /* return Task.FromResult(new List<ShipmentDto>()
        {
            new()
            {
                ShipmentId = 1,
                BookingId = 1,
                DepartureDate = DateTime.Now,
                ArrivalDate = DateTime.Now,
                CargoWeight = 20,
                CustomerName = "Company One",
                ShippingCost = 350_000,
                VesselId = 1,
                VesselName = "Vessel 1"
            }
        }); */


        var shipments = _context.Shipments.AsNoTracking().Include().Select(s => new ShipmentDto
        {
            ShipmentId = s.ShipmentsId,
            BookingId = s.BookingId.Value,
            CustomerName = "",
            VesselId = s.VesselId.Value,
            VesselName = "",
            DepartureDate =  new DateTime(2000,1,1),
            ArrivalDate = new DateTime(2000, 1, 1),
            CargoWeight = s.CargoWeight.Value,
            ShippingCost = s.ShippingCost,
            

        });
        return shipments.ToList();  

    }


}
