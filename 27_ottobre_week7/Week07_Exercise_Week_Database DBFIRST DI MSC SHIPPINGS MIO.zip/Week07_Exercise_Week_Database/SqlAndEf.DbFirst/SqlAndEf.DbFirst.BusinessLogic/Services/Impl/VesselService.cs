﻿using Microsoft.EntityFrameworkCore;
using SqlAndEf.DbFirst.BusinessLogic.Models;
using SqlAndEf.DbFirst.DataAccess.Models;

namespace SqlAndEf.DbFirst.BusinessLogic.Services.Impl;

public class VesselService : IVesselService
{
    /* public Task<List<VesselDto>> GetAllVesselsAsync()
    {
        return Task.FromResult(
            new List<VesselDto>
            {
                new()
                {
                    VesselId = 1,
                    VesselName = "Name 1",
                    Capacity = 100,
                    CurrentLoad = 50,
                    TotalShipments = 23,
                    YearBuilt = 1967
                },
                new()
                {
                    VesselId = 2,
                    VesselName = "Name 2",
                    Capacity = 1000,
                    CurrentLoad = 750,
                    TotalShipments = 22,
                    YearBuilt = 1969
                }
            });
    }*/
    private readonly ShippingCompanyDb01Context _context;
    public VesselService (ShippingCompanyDb01Context context)
    {
        _context = context;
    }
    public async Task<List<VesselDto>> GetAllVesselsAsync()
    {
        var vessels = _context.Vessels.AsNoTracking().Select(v => new VesselDto
        {
            VesselId = v.VesselId,
            VesselName = v.VesselName,
            Capacity = v.Capacity.Value,
            YearBuilt = v.YearBuilt.Value.Year,
            TotalShipments = 100,
            CurrentLoad = 100           
        });
        return vessels.ToList();
    }
    public Task<VesselDto> GetVesselByIdAsync(int vesselId)
    {
        return Task.FromResult(new VesselDto { VesselId = vesselId });
    }
}
