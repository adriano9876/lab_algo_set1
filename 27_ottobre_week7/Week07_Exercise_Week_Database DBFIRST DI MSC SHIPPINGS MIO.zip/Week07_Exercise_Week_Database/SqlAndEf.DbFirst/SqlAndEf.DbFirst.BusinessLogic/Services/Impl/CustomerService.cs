﻿using SqlAndEf.DbFirst.BusinessLogic.Models;
using SqlAndEf.DbFirst.DataAccess.Models;

namespace SqlAndEf.DbFirst.BusinessLogic.Services.Impl;

public class CustomerService : ICustomerService
{
    private readonly ShippingCompanyDb01Context _context;

    public CustomerService(ShippingCompanyDb01Context context)
    {
        _context = context;
    }

    public async Task<List<CustomerDto>> GetAllCustomersAsync()
    {
        /* List<CustomerDto> result = [
             new()
             {
                 CustomerId = 1,
                 CompanyName = "Company 1",
                 Email = "company.one@mail.com",
                 Phone = "+39 011 234 5678",
                 Address = "via Compagnia 1",
                 CreatedDate = DateTime.Parse("2025-04-07 09:00"),
             },
             new()
             {
                 CustomerId = 2,
                 CompanyName = "Company 2",
                 Email = "company.two@mail.com",
                 Phone = "+39 012 345 6789",
                 Address = "via Compagnia 2/B",
                 CreatedDate = DateTime.Parse("2025-07-07 18:00")
             },
             ];
        */

        var customer = _context.Customers.Select( c => new CustomerDto
        {
            CustomerId = c.CustomerId,
            Address = c.Adress,
            CompanyName = c.CompanyName,
            CreatedDate = (DateTime)c.CreatedData.Value, //new DateTime(2020,1,1),
            Email = c.Email,
            Phone = c.Phone,
            TotalBookings = 0
        });
        return customer.ToList();
        //return await customer.ToListAsync();
        //return Task.FromResult(result);
    }

    public async Task<int> CreateCustomersAsync(CustomerDto dto)
    {
        var customer = _context.Customers.Add(new Customer
        {
            CompanyName = dto.CompanyName,
            Email = dto.Email,
            Phone = dto.Phone,
            Adress = dto.Address
        }).Entity;//restituisce la entita
        await _context.SaveChangesAsync();
        return customer.CustomerId;
    }





}
