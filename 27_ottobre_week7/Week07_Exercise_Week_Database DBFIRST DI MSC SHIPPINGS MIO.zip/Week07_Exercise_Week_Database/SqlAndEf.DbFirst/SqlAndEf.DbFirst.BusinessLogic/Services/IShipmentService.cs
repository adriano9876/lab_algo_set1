﻿
using SqlAndEf.DbFirst.BusinessLogic.Models;

namespace SqlAndEf.DbFirst.BusinessLogic.Services;

public interface IShipmentService
{
    Task<List<ShipmentDto>> GetAllShipmentsAsync();
}
