﻿using SqlAndEf.DbFirst.BusinessLogic.Models;

namespace SqlAndEf.DbFirst.BusinessLogic.Services;

public interface ICustomerService
{
    Task<List<CustomerDto>> GetAllCustomersAsync();
    Task <int> CreateCustomersAsync(CustomerDto dto);


}
