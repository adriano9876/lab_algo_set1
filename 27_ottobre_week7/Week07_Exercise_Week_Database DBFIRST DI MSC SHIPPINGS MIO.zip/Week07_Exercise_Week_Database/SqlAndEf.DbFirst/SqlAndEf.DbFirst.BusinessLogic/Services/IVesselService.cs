﻿
using SqlAndEf.DbFirst.BusinessLogic.Models;

namespace SqlAndEf.DbFirst.BusinessLogic.Services;

public interface IVesselService
{
    Task<List<VesselDto>> GetAllVesselsAsync();
    Task<VesselDto> GetVesselByIdAsync(int vesselId);
}
