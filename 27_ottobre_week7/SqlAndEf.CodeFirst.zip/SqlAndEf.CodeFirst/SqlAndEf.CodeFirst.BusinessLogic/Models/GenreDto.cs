namespace SqlAndEf.CodeFirst.BusinessLogic.Models;

public class GenreDto
{
    public int GenreId { get; set; }
    public string Name { get; set; }
    public int TracksCount { get; set; }
}
