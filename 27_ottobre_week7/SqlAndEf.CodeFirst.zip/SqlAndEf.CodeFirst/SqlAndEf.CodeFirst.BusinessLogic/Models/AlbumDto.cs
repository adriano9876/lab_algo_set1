namespace SqlAndEf.CodeFirst.BusinessLogic.Models;

public class AlbumDto
{
    public int AlbumId { get; set; }
    public string Title { get; set; }
    public int ReleaseYear { get; set; }
    public int TracksCount { get; set; }
}
