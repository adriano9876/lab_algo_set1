using SqlAndEf.CodeFirst.BusinessLogic.Models;

namespace SqlAndEf.CodeFirst.BusinessLogic.Services.Impl;

public class AlbumService : IAlbumService
{
    // TODO: Implementare i metodi usando Entity Framework Core
    
    public Task<List<AlbumDto>> GetAllAlbumsAsync()
    {
        throw new NotImplementedException();
    }

    public Task<AlbumDto> GetAlbumByIdAsync(int id)
    {
        throw new NotImplementedException();
    }

    public Task<AlbumDto> CreateAlbumAsync(AlbumDto album)
    {
        throw new NotImplementedException();
    }

    public Task<AlbumDto> UpdateAlbumAsync(int id, AlbumDto album)
    {
        throw new NotImplementedException();
    }

    public Task<bool> DeleteAlbumAsync(int id)
    {
        throw new NotImplementedException();
    }

    public Task<List<AlbumDto>> GetAlbumsByYearAsync(int year)
    {
        throw new NotImplementedException();
    }
}
