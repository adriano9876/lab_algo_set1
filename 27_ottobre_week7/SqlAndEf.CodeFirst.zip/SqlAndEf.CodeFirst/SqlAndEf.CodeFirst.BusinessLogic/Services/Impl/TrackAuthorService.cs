using SqlAndEf.CodeFirst.BusinessLogic.Models;

namespace SqlAndEf.CodeFirst.BusinessLogic.Services.Impl;

public class TrackAuthorService : ITrackAuthorService
{
    // TODO: Implementare i metodi usando Entity Framework Core
    
    public Task<List<TrackAuthorDto>> GetAllTrackAuthorsAsync()
    {
        throw new NotImplementedException();
    }

    public Task<TrackAuthorDto> GetTrackAuthorByIdAsync(int id)
    {
        throw new NotImplementedException();
    }

    public Task<TrackAuthorDto> CreateTrackAuthorAsync(TrackAuthorDto trackAuthor)
    {
        throw new NotImplementedException();
    }

    public Task<bool> DeleteTrackAuthorAsync(int id)
    {
        throw new NotImplementedException();
    }

    public Task<List<TrackAuthorDto>> GetAuthorsByTrackAsync(int trackId)
    {
        throw new NotImplementedException();
    }

    public Task<List<TrackAuthorDto>> GetTracksByArtistAsync(int artistId)
    {
        throw new NotImplementedException();
    }
}
