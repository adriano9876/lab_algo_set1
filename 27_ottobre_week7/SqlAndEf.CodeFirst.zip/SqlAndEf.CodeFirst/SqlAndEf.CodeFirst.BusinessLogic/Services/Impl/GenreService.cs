using SqlAndEf.CodeFirst.BusinessLogic.Models;

namespace SqlAndEf.CodeFirst.BusinessLogic.Services.Impl;

public class GenreService : IGenreService
{
    // TODO: Implementare i metodi usando Entity Framework Core
    
    public Task<List<GenreDto>> GetAllGenresAsync()
    {
        throw new NotImplementedException();
    }

    public Task<GenreDto> GetGenreByIdAsync(int id)
    {
        throw new NotImplementedException();
    }

    public Task<GenreDto> CreateGenreAsync(GenreDto genre)
    {
        throw new NotImplementedException();
    }

    public Task<GenreDto> UpdateGenreAsync(int id, GenreDto genre)
    {
        throw new NotImplementedException();
    }

    public Task<bool> DeleteGenreAsync(int id)
    {
        throw new NotImplementedException();
    }
}
