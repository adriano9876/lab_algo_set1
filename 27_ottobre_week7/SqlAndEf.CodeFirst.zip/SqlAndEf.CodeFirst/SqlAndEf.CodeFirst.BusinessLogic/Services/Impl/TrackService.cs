using SqlAndEf.CodeFirst.BusinessLogic.Models;

namespace SqlAndEf.CodeFirst.BusinessLogic.Services.Impl;

public class TrackService : ITrackService
{
    // TODO: Implementare i metodi usando Entity Framework Core
    
    public Task<List<TrackDto>> GetAllTracksAsync()
    {
        throw new NotImplementedException();
    }

    public Task<TrackDto> GetTrackByIdAsync(int id)
    {
        throw new NotImplementedException();
    }

    public Task<TrackDto> CreateTrackAsync(TrackDto track)
    {
        throw new NotImplementedException();
    }

    public Task<TrackDto> UpdateTrackAsync(int id, TrackDto track)
    {
        throw new NotImplementedException();
    }

    public Task<bool> DeleteTrackAsync(int id)
    {
        throw new NotImplementedException();
    }

    public Task<List<TrackDto>> GetTracksByGenreAsync(int genreId)
    {
        throw new NotImplementedException();
    }

    public Task<List<TrackDto>> GetTracksByAlbumAsync(int albumId)
    {
        throw new NotImplementedException();
    }

    public Task<List<TrackDto>> GetTracksByArtistAsync(int artistId)
    {
        throw new NotImplementedException();
    }
}
