using SqlAndEf.CodeFirst.BusinessLogic.Models;

namespace SqlAndEf.CodeFirst.BusinessLogic.Services.Impl;

public class ArtistService : IArtistService
{
    public Task<List<ArtistDto>> GetAllArtistsAsync()
    {
        throw new NotImplementedException();
    }

    public Task<ArtistDto> GetArtistByIdAsync(int id)
    {
        throw new NotImplementedException();
    }

    public Task<ArtistDto> CreateArtistAsync(ArtistDto artist)
    {
        throw new NotImplementedException();
    }

    public Task<ArtistDto> UpdateArtistAsync(int id, ArtistDto artist)
    {
        throw new NotImplementedException();
    }

    public Task<bool> DeleteArtistAsync(int id)
    {
        throw new NotImplementedException();
    }

    public Task<List<ArtistDto>> GetArtistsByCountryAsync(string country)
    {
        throw new NotImplementedException();
    }
}
