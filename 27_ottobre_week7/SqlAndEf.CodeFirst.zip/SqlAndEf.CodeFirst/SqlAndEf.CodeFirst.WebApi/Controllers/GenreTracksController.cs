using Microsoft.AspNetCore.Mvc;
using SqlAndEf.CodeFirst.BusinessLogic.Services;
using SqlAndEf.CodeFirst.WebApi.Models.Responses;

namespace SqlAndEf.CodeFirst.WebApi.Controllers;

[ApiController]
[Route("api/genres/{genreId}/tracks")]
public class GenreTracksController : ControllerBase
{
    private readonly ITrackService _trackService;
    private readonly ILogger<GenreTracksController> _logger;

    public GenreTracksController(ITrackService trackService, ILogger<GenreTracksController> logger)
    {
        _trackService = trackService;
        _logger = logger;
    }

    [HttpGet]
    public async Task<ActionResult<List<TrackResponse>>> GetTracksByGenre(int genreId)
    {
        var tracks = await _trackService.GetTracksByGenreAsync(genreId);
        var response = tracks.Select(t => new TrackResponse
        {
            TrackId = t.TrackId,
            Title = t.Title,
            AlbumId = t.AlbumId,
            AlbumTitle = t.AlbumTitle,
            GenreId = t.GenreId,
            GenreName = t.GenreName,
            DurationSeconds = t.DurationSeconds,
            Artists = t.Artists
        }).ToList();

        return Ok(response);
    }
}
