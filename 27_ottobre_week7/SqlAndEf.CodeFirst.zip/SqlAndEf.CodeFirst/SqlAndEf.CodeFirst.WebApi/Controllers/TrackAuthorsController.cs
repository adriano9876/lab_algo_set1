using Microsoft.AspNetCore.Mvc;
using SqlAndEf.CodeFirst.BusinessLogic.Models;
using SqlAndEf.CodeFirst.BusinessLogic.Services;
using SqlAndEf.CodeFirst.WebApi.Models.Requests;
using SqlAndEf.CodeFirst.WebApi.Models.Responses;

namespace SqlAndEf.CodeFirst.WebApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class TrackAuthorsController : ControllerBase
{
    private readonly ITrackAuthorService _trackAuthorService;
    private readonly ILogger<TrackAuthorsController> _logger;

    public TrackAuthorsController(ITrackAuthorService trackAuthorService, ILogger<TrackAuthorsController> logger)
    {
        _trackAuthorService = trackAuthorService;
        _logger = logger;
    }

    [HttpGet]
    public async Task<ActionResult<List<TrackAuthorResponse>>> GetAll()
    {
        var trackAuthors = await _trackAuthorService.GetAllTrackAuthorsAsync();
        var response = trackAuthors.Select(ta => new TrackAuthorResponse
        {
            TrackAuthorId = ta.TrackAuthorId,
            TrackId = ta.TrackId,
            TrackTitle = ta.TrackTitle,
            ArtistId = ta.ArtistId,
            ArtistName = ta.ArtistName
        }).ToList();

        return Ok(response);
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<TrackAuthorResponse>> GetById(int id)
    {
        var trackAuthor = await _trackAuthorService.GetTrackAuthorByIdAsync(id);
        
        if (trackAuthor == null)
            return NotFound();

        var response = new TrackAuthorResponse
        {
            TrackAuthorId = trackAuthor.TrackAuthorId,
            TrackId = trackAuthor.TrackId,
            TrackTitle = trackAuthor.TrackTitle,
            ArtistId = trackAuthor.ArtistId,
            ArtistName = trackAuthor.ArtistName
        };

        return Ok(response);
    }

    [HttpGet("by-track/{trackId}")]
    public async Task<ActionResult<List<TrackAuthorResponse>>> GetByTrack(int trackId)
    {
        var trackAuthors = await _trackAuthorService.GetAuthorsByTrackAsync(trackId);
        var response = trackAuthors.Select(ta => new TrackAuthorResponse
        {
            TrackAuthorId = ta.TrackAuthorId,
            TrackId = ta.TrackId,
            TrackTitle = ta.TrackTitle,
            ArtistId = ta.ArtistId,
            ArtistName = ta.ArtistName
        }).ToList();

        return Ok(response);
    }

    [HttpGet("by-artist/{artistId}")]
    public async Task<ActionResult<List<TrackAuthorResponse>>> GetByArtist(int artistId)
    {
        var trackAuthors = await _trackAuthorService.GetTracksByArtistAsync(artistId);
        var response = trackAuthors.Select(ta => new TrackAuthorResponse
        {
            TrackAuthorId = ta.TrackAuthorId,
            TrackId = ta.TrackId,
            TrackTitle = ta.TrackTitle,
            ArtistId = ta.ArtistId,
            ArtistName = ta.ArtistName
        }).ToList();

        return Ok(response);
    }

    [HttpPost]
    public async Task<ActionResult<TrackAuthorResponse>> Create([FromBody] CreateTrackAuthorRequest request)
    {
        var trackAuthorDto = new TrackAuthorDto
        {
            TrackId = request.TrackId,
            ArtistId = request.ArtistId
        };

        var createdTrackAuthor = await _trackAuthorService.CreateTrackAuthorAsync(trackAuthorDto);

        var response = new TrackAuthorResponse
        {
            TrackAuthorId = createdTrackAuthor.TrackAuthorId,
            TrackId = createdTrackAuthor.TrackId,
            TrackTitle = createdTrackAuthor.TrackTitle,
            ArtistId = createdTrackAuthor.ArtistId,
            ArtistName = createdTrackAuthor.ArtistName
        };

        return CreatedAtAction(nameof(GetById), new { id = response.TrackAuthorId }, response);
    }

    [HttpDelete("{id}")]
    public async Task<ActionResult> Delete(int id)
    {
        var deleted = await _trackAuthorService.DeleteTrackAuthorAsync(id);

        if (!deleted)
            return NotFound();

        return NoContent();
    }
}
