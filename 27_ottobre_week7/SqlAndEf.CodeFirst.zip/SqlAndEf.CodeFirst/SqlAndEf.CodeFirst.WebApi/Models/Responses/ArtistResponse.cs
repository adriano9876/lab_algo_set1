namespace SqlAndEf.CodeFirst.WebApi.Models.Responses;

public class ArtistResponse
{
    public int ArtistId { get; set; }
    public string Name { get; set; }
    public string Country { get; set; }
    public int TracksCount { get; set; }
}
