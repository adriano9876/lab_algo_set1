namespace SqlAndEf.CodeFirst.WebApi.Models.Responses;

public class GenreResponse
{
    public int GenreId { get; set; }
    public string Name { get; set; }
    public int TracksCount { get; set; }
}
