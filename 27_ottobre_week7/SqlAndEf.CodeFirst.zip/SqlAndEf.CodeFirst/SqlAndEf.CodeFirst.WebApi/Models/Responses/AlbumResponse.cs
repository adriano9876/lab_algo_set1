namespace SqlAndEf.CodeFirst.WebApi.Models.Responses;

public class AlbumResponse
{
    public int AlbumId { get; set; }
    public string Title { get; set; }
    public int ReleaseYear { get; set; }
    public int TracksCount { get; set; }
}
