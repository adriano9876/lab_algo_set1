namespace SqlAndEf.CodeFirst.WebApi.Models.Requests;

public class CreateGenreRequest
{
    public string Name { get; set; }
}
