namespace SqlAndEf.CodeFirst.WebApi.Models.Requests;

public class CreateArtistRequest
{
    public string Name { get; set; }
    public string Country { get; set; }
}
