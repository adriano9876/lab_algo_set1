namespace SqlAndEf.CodeFirst.WebApi.Models.Requests;

public class CreateAlbumRequest
{
    public string Title { get; set; }
    public int ReleaseYear { get; set; }
}
