namespace SqlAndEf.CodeFirst.WebApi.Models.Requests;

public class UpdateTrackRequest
{
    public string Title { get; set; }
    public int AlbumId { get; set; }
    public int GenreId { get; set; }
    public int DurationSeconds { get; set; }
}
