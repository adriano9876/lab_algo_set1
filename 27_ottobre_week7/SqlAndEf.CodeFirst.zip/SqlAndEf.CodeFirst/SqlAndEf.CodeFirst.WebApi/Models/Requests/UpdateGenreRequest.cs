namespace SqlAndEf.CodeFirst.WebApi.Models.Requests;

public class UpdateGenreRequest
{
    public string Name { get; set; }
}
