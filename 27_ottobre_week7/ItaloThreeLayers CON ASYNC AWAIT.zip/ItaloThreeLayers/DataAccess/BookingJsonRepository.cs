﻿using System.Text;
using Entity;
using Newtonsoft.Json;

namespace DataAccess
{
    public class BookingJsonRepository : IBookingJsonRepository
    {
        private const string Path = "..\\..\\..\\..\\DataAccess\\Bookings.json";

        public async Task<Booking> CreateBookingAsync(Booking booking, CancellationToken cancellationToken)
        {
            if (booking == null)
            {
                throw new ArgumentNullException(nameof(booking), "Invalid booking");
            }

            var savedBookings = await this.GetSavedBookingsAsync(cancellationToken);

            DoCreateBooking(savedBookings, booking);

            await SaveBookingsAsync(savedBookings, cancellationToken);

            return booking;
        }

        public async Task<List<Booking>> GetAllBookingsAsync(CancellationToken cancellationToken)
        {
            var savedBookings = await this.GetSavedBookingsAsync(cancellationToken);
            if (savedBookings?.Bookings == null)
            {
                throw new ArgumentNullException(nameof(savedBookings), "Invalid saved bookings");
            }

            return savedBookings.Bookings;
        }

        public async Task<Booking> UpdateBookingAsync(Booking inputModel, CancellationToken cancellationToken)
        {
            if (inputModel == null)
            {
                throw new ArgumentNullException(nameof(inputModel), "Invalid booking");
            }

            var savedBookings = await this.GetSavedBookingsAsync(cancellationToken);

            var bookingToBeUpdated = DoUpdateBooking(inputModel, savedBookings);

            await SaveBookingsAsync(savedBookings, cancellationToken);

            return bookingToBeUpdated;
        }

        public async Task<bool> DeleteBookingAsync(int id, CancellationToken cancellationToken)
        {
            var savedBookings = await this.GetSavedBookingsAsync(cancellationToken);
            var isDeleted = DoDeleteBooking(id, savedBookings);

            await SaveBookingsAsync(savedBookings, cancellationToken);

            return isDeleted;
        }

        private static void DoCreateBooking(JsonBooking jsonBooking, Booking booking)
        {
            if (jsonBooking?.Bookings == null)
            {
                throw new ArgumentNullException(nameof(jsonBooking), "Invalid saved bookings");
            }

            var lastSavedId = jsonBooking.Bookings.Count == 0 ? 0 : jsonBooking.Bookings.Max(b => b.Id);

            booking.Id = lastSavedId + 1;

            jsonBooking.Bookings.Add(booking);
        }

        private static Booking DoUpdateBooking(Booking inputModel, JsonBooking savedBookings)
        {
            if (savedBookings?.Bookings == null)
            {
                throw new ArgumentNullException(nameof(savedBookings), "Invalid saved bookings");
            }

            var bookingToBeUpdated = savedBookings.Bookings.FirstOrDefault(b => b.Id == inputModel.Id);
            if (bookingToBeUpdated == null)
            {
                throw new InvalidOperationException(nameof(bookingToBeUpdated));
            }

            bookingToBeUpdated.DepartureStation = inputModel.DepartureStation;
            bookingToBeUpdated.ArrivalStation = inputModel.ArrivalStation;
            bookingToBeUpdated.Name = inputModel.Name;
            bookingToBeUpdated.Surname = inputModel.Surname;
            return bookingToBeUpdated;
        }

        private static bool DoDeleteBooking(int id, JsonBooking savedBookings)
        {
            if (savedBookings?.Bookings == null)
            {
                throw new ArgumentNullException(nameof(savedBookings), "Invalid saved bookings");
            }

            var removedItems = savedBookings.Bookings.RemoveAll(booking => booking.Id == id);
            return removedItems == 1;
        }

        private async Task<JsonBooking> GetSavedBookingsAsync(CancellationToken cancellationToken)
        {
            JsonBooking jsonBooking;

            if (!File.Exists(Path))
            {
                jsonBooking = new JsonBooking();
            }
            else
            {
                string savedBookings;
                using (var sr = new StreamReader(Path))
                {
                    savedBookings = await sr.ReadToEndAsync(cancellationToken);
                }

                jsonBooking = JsonConvert.DeserializeObject<JsonBooking>(savedBookings);
            }

            return jsonBooking;
        }

        private async Task SaveBookingsAsync(JsonBooking jsonBooking, CancellationToken cancellationToken)
        {
            if (jsonBooking?.Bookings == null)
            {
                throw new ArgumentNullException(nameof(jsonBooking), "Invalid saved bookings");
            }

            var jsonBookings = JsonConvert.SerializeObject(jsonBooking);

            await using var sw = new StreamWriter(Path, false);
            await sw.WriteAsync(new StringBuilder(jsonBookings), cancellationToken);
        }
    }
}
