﻿using Entity;

namespace DataAccess
{
    public class JsonBooking
    {
        public List<Booking> Bookings { get; set; } = new List<Booking>();
    }
}
