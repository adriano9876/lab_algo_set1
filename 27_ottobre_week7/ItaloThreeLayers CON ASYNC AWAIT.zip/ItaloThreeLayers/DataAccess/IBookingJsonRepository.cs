﻿using Entity;

namespace DataAccess
{
    public interface IBookingJsonRepository
    {
        Task<Booking> CreateBookingAsync(Booking booking, CancellationToken cancellationToken);

        Task<bool> DeleteBookingAsync(int id, CancellationToken cancellationToken);

        Task<List<Booking>> GetAllBookingsAsync(CancellationToken cancellationToken);

        Task<Booking> UpdateBookingAsync(Booking inputModel, CancellationToken cancellationToken);
    }
}
