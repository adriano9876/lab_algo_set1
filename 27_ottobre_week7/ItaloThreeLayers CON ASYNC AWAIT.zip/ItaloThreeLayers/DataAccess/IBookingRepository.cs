﻿using Entity;

namespace DataAccess
{
    public interface IBookingRepository
    {
        Booking CreateBooking(Booking booking);

        bool DeleteBooking(int id);

        List<Booking> GetAllBookings();

        Booking UpdateBooking(Booking inputModel);
    }
}
