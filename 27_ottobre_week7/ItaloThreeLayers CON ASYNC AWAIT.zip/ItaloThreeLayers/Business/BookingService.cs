﻿using DataAccess;
using Entity;

namespace Business
{
    public class BookingService : IBookingService
    {
        private readonly IBookingJsonRepository bookingRepository;
        private readonly IBookingConverter bookingConverter;

        public BookingService(
            IBookingJsonRepository bookingRepository,
            IBookingConverter bookingConverter)
        {
            if (bookingRepository == null)
            {
                throw new ArgumentNullException(nameof(bookingRepository), "No repository found");
            }

            if (bookingConverter == null)
            {
                throw new ArgumentNullException(nameof(bookingConverter), "No converter found");
            }

            this.bookingRepository = bookingRepository;
            this.bookingConverter = bookingConverter;
        }

        public async Task<BookingDto> CreateBookingAsync(
            CreateBookingCommand command,
            CancellationToken cancellationToken)
        {
            if (command == null)
            {
                throw new ArgumentNullException(nameof(command), "Invalid command");
            }

            var inputModel = new Booking(
                default,
                command.DepartureStation,
                command.ArrivalStation,
                command.Name,
                command.Surname);

            var model = await this.bookingRepository.CreateBookingAsync(inputModel, cancellationToken);

            var dto = this.bookingConverter.GetDto(model);

            return dto;
        }

        public async Task<bool> DeleteBookingAsync(
            DeleteBookingCommand deleteCommand,
            CancellationToken cancellationToken)
        {
            return await this.bookingRepository.DeleteBookingAsync(deleteCommand.Id, cancellationToken);
        }

        public async Task<List<BookingDto>> GetAllBookingsAsync(CancellationToken cancellationToken)
        {
            var savedBookings = await this.bookingRepository.GetAllBookingsAsync(cancellationToken);

            //return savedBookings.Select(booking => this.bookingConverter.GetDto(booking)).ToList();
            var bookingsDto = new List<BookingDto>();

            foreach (var savedBooking in savedBookings)
            {
                var dto = this.bookingConverter.GetDto(savedBooking);
                bookingsDto.Add(dto);
            }

            return bookingsDto;
        }

        public async Task<BookingDto> UpdateBookingAsync(
            UpdateBookingCommand updateCommand,
            CancellationToken cancellationToken)
        {
            var inputModel = new Booking(
                updateCommand.Id,
                updateCommand.DepartureStation,
                updateCommand.ArrivalStation,
                updateCommand.Name,
                updateCommand.Surname);

            var updatedModel = await this.bookingRepository.UpdateBookingAsync(inputModel, cancellationToken);

            return this.bookingConverter.GetDto(updatedModel);
        }
    }
}
