﻿namespace Business
{
    public class DeleteBookingCommand
    {
        public int Id { get; set; }
    }
}
