﻿using Entity;

namespace Business
{
    public interface IBookingConverter
    {
        BookingDto GetDto(Booking booking);

        Booking GetModel(BookingDto bookingDto);
    }
}
