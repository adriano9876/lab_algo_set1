﻿namespace Business
{
    public class UpdateBookingCommand
    {
        public int Id { get; set; }

        public string DepartureStation { get; set; }

        public string ArrivalStation { get; set; }

        public string Name { get; set; }

        public string Surname { get; set; }
    }
}