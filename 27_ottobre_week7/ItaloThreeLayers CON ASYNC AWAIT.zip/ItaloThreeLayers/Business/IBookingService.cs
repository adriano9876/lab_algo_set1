﻿namespace Business
{
    public interface IBookingService
    {
        Task<BookingDto> CreateBookingAsync(CreateBookingCommand command, CancellationToken cancellationToken);

        Task<bool> DeleteBookingAsync(DeleteBookingCommand deleteCommand, CancellationToken cancellationToken);

        Task<List<BookingDto>> GetAllBookingsAsync(CancellationToken cancellationToken);

        Task<BookingDto> UpdateBookingAsync(UpdateBookingCommand updateCommand, CancellationToken cancellationToken);
    }
}
