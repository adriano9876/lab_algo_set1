﻿namespace Business
{
    public class CreateBookingCommand
    {
        public string DepartureStation { get; set; }

        public string ArrivalStation { get; set; }

        public string Name { get; set; }

        public string Surname { get; set; }
    }
}
