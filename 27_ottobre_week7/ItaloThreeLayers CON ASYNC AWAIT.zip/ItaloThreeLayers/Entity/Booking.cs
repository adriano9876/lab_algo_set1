﻿namespace Entity
{
    public class Booking
    {
        public Booking(
            int id,
            string departureStation,
            string arrivalStation,
            string name,
            string surname)
        {
            Id = id;
            DepartureStation = departureStation;
            ArrivalStation = arrivalStation;
            Name = name;
            Surname = surname;
        }

        public int Id { get; set; }

        public string DepartureStation { get; set; }

        public string ArrivalStation { get; set; }

        public string Name { get; set; }

        public string Surname { get; set; }
    }
}
