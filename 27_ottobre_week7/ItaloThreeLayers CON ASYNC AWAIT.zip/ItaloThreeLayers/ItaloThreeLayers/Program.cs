﻿using Business;
using DataAccess;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Presentation;

namespace ItaloThreeLayers
{
    public static class Program
    {
        public static async Task Main()
        {
            var applicationBuilder = Host.CreateApplicationBuilder();
            applicationBuilder.Services.AddSingleton<IBookingJsonRepository, BookingJsonRepository>();
            applicationBuilder.Services.AddTransient<IBookingConverter, BookingConverter>();
            applicationBuilder.Services.AddTransient<IBookingService, BookingService>();
            applicationBuilder.Services.AddTransient<IConsoleView, ConsoleView>();

            using var host = applicationBuilder.Build();
            using IServiceScope serviceScope = host.Services.CreateScope();

            var consoleView = serviceScope.ServiceProvider.GetService<IConsoleView>();
            if (consoleView != null)
            {
                await consoleView.ShowMenuAsync();
            }
        }
    }
}