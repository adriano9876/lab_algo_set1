﻿using Business;

namespace Presentation
{
    public class ConsoleView : IConsoleView
    {
        private readonly IBookingService bookingService;

        public ConsoleView(IBookingService bookingService)
        {
            if (bookingService == null)
            {
                throw new ArgumentNullException(nameof(bookingService), "No service found");
            }

            this.bookingService = bookingService;
        }

        public async Task ShowMenuAsync()
        {
            var exit = false;
            try
            {
                do
                {
                    Console.WriteLine("=================== Menu ===================");
                    Console.WriteLine("0) Exit");
                    Console.WriteLine("1) Create booking");
                    Console.WriteLine("2) Get all bookings");
                    Console.WriteLine("3) Update booking by id");
                    Console.WriteLine("4) Delete booking by id");

                    var chosenFunctionality = Console.ReadLine();
                    switch (chosenFunctionality)
                    {
                        case "0":
                            exit = true;
                            break;
                        case "1":
                            await DoCreateFlowAsync();
                            break;
                        case "2":
                            await DoGetFlowAsync();
                            break;
                        case "3":
                            await DoUpdateFlowAsync();
                            break;
                        case "4":
                            await DoDeleteFlowAsync();
                            break;
                        default:
                            Console.WriteLine("Invalid choice");
                            break;
                    }

                } while (!exit);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            Environment.Exit(0);
        }

        private static (string departure, string arrival, string name, string surname) GetSaveParameters()
        {
            Console.Write("Insert departure station: ");
            var departure = Console.ReadLine();

            Console.Write("Insert arrival station: ");
            var arrival = Console.ReadLine();

            Console.Write("Insert passenger name: ");
            var name = Console.ReadLine();

            Console.Write("Insert passenger surname: ");
            var surname = Console.ReadLine();

            return (departure, arrival, name, surname);
        }

        private async Task DoDeleteFlowAsync()
        {
            Console.Write("Specify booking id: ");
            if (!int.TryParse(Console.ReadLine(), out var id) && id > 0)
            {
                Console.WriteLine("Invalid id");
                return;
            }

            var isSucceeded = await this.bookingService.DeleteBookingAsync(
                new DeleteBookingCommand { Id = id },
                CancellationToken.None);

            Console.WriteLine(
                isSucceeded
                    ? "Deleted successfully"
                    : "Error while deleting the booking");
        }

        private async Task DoUpdateFlowAsync()
        {
            Console.Write("Specify booking id: ");
            if (!int.TryParse(Console.ReadLine(), out var id) && id > 0)
            {
                Console.WriteLine("Invalid id");
                return;
            }

            var (departure, arrival, name, surname) = GetSaveParameters();
            var updateCommand = new UpdateBookingCommand
            {
                Id = id,
                DepartureStation = departure,
                ArrivalStation = arrival,
                Name = name,
                Surname = surname
            };

            var updatedDto = await this.bookingService.UpdateBookingAsync(updateCommand, CancellationToken.None);
            this.ShowDto(updatedDto);
        }

        private async Task DoGetFlowAsync()
        {
            var dtoList = await this.bookingService.GetAllBookingsAsync(CancellationToken.None);
            if (dtoList == null || dtoList.Count == 0)
            {
                Console.WriteLine("No bookings found");
            }

            foreach (var dto in dtoList)
            {
                this.ShowDto(dto);
            }
        }

        private async Task DoCreateFlowAsync()
        {
            var (departure, arrival, name, surname) = GetSaveParameters();
            var command = new CreateBookingCommand
            {
                DepartureStation = departure,
                ArrivalStation = arrival,
                Name = name,
                Surname = surname
            };

            var createdBookingDto = await this.bookingService.CreateBookingAsync(
                command,
                CancellationToken.None);

            if (createdBookingDto == null)
            {
                Console.WriteLine("Error while saving the booking");
                return;
            }

            Console.WriteLine("Booking saved successfully:");
            this.ShowDto(createdBookingDto);
        }

        private void ShowDto(BookingDto dto)
        {
            Console.WriteLine($"{dto.Id}) {dto.DepartureStation} - {dto.ArrivalStation} for {dto.Surname} {dto.Name}");
        }
    }
}
