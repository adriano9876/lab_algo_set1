﻿namespace Presentation
{
    public interface IConsoleView
    {
        Task ShowMenuAsync();
    }
}
