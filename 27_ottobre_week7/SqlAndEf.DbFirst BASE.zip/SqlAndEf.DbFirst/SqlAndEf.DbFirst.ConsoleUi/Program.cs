﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using SqlAndEf.DbFirst.BusinessLogic.Services;
using SqlAndEf.DbFirst.BusinessLogic.Services.Impl;
using SqlAndEf.DbFirst.ConsoleUi.Commands;

namespace SqlAndEf.DbFirst.ConsoleUi;

internal class Program
{
    static async Task Main(string[] args)
    {
        var host = Host.CreateDefaultBuilder(args)
            .ConfigureServices((context, services) =>
            {
                // Register DbContext
                //string connectionString = "";

                // Register Application Services
                services.AddScoped<ICustomerService, CustomerService>();
                services.AddScoped<IVesselService, VesselService>();
                services.AddScoped<IBookingService, BookingService>();
                services.AddScoped<IShipmentService, ShipmentService>();

                // Register Commands for Console App
                services.AddSingleton<ICommand, AddCustomerCommand>();
                services.AddSingleton<ICommand, CompleteShipmentCommand>();
                services.AddSingleton<ICommand, CreateBookingCommand>();
                services.AddSingleton<ICommand, CreateShipmentCommand>();
                services.AddSingleton<ICommand, ShowAllBookingsCommand>();
                services.AddSingleton<ICommand, ShowAllCustomersCommand>();
                services.AddSingleton<ICommand, ShowAllShipmentsCommand>();
                services.AddSingleton<ICommand, ShowAllVesselsCommand>();
                services.AddSingleton<ICommand, ShowPendingBookingsCommand>();

                // Register main App
                services.AddSingleton<App>();
            })
            .Build();

        // Execute application
        var app = host.Services.GetRequiredService<App>();
        await app.RunAsync();
    }
}
