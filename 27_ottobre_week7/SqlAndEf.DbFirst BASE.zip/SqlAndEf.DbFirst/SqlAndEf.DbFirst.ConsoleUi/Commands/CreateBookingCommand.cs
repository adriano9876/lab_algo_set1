﻿using SqlAndEf.DbFirst.BusinessLogic.Models;
using SqlAndEf.DbFirst.BusinessLogic.Services;
using SqlAndEf.DbFirst.ConsoleUi.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlAndEf.DbFirst.ConsoleUi.Commands;

public class CreateBookingCommand : ICommand
{
    private readonly IBookingService _bookingService;
    private readonly ICustomerService _customerService;

    public string DisplayName => "Create New Booking";
    public string Shortcut => "CNB";

    public CreateBookingCommand(IBookingService bookingService, ICustomerService customerService)
    {
        _bookingService = bookingService;
        _customerService = customerService;
    }

    public async Task Execute()
    {
        ConsoleTableHelper.PrintHeader("CREATE NEW BOOKING");

        // Mostra clienti disponibili
        var customers = await _customerService.GetAllCustomersAsync();
        if (customers.Count == 0)
        {
            ConsoleErrorHelper.Print("No customers available. Please add a customer first.");
            return;
        }

        Console.WriteLine("Available customers:");
        foreach (var c in customers)
        {
            Console.WriteLine($"  [{c.CustomerId}] {c.CompanyName}");
        }
        Console.WriteLine();

        var customerId = ConsoleInputHelper.ReadInt("Customer ID", min: 1);

        // TODO: data validation

        var departurePort = ConsoleInputHelper.ReadString("Departure Port", required: true);
        var arrivalPort = ConsoleInputHelper.ReadString("Arrival Port", required: true);
        var notes = ConsoleInputHelper.ReadString("Notes (optional)", required: false);

        try
        {
            // TODO: Create new booking
            var booking = new BookingDto();

            ConsoleTableHelper.PrintSuccess($"Booking #{booking.BookingId} created successfully!");
            ConsoleCardHelper.PrintBookingCard(booking);
        }
        catch (Exception ex)
        {
            ConsoleErrorHelper.Print($"Failed to create booking: {ex.Message}");
        }
    }
}
