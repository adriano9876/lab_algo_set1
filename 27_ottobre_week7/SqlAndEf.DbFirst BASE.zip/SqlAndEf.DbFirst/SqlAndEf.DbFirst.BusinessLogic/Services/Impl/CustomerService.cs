﻿using SqlAndEf.DbFirst.BusinessLogic.Models;

namespace SqlAndEf.DbFirst.BusinessLogic.Services.Impl;

public class CustomerService : ICustomerService
{
    public Task<List<CustomerDto>> GetAllCustomersAsync()
    {
        List<CustomerDto> result = [
            new()
            {
                CustomerId = 1,
                CompanyName = "Company 1",
                Email = "company.one@mail.com",
                Phone = "+39 011 234 5678",
                Address = "via Compagnia 1",
                CreatedDate = DateTime.Parse("2025-04-07 09:00"),
            },
            new()
            {
                CustomerId = 2,
                CompanyName = "Company 2",
                Email = "company.two@mail.com",
                Phone = "+39 012 345 6789",
                Address = "via Compagnia 2/B",
                CreatedDate = DateTime.Parse("2025-07-07 18:00")
            },
            ];
        return Task.FromResult(result);
    }
}
