﻿using SqlAndEf.DbFirst.BusinessLogic.Models;

namespace SqlAndEf.DbFirst.BusinessLogic.Services.Impl;

public class BookingService : IBookingService
{
    public Task<List<BookingDto>> GetAllBookingsAsync()
    {
        return Task.FromResult(new List<BookingDto>
        {
            new()
            {
                BookingId = 1,
                CustomerId = 1,
                BookingDate = DateTime.Now,
                CustomerName = "Company 1",
                Status = "Pending",
                DeparturePort = "Caracas",
                ArrivalPort = "Genoa",
                HasShipment = true,
            },
            new()
            {
                BookingId = 2,
                CustomerId = 2,
                BookingDate = DateTime.Now,
                CustomerName = "Company B",
                Status = "Pending",
                DeparturePort = "Helsinki",
                ArrivalPort = "Antwerp",
                HasShipment = false,
            }
        });
    }

    public Task<List<BookingDto>> GetPendingBookingsAsync()
    {
        return Task.FromResult(new List<BookingDto>());
    }
}
