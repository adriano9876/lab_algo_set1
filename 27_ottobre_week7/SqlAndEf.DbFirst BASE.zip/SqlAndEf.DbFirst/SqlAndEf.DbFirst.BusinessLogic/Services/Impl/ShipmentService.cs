﻿using SqlAndEf.DbFirst.BusinessLogic.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlAndEf.DbFirst.BusinessLogic.Services.Impl;

public class ShipmentService : IShipmentService
{
    public Task<List<ShipmentDto>> GetAllShipmentsAsync()
    {
        return Task.FromResult(new List<ShipmentDto>()
        {
            new()
            {
                ShipmentId = 1,
                BookingId = 1,
                DepartureDate = DateTime.Now,
                ArrivalDate = DateTime.Now,
                CargoWeight = 20,
                CustomerName = "Company One",
                ShippingCost = 350_000,
                VesselId = 1,
                VesselName = "Vessel 1"
            }
        });
    }
}
