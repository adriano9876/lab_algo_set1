﻿using SqlAndEf.DbFirst.BusinessLogic.Models;

namespace SqlAndEf.DbFirst.BusinessLogic.Services.Impl;

public class VesselService : IVesselService
{
    public Task<List<VesselDto>> GetAllVesselsAsync()
    {
        return Task.FromResult(
            new List<VesselDto>
            {
                new()
                {
                    VesselId = 1,
                    VesselName = "Name 1",
                    Capacity = 100,
                    CurrentLoad = 50,
                    TotalShipments = 23,
                    YearBuilt = 1967
                },
                new()
                {
                    VesselId = 2,
                    VesselName = "Name 2",
                    Capacity = 1000,
                    CurrentLoad = 750,
                    TotalShipments = 22,
                    YearBuilt = 1969
                }
            });
    }

    public Task<VesselDto> GetVesselByIdAsync(int vesselId)
    {
        return Task.FromResult(new VesselDto { VesselId = vesselId });
    }
}
