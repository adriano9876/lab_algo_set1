﻿
using SqlAndEf.DbFirst.BusinessLogic.Models;

namespace SqlAndEf.DbFirst.BusinessLogic.Services;

public interface IBookingService
{
    Task<List<BookingDto>> GetAllBookingsAsync();
    Task<List<BookingDto>> GetPendingBookingsAsync();
}
