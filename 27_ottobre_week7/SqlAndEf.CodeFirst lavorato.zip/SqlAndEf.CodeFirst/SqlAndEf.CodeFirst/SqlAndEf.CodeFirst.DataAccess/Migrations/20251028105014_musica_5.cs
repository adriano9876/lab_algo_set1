﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SqlAndEf.CodeFirst.DataAccess.Migrations
{
    /// <inheritdoc />
    public partial class musica_5 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
