﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlAndEf.CodeFirst.DataAccess.Models
{
    public class Track
    {
        public int TrackId { get; set; }
        public string Title { get; set; }
        public int DurationSecond { get; set; }
        
        /* collegamenti */
        public int GenreId { get; set; }
        public Genre Genre { get; set; }


        public int AlbumId { get; set; }
        public Album Album { get; set; }

        public IEnumerable<Artist> Artists { get; set; }// = new List<Artist>();



    }
}
