﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlAndEf.CodeFirst.DataAccess.Models
{
    public class Artist
    {
        public int ArtistId { get; set; }
        public string Name { get; set; }
        public string Country { get; set; }

        public IEnumerable<Track> Tracks { get; set; }//= new List<Track>();



    }

}
