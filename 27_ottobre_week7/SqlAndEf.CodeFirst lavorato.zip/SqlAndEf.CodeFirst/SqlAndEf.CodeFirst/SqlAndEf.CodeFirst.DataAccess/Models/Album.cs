﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlAndEf.CodeFirst.DataAccess.Models
{
    public class Album
    {
        public int AlbumId { get; set; }
        public string Title { get; set; }
        public DateOnly ReleaseYear { get; set; }

        public IEnumerable<Track> Tracks { get; set; }


    }
}
