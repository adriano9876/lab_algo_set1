﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlAndEf.CodeFirst.DataAccess.Models
{
    public class MusicContext : DbContext
    {
        public MusicContext() { }
        public MusicContext(DbContextOptions<MusicContext> options)
        : base(options)
        {
        }

        public virtual DbSet<Album> Albums { get; set; }
        public virtual DbSet<Artist> Artists { get; set; }
        public virtual DbSet<Genre> Genres { get; set; }
        public virtual DbSet<Track> Tracks { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            modelBuilder.Entity<Genre>()
                .HasMany(t => t.Tracks)
                .WithOne(g => g.Genre)
                .HasForeignKey(g => g.GenreId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Album>()
                .HasMany(t => t.Tracks)
                .WithOne(a => a.Album )
                .HasForeignKey(t => t.AlbumId )
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Artist>()
                .HasMany(t => t.Tracks)
                .WithMany(a => a.Artists)
                .UsingEntity("TrackAutors", m =>
                {
                    m.IndexerProperty<int>("Id");
                    m.HasKey("Id");
                });



            //modelBuilder.Entity<Comment>(entity =>
            //{
            //    entity.ToTable("Comment");

            //    entity.HasOne(d => d.Prodotto).WithMany(p => p.Comments)
            //        .HasForeignKey(d => d.ProdottoId)
            //        .OnDelete(DeleteBehavior.ClientSetNull)
            //        .HasConstraintName("FK_Comment_Product");
            //});

            //modelBuilder.Entity<Product>(entity =>
            //{
            //    entity.HasKey(e => e.Id).HasName("PK__Product__3214EC079A6F9D46");

            //    entity.ToTable("Product");

            //    entity.Property(e => e.Name).HasMaxLength(255);
            //    entity.Property(e => e.Price).HasColumnType("decimal(10, 2)");

            //    entity.HasOne(d => d.Warehouse).WithMany(p => p.Products).HasForeignKey(d => d.WarehouseId);
            //});

            //modelBuilder.Entity<Warehouse>(entity =>
            //{
            //    entity.HasKey(e => e.Id).HasName("PK__Warehous__3214EC079D477CC3");

            //    entity.ToTable("Warehouse");

            //    entity.Property(e => e.Location).HasMaxLength(100);
            //});

            //OnModelCreatingPartial(modelBuilder);
        }


    }




}
