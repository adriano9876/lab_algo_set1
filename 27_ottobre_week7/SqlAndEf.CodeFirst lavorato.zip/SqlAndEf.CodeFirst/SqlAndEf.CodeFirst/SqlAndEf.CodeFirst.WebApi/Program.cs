
using Microsoft.EntityFrameworkCore;
using SqlAndEf.CodeFirst.BusinessLogic.Services;
using SqlAndEf.CodeFirst.BusinessLogic.Services.Impl;
using SqlAndEf.CodeFirst.DataAccess.Models;

namespace SqlAndEf.CodeFirst.WebApi
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);
           
            // Add services to the container.

            builder.Services.AddControllers();
            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

            builder.Services.AddDbContext<MusicContext>
            (options => options.UseSqlServer(builder.Configuration
            .GetConnectionString("DefaultConnection")));
            /* aggiungo al builder i service */
            builder.Services.AddTransient<IAlbumService, AlbumService>();
            builder.Services.AddTransient<IArtistService, ArtistService >();
            builder.Services.AddTransient<IGenreService, GenreService>();
            builder.Services.AddTransient<ITrackAuthorService, TrackAuthorService>();
            builder.Services.AddTransient<ITrackService, TrackService>();

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseHttpsRedirection();
            app.UseAuthorization();
            app.MapControllers();
            app.Run();
        }
    }
}
