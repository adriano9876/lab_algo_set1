using Microsoft.EntityFrameworkCore;
using SqlAndEf.CodeFirst.BusinessLogic.Models;
using SqlAndEf.CodeFirst.DataAccess.Models;

namespace SqlAndEf.CodeFirst.BusinessLogic.Services.Impl;

public class GenreService : IGenreService
{
    // TODO: Implementare i metodi usando Entity Framework Core
    private readonly MusicContext _context;

    public GenreService(MusicContext context)
    {
        _context = context;
    }


 
    public async Task<List<GenreDto>> GetAllGenresAsync()
    {
        var genres = _context.Genres.AsNoTracking().Select(v => new GenreDto
        {
            GenreId = v.GenreId,
            Name = v.Name,
            TracksCount = 0
        });
        return genres.ToList();

    }

    public async Task<GenreDto> GetGenreByIdAsync(int id)   {
    
        var genre = await _context.Genres
            .AsNoTracking()
            //.Include(a => a.Tracks)
            .Select(a => new GenreDto
            {
               GenreId = a.GenreId,
               Name = a.Name,
               TracksCount = 111
            }).FirstOrDefaultAsync(x => x.GenreId == id);

        return genre;
    
    }

    public async Task<GenreDto> CreateGenreAsync(GenreDto genre)
    {
        Genre entity = new()
        {
           Name = genre.Name,
        };

        var c = _context.Genres.Add(entity);
        await _context.SaveChangesAsync();
        var t = new GenreDto
        {
            GenreId= genre.GenreId,
            Name = genre.Name,
        };
        return t;

    
    }

    public async Task<GenreDto> UpdateGenreAsync(int id, GenreDto genre)
    {
        var mod = await _context.Genres.FindAsync(id);
        if (mod != null)
        {
            mod.Name = genre.Name;
            _context.Genres.Update(mod);
            await _context.SaveChangesAsync();            
        }
        GenreDto ret = new GenreDto()
        {
            GenreId = mod.GenreId,
            Name = mod.Name,
            TracksCount = 0
        };
        return ret;
    }

    public async Task<bool> DeleteGenreAsync(int id)
    {
        var delete = await _context.Genres.FindAsync(id);
        if(delete != null)
        {
            _context.Genres.Remove(delete);
            await _context.SaveChangesAsync();
            return true;
        }
        return false;
    }
}
