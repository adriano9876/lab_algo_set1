﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlAndEf.ExamProject.DataAccess.Models
{
    public class Teacher
    {
        public int TeacherId { get; set; }
        public string Lastname { get; set; }
        public string Specialization { get; set; }
        public DateOnly HireDate { get; set; }
        public List<Course> Courses { get; set; }
    }
}
