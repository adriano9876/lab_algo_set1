﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlAndEf.ExamProject.DataAccess.Models
{
    public class Student
    {
        public int StudentId { get; set; }
        public string Lastname { get; set; }
        public string RegistrationNumber { get; set; }
        public DateOnly RegistrationDate { get; set; }
        public char Gender {get;set;}
        public List<Course> Courses { get; set; }
    }
}
