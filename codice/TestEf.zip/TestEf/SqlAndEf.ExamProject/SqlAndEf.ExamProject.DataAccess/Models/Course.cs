﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlAndEf.ExamProject.DataAccess.Models
{
    public  class Course
    {
        public int CourseId { get; set; }
        public string Name { get; set; }
        public int Cfu { get; set; }
        public int TotalHours { get; set; }
        public int TeacherId { get; set; }
        public Teacher Teacher { get; set; }
        public List<Student> Students { get; set; }
    }
}
