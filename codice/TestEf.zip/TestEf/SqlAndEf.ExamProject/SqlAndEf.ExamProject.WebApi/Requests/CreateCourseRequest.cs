﻿namespace SqlAndEf.ExamProject.WebApi.Requests
{
    public class CreateCourseRequest
    {
        public string Name { get; set; }
        public int Cfu { get; set; }
        public int TotalHours { get; set; }
        public int TeacherId { get; set; }
    }
}
