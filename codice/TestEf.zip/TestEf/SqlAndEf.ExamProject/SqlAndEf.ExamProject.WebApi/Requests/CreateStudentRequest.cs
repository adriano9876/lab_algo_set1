﻿namespace SqlAndEf.ExamProject.WebApi.Requests
{
    public class CreateStudentRequest
    {        
        public string Lastname { get; set; }
        public string RegistrationNumber { get; set; }
        public DateOnly RegistrationDate { get; set; }
        public char Gender { get; set; }
    }
}
