﻿using SqlAndEf.ExamProject.DataAccess.Models;

namespace SqlAndEf.ExamProject.WebApi.Responses
{
    public class StudentResponse
    {
        public int StudentId { get; set; }
        public string Lastname { get; set; }
        public string RegistrationNumber { get; set; }
        public DateOnly RegistrationDate { get; set; }
        public char Gender { get; set; }
        public int TotalCfu {get;set;}
        public List<string> Courses { get; set; }
    }
}
