﻿namespace SqlAndEf.ExamProject.WebApi.Responses
{
    public class CourseResponse
    {
        public string Name { get; set; }
        public int Cfu { get; set; }
        public int TotalHours { get; set; }

        
    }
}

