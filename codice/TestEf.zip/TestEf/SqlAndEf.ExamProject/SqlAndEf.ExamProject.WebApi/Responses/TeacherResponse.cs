﻿using SqlAndEf.ExamProject.DataAccess.Models;

namespace SqlAndEf.ExamProject.WebApi.Responses
{
    public class TeacherResponse
    {
        public string Lastname { get; set; }
        public string Specialization { get; set; }
        public DateOnly HireDate { get; set; }
        public int TotalCourses { get; set; }
        public List<string> Courses { get; set; }
    }
}
