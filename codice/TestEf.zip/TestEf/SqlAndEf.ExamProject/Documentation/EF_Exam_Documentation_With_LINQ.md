# Entity Framework - Test Documentation

## LINQ Quick Reference

| Metodo | Descrizione breve |
|---------|------------------|
| Select | Proiezione |
| SelectMany | Proiezione multipla |
| Where | Filtro |
| All | Tutti soddisfano |
| Any | Almeno uno |
| Contains | Contiene elemento |
| Concat | Unisce sequenze |
| Distinct | Rimuove duplicati |
| OrderBy | Ordine crescente |
| Average | Media valori |
| Count | Conta elementi |
| Max | Valore massimo |
| Min | Valore minimo |
| Sum | Somma valori |
| Skip | Salta N elementi |
| Take | Prendi N elementi |
