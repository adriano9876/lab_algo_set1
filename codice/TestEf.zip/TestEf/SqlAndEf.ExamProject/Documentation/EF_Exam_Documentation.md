# Entity Framework - Test Documentation

## Connection String
```json
"ConnectionStrings": {
  "DefaultConnection": "Data Source=HQAPEW1C966-AAX;Database=MyDatabase;TrustServerCertificate=True;Id=sa;Password=SQL2019"
}
```

## Program Configuration
```csharp
public static void Main(string[] args)
{
    // [..] Application builder initialization

    string connectionString = builder.Configuration.GetConnectionString("DefaultConnection");

    builder.Services.AddDbContext<MyDbContext>(options =>
        options.UseSqlServer(connectionString));
}
```

## DbContext Template
```csharp
public class MyDbContext : DbContext
{
    public MyDbContext(DbContextOptions<MyDbContext> options) : base(options)
    {
    }

    // […] DbSets declaration

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        // […] Entity relationships declaration
    }
}
```

## Example: N–N Relationship Template
```csharp
modelBuilder.Entity<***>()
    .HasMany(a => ***)
    .WithMany(t => ***)
    .UsingEntity(***,
        ta => ta.HasOne(***)
            .WithMany()
            .HasForeignKey(***)
            .IsRequired()
            .HasPrincipalKey(***)
            .OnDelete(***),
        ta => ta.HasOne(***)
            .WithMany()
            .HasForeignKey(***)
            .IsRequired()
            .HasPrincipalKey(***)
            .OnDelete(***),
        ta =>
        {
            ta.IndexerProperty<***>(***);
            ta.HasKey(***);
        });
```

---

Nota: Tutti i campi contrassegnati con `***` devono essere completati secondo le entità e le relazioni del proprio modello EF.
