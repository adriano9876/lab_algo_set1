﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataGridExample.Models
{
    public class Person
    {
        public string Name { get; set; }
        public string Lastname { get; set; }
        public int Age { get; set; }
        public bool CanSwim { get; set; }
        public Licence Licence { get; set; }
        public Pet Pet { get; set; }
    }

    public enum Licence
    {
        Car,
        Bike,
        Boat,
        Horse,
        None,
    }
}
