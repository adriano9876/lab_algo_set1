﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace DataGridExample.ViewModels
{
    public class MainViewModel: INotifyPropertyChanged
    {
        public PersonViewModel PersonViewModel { get; set; }
        public event PropertyChangedEventHandler? PropertyChanged;

        public MainViewModel()
        {
            PersonViewModel = new PersonViewModel();
            
        }
        protected virtual void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
