﻿using DataGridExample.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;

namespace DataGridExample.ViewModels
{
    public class PersonViewModel : INotifyPropertyChanged
    {
        private readonly CollectionViewSource _viewSource;
        public ObservableCollection<Person> Persons { get; set; }
        public event PropertyChangedEventHandler? PropertyChanged;
        
        private string _textSearch;
        public PersonViewModel()
        {
            Persons = new ObservableCollection<Person>
            {
                new Person
                {
                    Name="Bianca",                   
                    Lastname="Rossi",
                    Age=20,
                    CanSwim=true,
                    Licence=Models.Licence.Car,
                    Pet=new Pet{Name="Pietro",Type="Pietra"}
                },
                new Person
                {
                    Name="Giulio",
                    Lastname="ehhhhhhh Pappalardo",
                    Age=29,
                    CanSwim=true,
                    Licence=Models.Licence.Boat,
                    Pet=null
                },
                new Person
                {
                    Name="Marco",
                    Lastname="Stringa",
                    Age=34,
                    CanSwim=false,
                    Licence=Models.Licence.Horse,
                    Pet= new Pet{Name="Giorgio",Type="Cavallo"}
                },
            };
            
            _viewSource = new CollectionViewSource();
            _viewSource.Source = Persons;
            _viewSource.View.Refresh();
            _viewSource.View.Filter += Filter;
            
        }
        public ICollectionView View
        {
            get => _viewSource?.View; 
        }
        public string TextSearch
        {
            get { return _textSearch; }
            set
            {
                if(_textSearch!=value)
                {
                    _textSearch = value;                   
                    OnPropertyChanged(nameof(TextSearch));
                    _viewSource.View.Refresh();
                    
                }
            }
        }

        public bool Filter(object obj)
        {
            if(obj is Person item)
            {
                return string.IsNullOrEmpty(TextSearch)
                    || item.Name.Contains(TextSearch, StringComparison.OrdinalIgnoreCase)
                    || item.Lastname.Contains(TextSearch,StringComparison.OrdinalIgnoreCase);
            }
            return true;
        }

        
        protected virtual void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
