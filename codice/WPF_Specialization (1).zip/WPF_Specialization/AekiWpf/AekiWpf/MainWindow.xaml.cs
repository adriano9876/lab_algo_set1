﻿using System.Globalization;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AekiWpf;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{
    private bool darkMode = false;
    
    public MainWindow()
    {
        //Thread.CurrentThread.CurrentUICulture = new CultureInfo("it-IT");
        InitializeComponent();
    }

    private void DarkModeButton_Click(object sender, RoutedEventArgs e)
    {
        darkMode = !darkMode;
        this.Resources["LabelBack"] = darkMode ? new SolidColorBrush(Colors.Black) : new SolidColorBrush(Colors.White);
        this.DarkModeButton.Content = darkMode ? "Light Mode" : "Dark Mode";
    }

    private void LanguageButton_Click(object sender, RoutedEventArgs e)
    {
        Thread.CurrentThread.CurrentUICulture = Thread.CurrentThread.CurrentUICulture.ToString().Contains("en") ? new CultureInfo("it") : new CultureInfo("en");       
        var window = new MainWindow
        {
            Left=this.Left,
            Height=this.Height,
            Top=this.Top,
            Width=this.Width

        };       
        Application.Current.MainWindow = window;
        window.Show();
        this.Close();
        
        
            

    }


    private void Label_MouseEnter(object sender, MouseEventArgs e)
    {
        var label = (Label)sender;
        label.Background = new SolidColorBrush(Colors.Wheat);
    }

    private void Label_MouseLeave(object sender, MouseEventArgs e)
    {
        var label = (Label)sender;
        //label.Style = (Style)this.Resources["LabelStyle"];
        label.Background = (SolidColorBrush)this.Resources["LabelBack"];
        
    }
}