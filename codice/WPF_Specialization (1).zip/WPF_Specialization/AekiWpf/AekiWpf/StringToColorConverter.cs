﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;
using System.Windows.Media;

namespace AekiWpf
{
    public class StringToColorConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var text = value as string;
            if(text==null)
            {
                return new SolidColorBrush(Colors.LightBlue);
            }
            if(text.ToLower()=="black")
            {
                return new SolidColorBrush(Colors.White);
            }
            if(text.ToLower() == "white")
            {
                return new SolidColorBrush(Colors.Gray);
            }
            if (text.ToLower() == "gray")
            {
                return new SolidColorBrush(Colors.Peru);
            }
            if (text.ToLower() == "blue")
            {
                return new SolidColorBrush(Colors.Pink);
            }
            if (text.ToLower() == "yellow")
            {
                return new SolidColorBrush(Colors.Blue);
            }
            if (text.ToLower() == "orange")
            {
                return new SolidColorBrush(Colors.Cyan);
            }
            if (text.ToLower() == "red")
            {
                return new SolidColorBrush(Colors.Green);
            }
            if (text.ToLower() == "green")
            {
                return new SolidColorBrush(Colors.Black);
            }
            if (text.Length<5)
            {
                return new SolidColorBrush(Colors.AliceBlue);
            }
            if(text.Length<10)
            {
                return new SolidColorBrush(Colors.LightYellow);
            }
            return new SolidColorBrush(Colors.Orange);
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
