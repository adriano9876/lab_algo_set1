﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StyleExample
{
    public class Person
    { 
        public int Id { get; set; }
        public string Name { get; set; }
        public string Lastname { get; set; }
        public List<int> Scores { get; set; }
        
        public double Avarage
        {
            get { return Math.Round(Scores.Average(),2); }
        }
    }
}
