﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace StyleExample;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }

    private void Button_Click(object sender, RoutedEventArgs e)
    {
        List<Person> list = new List<Person>();
        list.Add(new Person { Id = 1, Name = "Anna", Lastname = "Anni" ,Scores=new List<int> { 9,4,7,8,8} });
        list.Add(new Person { Id = 2, Name = "Giulio", Lastname = "Giuli", Scores = new List<int> { 4, 7,10,10,6,6,9} });
        list.Add(new Person { Id = 3, Name = "Marco", Lastname = "Marchi", Scores = new List<int> { 6, 7, 9, 8, 8 } });
        this.PersonList.ItemsSource = list;
    }
}