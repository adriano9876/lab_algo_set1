﻿using Newtonsoft.Json;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;


namespace KleshRoialWpf
{
    public class User
    {
        private readonly string _path = "C:\\Users\\e-duccio.tarno\\Desktop\\git-academy7\\MSC-Academy-Dev-7\\Weeks11_and_12_Specializations\\WPF_Specialization\\KleshRoialWpf\\KleshRoialWpf\\User.json";
        public string Username { get; set; }
        public int Money { get; set; }
        public int Gems { get; set; }
        public int Level { get; set; }
        public List<TupleCardInt> Collection { get; set; } = new List<TupleCardInt>();
        public void Initialize()
        {
            if(File.Exists(_path))
            {

                //var user = JsonSerializer.Deserialize<User>(File.ReadAllText(_path));
                var user = JsonConvert.DeserializeObject<User>(File.ReadAllText(_path));
                Money = user.Money;
                Gems = user.Gems;
                Level = user.Level;
                Username = user.Username;
                Collection = user.Collection;
            }
            else
            {
                Money = 1000;
                Gems = 0;
                Level = 1;
                Username = "User1234";
                Collection = new List<TupleCardInt>();
                SaveUser();
                
            }
        }

        public void SaveUser()
        {
            //var options = new JsonSerializerOptions { WriteIndented = true, DictionaryKeyPolicy=null };
            var json =JsonConvert.SerializeObject(this,Formatting.Indented);
            //var json = JsonSerializer.Serialize<User>(this,options);
            File.WriteAllText(_path, json);
        }
    }
}
