﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KleshRoialWpf
{
    public class Unit
    {
        public string Name { get; set; }
        public int Row { get; set; }
        public int Column { get; set; }
        public int Z { get; set; }
    }
}
