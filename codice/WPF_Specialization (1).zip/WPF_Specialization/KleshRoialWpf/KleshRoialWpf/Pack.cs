﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace KleshRoialWpf
{
    class Pack
    {
        public object Name { get; set; }
        public int Cost { get; set; }
        public List<Card> Cards { get; set; }

        public override string ToString()
        {             

                StringBuilder res = new StringBuilder("Content of the pack:\n");

                Cards.ForEach(card => res.Append(card.ToString()).Append("\n"));

                return res.ToString();
            
        }
    }
}
