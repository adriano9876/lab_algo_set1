﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;
using System.Windows.Markup;
using System.Windows.Media;

namespace KleshRoialWpf
{
    class StringToColorConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if(value as string =="Comune")
            {
                return new SolidColorBrush(Colors.LightGray);
            }
            if (value as string == "Rara")
            {
                return new SolidColorBrush(Colors.Yellow);
            }
            if (value as string == "Epica")
            {
                return new SolidColorBrush(Colors.Purple);
            }
            if (value as string == "Leggendaria")
            {
                return new SolidColorBrush(Colors.OrangeRed);
            }
            return new SolidColorBrush(Colors.Black);
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
