﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KleshRoialWpf
{
    public class Tower
    {
        public int Health { get; set; }
        public int Row { get; set; }
        public int Column { get; set; }
    }
}
