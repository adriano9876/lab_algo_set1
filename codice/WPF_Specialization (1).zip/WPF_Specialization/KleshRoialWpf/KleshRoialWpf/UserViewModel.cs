﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace KleshRoialWpf
{
    class UserViewModel : INotifyPropertyChanged
    {
        private readonly string _path = "C:\\Users\\e-duccio.tarno\\Desktop\\git-academy7\\MSC-Academy-Dev-7\\Weeks11_and_12_Specializations\\WPF_Specialization\\KleshRoialWpf\\KleshRoialWpf\\Packs.json";
        private User _user;
        private List<Pack> _packs;
        private string _displayBoxText;
        private Tower _leftTower;
        private Tower _rightTower;
        private bool _gemBought;
        
        
        public Pack SelectedPack { get; set; }
        public RelayCommand PlayCommand { get; set; }
        public RelayCommand NextCommand { get; set; }
        public RelayCommand GemShopCommand { get; set; }
        public RelayCommand BuyPackCommand { get; set; }
        public RelayCommand BuyGemsCommand { get; set; }
        public RelayCommand DeployCommand { get; set; }
        public UserViewModel() 
        {
            var st = File.ReadAllText(_path);
            _packs = JsonConvert.DeserializeObject<List<Pack>>(st);
            _user = new User();
            _user.Initialize();
            _user.Collection.ForEach(x=>this.TempCollection.Add(x));
            PlayCommand = new RelayCommand((x)=>Play());
            GemShopCommand = new RelayCommand((x) => ShowGemShop());
            BuyPackCommand = new RelayCommand((x) => BuyPack());
            NextCommand = new RelayCommand((x) => NextMove());
            BuyGemsCommand = new RelayCommand((x) => BuyGems(Int32.Parse((string)x)));
            DeployCommand = new RelayCommand((x) => DeployUnit(Int32.Parse((string)x)));
            _gemBought = false;
            
            //var a=TempCollection.GroupBy(x => x.Name).ToList();                                   
        }
        public void SaveChanges()
        {
            var list = new List<TupleCardInt>();
            list.AddRange(TempCollection);
            _user.Collection = list;
            _user.SaveUser();
        }
        public void Play()
        {
            Random rng = new Random();
            Units.Clear();
            for (int i = 0; i < 4; i++)
            {
                var unit = new Unit();
                unit.Name = TempCollection.ElementAt(rng.Next(TempCollection.Count)).Card.Name;
                unit.Z = 0;
                unit.Row = 7;
                unit.Column = i < 2 ? 2 : 8;
                Units.Add(unit);

            }
            
            _leftTower=new Tower { Health = 10, Row = 2, Column = 2 };
            _rightTower = new Tower { Health = 10, Row = 2, Column = 8 };
            //Towers.Add(new Tower { Health = 20, Row = 1, Column = 5 });
            Money += 50;
            Level += 1;
            SaveChanges();
        }
        public void NextMove()
        {
            for(int i =0;i<4;i++)
            {
                var unit = Units.ElementAt(i);
                if (unit.Z!=0)
                {
                    if (unit.Row != 0)
                    {
                        
                        
                        if (unit.Row == LeftTower.Row+1)
                        {
                            var tower = unit.Column==LeftTower.Column? LeftTower:RightTower;
                            tower.Health--;
                            if(tower.Health<=0)
                            {
                                unit.Row--;
                            }
                            if(tower.Column==LeftTower.Column)
                            {
                                OnPropertyChanged(nameof(LeftTower));
                            }
                            else
                            {
                                OnPropertyChanged(nameof(RightTower));
                            }
                            
                            
                        }
                        else
                        {
                            unit.Row--;

                        }
                        
                    }
                    else
                    {
                        unit.Row = 7;
                        unit.Z = 0;
                    }
                        
                    
                }

            }
            OnPropertyChanged(nameof(Units));
        }
        public void DeployUnit(int i)
        {
            Units.ElementAt(i).Z = 4;
            OnPropertyChanged(nameof(Units));
        }

        public Tower LeftTower
        {
            get { return _leftTower; }
            set
            {
                if (_leftTower != value)
                {
                    _leftTower = value;
                    OnPropertyChanged();
                }
            }
        }
        public Tower RightTower
        {
            get { return _rightTower; }
            set
            {
                if (_rightTower != value)
                {
                    _rightTower = value;
                    OnPropertyChanged();
                }
            }
        }
        public ObservableCollection<Unit> Units
        {
            get;
            set;
        } = new ObservableCollection<Unit>();
        public void BuyGems(int gems)
        {                   
            Gems += gems;
            _gemBought = true;
        }
        public void BuyPack()
        {                       
            var rng = new Random();
            if (Gems >= SelectedPack.Cost)
            {
                Gems -= SelectedPack.Cost;
                var card = SelectedPack.Cards.ElementAt(rng.Next(SelectedPack.Cards.Count()));
                var couple = TempCollection.Where(x => x.Card.Name == card.Name).FirstOrDefault();
                if (couple == default)
                {
                    TempCollection.Add(new TupleCardInt { Card = card, Count = 1 });
                }
                else
                {
                    
                    couple.Count++;
                    OnPropertyChanged(nameof(TempCollection));
                }
                //pack.Cards.ForEach(x => user.Collection.Add(x));
                OnPropertyChanged(nameof(TempCollection));
                DisplayBoxText = $"Hai trovato {card.ToString()}";
                SaveChanges();
            }
            else
            {
                ShowGemShop();
            }
        }
        public void ShowGemShop()
        {
            var gemShop = new GemShopWindow();
            gemShop.ShowDialog();
            while (!gemShop.IsActive && !_gemBought)
            {
                gemShop = new GemShopWindow();
                MessageBox.Show("Compra Delle gemme per poter uscire");
                gemShop.ShowDialog();
            }
            _gemBought = false;
            SaveChanges();
        }
        
        
        public List<Pack> Packs
        {
            get { return _packs; }
        }
        
        public List<TupleCardInt> Collection
        {
            get { return _user.Collection; }
        }
        
        public ObservableCollection<TupleCardInt> TempCollection
        {
            get;
            set;

        } = new ObservableCollection<TupleCardInt>();
        public string DisplayBoxText
        {
            get { return _displayBoxText; }
            set
            {
                if(_displayBoxText!=value)
                {
                    _displayBoxText = value;
                    OnPropertyChanged();
                }
            }
        }
        public int Level
        {
            get { return _user.Level; }
            set
            {
                if (_user.Level != value)
                {
                    _user.Level = value;
                    OnPropertyChanged();
                }
            }
        }
        public int Money
        {
            get { return _user.Money; }
            set
            {
                if(_user.Money!=value)
                {
                    _user.Money = value;
                    OnPropertyChanged();
                }
            }
        }
        public int Gems
        {
            get { return _user.Gems; }
            set
            {
                if (_user.Gems != value)
                {
                    _user.Gems = value;
                    OnPropertyChanged();
                }
            }
        }
        public string Username
        {
            get { return _user.Username; }
            set
            {
                if (_user.Username != value)
                {
                    _user.Username = value;
                    OnPropertyChanged();
                }
            }
        }
        public event PropertyChangedEventHandler? PropertyChanged;
        protected virtual void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
