﻿using DatGrid_MVVM.Models;
using DatGrid_MVVM.Repository;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Documents;
using System.Windows.Input;

namespace SearchAsync
{
    class MainViewModel:BindableBase
    {
        private ObservableCollection<Person> _people = new();
        private string _searchTerm;
        private bool _isTextBlockVisible;
        
        public ICommand GetAllSynchCommand { get; set; }
        public ICommand GetAllSynchSmartCommand { get; set; }
        public ICommand GetAllAsynchCommand { get; set; }
        public ICommand ClearCommand { get; set; }
        private PersonRepository _repository;

        public MainViewModel()
        {
            _repository = new PersonRepository();
            ClearCommand = new DelegateCommand(ClearPeople);
            GetAllSynchCommand = new DelegateCommand(GetAllSynch);
            GetAllSynchSmartCommand = new DelegateCommand(GetAllSynchSmart);
            GetAllAsynchCommand = new DelegateCommand(GetAllAsynch);

        }
        
        public bool IsTextBlockVisible
        {
            get { return _isTextBlockVisible; }
            set
            {
                if(_isTextBlockVisible!=value)
                {
                    _isTextBlockVisible = value;
                    OnPropertyChanged(new PropertyChangedEventArgs(nameof(IsTextBlockVisible)));
                }
            }
        }
        public void ClearPeople()
        {
            People.Clear();
        }
        public void GetAllSynch()
        {
            IsTextBlockVisible = true;
            People.Clear();
            People.AddRange(_repository.GetAll_VeryHeavy());
            IsTextBlockVisible = false;
        }
        public async void GetAllSynchSmart()
        {
            List<Person> people =new List<Person>();
            People.Clear();
            IsTextBlockVisible = true;
            await Task.Run(() =>
            {               
                people = _repository.GetAll_VeryHeavy();                
            });
            IsTextBlockVisible = false;
            People.AddRange(people);
        }
        public async void GetAllAsynch()
        {
            IsTextBlockVisible = true;           
            var list = await _repository.GetAllAsync(CancellationToken.None);
            People.Clear();
            People.AddRange(list);
            IsTextBlockVisible = false;
        }
        
        public ObservableCollection<Person> People
        {
            get => _people;
            set
            {
                if (_people != value)
                {
                    _people = value;
                    OnPropertyChanged(new PropertyChangedEventArgs(nameof(People)));
                }
            }
        }

        public string SearchTerm
        {
            get { return _searchTerm; }
            set
            {
                if(_searchTerm!=value)
                {
                    _searchTerm = value;
                    OnPropertyChanged(new PropertyChangedEventArgs(nameof(SearchTerm)));
                }
            }
        }
    }
}
