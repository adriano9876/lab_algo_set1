using DatGrid_MVVM.Models;

namespace DatGrid_MVVM.Repository
{
    public class PersonRepository
    {
        private readonly List<Person> _people = new()
        {
            new Person("Alice", "Smith", 28, true)
            {
                Pet = new Pet("Buddy", "Dog"),
                DrivingLicence = DrivingLicence.Car
            },
            new Person("Bob", "Johnson", 35, false)
            {
                Pet = new Pet("Whiskers", "Cat"),
                DrivingLicence = DrivingLicence.Bike
            },
            new Person("Charlie", "Williams", 22, true)
            {
                Pet = new Pet("Goldie", "Fish"),
                DrivingLicence = DrivingLicence.NoLicence
            },
            new Person("Diana", "Brown", 40, false)
            {
                DrivingLicence = DrivingLicence.Car
            },
            new Person("Ethan", "Davis", 31, true)
            {
                DrivingLicence = DrivingLicence.Bike
            }
        };

        public List<Person> GetAll_VeryHeavy()
        {
            var fib = SlowFibonacci(43); // Simulate a slow operation
            return _people;
        }

        public async Task<List<Person>> GetAllAsync(CancellationToken cancellationToken)
        {
            // Simulate async operation with cancellation support
            await Task.Delay(5000, cancellationToken); // Optional: simulate latency
            return _people;
        }

        // Returns people whose name or last name contains the given string (case-insensitive)
        public List<Person> GetByName(string search)
        {
            if (string.IsNullOrWhiteSpace(search))
            {
                return _people;
            }

            var lower = search.ToLowerInvariant();
            return _people.Where(p =>
                (!string.IsNullOrEmpty(p.Name) && p.Name.ToLowerInvariant().Contains(lower)) ||
                (!string.IsNullOrEmpty(p.LastName) && p.LastName.ToLowerInvariant().Contains(lower))
            ).ToList();
        }



        private static long SlowFibonacci(int n)
        {
            // This recursive approach is intentionally inefficient
            if (n <= 1)
                return n;

            return SlowFibonacci(n - 1) + SlowFibonacci(n - 2);
        }

    }
}