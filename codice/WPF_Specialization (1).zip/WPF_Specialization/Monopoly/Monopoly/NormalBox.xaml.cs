﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Monopoly
{
    /// <summary>
    /// Interaction logic for NormalBox.xaml
    /// </summary>
    public partial class NormalBox : UserControl 
    {
        public NormalBox()
        {
            InitializeComponent();
        }

        public static readonly DependencyProperty TextContentProperty =
        DependencyProperty.Register(
       "TextContent",
       typeof(string),
       typeof(NormalBox),
       default
        );
        public string TextContent
        {
            get => (string)GetValue(TextContentProperty);
            set => SetValue(TextContentProperty, value);
        }

        public static readonly DependencyProperty PriceProperty =
        DependencyProperty.Register(
       "Price",
       typeof(int),
       typeof(NormalBox),
       default
        );

        public int Price
        {
            get => (int)GetValue(PriceProperty);
            set => SetValue(PriceProperty, value);
        }
        
    }
}
