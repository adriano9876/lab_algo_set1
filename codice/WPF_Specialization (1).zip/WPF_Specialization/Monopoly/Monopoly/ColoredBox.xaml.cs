﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Monopoly
{
    /// <summary>
    /// Interaction logic for Property.xaml
    /// </summary>
    public partial class ColoredBox : UserControl
    {
        public ColoredBox()
        {
            InitializeComponent();
        }

        public static readonly DependencyProperty ColorProperty =
        DependencyProperty.Register(
       "Color",
       typeof(string),
       typeof(ColoredBox),
       default
        );


        public string Color
        {
            get => (string)GetValue(ColorProperty);
            set => SetValue(ColorProperty, value);
        }

        public static readonly DependencyProperty TextContentProperty =
        DependencyProperty.Register(
       "TextContent",
       typeof(string),
       typeof(ColoredBox),
       default
        );
        public string TextContent
        {
            get => (string)GetValue(TextContentProperty);
            set => SetValue(TextContentProperty, value);
        }

        

        public static readonly DependencyProperty PriceProperty =
        DependencyProperty.Register(
       "Price",
       typeof(int),
       typeof(ColoredBox),
       default
        );

        public int Price
        {
            get => (int)GetValue(PriceProperty);
            set => SetValue(PriceProperty, value);
        }

    }
}
