﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Linq;
namespace Monopoly;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{
    private Rectangle player;
    public MainWindow()
    {
        InitializeComponent();
        player = this.RedPawn;
    }

    private void RollDice_Click(object sender, RoutedEventArgs e)
    {
        Random rng = new Random();
        int d1 = rng.Next(1, 7);
        int d2 = rng.Next(1, 7);
        int res = d1 + d2;
        
        for(int i=0;i<res;i++)
        {
            MoveByOne(player);
        }
        this.Result.Content = res;
        if(player== RedPawn)
        {
            player = this.BluePawn;
            RollDice.Content = "Tira il blu";
        }
        else
        {
            player = this.RedPawn;
            RollDice.Content = "Tira il rosso";
        }

    }

    private void MoveByOne(Rectangle pawn)
    {
        if (Grid.GetColumn(pawn) > 0 && Grid.GetRow(pawn) == this.Grid.RowDefinitions.Count-1)
        {
            Grid.SetColumn(pawn, Grid.GetColumn(pawn) - 1);
            return;
        }       
        if (Grid.GetColumn(pawn) == 0 && Grid.GetRow(pawn) > 0)
        {
            Grid.SetRow(pawn, Grid.GetRow(pawn)-1);
            return;
        }
        if (Grid.GetColumn(pawn) < this.Grid.ColumnDefinitions.Count-1 && Grid.GetRow(pawn) == 0)
        {
            Grid.SetColumn(pawn, Grid.GetColumn(pawn) + 1);
            return;
        }
        if (Grid.GetColumn(pawn) == this.Grid.ColumnDefinitions.Count-1 && Grid.GetRow(pawn) < this.Grid.RowDefinitions.Count-1)
        {
            Grid.SetRow(pawn, Grid.GetRow(pawn) + 1);
            return;
        }

    }
}