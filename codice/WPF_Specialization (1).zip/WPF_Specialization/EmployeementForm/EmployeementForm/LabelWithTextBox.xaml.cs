﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EmployeementForm
{
    /// <summary>
    /// Interaction logic for LabelWithTextBox.xaml
    /// </summary>
    public partial class LabelWithTextBox : UserControl
    {
        public LabelWithTextBox()
        {
            InitializeComponent();
        }
        public string LabelText
        {
            get => (string)GetValue(LabelTextProperty);
            set => SetValue(LabelTextProperty, value);
        }
        public static readonly DependencyProperty LabelTextProperty =
                DependencyProperty.Register(
                   "LabelText",
                   typeof(string),
                   typeof(LabelWithTextBox),
                   default
                );
        public string TextBoxContent
        {
            get => (string)GetValue(TextBoxContentProperty);
            set => SetValue(TextBoxContentProperty, value);
        }
        public static readonly DependencyProperty TextBoxContentProperty =
                DependencyProperty.Register(
                   "TextBoxContent",
                   typeof(string),
                   typeof(LabelWithTextBox),
                   default
                );

        
    }
}
