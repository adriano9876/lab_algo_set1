﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EmployeementForm;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
/// 
public enum Role
{
    Developer,
    Tester,
    Intern
}
public partial class MainWindow : Window
{
    private bool dateValid;
    private bool nameValid;
    private bool roleValid;
    
    public MainWindow()
    {
        InitializeComponent();
        this.ComboBoxRole.Items.Add(Role.Developer);
        this.ComboBoxRole.Items.Add(Role.Tester);
        this.ComboBoxRole.Items.Add(Role.Intern);
        dateValid = false;
        nameValid = false;
        roleValid = false;
        //this.Name.Lab.Content = "Name";
        //this.Lastname.Lab.Content = "Lastname";
    }

    private void ValidationButton_Click(object sender, RoutedEventArgs e)
    {                      
        if(dateValid && roleValid && nameValid)
        { 
            this.Panel.Visibility = Visibility.Collapsed; 
        }                                   
    }

    private void ComboBoxRole_DropDownClosed(object sender, EventArgs e)
    {
        this.ComboBoxRole.Foreground= new SolidColorBrush(Colors.Black);
        switch ((int)this.ComboBoxRole.SelectedValue)
        {
            case (int)Role.Developer:
                this.ComboBoxRole.Foreground = new SolidColorBrush(Colors.Green);
                roleValid = true;
                break;
            case (int)Role.Tester:                
                this.ComboBoxRole.Foreground = new SolidColorBrush(Colors.Yellow);
                roleValid = true;
                break;
            case (int)Role.Intern:                
                this.ComboBoxRole.Foreground = new SolidColorBrush(Colors.Blue);
                roleValid = true;
                break;
            
                         
        }
    }

    

    private void Date_CalendarClosed(object sender, RoutedEventArgs e)
    {
        this.BorderFrom.BorderBrush = new SolidColorBrush(Colors.White);
        this.BorderTo.BorderBrush = new SolidColorBrush(Colors.White);
        this.ValidationLabel.Background = new SolidColorBrush(Colors.White);
        this.ValidationLabel.Content = "";
        this.CheckBox1Year.IsChecked = false;
        if (this.DateTo.SelectedDate==null || this.DateFrom.SelectedDate==null || this.DateTo.SelectedDate < this.DateFrom.SelectedDate)
        {
            this.ValidationLabel.Content = "Invalid Dates";
            this.BorderTo.BorderBrush = new SolidColorBrush(Colors.Red);
            this.BorderFrom.BorderBrush = new SolidColorBrush(Colors.Red);
            this.ValidationLabel.Background = new SolidColorBrush(Colors.OrangeRed);
            dateValid = false;
            return;

        }
        if ((this.DateTo.SelectedDate - this.DateFrom.SelectedDate) < new TimeSpan(365, 0, 0, 0))
        {
            this.CheckBox1Year.IsChecked = true;
        }
        dateValid = true;
    }

    private void Name_LostFocus(object sender, RoutedEventArgs e)
    {
        LabelWithTextBox box = (LabelWithTextBox)sender;
        this.ValidationLabel.Background = new SolidColorBrush(Colors.White);
        this.BorderName.BorderBrush = new SolidColorBrush(Colors.White);
        this.BorderLastname.BorderBrush = new SolidColorBrush(Colors.White);
        if (box.Text.Text == "")
        {
            this.ValidationLabel.Content = "Must insert a name";
            this.ValidationLabel.Background = new SolidColorBrush(Colors.OrangeRed);
            this.BorderName.BorderBrush = new SolidColorBrush(Colors.Red);
            this.BorderLastname.BorderBrush = new SolidColorBrush(Colors.Red);
            nameValid = false;
            
        }
        if(this.Name.Text.Text!=null && this.Name.Text.Text!="" && this.Lastname.Text.Text != null && this.Lastname.Text.Text != "")
        {
            nameValid = true;
        }

    }

    private void ValidationButton_MouseEnter(object sender, MouseEventArgs e)
    {
        this.MessageLabel.Content = "Are you sure?";
    }

    private void ValidationButton_MouseLeave(object sender, MouseEventArgs e)
    {
        this.MessageLabel.Content = "";
    }

    private void ColorBotton_Click(object sender, RoutedEventArgs e)
    {
        Random rng = new Random();
        Color color;
        
        color = Color.FromRgb((byte)rng.Next(256), (byte)rng.Next(256), (byte)rng.Next(256));
        this.Panel.Background = new SolidColorBrush(color);
            
        
        
        

    }
}