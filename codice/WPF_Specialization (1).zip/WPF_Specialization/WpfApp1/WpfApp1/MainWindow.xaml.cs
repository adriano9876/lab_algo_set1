﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
        //this.Button1.Margin = new Thickness(200,100,0,0);
    }

   

    private void Button1_Click(object sender, RoutedEventArgs e)
    {
        double a = 0;
        double b = 0;
        bool flag = Double.TryParse(this.Box1.Text, out a) && Double.TryParse(this.Box2.Text, out b);

        if(flag)
        {
            double res = Math.Round(a + b, 2);
            this.Label1.Content = res;
            this.Label1.Background = new SolidColorBrush(Colors.White);
        }
        else
        {
            this.Label1.Content = "Invalid Input";
            this.Label1.Background= new SolidColorBrush(Colors.Red);
        }
        
    }

    private void Box_GotFocus(object sender, RoutedEventArgs e)
    {
        
        TextBox box = (TextBox) e.Source;
        if (box.Text == "Insert number")
        {
            box.Text = "";
        }
        
    }

    private void Box_LostFocus(object sender, RoutedEventArgs e)
    {
        TextBox box = (TextBox) e.Source;
        if(box.Text=="")
        {
            box.Text = "Insert number";
        }
        
    }
}