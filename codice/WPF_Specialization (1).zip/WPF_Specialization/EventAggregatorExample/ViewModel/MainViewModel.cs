﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventAggregatorExample.ViewModel
{
    public class MainViewModel : BindableBase
    {
        private PublisherViewModel _publisher;
        private SubscriberViewModel _subscriber;

        
        public MainViewModel()
        {
            _publisher = new PublisherViewModel();
            _subscriber = new SubscriberViewModel();
        }


        public PublisherViewModel Publisher
        {
            get { return _publisher; }
            
        }

        public SubscriberViewModel Subscriber
        {
            get { return _subscriber; }
        }

    }
}
