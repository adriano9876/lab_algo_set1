﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;
using System.Windows.Shapes;

namespace EventAggregatorExample.ViewModel
{
    public class SubscriberViewModel:BindableBase
    {
        private string _text;
        private SolidColorBrush _brush;

        public SubscriberViewModel()
        {
            EventAggregator.Current.GetEvent<StringEvent>().Subscribe(HandleEvent);
        }
        public string Text
        {
            get { return _text; }
            set
            {
                if (_text != value)
                {
                    _text = value;
                    OnPropertyChanged(new PropertyChangedEventArgs(nameof(Text)));
                }
            }
        }
         public SolidColorBrush Brush
        {
            get { return _brush; }
            set
            {
                if(_brush!=value)
                {
                    _brush = value;
                    OnPropertyChanged(new PropertyChangedEventArgs(nameof(Brush)));
                }
            }
        }
        public void HandleEvent(string message)
        {
            Color color;
            
            try
            {
                Text = "";
                color = (Color)ColorConverter.ConvertFromString($"#{message}");
            }
            catch(FormatException e)
            {
                Text = "Formato non valido";
                color = Colors.White;
                
            }
            
            
            Brush = new SolidColorBrush(color);
            //Text = message;
            //var ord = String.Concat(message.Order());
            //if (ord.Equals(message))
            //{
            //    Text = "Ordinato";
            //}
            //else
            //{
            //    Text = "Non ordinato";    
            //}
            
        }
    }
}
