﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Windows.Media;

namespace EventAggregatorExample.ViewModel
{
    public class PublisherViewModel:BindableBase, IDataErrorInfo
    {
        private readonly IEventAggregator _eventAggregator;
        private string _message;
        public ICommand PublishCommand { get; set; }
        public PublisherViewModel()
        {
            _eventAggregator = EventAggregator.Current;
            PublishCommand = new DelegateCommand(PublishEvent);
        }

        public string Message
        {
            get { return _message; }
            set
            {
                if(_message!=value)
                {
                    _message = value;
                    OnPropertyChanged(new PropertyChangedEventArgs(nameof(Message)));
                }
            }
        }

        public string Error => null;

        public string this[string columnName] 
        {
            get
            {
                if(columnName==nameof(Message))
                {
                    if(string.IsNullOrEmpty(Message))
                    {
                        return "Valore richiesto";
                    }
                    if(Message.Length!=6)
                    {
                        return "Il codice deve essere esattamente 6 caratteri";
                    }
                    try
                    {
                        ColorConverter.ConvertFromString($"#{Message}");
                    }
                    catch(FormatException e)
                    {
                        return "Formato non valido";
                    }
                    
                }
                return null;
            }
        }

        public void PublishEvent()
        {
            _eventAggregator.GetEvent<StringEvent>().Publish(Message);
        }
    }
}
