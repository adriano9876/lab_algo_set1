﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventAggregatorExample.ViewModel
{
    public class StringEvent: PubSubEvent<string>
    {
    }
}
