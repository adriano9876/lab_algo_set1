﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace WpfBinding
{
    public class Order :INotifyPropertyChanged
    {
        private double _price;
        private string _object;
        public string StringPrice
        {
            get
            {
                return $"{Price}€";
            }
        }

        public string Object
        {
            get { return _object; }
            set
            {
                if (_object != value)
                {
                    _object = value;
                    OnPropertyChanged();
                }
            }
        }

        public double Price
        {
            get { return _price; }
            set
            {
                if (_price != value)
                {
                    _price = value;
                    OnPropertyChanged();
                    OnPropertyChanged(nameof(StringPrice));
                }
            }
        }
        public event PropertyChangedEventHandler? PropertyChanged;
        protected virtual void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
