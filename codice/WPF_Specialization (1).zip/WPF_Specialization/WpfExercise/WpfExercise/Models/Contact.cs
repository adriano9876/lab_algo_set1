﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfExercise.Models
{
    public class Contact
    {
        public string Name { get; set; }
        public string Lastname { get; set; }
        public string Phone { get; set; }
        public int Age { get; set; }
        public override string ToString()
        {
            return $"{Name} {Lastname}";
        }
    }
}
