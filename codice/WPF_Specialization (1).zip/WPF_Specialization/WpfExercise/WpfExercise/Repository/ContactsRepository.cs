﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfExercise.Models;

namespace WpfExercise.Repository
{
    public class ContactsRepository
    {
        private List<Contact> _contacts;

        public ContactsRepository()
        {
            _contacts = new List<Contact>()
            {
                new Contact
                {
                    Name="Karim",
                    Lastname="Musa",
                    Age=37,
                    Phone="+39 3333333666"
                },
                new Contact
                {
                    Name="Raimondo",
                    Lastname="Mondo",
                    Age=57,
                    Phone="+39 3378725981"
                },
                new Contact
                {
                    Name="Paola",
                    Lastname="Aloap",
                    Age=44,
                    Phone="+39 3309944134"
                }
            };
        }

        public List<Contact> GetAll()
        {
            return _contacts;
        }

        public void AddContact(Contact contact)
        {
            _contacts.Add(contact);
        }
        public void RemoveContact(Contact contact)
        {
            var f=_contacts.Remove(contact);
        }
    }
}
