﻿using System.Collections.ObjectModel;
using WpfExercise.Models;
using WpfExercise.Repository;

namespace WpfExercise.ViewModels
{
    public class MainViewModel: ViewModelBase
    {
        private ObservableCollection<Contact> _contacts=new();
        private ContactsRepository _repository;
        private Contact newContact=new();
        private Contact _selectedContact;
        private AddContactWindow addWindow { get; set; }
        public RelayCommand ClearCommand { get; set; }
        public RelayCommand LoadCommand { get; set; }
        public RelayCommand OpenWindowCommand { get; set; }
        public RelayCommand AddCommand { get; set; }
        public RelayCommand RemoveCommand { get; set; }

        public MainViewModel()
        {
            _repository = new ContactsRepository();
            LoadCommand = new RelayCommand(x => LoadContacts());
            ClearCommand = new RelayCommand(x => ClearContacts());
            OpenWindowCommand = new RelayCommand(x => OpenAddContactWindow());
            AddCommand = new RelayCommand(x => AddContact());
            RemoveCommand = new RelayCommand(x => RemoveContact());
        }

        public ObservableCollection<Contact> Contacts
        {
            get { return _contacts; }
        }
        public Contact SelectedContact
        {
            get { return _selectedContact; }
            set
            {
                if(_selectedContact != value)
                {
                    _selectedContact = value;
                    OnPropertyChanged(nameof(SelectedContact));
                }
            }
        }
        public string NewContactName
        {
            get {return  newContact.Name; }
            set
            {
                if(newContact.Name!=value)
                {
                    newContact.Name = value;
                    OnPropertyChanged(nameof(NewContactName));
                }
            }
        }
        public string NewContactLastname
        {
            get { return newContact.Lastname; }
            set
            {
                if (newContact.Lastname != value)
                {
                    newContact.Lastname = value;
                    OnPropertyChanged(nameof(NewContactLastname));
                }
            }
        }
        public string NewContactPhone
        {
            get { return newContact.Phone; }
            set
            {
                if (newContact.Phone != value)
                {
                    newContact.Phone = value;
                    OnPropertyChanged(nameof(NewContactPhone));
                }
            }
        }
        public string NewContactAge
        {
            get { return newContact.Age.ToString(); }
            set
            {
                var flag = Int32.TryParse(value, out int res);
                if(flag && newContact.Age != res)
                {
                    newContact.Age = res;
                    OnPropertyChanged(nameof(NewContactPhone));
                }
            }
        }
        public void RemoveContact()
        {
            var removed = SelectedContact;
            Contacts.Remove(removed);
            _repository.RemoveContact(removed);
        }
        public void ClearContacts()
        {
            Contacts.Clear();            
        }
        public void LoadContacts()
        {
            ClearContacts();
            var contacts=_repository.GetAll();
            contacts.ForEach(x => Contacts.Add(x));
        }
        public void OpenAddContactWindow()
        {
            addWindow = new AddContactWindow();
            addWindow.DataContext = this;
            addWindow.ShowDialog();
        }
        public void AddContact()
        {
            var contact = new Contact
            {
                Name = newContact.Name,
                Lastname = newContact.Lastname,
                Age = newContact.Age,
                Phone = newContact.Phone
            };
            Contacts.Add(contact);
            _repository.AddContact(contact);
            newContact = new Contact();
            addWindow.Close();
        }

    }
}
