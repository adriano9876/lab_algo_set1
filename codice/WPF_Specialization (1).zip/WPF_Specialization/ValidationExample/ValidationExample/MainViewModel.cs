﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ValidationExample
{
    public class MainViewModel: BindableBase, IDataErrorInfo
    {
        private string _input1;
        private string _input2;

        

        public string Input1
        {
            get { return _input1; }
            set
            {
                if(_input1!=value)
                {
                    _input1 = value;
                    OnPropertyChanged(new PropertyChangedEventArgs(nameof(Input1)));
                }
            }
        }

        public string Input2
        {
            get { return _input2; }
            set
            {
                if (_input2 != value)
                {
                    _input2 = value;
                    OnPropertyChanged(new PropertyChangedEventArgs(nameof(Input2)));
                }
            }
        }

        public string this[string columnName]
        {
            get
            {
                switch(columnName)
                {
                    case nameof(Input1):
                        return ValidationInput1();                   
                    case nameof(Input2):
                        return ValidationInput2();
                        
                }
                
                return null;
            }
            
        }
        private string ValidationInput1()
        {
            var number = new List<char> { '1', '2', '3', '4', '5', '6', '7', '8', '9', '0' };
            if(string.IsNullOrEmpty(Input1))
            {
                return "Password richiesta";
            }
            if(Input1.Length < 3)
            {
                return "Richiesti almeno tre caratteri";
            }
            if(!Input1.Any(x=>number.Contains(x)))
            {
                return "La password deve contenere almeno un numero";
            }
            return null;
            
        }
        private string ValidationInput2()
        {
            if (string.IsNullOrEmpty(Input2))
            {
                return "Input richiesto";
            }
            if (Input2!=Input1)
            {
                return "Le password devono essere uguali";
            }
            return null;

        }
        public string Error => null;
    }
}
