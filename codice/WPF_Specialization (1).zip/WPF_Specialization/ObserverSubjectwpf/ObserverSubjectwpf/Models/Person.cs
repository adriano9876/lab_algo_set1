﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;

namespace ObserverSubjectwpf.Models
{
    public enum DrivingLicence
    {
        NoLicence,
        Bike,
        Car
    }

    public class Person
    {
        public Person()
        {
            // Parameterless constructor for serialization or default initialization
        }

        public Person(string name, string lastName, int age, bool canSwim)
        {
            Name = name;
            LastName = lastName;
            Age = age;
            CanSwim = canSwim;
        }

        public string Name { get; set; }
        public string LastName { get; set; }
        public int Age { get; set; }

        

        public DrivingLicence DrivingLicence { get; set; } = DrivingLicence.NoLicence;

        public bool CanSwim { get; set; }

        public override string ToString()
        {
            return $"{Name} {LastName}, Age: {Age}, Can Swim: {CanSwim}, Driving Licence: {DrivingLicence}";
        }
    }
}
