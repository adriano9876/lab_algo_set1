﻿using ObserverSubjectwpf.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObserverSubjectwpf.ViewModels
{
    class PeopleListViewModel : BaseViewModel, ISearchResultObserver
    {
        private ObservableCollection<Person> _people = new();       
        public ObservableCollection<Person> People
        {
            get => _people;
            set
            {
                if (_people != value)
                {
                    _people = value;
                    OnPropertyChanged(nameof(People));
                }
            }
        }
        public void Update(IEnumerable<Person> searchResult)
        {
            if(searchResult==null)
            {
                return;
            }
            _people.Clear();
            foreach(var person in searchResult)
            {
                _people.Add(person);
            }
            
        }
    }
}
