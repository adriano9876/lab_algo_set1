﻿using ObserverSubjectwpf.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObserverSubjectwpf.ViewModels
{
    public interface ISearchResultObserver
    {
        void Update(IEnumerable<Person> searchResult); 
    }
}
