﻿using ObserverSubjectwpf.Models;
using ObserverSubjectwpf.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObserverSubjectwpf.ViewModels
{
    public class SearchViewModel : BaseViewModel
    {
        private string _searchTerm;
        private List<ISearchResultObserver> _observers;
        private readonly IPersonRepository _personRepository;


        public SearchViewModel()
        {
            _observers = new();
            _personRepository = new PersonRepository();
        }
        public string SearchTerm
        {
            get { return _searchTerm; }
            set
            {
                if(value!=_searchTerm)
                {
                    _searchTerm = value;
                    OnPropertyChanged(nameof(SearchTerm));
                    Search();
                }
            }
        }
        public void Attach(ISearchResultObserver observer)
        {
            if(!_observers.Contains(observer))
            {
                _observers.Add(observer);
            }
        }

        public void Detach(ISearchResultObserver observer)
        {
            if (_observers.Contains(observer))
            {
                _observers.Remove(observer);
            }
        }

        private void Search()
        {
            
            var name = SearchTerm?.Trim();
            var persons = _personRepository.GetByName(name);

            Notify(persons);
        }

        private void Notify(List<Person> persons)
        {
            foreach (var observer in _observers)
            {
                observer.Update(persons);
            }
        }
    }
}
