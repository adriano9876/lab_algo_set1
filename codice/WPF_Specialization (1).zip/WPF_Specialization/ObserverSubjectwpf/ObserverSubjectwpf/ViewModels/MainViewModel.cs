﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObserverSubjectwpf.ViewModels
{
    class MainViewModel :BaseViewModel
    {
        private SearchViewModel _searchViewModel;
        private PeopleListViewModel _peopleListViewModel;

        public MainViewModel()
        {
            _searchViewModel = new SearchViewModel();
            _peopleListViewModel = new PeopleListViewModel();
            _searchViewModel.Attach(_peopleListViewModel);
        }

        public SearchViewModel Search
        {
            get { return _searchViewModel; }
            set
            {
                if(_searchViewModel!=value)
                {
                    _searchViewModel = value;
                    OnPropertyChanged(nameof(Search));
                }
            }
        }

        public PeopleListViewModel List
        {
            get { return _peopleListViewModel; }
            set
            {
                if (_peopleListViewModel != value)
                {
                    _peopleListViewModel = value;
                    OnPropertyChanged(nameof(List));
                }
            }
        }
    }
}
