using System.Collections.Generic;
using System.Linq;
using ObserverSubjectwpf.Models;

namespace ObserverSubjectwpf.Repository
{
    public class PersonRepository : IPersonRepository
    {
        private readonly List<Person> _people = new()
        {
            new Person("Alice", "Smith", 28, true)
            {
                
                DrivingLicence = DrivingLicence.Car
            },
            new Person("Bob", "Johnson", 35, false)
            {
                
                DrivingLicence = DrivingLicence.Bike
            },
            new Person("Charlie", "Williams", 22, true)
            {
                
                DrivingLicence = DrivingLicence.NoLicence
            },
            new Person("Diana", "Brown", 40, false)
            {
                DrivingLicence = DrivingLicence.Car
            },
            new Person("Ethan", "Davis", 31, true)
            {
                DrivingLicence = DrivingLicence.Bike
            }
        };

        public List<Person> GetAll()
        {
            return _people;
        }

        public void Add(Person person)
        {
            if (person != null)
                _people.Add(person);
        }

        public void Remove(Person person)
        {
            if (person != null)
                _people.Remove(person);
        }

        // Returns people whose name or last name contains the given string (case-insensitive)
        public List<Person> GetByName(string search)
        {
            if (string.IsNullOrWhiteSpace(search))
            {
                return _people;
            }

            var lower = search.ToLowerInvariant();
            return _people.Where(p =>
                (!string.IsNullOrEmpty(p.Name) && p.Name.ToLowerInvariant().Contains(lower)) ||
                (!string.IsNullOrEmpty(p.LastName) && p.LastName.ToLowerInvariant().Contains(lower))
            ).ToList();
        }
    }
}