﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Linq;
namespace WpfLayout;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }

    private void RightNavigationButton_Click(object sender, RoutedEventArgs e)
    {
        if (this.TabFunghi.SelectedIndex < this.TabFunghi.Items.Count - 1)
        {
            this.TabFunghi.SelectedIndex++;
        }

    }

    private void LeftNavigationButton_Click(object sender, RoutedEventArgs e)
    {

        if (this.TabFunghi.SelectedIndex > 0)
        {
            this.TabFunghi.SelectedIndex--;
        }

    }

    private void RemoveTabButton_Click(object sender, RoutedEventArgs e)
    {
        this.TabFunghi.Items.Remove(this.TabFunghi.SelectedItem);
    }

    private void AddTabButton_Click(object sender, RoutedEventArgs e)
    {

        var tab = new TabItem();
        var label = new Label();
        var panel = new WrapPanel();
        var image = new Image();
        var bitmap = new BitmapImage();
        bitmap.BeginInit();
        bitmap.UriSource = new Uri("C:\\Users\\e-duccio.tarno\\Desktop\\git-academy7\\MSC-Academy-Dev-7\\Weeks11_and_12_Specializations\\WPF_Specialization\\WpfLayout\\WpfLayout\\Images\\Magici.webp"); // Adjust the path as needed
        bitmap.EndInit();
        image.Source = bitmap;
        image.Height = 200;

        label.Content = $"Pagina numero {this.TabFunghi.Items.Count - 1}";
        tab.Header = $"Fungo magico numero {this.TabFunghi.Items.Count - 1}";
        panel.Children.Add(image);
        panel.Children.Add(label);

        tab.Content = panel;
        this.TabFunghi.Items.Add(tab);

        var button = new Button();
        button.Tag = this.TabFunghi.Items.Count.ToString();
        button.Content = $"Fungo magico numero {this.TabFunghi.Items.Count - 1}";
        button.Click += PageButton_Click;
        this.MenuPanel.Children.Add(button);



    }

    private void PageButton_Click(object sender, RoutedEventArgs e)
    {
        var button = (Button)sender;
        Int32.TryParse((string)button.Tag, out int index);
        this.TabFunghi.SelectedIndex = index;
    }

    private void RngButton_Click(object sender, RoutedEventArgs e)
    {
        Random rng = new Random();
        int index = rng.Next(this.TabFunghi.Items.Count);
        this.TabFunghi.SelectedIndex = index;
    }

    private void ScrollBar_Scroll(object sender, System.Windows.Controls.Primitives.ScrollEventArgs e)
    {

    }

    //private void Search_TextChanged(object sender, TextChangedEventArgs e)
    //{
    //    foreach(Button c in this.MenuPanel.Children)
    //    {
    //        c.Visibility = Visibility.Hidden;
    //    }
    //    var children = this.MenuPanel.Children.Cast<Button>().Where(x=>x.Content.ToString().Contains(this.Search.Text));
    //    foreach(var c in children)
    //    {
    //        c.Visibility=Visibility.Visible;
    //    }


    //}
}