﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using WPF_Finals.Models;

namespace WPF_Finals
{
    //This class will handle all user related operations
    //Do not change the methods here.
    internal static class UserHandler
    {
        private const string UsersFilePath = "Models/users.json";

        public static async Task<List<UserDto>> GetAllUsersAsync()
        {
            var users = JsonSerializer.Deserialize<Dictionary<int, UserDto>>(File.ReadAllText(UsersFilePath));
            await Task.Delay(5000);
            return users.Values.ToList();
        }

        public static List<UserDto> GetAllUsers()
        {
            var users = JsonSerializer.Deserialize<Dictionary<int, UserDto>>(File.ReadAllText(UsersFilePath));
            return users.Values.ToList();
        }

        public static UserDto GetUserById(int id)
        {
            var users = JsonSerializer.Deserialize<Dictionary<int, UserDto>>(File.ReadAllText(UsersFilePath));
            return users[id];
        }

        public static void AddUser(UserDto user)
        {
            var users = JsonSerializer.Deserialize<Dictionary<int, UserDto>>(File.ReadAllText(UsersFilePath));
            if(user.Id == 0)
            {
                user.Id = users.Keys.Max() + 1;
            }

            users[user.Id] = user;
            File.WriteAllText(UsersFilePath, JsonSerializer.Serialize(users));
        }

        public static void UpdateUser(UserDto user)
        {
            var users = JsonSerializer.Deserialize<Dictionary<int, UserDto>>(File.ReadAllText(UsersFilePath));
            users[user.Id] = user;
            File.WriteAllText(UsersFilePath, JsonSerializer.Serialize(users));
        }

        public static void DeleteUser(int id)
        {
            var users = JsonSerializer.Deserialize<Dictionary<int, UserDto>>(File.ReadAllText(UsersFilePath));
            users.Remove(id);
            File.WriteAllText(UsersFilePath, JsonSerializer.Serialize(users));
        }

        public static void GenerateUsers()
        {
            var random = new Random();
            var names = new List<string>
            {
                "Alice", "Bob", "Charlie", "Diana", "Ethan", "Fiona", "George", "Hannah", "Ian", "Julia"
            };
            var surnnames = new List<string>
            {
                "Smith", "Johnson", "Williams", "Brown", "Jones",
                "Miller", "Davis", "Garcia", "Rodriguez", "Wilson"
            };

            var services = Enum.GetValues(typeof(ServiceEnum));
            var paymentStatuses = Enum.GetValues(typeof(PaymentStatusEnum));

            var users = new Dictionary<int, UserDto>();
            var counter = 1;
            foreach (var surname in surnnames)
            {
                foreach (var name in names)
                {
                    var user = new UserDto
                    {
                        Id = counter++,
                        Name = name,
                        Surname = surname,
                        BirthDate = DateTime.Now.AddYears(-random.Next(18, 60)).AddDays(random.Next(0, 365)),
                        Email = $"{name}.{surname}@example.com",
                        SelectedService = (ServiceEnum)services.GetValue(random.Next(services.Length)),
                        PaymentStatus = (PaymentStatusEnum)paymentStatuses.GetValue(random.Next(paymentStatuses.Length)),
                        HappinessLevel = random.Next(1, 101)
                    };
                    users.Add(user.Id, user);
                }
            }
            
            File.WriteAllText(UsersFilePath, JsonSerializer.Serialize(users));
        }
    }
}
