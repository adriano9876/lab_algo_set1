﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPF_Finals.Models
{
    public enum PaymentStatusEnum
    {
        NotPayed,
        Processing,
        Payed
    }
}
