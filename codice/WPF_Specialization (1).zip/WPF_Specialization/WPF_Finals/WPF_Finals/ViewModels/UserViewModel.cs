﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using WPF_Finals.Models;

namespace WPF_Finals.ViewModels
{
    public class UserViewModel : ViewModelBase, IDataErrorInfo
    {
        private UserDto _newUser = new();
        private AddUserWindow _addUserWindow;
        public RelayCommand AddUserCommand { get; set; }
        public UserViewModel(AddUserWindow window)
        {
            _addUserWindow = window;
            AddUserCommand = new RelayCommand(x => AddUser());
            
        }
        internal UserDto NewUser
        {
            get { return _newUser; }
        }
        public string Name
        {
            get { return _newUser.Name; }
            set
            {
                if (_newUser.Name != value)
                {
                    _newUser.Name = value;
                    OnPropertyChanged(nameof(Name));
                }
            }
        }
        public string Surname
        {
            get { return _newUser.Surname; }
            set
            {
                if (_newUser.Surname != value)
                {
                    _newUser.Surname = value;
                    OnPropertyChanged(nameof(Surname));
                }
            }
        }
        public string Email
        {
            get { return _newUser.Email; }
            set
            {
                if (_newUser.Email != value)
                {
                    _newUser.Email = value;
                    OnPropertyChanged(nameof(Email));
                }
            }
        }
        public ServiceEnum SelectedService
        {
            get { return _newUser.SelectedService; }
            set
            {
                if (_newUser.SelectedService != value)
                {
                    _newUser.SelectedService = value;
                    OnPropertyChanged(nameof(SelectedService));
                }
            }
        }
        public DateTime BirthDate
        {
            get { return _newUser.BirthDate; }
            set
            {
                if (_newUser.BirthDate != value)
                {
                    _newUser.BirthDate = value;
                    OnPropertyChanged(nameof(BirthDate));
                }
            }
        }
        public PaymentStatusEnum PaymentStatus
        {
            get { return _newUser.PaymentStatus; }
            set
            {
                if (_newUser.PaymentStatus != value)
                {
                    _newUser.PaymentStatus = value;
                    OnPropertyChanged(nameof(PaymentStatus));
                }
            }
        }
        public int HappinessLevel
        {
            get { return _newUser.HappinessLevel; }
            set
            {
                if (_newUser.HappinessLevel != value)
                {
                    _newUser.HappinessLevel = value;
                    OnPropertyChanged(nameof(HappinessLevel));
                }
            }
        }

        public string Error => null;

        public string this[string columnName] 
        {

            get
            {
                switch(columnName)
                {
                    case nameof(Name):
                        return NameValidation();
                    case nameof(Surname):
                        return SurnameValidation();
                    case nameof(Email):
                        return EmailValidation();

                }
                return null;
            }
        }
        private string NameValidation()
        {
            if(string.IsNullOrEmpty(Name))
            {
                return "Name is required";
            }
            return null;
        }


        private string SurnameValidation()
        {
            if (string.IsNullOrEmpty(Surname))
            {
                return "Name is required";
            }
            return null;
        }

        private string EmailValidation()
        {
            if (string.IsNullOrEmpty(Email))
            {
                return "Name is required";
            }
            return null;
        }
        public void AddUser()
        {
            var user = new UserDto
            {
                Name = _newUser.Name,
                Surname = _newUser.Surname,
                BirthDate = _newUser.BirthDate,
                HappinessLevel = _newUser.HappinessLevel,
                SelectedService = _newUser.SelectedService,
                PaymentStatus = _newUser.PaymentStatus,
                Email = _newUser.Email
            };
            //Users.Add(user);
            UserHandler.AddUser(_newUser);
            _addUserWindow.Close();



        }
    }
}
