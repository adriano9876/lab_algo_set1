﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Data;
using WPF_Finals.Models;

namespace WPF_Finals.ViewModels
{
    public class MainViewModel:ViewModelBase
    {
        private readonly CollectionViewSource _viewSource=new();
        internal ObservableCollection<UserDto> Users { get; set; } = new();
        private string _searchTerm;
        private UserDto _selectedUser;
        private UserViewModel _userViewModel;
        private AddUserWindow _addUserWindow;
        public RelayCommand OpenAddUserWindowCommand { get; set; }
        public RelayCommand DeleteUserCommand { get; set; }

        public MainViewModel()
        {
            UserHandler.GetAllUsers().ForEach(x=>Users.Add(x));
            _viewSource.Source = Users;
            _viewSource.View.Refresh();
            _viewSource.View.Filter = Filter;
            OpenAddUserWindowCommand = new RelayCommand(x=>OpenAddUserWindow());
            DeleteUserCommand = new RelayCommand(x => DeleteUser());


        }
        public ICollectionView View
        {
            get { return _viewSource?.View; }
        }
        public string SearchTerm
        {
            get { return _searchTerm; }
            set
            {
                if(_searchTerm!=value)
                {
                    _searchTerm = value;
                    OnPropertyChanged(nameof(SearchTerm));
                    _viewSource.View.Refresh();
                }
            }
        }
        public object SelectedUser
        {
            get { return _selectedUser; }
            set
            {
                if(_selectedUser!=value)
                {
                    _selectedUser = (UserDto)value;
                    OnPropertyChanged(nameof(SelectedUser));
                }
            }
        }
        public bool Filter(object obj)
        {
            if(obj is UserDto user)
            {
                return string.IsNullOrEmpty(SearchTerm)
                    || user.Name.Contains(SearchTerm, StringComparison.OrdinalIgnoreCase)
                    || user.Email.Contains(SearchTerm, StringComparison.OrdinalIgnoreCase);                    
            }
            return false;
        }

        public void OpenAddUserWindow()
        {
            _addUserWindow = new AddUserWindow();
            _userViewModel = new UserViewModel(_addUserWindow);
            _addUserWindow.DataContext = _userViewModel;
            _addUserWindow.ShowDialog();
            Users.Add(_userViewModel.NewUser);
            
        }
        public void DeleteUser()
        {
            var user = (UserDto)SelectedUser;
            UserHandler.DeleteUser(user.Id);
            Users.Remove(user);
            

        }
        
    }
}
