﻿using Microsoft.Extensions.DependencyInjection;
using ProgettoFattoConMarta.DataAccess;
using ProgettoFattoConMarta.View;
using ProgettoFattoConMarta.ViewModel;
using System.Configuration;
using System.Data;
using System.Windows;

namespace ProgettoFattoConMarta
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        private ServiceProvider _serviceProvider;

        public App()
        {
            var services = new ServiceCollection();
            ConfigureServices(services);
            _serviceProvider = services.BuildServiceProvider();
        }

        private void ConfigureServices(IServiceCollection services)
        {
          
            services.AddDbContext<AppDbContext>();

      
            services.AddTransient<UserRepository>();

        
            services.AddTransient<LoginViewModel>();
            services.AddTransient<MainViewModel>();
        }
        public void ApplicationStart(object sender, StartupEventArgs e)
        {

            var loginView = new LoginView();
            loginView.DataContext = _serviceProvider.GetService<LoginViewModel>();
            loginView.Show();
            loginView.IsVisibleChanged += (s, ev) =>
            {
                if (loginView.IsVisible == false && loginView.IsLoaded)
                {
                    var mainView = new MainView();
                    mainView.DataContext = _serviceProvider.GetService<MainViewModel>();
                    mainView.Show();
                    loginView.Close();
                   
                }

            };
        }
    }

}
