﻿using ProgettoFattoConMarta.DataAccess;
using ProgettoFattoConMarta.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace ProgettoFattoConMarta.ViewModel
{
    public class MainViewModel : ViewModelBase
    {
        private UserAccountModel _currentuserAccount;
        private UserRepository _userRepository;

        public UserAccountModel CurrentUserAccount
        {
            get => _currentuserAccount;
            set
            {
                _currentuserAccount = value;
                OnPropertyChanged(nameof(CurrentUserAccount));
            }
        }

        public MainViewModel(UserRepository userRepo)
        {
            _userRepository = userRepo;
            LoadCurrentUserData();
        }

        private async void LoadCurrentUserData()
        {
            if (Thread.CurrentPrincipal != null) { 
            var user = await  _userRepository.GetByUsername(Thread.CurrentPrincipal.Identity.Name);
            if (user != null)
            {
                CurrentUserAccount = new UserAccountModel()
                {
                    Username = user.Username,
                    DisplayName = $"Welcome {user.Name} {user.LastName} ",
                    ProfilePicture = null
                };
            }
            else
            {
                MessageBox.Show("Invalid User, not logged in");
                Application.Current.Shutdown();
            }
            }
            else Application.Current.Shutdown();
        }
    }
}
