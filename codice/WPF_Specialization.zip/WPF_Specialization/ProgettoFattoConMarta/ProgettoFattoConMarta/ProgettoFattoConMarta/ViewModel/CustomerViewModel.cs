﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgettoFattoConMarta.ViewModel
{
    internal class CustomerViewModel
    {
    }
}
