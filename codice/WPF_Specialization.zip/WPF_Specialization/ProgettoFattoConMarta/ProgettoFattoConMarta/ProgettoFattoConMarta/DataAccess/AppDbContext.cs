﻿using Microsoft.EntityFrameworkCore;
using ProgettoFattoConMarta.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;

namespace ProgettoFattoConMarta.DataAccess
{
    public class AppDbContext : DbContext
    {
        public DbSet<UserModel> Users { get; set; }
        private readonly string _connectionString = "Server=HQAPEW1C966-AAF;Database=UsersDatabase;User Id=sa;Password=SQL2019;TrustServerCertificate=True;";

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(_connectionString);
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<UserModel>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.HasIndex(e => e.Username).IsUnique();
            });
        }
    }
}
