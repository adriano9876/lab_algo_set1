﻿using Microsoft.EntityFrameworkCore;
using ProgettoFattoConMarta.DataAccess.Utility;
using ProgettoFattoConMarta.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace ProgettoFattoConMarta.DataAccess
{
    public class UserRepository
    {
        private readonly AppDbContext _context;

        public UserRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<bool> AuthenticateUser(NetworkCredential credential)
        {
            var hashedpass = PasswordHasher.HashPassword(credential.Password);
            var user = await _context.Users.FirstOrDefaultAsync(u => u.Username == credential.UserName && u.Password == hashedpass);

            if (user != null) return true;
            return false;
        }

        public async Task<bool> AddUser(string username, string password, string email)
        {
            if (await _context.Users.AnyAsync(u => u.Username == username))
                return false;

            var user = new UserModel
            {
                Username = username,
                Password = PasswordHasher.HashPassword(password),
                Email = email
            };

            await _context.Users.AddAsync(user);
            await _context.SaveChangesAsync();
            return true;
        }
        public async Task<UserModel> GetByUsername(string username)
        {
          
            var user = await _context.Users.AsNoTracking().FirstOrDefaultAsync(a=>a.Username == username);

            if (user != null)
            {
                 user.Password = string.Empty;
                return user;
               
            }
            return null;
        }


    }
}
