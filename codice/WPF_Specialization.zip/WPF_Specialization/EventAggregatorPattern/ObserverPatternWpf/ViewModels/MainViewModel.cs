﻿using ObserverPatternWpf.DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObserverPatternWpf.ViewModels
{
    public class MainViewModel : BindableBase
    {
        private OrderListViewModel _orderListViewModel;
        private OrderSearchViewModel _orderSearchViewModel;






        public MainViewModel(IEventAggregator eventAggregator, Repository repo)
        {
            OrderListViewModel = new OrderListViewModel(eventAggregator, repo);
            OrderSearchViewModel = new OrderSearchViewModel(eventAggregator);

        }

        public OrderListViewModel OrderListViewModel { get => _orderListViewModel; set => _orderListViewModel = value; }
        public OrderSearchViewModel OrderSearchViewModel { get => _orderSearchViewModel; set => _orderSearchViewModel = value; }
    }
}
