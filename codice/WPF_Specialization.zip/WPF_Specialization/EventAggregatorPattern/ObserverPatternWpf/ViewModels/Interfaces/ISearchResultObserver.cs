﻿using ObserverPatternWpf.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObserverPatternWpf.ViewModels.Interfaces
{
    public interface ISearchResultObserver
    {
        void Update(IEnumerable<Order> searchResult);
    }
}
