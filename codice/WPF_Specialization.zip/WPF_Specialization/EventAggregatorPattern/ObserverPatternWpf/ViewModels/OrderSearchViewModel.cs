﻿using ObserverPatternWpf.Commands;
using ObserverPatternWpf.DataAccess;
using ObserverPatternWpf.Events;
using ObserverPatternWpf.ViewModels.Interfaces;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace ObserverPatternWpf.ViewModels
{
    public class OrderSearchViewModel : BindableBase
    {
        private string _searchOrder;
        private readonly IEventAggregator _eventAggregator;
   
    

        public OrderSearchViewModel(IEventAggregator eventAggregator)
        {
        
            _eventAggregator = eventAggregator;
            _searchOrder = string.Empty;    
        }

       

        public string SearchOrder
        {
            get => _searchOrder;
            set
            {
                SetProperty(ref _searchOrder, value);
                _eventAggregator.GetEvent<OrdersResearch>().Publish(SearchOrder);
            }
        }
       
    
      

    }
}

