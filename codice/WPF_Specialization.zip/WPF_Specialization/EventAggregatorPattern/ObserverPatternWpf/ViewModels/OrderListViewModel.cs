﻿using ObserverPatternWpf.DataAccess;
using ObserverPatternWpf.Events;
using ObserverPatternWpf.Models;
using ObserverPatternWpf.ViewModels.Interfaces;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObserverPatternWpf.ViewModels
{
    public class OrderListViewModel : BindableBase
    {
        private readonly ObservableCollection<Order> _allOrders;
        private  ObservableCollection<Order> _filteredOrders = new ObservableCollection<Order>();
        private readonly IEventAggregator _eventAggregator;
        private readonly Repository _orderRepo;

        public ObservableCollection<Order> FilteredOrders
        { 
            get => _filteredOrders; 
            set 
            { 
                _filteredOrders = value;
                SetProperty(ref _filteredOrders, value);
            } 
        }

        public OrderListViewModel(IEventAggregator eventAggregator , Repository orderRepo)
        {

            _eventAggregator = eventAggregator;
            _orderRepo = orderRepo;
            var orders = _orderRepo.GetAllOrders();
            _allOrders = new ObservableCollection<Order>(orders);
            FilteredOrders = new ObservableCollection<Order>(_allOrders);
            _eventAggregator.GetEvent<OrdersResearch>().Subscribe(OnOrderSearchTextChanged);
        }
        Task
        private void OnOrderSearchTextChanged(string text)
        {
            if (string.IsNullOrWhiteSpace(text))
            {
                FilteredOrders.Clear();
                foreach (var item in _allOrders)
                {
                    FilteredOrders.Add(item);
                }
             
              
            }
            else
            {
                FilteredOrders.Clear();
                var filtered = _allOrders.Where(a=>a.Item.Contains(text)).ToList();
             
                filtered.ForEach(a => this.FilteredOrders.Add(a));  
            }
        }
    }
}
