﻿using ObserverPatternWpf.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObserverPatternWpf.DataAccess
{
    public class Repository
    {

        public List<Order> Orders { get; set; } = new List<Order>();


        public Repository()
        {
            this.Orders.Add(new Order(1, "Pc", "Pending", true, "Boat", "Corsair"));
            this.Orders.Add(new Order(2, "Ram", "Delivered", false, "Boat", "HyperX"));
            this.Orders.Add(new Order(3, "Cpu", "Payment Required", true, "Boat", "Intel"));
            this.Orders.Add(new Order(4, "Gpu", "Pending", true, "Boat", "Msi"));
            this.Orders.Add(new Order(5, "Fan", "Out for delivery", false, "Boat", "ThermalTake"));
            this.Orders.Add(new Order(6, "Power System", "Pending", true, "Boat", "Cooler Master"));
            this.Orders.Add(new Order(7, "Monitor", "Cancelled", false, "Boat", "Logitech"));
            this.Orders.Add(new Order(8, "Mouse", "Returned", false, "Boat", "Glorious"));
        }

        public List<Order> GetOrdersByItemName(string itemName)
        {

            if (string.IsNullOrEmpty(itemName)) return Orders;
            var list = Orders.Where(a => a.Item.Contains(itemName)).ToList();
            if (list.Count == 0)
            {
                return Orders;
            }
            return list;
        }
        public List<Order> GetAllOrders()
        {
            return Orders;
        }
    }
}
