﻿using ObserverPatternWpf.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObserverPatternWpf.Events
{
    public class OrdersResearch : PubSubEvent<string>
    {
    }
}
