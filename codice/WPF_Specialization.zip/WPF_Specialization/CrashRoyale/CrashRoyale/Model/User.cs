﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Text.Json;

namespace CrashRoyale.Model
{
    public class User
    {

        public string Username { get; set; }
        public int Level { get; set; }
        public int Gems { get; set; }
        public int Money { get; set; }
        public bool IsInClan { get; set; }

        private readonly string _path = "C:\\Users\\e-giulio.pappalardo\\Desktop\\academy7\\MSC-Academy-Dev-7\\Weeks11_and_12_Specializations\\WPF_Specialization\\CrashRoyale\\CrashRoyale\\Datas\\database.json";

        public void InitiateUser()
        {
            if (File.Exists(_path))
            {
              
                var user = JsonSerializer.Deserialize<User>(File.ReadAllText(_path));
                Gems = user.Gems;
                Money = user.Money;
                IsInClan = user.IsInClan;
                Username = user.Username;
                Level = user.Level;
            }
            else
            {
                InitializeAccountStats();
            }

        }

        public void SaveUser()
        {
            if (File.Exists(_path))
            {

                var jsonString = JsonSerializer.Serialize<User>(this, new JsonSerializerOptions { WriteIndented = true });
                if (File.Exists(_path))
                {
                    File.WriteAllText(_path, jsonString);

                }
            }

        }



        public void InitializeAccountStats()
        {
            Gems = 0;
            Money = 0;
            IsInClan = false;
            Level = 1;
           
        }
        // public Deck Deck { get; set; }
        

    }
}
