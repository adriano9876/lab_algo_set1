﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace CrashRoyale.Model
{

    
  
        
 

    public class Rootobject
    {
        public List<Package> Package { get; set; } = new List<Package>();
    }

    public class Package
    {
        public string Nome { get; set; }
        public int Costo { get; set; }
         public List<Carte> Carte { get; set; } = new List<Carte>();
    }

    public class Carte
    {
        public string Nome { get; set; }
        public string Rarita { get; set; }
    }

}


