﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace CrashRoyale.Model
{
    public class Shop
    {

        public List<Package> Packages { get; set; }
        private readonly string _path = "C:\\Users\\e-giulio.pappalardo\\Desktop\\academy7\\MSC-Academy-Dev-7\\Weeks11_and_12_Specializations\\WPF_Specialization\\CrashRoyale\\CrashRoyale\\Datas\\dailypackages.json";
       
        public void InitiatePackage()
        {
            if (File.Exists(_path))
            {
                this.Packages = JsonSerializer.Deserialize<Rootobject>(File.ReadAllText(_path)).Package.ToList();
            }
          

        }
       
        //public void SavePackage()
        //{
        //    if (File.Exists(_path))
        //    {

        //        var jsonString = JsonSerializer.Serialize<OfferPack>(this, new JsonSerializerOptions { WriteIndented = true });
        //        if (File.Exists(_path))
        //        {
        //            File.WriteAllText(_path, jsonString);

        //        }
        //    }

        //}
    }
}
