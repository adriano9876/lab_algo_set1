﻿using CrashRoyale.Model;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security.RightsManagement;
using System.Text;
using System.Threading.Tasks;

namespace CrashRoyale.ViewModel
{
    public class MainViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler? PropertyChanged;
       

        public User _user = new User();
        public ShopWindowViewModel ShopWindowViewModel { get; set; } = new ShopWindowViewModel();
        public Package _selectedPackage;
        public MainViewModel()
        {
            _user.InitiateUser();
            
            
        }

        public string Username
        {
            get
            {
                return _user.Username;
            }
            set
            {
                _user.Username = value;
                OnPropertyChanged();
            }
        }
        public int Level
        {
            get
            {
                return _user.Level;
            }
            set
            {
                _user.Level = value;
                OnPropertyChanged();
            }
        }
        public int Gems
        {
            get
            {
                return _user.Gems;
            }
            set
            {
                _user.Gems = value;
                OnPropertyChanged();
            }
        }
        public bool IsInClan
        {
            get
            {
                return _user.IsInClan;
            }
            set
            {
                _user.IsInClan = value;
                OnPropertyChanged();
            }
        }
        protected virtual void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }


    }
}
