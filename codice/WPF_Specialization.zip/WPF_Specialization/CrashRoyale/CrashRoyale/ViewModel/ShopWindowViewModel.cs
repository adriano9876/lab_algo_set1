﻿using CrashRoyale.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace CrashRoyale.ViewModel
{
    public class ShopWindowViewModel : INotifyPropertyChanged
    {


        public ObservableCollection<Package> Packages { get; } = new ObservableCollection<Package>();
        public event PropertyChangedEventHandler? PropertyChanged ;
        public Shop _shop = new Shop();
        private Package _selectedPackage;

        public Package SelectedPackage
        {
            get => _selectedPackage;
            set
            {
                _selectedPackage = value;
                OnPropertyChanged();
            }

        }
        public Shop Shop
        {
            get=> _shop;
            set
            {
                _shop = value;
                OnPropertyChanged();
            }

        }

        public ShopWindowViewModel()
        {
            Shop.InitiatePackage();
            Shop.Packages.ForEach(x => this.Packages.Add(x));
        }

        protected virtual void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }


    }
}
