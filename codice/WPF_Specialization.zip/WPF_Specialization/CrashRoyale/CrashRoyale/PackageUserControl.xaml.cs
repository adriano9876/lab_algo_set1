﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CrashRoyale
{
    /// <summary>
    /// Interaction logic for PackageUserControl.xaml
    /// </summary>
    public partial class PackageUserControl : UserControl
    {
        public PackageUserControl()
        {
            InitializeComponent();
            InitializeComponent();
        }
        public static readonly DependencyProperty NameContentProperty =
           DependencyProperty.Register("NameContent",
               typeof(string),
               typeof(PackageUserControl),
               default);

        public string NameContent
        {
            get => (string)GetValue(NameContentProperty);
            set => SetValue(NameContentProperty, value);
        }

        public static readonly DependencyProperty PriceContentProperty =
           DependencyProperty.Register("PriceContent",
               typeof(int),
               typeof(PackageUserControl),
               default);

        public int PriceContent
        {
            get => (int)GetValue(PriceContentProperty);
            set => SetValue(PriceContentProperty, value);
        }
    }
}
