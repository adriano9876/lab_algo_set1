﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ValidationExerciseWpf.Models
{
    internal class User
    {
    }
}
