﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace ValidationExercise
{
    public class MainViewModel : BaseViewModel, IDataErrorInfo
    {

        private string _username;
        private string _email;
        private string _password;
        private int _age;
        private string _phoneNumber;
        public ICommand SubmitCommand { get; }

        public string Username { get => _username; set { _username = value; OnPropertyChanged(nameof(Username)); } }
        public string Email { get => _email; set { _email = value; OnPropertyChanged(nameof(Email)); } }
        public string Password { get => _password; set { _password = value; OnPropertyChanged(nameof(Password)); } }

        public int Age { get => _age; set { _age = value; OnPropertyChanged(nameof(Age)); } }
        public string PhoneNumber { get => _phoneNumber; set { _phoneNumber = value; OnPropertyChanged(nameof(PhoneNumber)); } }


        public MainViewModel()
        {
            SubmitCommand = new RelayCommand(ExecuteSubmit, CanExecuteSubmit);
        }

        private bool CanExecuteSubmit(object arg)
        {
            return IsFormValid();
        }

        private bool IsFormValid()
        {
            return ValidateUsername() == null &&
                   ValidateEmail() == null &&
                   ValidatePassword() == null &&
                   ValidateAge() == null;
        }
        private void ExecuteSubmit(object obj)
        {
            MessageBox.Show(
                $"Registrazione completata!\n\n" +
                $"Username: {Username}\n" +
                $"Email: {Email}\n" +
                $"Password: {new string('*', Password.Length)}\n" +
                $"Età: {Age}",
                "Successo",
                MessageBoxButton.OK,
                MessageBoxImage.Information);

          
            
        }

        public string this[string propertyName]
        {
            get
            {
                string error = null;

                switch (propertyName)
                {
                    case nameof(Username):
                        error = ValidateUsername();
                        break;

                    case nameof(Email):
                        error = ValidateEmail();
                        break;

                    case nameof(Password):
                        error = ValidatePassword();
                        break;
                    case nameof(Age):
                        error = ValidateAge();
                        break;


                }

                return error;
            }
        }

        private string? ValidateAge()
        {
            if (Age <= 0)
                return "L'età deve essere un valore positivo";

            if (Age < 18)
                return "Devi avere almeno 18 anni per registrarti";

            if (Age > 120)
                return "Età non valida";

            return null;
        }

        private string? ValidatePassword()
        {
            if (string.IsNullOrWhiteSpace(Password))
                return "La password è obbligatoria";

            if (Password.Length < 8)
                return "La password deve contenere almeno 8 caratteri";

            if (!Regex.IsMatch(Password, @"[A-Z]"))
                return "La password deve contenere almeno una lettera maiuscola";

            if (!Regex.IsMatch(Password, @"[a-z]"))
                return "La password deve contenere almeno una lettera minuscola";

            if (!Regex.IsMatch(Password, @"[0-9]"))
                return "La password deve contenere almeno un numero";

            if (!Regex.IsMatch(Password, @"[!@#$%^&*(),.?""':{}|<>]"))
                return "La password deve contenere almeno un carattere speciale";

            return null;
        }

        private string? ValidateEmail()
        {
            if (string.IsNullOrWhiteSpace(Email))
                return "L'email è obbligatoria";

            string emailPattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
            if (!Regex.IsMatch(Email, emailPattern))
                return "Formato email non valido";

            return null;
        }

        private string? ValidateUsername()
        {
            if (string.IsNullOrWhiteSpace(Username))
                return "L'username è obbligatorio";

            if (Username.Length < 3)
                return "L'username deve contenere almeno 3 caratteri";

            if (Username.Length > 20)
                return "L'username non può superare 20 caratteri";

            if (!Regex.IsMatch(Username, @"^[a-zA-Z0-9_]+$"))
                return "L'username può contenere solo lettere, numeri e underscore";

            return null;
        }

        public string Error => null;
    }
}
