using DatGrid_MVVM.Models;
using DatGrid_MVVM.Repository;
using System.Collections.ObjectModel;
using WPF_Subcriber.Interfaces;

namespace WPF_Subcriber.ViewModels
{
    public class PeopleListViewModel : BaseViewModel, ISearchResultObserver
    {
        #region Fields
        private ObservableCollection<Person> _people = new();
        #endregion

        #region Properties
        public ObservableCollection<Person> People
        {
            get => _people;
            set
            {
                if (_people != value)
                {
                    _people = value;
                    OnPropertyChanged(nameof(People));
                }
            }
        }
        #endregion

        #region Constructors
        public PeopleListViewModel()
        {
        }

        #endregion

        #region Methods
        public void Update(IEnumerable<Person> searchResults)
        {
            if (searchResults == null || !searchResults.Any())
            {
                return;
            }

            _people.Clear();
            foreach (var person in searchResults)
            {
                _people.Add(person);
            }
        }

        #endregion
    }
}