using System.Collections.Generic;
using DatGrid_MVVM.Models;

namespace DatGrid_MVVM.Repository
{
    public interface IPersonRepository
    {
        List<Person> GetAll();
        void Add(Person person);
        void Remove(Person person);
        List<Person> GetByName(string search);
    }
}
