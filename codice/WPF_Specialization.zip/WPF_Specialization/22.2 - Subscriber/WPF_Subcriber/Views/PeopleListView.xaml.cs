﻿using System.Windows.Controls;

namespace WPF_Subcriber.Views
{
    /// <summary>
    /// Interaction logic for PeopleListView.xaml
    /// </summary>
    public partial class PeopleListView : UserControl
    {
        public PeopleListView()
        {
            InitializeComponent();
        }
    }
}
