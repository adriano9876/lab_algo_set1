﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            this.FirstButton.Margin = new Thickness(1, 2, 3, 4);
            this.FirstButton.Content = "FirstButtonContent";
        }

       

        

        private void FirstButton_Click(object sender, RoutedEventArgs e)
        {
       
          
       

            if (int.TryParse(this.first.Text, out int first) && int.TryParse(this.second.Text, out int second))
            {
                var sum = first + second;
                this.firstlabel.Content = sum;

            }
            else
            {
                this.firstlabel.Foreground = new SolidColorBrush(Colors.Red);
                this.firstlabel.FontWeight = FontWeights.Bold;
                this.firstlabel.FontSize = 30;
            

                this.firstlabel.Content = "Invalid input";
                
            }
           
            
        }

      
    }
}