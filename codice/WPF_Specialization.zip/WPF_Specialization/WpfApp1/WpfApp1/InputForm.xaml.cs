﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for InputForm.xaml
    /// </summary>
    public partial class InputForm : Window
    {
        public InputForm()
        {
            InitializeComponent();
            this.LabelName.checkempty.TextChanged += Checkempty_TextChanged;

            this.role.Items.Add("Developer");
            this.role.Items.Add("Tester");
        }

        private void Checkempty_TextChanged(object sender, TextChangedEventArgs e)
        {
            CheckAll();
        }

        private  void ChangeColor()
        {
            var list = new List<SolidColorBrush>();

            list.Add(new SolidColorBrush(Colors.Green));
            list.Add(new SolidColorBrush(Colors.Yellow));
            list.Add(new SolidColorBrush(Colors.Beige));
            list.Add(new SolidColorBrush(Colors.Red));
            list.Add(new SolidColorBrush(Colors.Bisque));
            list.Add(new SolidColorBrush(Colors.WhiteSmoke));


            this.total.Background = list.OrderBy(arg => Guid.NewGuid()).Take(list.Count()).FirstOrDefault();
            
           
            
        }
        private void Submit_Click(object sender, RoutedEventArgs e)
        {
          this.totalstack.Visibility = Visibility.Collapsed;
            ChangeColor();

           
        }

      
        private void CheckAll()
        {
            var a  = this.LabelName.checkempty.Text.ToString();
            if (!string.IsNullOrEmpty(a))
            {
                if (this.errorlabel.Content.ToString() == "Seniority Ok!") { this.Submit.IsEnabled = true; }
            }

           
        }
        private void role_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var a = e.AddedItems;
            if (a[0].ToString().Equals("Developer")) 
            {
                ChangeColor();
                
            }
            if (string.IsNullOrEmpty( a[0].ToString()))
            {
                
                CheckAll();
            }
            CheckAll();
        }

        private void SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            var from = this.From.SelectedDate;
            var to = this.To.SelectedDate;
            var delta = to - from;
            if (delta < new TimeSpan(0, 0, 0, 0))
            {
                this.seniority.IsChecked = false;
                this.errorlabel.Visibility = Visibility.Visible;
                this.errorlabel.Content = "Set a correct time span";
                this.errorlabel.Foreground = new SolidColorBrush(Colors.Red);
            }
            if (delta > new TimeSpan(365, 0, 0, 0))
            {

                this.seniority.IsChecked = true;
                this.errorlabel.Visibility = Visibility.Visible;
                this.errorlabel.Content = "Seniority Ok!";
                CheckAll();
                
                this.errorlabel.Foreground = new SolidColorBrush(Colors.Green);
            }
            if (delta < new TimeSpan(365, 0, 0, 0) || delta == null)
            {
                this.seniority.IsChecked = false;
                this.errorlabel.Visibility = Visibility.Visible;
                this.errorlabel.Content = "Error";
                this.errorlabel.Foreground = new SolidColorBrush(Colors.Red);
            }

        }

       
    }
}
