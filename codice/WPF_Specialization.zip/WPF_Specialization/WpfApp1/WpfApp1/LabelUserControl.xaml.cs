﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for LabelUserControl.xaml
    /// </summary>
    public partial class LabelUserControl : UserControl
    {
        public LabelUserControl()
        {
            InitializeComponent();
        }
        public static readonly DependencyProperty LabelTextProperty =

   DependencyProperty.Register(

       "LabelText",

       typeof(string),

       typeof(LabelUserControl)

       

   );

        public string LabelText

        {

            get => (string)GetValue(LabelTextProperty);

            set => SetValue(LabelTextProperty, value);

        }

        private void checkempty_LostFocus(object sender, RoutedEventArgs e)
        {
            
            if (string.IsNullOrEmpty(this.checkempty.Text.ToString()))
            {
                this.nameerror.Visibility = Visibility.Visible;
                this.nameerror.Content = "Field must not be empty";
                this.nameerror.Foreground = new SolidColorBrush(Colors.Red);
            }

            if (!string.IsNullOrEmpty(this.checkempty.Text.ToString()))
            {
                this.nameerror.Visibility = Visibility.Collapsed;
              
            }
        }
    }
}
