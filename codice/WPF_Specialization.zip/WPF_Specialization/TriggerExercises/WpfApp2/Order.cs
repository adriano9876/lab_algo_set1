﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace WpfApp2
{
    public class Order
    {
        public Order(int id, string item, string status, bool isCritical, string shippingMethod, string brand)
        {
            Id = id;
            Item = item;
            Status = status;
            IsCritical = isCritical;
            ShippingMethod = shippingMethod;
            Brand = brand;
        }

        public  int Id {  get; set; }
        public string Item { get; set; }
        public  string Status { get; set; }
        public bool IsCritical { get; set; }
        public string ShippingMethod { get; set; }
        public string Brand { get; set; }






       

    }
  

   
}
