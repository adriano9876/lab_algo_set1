﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;

namespace WpfApp2
{
    public class MainViewModel : BaseViewModel
    {
        private string _backgroundColor = "#FFFFFF";
        public ICommand SortByItemCommand { get; }
        public ICommand DeleteSorting { get; }
        public ObservableCollection<Order> Orders { get; } = new ObservableCollection<Order>();
        public ObservableCollection<string> StaticShipmentMethods { get; } = new ObservableCollection<string> { "Boat", "Airplane", "Truck" };
        private string _searchText;
        private ICollectionView _ordersView;


        public string BackgroundColor
        {
            get => _backgroundColor;
            set
            { _backgroundColor = value; OnPropertyChanged(nameof(BackgroundColor)); }
        }

        public string SearchText
        {
            get => _searchText;
            set
            {
                _searchText = value; 
                OnPropertyChanged(nameof(SearchText));

                OrdersView.Refresh();

             

            }
        }

        public MainViewModel()
        {

            InitializeOrderList();

            OrdersView = CollectionViewSource.GetDefaultView(Orders);
            OrdersView.Filter = FilterOrders;
            SortByItemCommand = new RelayCommand(x => SortByItem());
            DeleteSorting = new RelayCommand(x => RemoveSorting());
        }

        private void SortByItem()
        {
          
            OrdersView.SortDescriptions.Add(new SortDescription("Item", ListSortDirection.Ascending));
            
        }
        private void RemoveSorting()
        {
            OrdersView.SortDescriptions.Clear();
        }

        public ICollectionView OrdersView
        {
            get => _ordersView;
            set
            {
                _ordersView = value;
                OnPropertyChanged(nameof(OrdersView));
            }
        }
        public void InitializeOrderList()
        {
            this.Orders.Add(new Order(1, "Pc", "Pending", true, "Boat", "Corsair"));
            this.Orders.Add(new Order(2, "Ram", "Delivered", false, "Boat", "HyperX"));
            this.Orders.Add(new Order(3, "Cpu", "Payment Required", true, "Boat", "Intel"));
            this.Orders.Add(new Order(4, "Gpu", "Pending", true, "Boat", "Msi"));
            this.Orders.Add(new Order(5, "Fan", "Out for delivery", false, "Boat", "ThermalTake"));
            this.Orders.Add(new Order(6, "Power System", "Pending", true, "Boat", "Cooler Master"));
            this.Orders.Add(new Order(7, "Monitor", "Cancelled", false, "Boat", "Logitech"));
            this.Orders.Add(new Order(8, "Mouse", "Returned", false, "Boat", "Glorious"));


        }
        private bool FilterOrders(object obj)
        {
            if (string.IsNullOrEmpty(SearchText))
            {
                return true;
            }
            else
            {
                if (obj is Order order)
                {
                    string itemToLower = order.Item.ToLower();
                    string searchTextToLower = SearchText.ToLower();
                    return itemToLower.Contains(SearchText);
                }
            }
            return false;
        }
    }
}
