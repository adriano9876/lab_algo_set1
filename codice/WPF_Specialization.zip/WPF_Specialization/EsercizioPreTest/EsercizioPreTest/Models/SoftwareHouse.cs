﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace EsercizioPreTest.Models
{
   public class SoftwareHouse : INotifyPropertyChanged
    {
        private string _name;
        private string _location;
        private int _rating;

        public string Name { get => _name; set { _name = value; OnPropertyChanged(nameof(Name)); }  }
        public string Location { get => _location; set { _location = value; OnPropertyChanged(nameof(Location)); } }
        public int Rating { get => _rating; set { _rating = value; OnPropertyChanged(nameof(Rating)); } }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}

