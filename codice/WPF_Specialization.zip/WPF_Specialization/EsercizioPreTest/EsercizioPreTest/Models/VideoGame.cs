﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace EsercizioPreTest.Models
{
    public class VideoGame : INotifyPropertyChanged
    {

        private string _title;
        private int _requiredSpace;
        private string _softwareHouse;
        private string _genre;

        public string Title { get => _title; set { _title = value; OnPropertyChanged(nameof(Title)); } }
        public int RequiredSpace { get => _requiredSpace; set { _requiredSpace = value; OnPropertyChanged(nameof(RequiredSpace)); } }
        
        public string Genre { get => _genre; set { _genre = value; OnPropertyChanged(nameof(Genre)); } }

        public string SoftwareHouse { get => _softwareHouse; set { _softwareHouse = value; OnPropertyChanged(nameof(SoftwareHouse)); }  }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}

