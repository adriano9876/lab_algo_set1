﻿using EsercizioPreTest.DataAccess;
using EsercizioPreTest.Models;
using EsercizioPreTest.Views;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace EsercizioPreTest.ViewModels
{
    public class MainViewModel : ViewModelBase
    {

        private readonly RepositoryVideoGames _repo;
        public ObservableCollection<VideoGame> VideoGames { get; set; } = new ObservableCollection<VideoGame>();

        private VideoGame _selectedVideoGame;

        public ICommand OpenDialogCommand { get; }
        public ICommand RemoveVideoGameCommand { get; }
        public VideoGame SelectedVideoGame { get => _selectedVideoGame; set { _selectedVideoGame = value; OnPropertyChanged(nameof(SelectedVideoGame)); } }

        public MainViewModel()
        {

            _repo = new RepositoryVideoGames();
            foreach (var item in _repo.LoadVideoGames())
            {
                VideoGames.Add(item);
            }

            OpenDialogCommand = new RelayCommand(x => OpenDialog());
            RemoveVideoGameCommand = new RelayCommand(x => RemoveVideoGame());
        }

        private void OpenDialog()
        {
            var addVideoGameDialog = new AddVideoGameDialog();
            var addVideoGameViewModel = new AddVideoGameViewModel();
            addVideoGameDialog.DataContext = addVideoGameViewModel;

            if (addVideoGameDialog.ShowDialog() == true)
            {
                _repo.AddVideoGame(addVideoGameViewModel.NewVideoGame);
                VideoGames.Add(addVideoGameViewModel.NewVideoGame);
            }



        }

        private void RemoveVideoGame()
        {
            _repo.RemoveVideoGame(SelectedVideoGame);
            VideoGames.Remove(SelectedVideoGame);
        }
    }
}
