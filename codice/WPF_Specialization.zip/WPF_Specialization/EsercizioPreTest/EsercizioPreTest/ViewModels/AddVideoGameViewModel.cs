﻿using EsercizioPreTest.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace EsercizioPreTest.ViewModels
{
    public class AddVideoGameViewModel : ViewModelBase
    {

        private string _gameTitle;
        private int _gameRequiredSpace;
        private string _gameGenre;
        private string _gameSoftwareHouse;
        private Window _window;




        public VideoGame NewVideoGame { get; set; }
        public string GameTitle { get => _gameTitle; set { _gameTitle = value; OnPropertyChanged(nameof(GameTitle)); } }
        public int GameRequiredSpace { get => _gameRequiredSpace; set { _gameRequiredSpace = value; OnPropertyChanged(nameof(GameRequiredSpace)); } }
        public string GameGenre { get => _gameGenre; set { _gameGenre = value; OnPropertyChanged(nameof(GameGenre)); } }
        public string GameSoftwareHouse { get => _gameSoftwareHouse; set { _gameSoftwareHouse = value; OnPropertyChanged(nameof(GameSoftwareHouse)); } }

        public ObservableCollection<string> Genres { get; set; }

        public ICommand AddVideoGameCommand { get; set; }
        public ICommand LoadedWindow { get; set; }



        public AddVideoGameViewModel()
        {
            NewVideoGame = new VideoGame();
            Genres = new ObservableCollection<string>() { "Action", "Thriller", "Moba" };

            AddVideoGameCommand = new RelayCommand(AddVideoGame);



        }


        private void AddVideoGame(object parameter)
        {
            NewVideoGame.Title = GameTitle;
            NewVideoGame.RequiredSpace = GameRequiredSpace;
            NewVideoGame.SoftwareHouse = GameSoftwareHouse;
            NewVideoGame.Genre = GameGenre;
            var window = parameter as Window;
            if (window != null)
            {
                window.DialogResult = true;
                window.Close();
            }
        }
    }
}
