﻿using EsercizioPreTest.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace EsercizioPreTest.DataAccess
{
    public class RepositoryVideoGames
    {
        private readonly string _filePath = "C:\\Users\\giuli\\source\\repos\\EsercizioPreTest\\EsercizioPreTest\\DataAccess\\VideoGames.json";
        private JsonSerializerOptions _serializerOptions;
        public ObservableCollection<VideoGame> VideoGames {  get; set; }


        public RepositoryVideoGames()
        {
            _serializerOptions = new JsonSerializerOptions()
            {
                WriteIndented = true,
                PropertyNameCaseInsensitive = true,
            };
            VideoGames = new ObservableCollection<VideoGame>();
            VideoGames.Clear();
            var videogamesrepo = LoadVideoGames();
            foreach(var game in videogamesrepo)
            {
                VideoGames.Add(game);
            }
        }
        public void AddVideoGame(VideoGame vg)
        {
            VideoGames.Add(vg);
            SaveVideoGames();
        }
        public void RemoveVideoGame(VideoGame vg)
        {
            var toDelete = VideoGames.FirstOrDefault(x => x.Title == vg.Title);
            VideoGames.Remove(toDelete);
            SaveVideoGames();
        }

        public List<VideoGame> LoadVideoGames()
        {
            if (!File.Exists(_filePath))
            {
                return new List<VideoGame>();
            }
            string jsonString = File.ReadAllText(_filePath);
            var videogames = JsonSerializer.Deserialize<List<VideoGame>>(jsonString, _serializerOptions);
            return videogames.ToList();
        }

        public void SaveVideoGames()
        {
            string jsonString = JsonSerializer.Serialize(this.VideoGames, _serializerOptions);
            File.WriteAllText(_filePath, jsonString);
        }

    }
}
