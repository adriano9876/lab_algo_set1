﻿using AsyncExampleWpf.Models;
using AsyncExampleWpf.ViewModels.Command;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Security.RightsManagement;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;
using System.Windows.Input;

namespace AsyncExampleWpf.ViewModels
{
    public class MainViewModel : BaseViewModel
    {

        public ICommand ShowAllUsers {get;}
        public ICommand ShowAllUsersAsync {get;}
        public ICommand Clear {get;}

        public UserRepository UserRepository {get;set;}

        public ObservableCollection<User> Users { get; set; } = new ObservableCollection<User>();

        public MainViewModel()
        {
            ShowAllUsers = new RelayCommand(ExecuteHeavySearch);
            ShowAllUsersAsync = new RelayCommand(ExecuteAsyncSearch);
            Clear = new RelayCommand(ExecuteClear);

            UserRepository = new UserRepository();  
        }

        private void ExecuteClear(object obj)
        {
            Users.Clear();

        }

        private async void ExecuteAsyncSearch(object obj)
        {
            var userList = await  UserRepository.GetAllAsync(CancellationToken.None);
            Users.Clear();
            userList.ForEach(a => Users.Add(a));
        }

        private void ExecuteHeavySearch(object obj)
        {
            Users.Clear();
            var userList = UserRepository.GetAll_VeryHeavy();
            userList.ForEach(a => Users.Add(a));
        }
    }
}
