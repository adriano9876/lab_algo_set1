﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;

namespace AsyncExampleWpf.Models
{
    public class UserRepository
    {
        private readonly List<User> _people = new()
        {
            new User(1,"Alice","mail@mail.com","Username")
           ,
            new User(2,"Marco","mail@mail.com","Username1")
           ,
            new User(3,"Francesco","mail@mail.com","Username2")
           ,
            new User(4,"Marta","mail@mail.com","Username3")
           ,
            new User(5,"Antonio","mail@mail.com","Username4")
           ,
            new User(6,"Betta","mail@mail.com","Username5")
           ,

        };

        public List<User> GetAll_VeryHeavy()
        {
            var fib = SlowFibonacci(43); // Simulate a slow operation
            return _people;
        }

        public async Task<List<User>> GetAllAsync(CancellationToken cancellationToken)
        {
            // Simulate async operation with cancellation support
            await Task.Delay(5000, cancellationToken); // Optional: simulate latency
            return _people;
        }

        // Returns people whose name or last name contains the given string (case-insensitive)
        public List<User> GetByName(string search)
        {
            if (string.IsNullOrWhiteSpace(search))
            {
                return _people;
            }

            var lower = search.ToLowerInvariant();
            return _people.Where(p =>
                (!string.IsNullOrEmpty(p.Name) && p.Name.ToLowerInvariant().Contains(lower)) 
            ).ToList();
        }



        private static long SlowFibonacci(int n)
        {
            // This recursive approach is intentionally inefficient
            if (n <= 1)
                return n;

            return SlowFibonacci(n - 1) + SlowFibonacci(n - 2);
        }

    }
}

