﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AsyncExampleWpf.Models
{
   public class User
    {
        public User(int id, string name, string email, string userName)
        {
            Id = id;
            Name = name;
            Email = email;
            
            UserName = userName;
        }

        public int Id { get; set; }
        public string Name { get; set; }    
        public string Email { get; set; }
    
        public string UserName { get; set; }

      

    }
}
