﻿using Prism.Events;
using Prism_MVVM.Models;

namespace Prism_MVVM.EventAggregator
{
    public class EmployeeEvent : PubSubEvent<IEnumerable<Employee>>
    {

    }
}
