﻿namespace Prism_MVVM.ViewModels.Interfaces
{
    public interface ISumViewModel
    {
        string FullNames { get; set; }
        int AgeSum { get; set; }
        double SalarySum { get; set; }
    }
}
