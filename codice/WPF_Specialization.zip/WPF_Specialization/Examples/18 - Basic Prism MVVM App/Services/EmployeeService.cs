﻿using Prism_MVVM.Models;

namespace Prism_MVVM.Services
{
    public class EmployeeService : IEmployeeService
    {
        public IList<Employee> GetAllEmployees()
        {
            return new List<Employee>
            {
                new Employee {FirstName = "Carlo", LastName = "Carli", Age = 28, Salary = 1500, IsManager = false },
                new Employee {FirstName = "Giorgia", LastName = "Giorgi", Age = 45, Salary = 2500, IsManager = true },
                new Employee {FirstName = "Marco", LastName = "Marchi", Age = 21, Salary = 1000, IsManager = false },
                new Employee {FirstName = "Yin", LastName = "Yan", Age = 23, Salary = 1120, IsManager = false },
                new Employee {FirstName = "Paolo", LastName = "Paoli", Age = 55, Salary = 3400, IsManager = true }
            };
        }
    }
}
