﻿using Prism_MVVM.Models;

namespace Prism_MVVM.Services
{
    public interface IEmployeeService
    {
        IList<Employee> GetAllEmployees();
    }
}
