﻿using Prism.DryIoc;
using Prism.Ioc;
using Prism_MVVM.Services;
using Prism_MVVM.ViewModels;
using Prism_MVVM.ViewModels.Dialogs;
using Prism_MVVM.ViewModels.Interfaces;
using Prism_MVVM.Views;
using Prism_MVVM.Views.Dialogs;
using System.Windows;

namespace Prism_MVVM
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : PrismApplication
    {
        protected override Window CreateShell()
        {
            return Container.Resolve<LoginView>();
        }

        protected override void RegisterTypes(IContainerRegistry containerRegistry)
        {
            // Register Services
            containerRegistry.RegisterSingleton<IEmployeeService, EmployeeService>();

            // Register Types
            containerRegistry.Register<ISumViewModel, SumViewModel>();

            // Register Dialogs
            containerRegistry.RegisterDialog<DialogView, DialogViewModel>();
        }
    }
}
