﻿using System.Windows.Controls;

namespace Prism_MVVM.Views.Dialogs
{
    /// <summary>
    /// Interaction logic for DialogView.xaml
    /// </summary>
    public partial class DialogView : UserControl
    {
        public DialogView()
        {
            InitializeComponent();
        }
    }
}
