﻿using Prism_MVVM.ViewModels.Interfaces;
using System.Windows.Controls;

namespace Prism_MVVM.Views
{
    /// <summary>
    /// Interaction logic for SumView.xaml
    /// </summary>
    public partial class SumView : UserControl
    {
        public SumView(ISumViewModel sumViewModel)
        {
            DataContext = sumViewModel;
            InitializeComponent();
        }
    }
}
