﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObserverPatternWpf.ViewModels
{
    public class MainViewModel :BaseViewModel
    {
        private OrderListViewModel _orderListViewModel;
        private OrderSearchViewModel _orderSearchViewModel;


        public OrderSearchViewModel OrderSearchViewModel
        {
            get => _orderSearchViewModel;
            set
            {
                _orderSearchViewModel = value;
                OnPropertyChanged(nameof(OrderSearchViewModel));
               
            }
        }

        public OrderListViewModel OrderListViewModel
        {
            get => _orderListViewModel;
            set
            {
                _orderListViewModel = value;
                OnPropertyChanged(nameof(OrderListViewModel));

            }
        }

        public MainViewModel()
        {
            _orderListViewModel = new OrderListViewModel();
            _orderSearchViewModel = new OrderSearchViewModel();
            _orderSearchViewModel.Attach(_orderListViewModel);
        }


    }
}
