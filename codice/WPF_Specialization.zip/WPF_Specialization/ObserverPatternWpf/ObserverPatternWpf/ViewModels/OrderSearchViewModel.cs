﻿using ObserverPatternWpf.Commands;
using ObserverPatternWpf.DataAccess;
using ObserverPatternWpf.ViewModels.Interfaces;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace ObserverPatternWpf.ViewModels
{
    public class OrderSearchViewModel : BaseViewModel
    {
        private string _searchOrder;
        private List<ISearchResultObserver> _observers;
        private readonly Repository _orderRepository;
        public ICommand SearchCommand { get;}

        public OrderSearchViewModel()
        {
            _observers = new();
            
            _orderRepository = new Repository();
            SearchCommand = new RelayCommand(_ => Search());
        }

       

        public string SearchOrder
        {
            get => _searchOrder;
            set
            {
                if (_searchOrder != value)
                {
                    _searchOrder= value;
                    OnPropertyChanged(nameof(SearchOrder));
                }
            }
        }
        public void Attach(ISearchResultObserver observer)
        {
            if (!_observers.Contains(observer))
            {
                _observers.Add(observer);
            }
        }
        public void Detach(ISearchResultObserver observer)
        {
            if (_observers.Contains(observer))
            {
                _observers.Remove(observer);
            }
        }
        private void Search()
        {
            var orderItem = SearchOrder?.Trim();
            var orders = _orderRepository.GetOrdersByItemName(orderItem);
            foreach (var observer in _observers)
            {
                observer.Update(orders);
            }
        }

    }
}

