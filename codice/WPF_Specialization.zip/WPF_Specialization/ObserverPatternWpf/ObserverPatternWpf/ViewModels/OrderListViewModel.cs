﻿using ObserverPatternWpf.Models;
using ObserverPatternWpf.ViewModels.Interfaces;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObserverPatternWpf.ViewModels
{
    public class OrderListViewModel : BaseViewModel, ISearchResultObserver
    {
        private ObservableCollection<Order> _orders = new();

        public ObservableCollection<Order> Orders
        {
            get => _orders;
            //set
            //{
            //    if (_orders != value)
            //    {
            //        _orders = value;
            //        OnPropertyChanged(nameof(Orders));
            //    }
            //}
               
        }

        public OrderListViewModel()
        {
            
        }

        public void Update(IEnumerable<Order> searchResult)
        {
            if(searchResult == null|| !searchResult.Any())
            {
                return;
            }
            _orders.Clear();
            foreach (var item in searchResult)
            {
                _orders.Add(item);
            }
        }
    }
}
