﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalExerciseExample.Models
{
    public class IngredientModel
    {
        public string Name { get; set; }
        public int Quantity { get; set; }

        public IngredientModel(string name, int quantity)
        {
            Name = name;
            Quantity = quantity;
        }
    }
}
