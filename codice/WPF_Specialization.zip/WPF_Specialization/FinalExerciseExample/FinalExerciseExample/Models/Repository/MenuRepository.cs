﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalExerciseExample.Models.Repository
{
    public class MenuRepository
    {
        public ObservableCollection<DishModel> Dishes { get; set; }
        public ObservableCollection<IngredientModel> Ingredients { get; set; }

        public MenuRepository()
        {


            Ingredients = new ObservableCollection<IngredientModel>()
            {
                new IngredientModel("Flour", 1000 ),
                new IngredientModel("Salt", 20 ),
                new IngredientModel("Tomato", 2000 ),
                new IngredientModel("Pepper", 10 ),
                new IngredientModel("Rice", 500 ),
                new IngredientModel("Cheese", 300 ),
                new IngredientModel("Oil", 100 )
            };
            Dishes = new ObservableCollection<DishModel>()
            {
                new DishModel(1,"Pizza",new List<IngredientModel>(){Ingredients[0] ,Ingredients[1],Ingredients[2] },12,false),
                new DishModel(2,"Chili Rice",new List<IngredientModel>(){Ingredients[6] ,Ingredients[5],Ingredients[3] },12,false),
                new DishModel(3,"Tomato Rice",new List<IngredientModel>(){Ingredients[1] ,Ingredients[4],Ingredients[6] },12,true),
                new DishModel(4,"Bread",new List<IngredientModel>(){Ingredients[0] ,Ingredients[1],Ingredients[6] },12,true),
            };
        }

        public ObservableCollection<DishModel> GetAllDishes()
        {
            return Dishes;
        }

        public void AddDish(DishModel newDish)
        {
            Dishes.Add(newDish);
        }
        public ObservableCollection<IngredientModel> GetAllIngredients()
        {
            return Ingredients;
        }
    }
}
