﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalExerciseExample.Models
{
    public class DishModel
    {

        public int Id { get; set; }
        public string Name { get; set; }
        public List<IngredientModel> ingredients;
        public double Price { get; set; }
        public bool IsVegan { get; set; }

        public DishModel(int id, string name, List<IngredientModel> ingredients, double price, bool isVegan)
        {
            Id = id;
            Name = name;
            this.ingredients = ingredients;
            Price = price;
            IsVegan = isVegan;
        }
    }
}
