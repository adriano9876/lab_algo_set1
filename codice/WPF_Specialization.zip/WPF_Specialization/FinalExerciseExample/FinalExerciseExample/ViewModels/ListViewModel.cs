﻿using FinalExerciseExample.Commands;
using FinalExerciseExample.Models;
using FinalExerciseExample.Models.Repository;
using FinalExerciseExample.Views;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;
using System.Windows.Input;

namespace FinalExerciseExample.ViewModels
{
    public class ListViewModel : ViewModelBase
    {
        public ObservableCollection<DishModel> Dishes { get;  }
        public MenuRepository _repo;
        public ICommand OpenDialogCommand { get; }


        public ListViewModel()
        {
            _repo = new MenuRepository();
            Dishes = new ObservableCollection<DishModel>();  
            Dishes = _repo.GetAllDishes();
            OpenDialogCommand = new RelayCommand(x=>OpenDishAddDialog());

        }

        private void OpenDishAddDialog()
        {
            var window = new DialogView();
            window.ShowDialog();
        }

        //private object AddDish()
        //{
        //    _repo.AddDish(dish);
        //}
    }
}
