﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace FinalExerciseExample.ViewModels
{
    public class MainViewModel : ViewModelBase
    {
        private InsertDishViewModel _insertDishViewModel;
        private ListViewModel _listViewModel;
       

        public MainViewModel()
        {
            ListViewModel = new ListViewModel();
            InsertDishViewModel = new InsertDishViewModel();
        }

        public InsertDishViewModel InsertDishViewModel { get => _insertDishViewModel; set { _insertDishViewModel = value; OnPropertyChanged(nameof(InsertDishViewModel)); }  }
        public ListViewModel ListViewModel { get => _listViewModel; set { _listViewModel = value; OnPropertyChanged(nameof(ListViewModel)); }  }



    }
}
