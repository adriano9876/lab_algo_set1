﻿using Accessibility;
using FinalExerciseExample.Commands;
using FinalExerciseExample.Models;
using FinalExerciseExample.Models.Repository;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace FinalExerciseExample.ViewModels
{
    public class InsertDishViewModel : ViewModelBase
    {
        private MenuRepository _repo;
        private string name;
        private double price;
        private int id;
        private bool isVegan;

        private ObservableCollection<IngredientModel> AvailbleIngredients = new ObservableCollection<IngredientModel>();
        private ObservableCollection<IngredientModel> _selectedIngredients = new();

        public ICommand SaveDishCommand {  get;  }



       
        public MenuRepository Repo { get => _repo; set => _repo = value; }
        public string Name { get => name; set => name = value; }
        public double Price { get => price; set => price = value; }
        public bool IsVegan { get => isVegan; set => isVegan = value; }
        public int Id { get => id; set { id = value; OnPropertyChanged(nameof(Id)); } }

        public  InsertDishViewModel()
        {
            Repo = new MenuRepository();
            AvailbleIngredients = _repo.GetAllIngredients();
            SaveDishCommand = new RelayCommand(x => SaveDish());
        }

        private void SaveDish()
        {
            var dish = new DishModel(Id, Name, new List<IngredientModel>(), 200, IsVegan);
           _repo.AddDish(dish);
        }
    }
}
