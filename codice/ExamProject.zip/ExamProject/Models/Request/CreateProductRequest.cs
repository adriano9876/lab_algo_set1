﻿using System.ComponentModel.DataAnnotations.Schema;

namespace ExamProject.Models.Request
{
    public class CreateProductRequest
    {
        public string Name { get; set; }
        public string? Description { get; set; }

        public decimal Price { get; set; }
        
        public bool IsAvailable { get; set; }

        // Foreign Key for 1:N relationship
        public int CategoryId { get; set; }
        // Navigation property (1:N)
        

    }
}
