using ExamProject.Data;
using ExamProject.Models;

using ExamProject.Models.Request;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

namespace ExamProject.Controllers;

[Route("api/[controller]")]
[ApiController]
public class StoreController : ControllerBase
{
    private readonly AppDbContext _context;

    public StoreController(AppDbContext context)
    {
        _context = context;
    }

    // -----------------------------------------------------------------
    // TASK 2.1: GetProductById (10 Points)
    // Implement this method
    // -----------------------------------------------------------------
    [HttpGet("{id}")]
    public async Task<ActionResult<Product>> GetProductById(int id)
    {
        // STUDENT TODO:
        // 1. Find the product by id.
        // 2. Use Eager Loading (Include/ThenInclude) to load Category AND Tags.
        // 3. If not found, return NotFound().
        // 4. Return the product.
        var product = await _context.Products.AsNoTracking()
            .Include(w => w.ProductTags)
            .ThenInclude(w => w.Tag)
            .Include(w => w.Category)
            .SingleOrDefaultAsync(w => w.ProductId == id);

        if (product == null) { return NotFound(); }
        return Ok(product);


    }

    // -----------------------------------------------------------------
    // TASK 2.2: SearchProducts (10 Points)
    // Implement this method
    // -----------------------------------------------------------------
    [HttpGet("search")]
    public async Task<ActionResult<IEnumerable<Product>>> SearchProducts(
        [FromQuery] string? searchTerm,
        [FromQuery] decimal? minPrice)
    {
        var query = _context.Products.AsQueryable();
        if (!string.IsNullOrWhiteSpace(searchTerm))
        {
            query = query.Where(p => p.Name.Contains(searchTerm) ||
                                     p.Description.Contains(searchTerm));
        }


        if (minPrice.HasValue)
        {
            query = query.Where(p => p.Price >= minPrice.Value);
        }


        query = query.AsNoTracking();

        var products = await query.ToListAsync();

        return Ok(products);
    }

    // -----------------------------------------------------------------
    // TASK 2.3: GetCategoryStatistics (10 Points)
    // Implement this method
    // -----------------------------------------------------------------
    [HttpGet("statistics")]
    public async Task<IActionResult> GetCategoryStatistics()
    {
        // STUDENT TODO:
        // 1. Query the Categories.
        // 2. Use .Select() to project the results into a new anonymous object (or DTO).
        // 3. The new object should have:
        //    - CategoryName (from category.Name)
        //    - ProductCount (using category.Products.Count())
        // 4. Execute and return the list.
        var categories = _context.Categories
          .AsNoTracking()
          .Select(a => new
          {
              Name = a.Name,
              ProductCount = a.Products.Count()



          });
        var tolist = await categories.ToListAsync();
        return Ok(tolist);


    }

    // -----------------------------------------------------------------
    // TASK 3: CreateProduct (15 Points)
    // Implement this method
    // -----------------------------------------------------------------
    [HttpPost]
    public async Task<ActionResult<Product>> CreateProduct(CreateProductRequest product)
    {
        // STUDENT TODO:
        // 1. Add the 'product' entity to the DbContext.
        // 2. Save the changes to the database.
        // 3. Return a 201 Created response using CreatedAtAction.
        //    Hint: nameof(GetProductById)_
        if( await _context.Categories.SingleAsync(a=>a.CategoryId==product.CategoryId) == null) { return BadRequest("Categoria non trovata"); }
        var producttoadd = new Product
        {
            CategoryId = product.CategoryId,
            Name = product.Name,
            Description = product.Description,
            Price = product.Price,
            IsAvailable = product.IsAvailable,
            DateAdded = DateTime.UtcNow
        };
          
        _context.Products.Add(producttoadd);

        await _context.SaveChangesAsync();
        return CreatedAtAction(nameof(GetProductById), new { id = producttoadd.ProductId},producttoadd);
        throw new NotImplementedException();
    }
}