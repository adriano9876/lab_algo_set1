﻿using Microsoft.EntityFrameworkCore;
using SqlAndEf.ExamProject.DataAccess.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlAndEf.ExamProject.DataAccess
{
    public class UniversityDbContext : DbContext
    {
        /*
         * DBCONTEXT CONFIGURATION:
         * - Entities
         * - Relationships
         * - Migrations
         * - Seeding
         */
        public UniversityDbContext(): base() { }    

        public UniversityDbContext(DbContextOptions<UniversityDbContext> options) : base(options)
        {
        }

        public DbSet <Corso> Corsos { get; set; }
        public DbSet <Docente> Docentes { get; set; }
        public DbSet <Studente> Studentes { get; set; }



        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            modelBuilder.Entity<Corso>().HasData(
                    new Corso { Id = 1, Nome = "fisica 1", CfuTotali = 10, DocenteId = 2 ,OreLezioniPreviste =100 },
                    new Corso { Id = 2, Nome = "chimica 1", CfuTotali = 10, DocenteId = 3 ,OreLezioniPreviste =50 },
                    new Corso { Id = 3, Nome = "analisi 1", CfuTotali = 10, DocenteId = 1 ,OreLezioniPreviste =50 }
            );


            modelBuilder.Entity<Studente>().HasData(
                new Studente { Id = 1, Cognome = "darius", Matricola = "10010", DataImmatricolazione = new DateOnly(2000, 1, 1), Genere = "m" },
                new Studente { Id = 2, Cognome = "luca", Matricola = "10020", DataImmatricolazione = new DateOnly(2005, 1, 1), Genere = "m" },
                new Studente { Id = 3, Cognome = "sara", Matricola = "10030", DataImmatricolazione = new DateOnly(2006, 1, 1), Genere = "f" }
            );

            modelBuilder.Entity<Docente>().HasData(
                new Docente { Id = 1, Cognome ="rossi", DataAssunzione = new DateOnly(1995,1,1), Specializzazione = "matematica" },
                new Docente { Id = 2, Cognome ="agostino", DataAssunzione = new DateOnly(1994,1,1), Specializzazione = "fisica" },
                new Docente { Id = 3, Cognome ="balotelli", DataAssunzione = new DateOnly(1996,1,1), Specializzazione = "chimica" }

            );

            modelBuilder.Entity("StudenteCorso").HasData(
                new {StudenteId = 1, CorsoId=1 },
                new {StudenteId = 2, CorsoId=2 },
                new {StudenteId = 3, CorsoId=3 }
                
                );
           



            modelBuilder.Entity<Corso>()
                .HasOne(c => c.Docente)
                .WithMany(d => d.CorsiDocente)
                .HasForeignKey(c => c.DocenteId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Docente>()
                .HasMany(d => d.CorsiDocente)
                .WithOne(d => d.Docente)
                .HasForeignKey(c => c.DocenteId)
                .OnDelete(DeleteBehavior.Restrict);


            modelBuilder.Entity<Studente>()
                .HasMany(s => s.CorsiIscritto)
                .WithMany(c => c.StudentiIscritti)
                .UsingEntity<Dictionary<string, object>>(
                    "StudenteCorso",
                    sc => sc.HasOne<Corso>()
                        .WithMany()
                        .HasForeignKey("CorsoId")
                        .IsRequired()
                        .HasPrincipalKey(nameof(Corso.Id))
                        .OnDelete(DeleteBehavior.Cascade),
                    sc => sc.HasOne<Studente>()
                        .WithMany()
                        .HasForeignKey("StudenteId")
                        .IsRequired()
                        .HasPrincipalKey(nameof(Studente.Id))
                        .OnDelete(DeleteBehavior.Cascade),
                    sc =>
                    {
                        sc.HasKey("StudenteId", "CorsoId");
                        sc.Property<int>("StudenteId");
                        sc.Property<int>("CorsoId");
                    });






            //modelBuilder.Entity<Studente>()
            //    .HasMany(c => c.Corsos)
            //    .WithMany(d => d.Studentes)
            //    .UsingEntity("CorsiStudenti",

            //     ta => ta.HasOne(typeof(Studente))
            //     .WithMany()
            //     .HasForeignKey("StudenteId")
            //     .HasPrincipalKey(nameof(Studente.Id))
            //     .OnDelete(DeleteBehavior.Restrict),

            //     ta=> ta.HasOne(typeof(Corso))
            //     .WithMany()
            //     .HasForeignKey("CorsoId")
            //     .HasPrincipalKey(nameof(Corso.Id))
            //     .OnDelete(DeleteBehavior.Restrict)

            //    );






            base.OnModelCreating(modelBuilder);
        }
    }
}










































