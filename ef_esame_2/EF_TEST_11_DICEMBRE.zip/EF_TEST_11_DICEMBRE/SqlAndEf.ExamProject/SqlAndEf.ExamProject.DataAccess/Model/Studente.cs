﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlAndEf.ExamProject.DataAccess.Model
{
    public class Studente
    {
        
        public int Id { get; set; }
        public string Cognome { get; set; }
        public string Matricola { get; set; }
        public DateOnly DataImmatricolazione { get; set; }
        public string Genere { get; set; }

        /* Navigazione */
        public virtual ICollection<Corso> CorsiIscritto { get; set; }




    }


}
