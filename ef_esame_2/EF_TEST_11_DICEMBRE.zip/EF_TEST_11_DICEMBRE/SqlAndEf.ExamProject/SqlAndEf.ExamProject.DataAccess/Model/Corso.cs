﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlAndEf.ExamProject.DataAccess.Model
{
    public  class Corso
    {
        public int Id { get; set; }

        public string Nome { get; set; }

        public int CfuTotali { get; set; }

        public int OreLezioniPreviste { get; set; }


        /* navigazione */
        public int DocenteId {  get; set; }   
        public virtual Docente Docente {  get; set; }
        public virtual ICollection<Studente> StudentiIscritti { get; set; }    



    }


}
