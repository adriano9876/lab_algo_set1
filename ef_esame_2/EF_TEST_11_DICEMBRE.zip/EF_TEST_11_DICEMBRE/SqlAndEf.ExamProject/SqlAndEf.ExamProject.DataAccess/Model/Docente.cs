﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlAndEf.ExamProject.DataAccess.Model
{
    public class Docente
    {
        public int Id { get; set; }
        public string Cognome { get; set; }
        public string Specializzazione { get; set; }
        public DateOnly DataAssunzione  { get; set; }

        /* Navigazione */
        public virtual ICollection<Corso> CorsiDocente { get; set; }




    }


}
