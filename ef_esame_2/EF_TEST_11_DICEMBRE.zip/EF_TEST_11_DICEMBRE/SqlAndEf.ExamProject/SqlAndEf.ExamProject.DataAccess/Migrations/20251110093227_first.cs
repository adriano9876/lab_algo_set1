﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SqlAndEf.ExamProject.DataAccess.Migrations
{
    /// <inheritdoc />
    public partial class first : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Docentes",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Cognome = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Specializzazione = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DataAssunzione = table.Column<DateOnly>(type: "date", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Docentes", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Studentes",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Cognome = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Matricola = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DataImmatricolazione = table.Column<DateOnly>(type: "date", nullable: false),
                    Genere = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Studentes", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Corsos",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nome = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CfuTotali = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    OreLezioniPreviste = table.Column<int>(type: "int", nullable: false),
                    DocenteId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Corsos", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Corsos_Docentes_DocenteId",
                        column: x => x.DocenteId,
                        principalTable: "Docentes",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "StudenteCorso",
                columns: table => new
                {
                    StudenteId = table.Column<int>(type: "int", nullable: false),
                    CorsoId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_StudenteCorso", x => new { x.StudenteId, x.CorsoId });
                    table.ForeignKey(
                        name: "FK_StudenteCorso_Corsos_CorsoId",
                        column: x => x.CorsoId,
                        principalTable: "Corsos",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_StudenteCorso_Studentes_StudenteId",
                        column: x => x.StudenteId,
                        principalTable: "Studentes",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Corsos_DocenteId",
                table: "Corsos",
                column: "DocenteId");

            migrationBuilder.CreateIndex(
                name: "IX_StudenteCorso_CorsoId",
                table: "StudenteCorso",
                column: "CorsoId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "StudenteCorso");

            migrationBuilder.DropTable(
                name: "Corsos");

            migrationBuilder.DropTable(
                name: "Studentes");

            migrationBuilder.DropTable(
                name: "Docentes");
        }
    }
}
