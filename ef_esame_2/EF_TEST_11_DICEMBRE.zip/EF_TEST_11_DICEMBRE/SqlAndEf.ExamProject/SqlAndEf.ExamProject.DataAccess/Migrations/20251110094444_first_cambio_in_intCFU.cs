﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SqlAndEf.ExamProject.DataAccess.Migrations
{
    /// <inheritdoc />
    public partial class first_cambio_in_intCFU : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<int>(
                name: "CfuTotali",
                table: "Corsos",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "CfuTotali",
                table: "Corsos",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");
        }
    }
}
