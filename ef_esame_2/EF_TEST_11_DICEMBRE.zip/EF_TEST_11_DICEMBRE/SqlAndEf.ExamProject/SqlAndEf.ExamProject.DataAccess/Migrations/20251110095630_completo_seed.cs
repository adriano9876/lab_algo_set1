﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace SqlAndEf.ExamProject.DataAccess.Migrations
{
    /// <inheritdoc />
    public partial class completo_seed : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "StudenteCorso",
                columns: new[] { "CorsoId", "StudenteId" },
                values: new object[,]
                {
                    { 1, 1 },
                    { 2, 2 },
                    { 3, 3 }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "StudenteCorso",
                keyColumns: new[] { "CorsoId", "StudenteId" },
                keyValues: new object[] { 1, 1 });

            migrationBuilder.DeleteData(
                table: "StudenteCorso",
                keyColumns: new[] { "CorsoId", "StudenteId" },
                keyValues: new object[] { 2, 2 });

            migrationBuilder.DeleteData(
                table: "StudenteCorso",
                keyColumns: new[] { "CorsoId", "StudenteId" },
                keyValues: new object[] { 3, 3 });
        }
    }
}
