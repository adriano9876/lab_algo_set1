﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace SqlAndEf.ExamProject.DataAccess.Migrations
{
    /// <inheritdoc />
    public partial class first_seed1 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Docentes",
                columns: new[] { "Id", "Cognome", "DataAssunzione", "Specializzazione" },
                values: new object[,]
                {
                    { 1, "rossi", new DateOnly(1995, 1, 1), "matematica" },
                    { 2, "agostino", new DateOnly(1994, 1, 1), "fisica" },
                    { 3, "balotelli", new DateOnly(1996, 1, 1), "chimica" }
                });

            migrationBuilder.InsertData(
                table: "Studentes",
                columns: new[] { "Id", "Cognome", "DataImmatricolazione", "Genere", "Matricola" },
                values: new object[,]
                {
                    { 1, "darius", new DateOnly(2000, 1, 1), "m", "10010" },
                    { 2, "luca", new DateOnly(2005, 1, 1), "m", "10020" },
                    { 3, "sara", new DateOnly(2006, 1, 1), "f", "10030" }
                });

            migrationBuilder.InsertData(
                table: "Corsos",
                columns: new[] { "Id", "CfuTotali", "DocenteId", "Nome", "OreLezioniPreviste" },
                values: new object[,]
                {
                    { 1, 10, 2, "fisica 1", 100 },
                    { 2, 10, 3, "chimica 1", 50 },
                    { 3, 10, 1, "analisi 1", 50 }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Corsos",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Corsos",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Corsos",
                keyColumn: "Id",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Studentes",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Studentes",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Studentes",
                keyColumn: "Id",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Docentes",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Docentes",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Docentes",
                keyColumn: "Id",
                keyValue: 3);
        }
    }
}
