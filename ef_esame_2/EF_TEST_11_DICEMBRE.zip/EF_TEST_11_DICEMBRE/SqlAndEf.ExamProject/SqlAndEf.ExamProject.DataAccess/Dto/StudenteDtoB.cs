﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlAndEf.ExamProject.DataAccess.Dto
{
    public class StudenteDtoB
    {
        public int Id { get; set; }
        public string Cognome { get; set; }
        public string Matricola { get; set; }
        public int TotaleCfu { get; set; }
        public  ICollection<CorsoDto> CorsiIscritto { get; set; }


    }


}
