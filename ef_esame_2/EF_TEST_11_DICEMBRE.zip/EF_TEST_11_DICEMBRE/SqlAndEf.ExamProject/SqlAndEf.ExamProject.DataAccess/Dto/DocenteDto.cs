﻿using SqlAndEf.ExamProject.DataAccess.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlAndEf.ExamProject.DataAccess.Dto
{
    public class DocenteDto
    {
        public int Id { get; set; }
        public string Cognome { get; set; }
        public string Specializzazione { get; set; }
        public DateOnly DataAssunzione { get; set; }

       
        //public virtual ICollection<CorsoDto> CorsiDocente { get; set; }

    }
}

//LINQ Quick Reference
//Metodo	Descrizione breve
//Select	Proiezione
//SelectMany	Proiezione multipla
//Where	Filtro
//All	Tutti soddisfano
//Any	Almeno uno
//Contains	Contiene elemento
//Concat	Unisce sequenze
//Distinct	Rimuove duplicati
//OrderBy	Ordine crescente
//Average	Media valori
//Count	Conta elementi
//Max	Valore massimo
//Min	Valore minimo
//Sum	Somma valori
//Skip	Salta N elementi
//Take	Prendi N elementi


