﻿using SqlAndEf.ExamProject.DataAccess.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlAndEf.ExamProject.DataAccess.Dto
{
    public  class CorsoDto
    {
        public int Id { get; set; }

        public string Nome { get; set; }

        public int CfuTotali { get; set; }

        public int OreLezioniPreviste { get; set; }       
        public int DocenteId { get; set; }
        //public virtual DocenteDto Docente { get; set; }
        //public virtual ICollection<StudenteDto> StudentiIscritti { get; set; }

    }


}
