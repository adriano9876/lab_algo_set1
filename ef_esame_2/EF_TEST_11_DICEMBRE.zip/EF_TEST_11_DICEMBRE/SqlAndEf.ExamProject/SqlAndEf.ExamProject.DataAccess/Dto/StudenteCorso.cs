﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlAndEf.ExamProject.DataAccess.Dto
{
    public class StudenteCorso
    {
        public int StudenteId { get; set; }
        public int CorsoId { get; set; }    
    }
}
