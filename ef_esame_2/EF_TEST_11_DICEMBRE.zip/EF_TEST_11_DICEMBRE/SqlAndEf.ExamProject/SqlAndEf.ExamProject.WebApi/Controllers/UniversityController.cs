using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SqlAndEf.ExamProject.DataAccess;
using SqlAndEf.ExamProject.DataAccess.Dto;
using SqlAndEf.ExamProject.DataAccess.Model;
using Swashbuckle.AspNetCore.SwaggerUI;

namespace SqlAndEf.ExamProject.WebApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class UniversityController : ControllerBase
    {
        private UniversityDbContext _context;
        public UniversityController(UniversityDbContext context)
        {
            _context = context;
        }

        #region CRUD ACTIONS

        //a) Crea un corso FATTO
        [HttpPost("courses/create")]
        public async Task<ActionResult<int>> CreateCourse(CorsoDto dto)
        {
            Corso toDb = new Corso
            {
                Nome = dto.Nome,
                CfuTotali = dto.CfuTotali,
                OreLezioniPreviste = dto.OreLezioniPreviste,
                DocenteId = dto.DocenteId 
            };
            var ris = _context.Corsos.Add(toDb);
            await _context.SaveChangesAsync();
            return Ok(toDb.Id);

        }

        //b) Ritorna la lista di tutti i corsi - FATTO  
        [HttpGet("courses")]
        public async Task<ActionResult<ICollection<CorsoDto>>> GetAllCourses()
        {
            var listaCorsi = await _context.Corsos.AsNoTracking().ToListAsync();
            
            var listaDto = listaCorsi.Select( c=> new CorsoDto
            {
                Id= c.Id,
                Nome = c.Nome,
                CfuTotali = c.CfuTotali,
                OreLezioniPreviste = c.OreLezioniPreviste,
                DocenteId = c.DocenteId,
            }).ToList();

            return Ok(listaDto);

            //throw new NotImplementedException();
        }

        //c) Aggiorna i dati di un corso FATTO
        [HttpPut("courses/update")]
        public async Task<ActionResult> UpdateCourse(CorsoDto dto)
        {
            Corso corso = await _context.Corsos.AsNoTracking()
                .Include(d =>d.Docente)
                .FirstOrDefaultAsync(c => c.Id==dto.Id);
            corso.Nome = dto.Nome;
            corso.CfuTotali = dto.CfuTotali;
            corso.OreLezioniPreviste = dto.OreLezioniPreviste;
            corso.DocenteId = dto.DocenteId;
            await  _context.SaveChangesAsync();

            return Ok();
        }

        //d) Cancella un corso FATTO
        [HttpDelete("courses/delete/{id}")]
        public async Task<ActionResult<bool>> DeleteCourse(int id)
        {
            Corso corso = await _context.Corsos.AsNoTracking().FirstOrDefaultAsync(c => c.Id == id);
            _context.Corsos.Remove(corso);
            await _context.SaveChangesAsync();
            return Ok(true);
        }

        //e) Crea uno studente -FATTO
        [HttpPost("students/create")]
        public async Task<ActionResult<int>> CreateStudent(StudenteDto dto )
        {
            Studente toDb = new Studente
            {
                Cognome = dto.Cognome,
                Matricola = dto.Matricola,
                DataImmatricolazione = dto.DataImmatricolazione,
                Genere = dto.Genere
            };
            var ris = _context.Studentes.Add(toDb);
            await _context.SaveChangesAsync();
            return Ok(toDb.Id);
        }

        //f) Associa uno studente a un corso
        [HttpPost("courses/associate-student")]
        public async Task<ActionResult<bool>> AssociateStudentToCourse(StudenteCorso dto )
        {
            //Studente studente_mod = await _context.Studentes.AsNoTracking.()Include()
            //    .FirstOrDefaultAsync(c => c.Id == dto.StudenteId);

            throw new NotImplementedException();
        }

        #endregion

        #region QUERY ACTIONS

        //a) GetAllTeacherFiltered
        [HttpGet("teachers/byname")]
        public async Task<ActionResult<ICollection<DocenteDto>>> GetAllTeachersFiltered(string name)
        {
            var teachers= await _context.Docentes.AsNoTracking().Include( d=>d.CorsiDocente ).ToListAsync();
            var listadocenti = teachers.Where(d => d.Cognome == name)
                .Select(d => new DocenteDtoA
                {
                    Cognome = d.Cognome,
                    Specializzazione = d.Specializzazione,
                    DataAssunzione = d.DataAssunzione,
                    CorsiDocente = d.CorsiDocente.Select(c => new CorsoDto
                    {
                        Nome = c.Nome,
                        CfuTotali = c.CfuTotali,
                        OreLezioniPreviste = c.OreLezioniPreviste,
                        DocenteId = c.DocenteId
                    }).ToList(),
                    NumeroCorsi = d.CorsiDocente.Count()
                }).OrderBy(x=>x.Cognome).ToList(); 

            return Ok(listadocenti);
        }

        //b) GetStudentCareer
        [HttpGet("students/bymatricola/{cognome}")]
        public async Task<ActionResult<StudenteDtoB>> GetStudentCarrier(string cognome)
        {
            Studente studente = await _context.Studentes
                .AsNoTracking()
                .FirstOrDefaultAsync(c => c.Cognome == cognome);
            StudenteDtoB toRet = new StudenteDtoB
            {
                Id = studente.Id,
                Cognome = studente.Cognome,
                Matricola = studente.Matricola,
                CorsiIscritto = studente.CorsiIscritto.Select(
                    c => new CorsoDto
                    {
                        Id = c.Id,
                        Nome = c.Nome,
                        CfuTotali = c.CfuTotali,
                        OreLezioniPreviste = c.OreLezioniPreviste,
                        DocenteId = c.DocenteId
                    }
                    ).ToList(),
                TotaleCfu = studente.CorsiIscritto.Sum(c=> c.CfuTotali)
            };

            return Ok(toRet);
        }

        //c) GetTopCoursesByEfficiency
        [HttpGet("courses/byefficiency")]
        public Task<IActionResult> GetTopCoursesByEfficiency()
        {
            throw new NotImplementedException();
        }

        //d) GetStudentsByEnrollmentDate
        [HttpGet("students/byenrollmentdate")]
        public Task<IActionResult> GetStudentsByEnrollmentDate()
        {
            throw new NotImplementedException(); 
        }

        //e) GetStudentsByTeachersHireDate
        [HttpGet("students/byteachershiredate")]
        public Task<IActionResult> GetStudentsByTeachersHireDate()
        {
            throw new NotImplementedException();
        }

        //f) GetUnEfficientStudents
        [HttpGet("students/byefficiency")]
        public Task<IActionResult> GetUnEfficientStudents()
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}
