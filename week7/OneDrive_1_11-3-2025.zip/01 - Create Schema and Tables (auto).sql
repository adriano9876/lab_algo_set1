USE [master];
GO
IF NOT EXISTS (
SELECT name
FROM sys.databases
WHERE name = N'MusicStreaming_Light')

CREATE DATABASE MusicStreaming_Light;
GO

USE MusicStreaming_Light;

GO

/*
Run this script on:

        (localdb)\MSSQLLocalDB.MusicStreaming_Light_Empty    -  This database will be modified

to synchronize it with:

        (localdb)\MSSQLLocalDB.MusicStreaming_Light

You are recommended to back up your database before running this script

Script created by SQL Compare version 15.0.9.23488 from Red Gate Software Ltd at 28/10/2025 14:56:43

*/
SET NUMERIC_ROUNDABORT OFF;
GO
SET ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULLS ON;
GO
SET XACT_ABORT ON;
GO
SET TRANSACTION ISOLATION LEVEL Serializable;
GO
BEGIN TRANSACTION;
GO
IF @@ERROR <> 0 SET NOEXEC ON;
GO
PRINT N'Creating schemas';
GO
CREATE SCHEMA [activity]
AUTHORIZATION [dbo];
GO
IF @@ERROR <> 0 SET NOEXEC ON;
GO
CREATE SCHEMA [music]
AUTHORIZATION [dbo];
GO
IF @@ERROR <> 0 SET NOEXEC ON;
GO
CREATE SCHEMA [pers]
AUTHORIZATION [dbo];
GO
IF @@ERROR <> 0 SET NOEXEC ON;
GO
CREATE SCHEMA [usercontent]
AUTHORIZATION [dbo];
GO
IF @@ERROR <> 0 SET NOEXEC ON;
GO
PRINT N'Creating [music].[Labels]';
GO
CREATE TABLE [music].[Labels]
(
[LabelId] [int] NOT NULL IDENTITY(1, 1),
[LabelName] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
);
GO
IF @@ERROR <> 0 SET NOEXEC ON;
GO
PRINT N'Creating primary key [PK__Labels] on [music].[Labels]';
GO
ALTER TABLE [music].[Labels] ADD CONSTRAINT [PK__Labels] PRIMARY KEY CLUSTERED ([LabelId]);
GO
IF @@ERROR <> 0 SET NOEXEC ON;
GO
PRINT N'Creating [music].[Albums]';
GO
CREATE TABLE [music].[Albums]
(
[AlbumId] [int] NOT NULL IDENTITY(1, 1),
[AlbumTitle] [nvarchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[ReleaseYear] [int] NULL,
[LabelId] [int] NULL
);
GO
IF @@ERROR <> 0 SET NOEXEC ON;
GO
PRINT N'Creating primary key [PK__Albums] on [music].[Albums]';
GO
ALTER TABLE [music].[Albums] ADD CONSTRAINT [PK__Albums] PRIMARY KEY CLUSTERED ([AlbumId]);
GO
IF @@ERROR <> 0 SET NOEXEC ON;
GO
PRINT N'Creating [activity].[DeviceTypes]';
GO
CREATE TABLE [activity].[DeviceTypes]
(
[DeviceTypeId] [tinyint] NOT NULL IDENTITY(1, 1),
[DeviceType] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
);
GO
IF @@ERROR <> 0 SET NOEXEC ON;
GO
PRINT N'Creating primary key [PK__DeviceType] on [activity].[DeviceTypes]';
GO
ALTER TABLE [activity].[DeviceTypes] ADD CONSTRAINT [PK__DeviceType] PRIMARY KEY CLUSTERED ([DeviceTypeId]);
GO
IF @@ERROR <> 0 SET NOEXEC ON;
GO
PRINT N'Creating [activity].[Devices]';
GO
CREATE TABLE [activity].[Devices]
(
[DeviceId] [int] NOT NULL IDENTITY(1, 1),
[OperatingSystemId] [tinyint] NOT NULL,
[DeviceTypeId] [tinyint] NOT NULL
);
GO
IF @@ERROR <> 0 SET NOEXEC ON;
GO
PRINT N'Creating primary key [PK__Devices] on [activity].[Devices]';
GO
ALTER TABLE [activity].[Devices] ADD CONSTRAINT [PK__Devices] PRIMARY KEY CLUSTERED ([DeviceId]);
GO
IF @@ERROR <> 0 SET NOEXEC ON;
GO
PRINT N'Creating [activity].[OperatingSystems]';
GO
CREATE TABLE [activity].[OperatingSystems]
(
[OperatingSystemId] [tinyint] NOT NULL IDENTITY(1, 1),
[OperatingSystem] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
);
GO
IF @@ERROR <> 0 SET NOEXEC ON;
GO
PRINT N'Creating primary key [PK__OperatingSystems] on [activity].[OperatingSystems]';
GO
ALTER TABLE [activity].[OperatingSystems] ADD CONSTRAINT [PK__OperatingSystems] PRIMARY KEY CLUSTERED ([OperatingSystemId]);
GO
IF @@ERROR <> 0 SET NOEXEC ON;
GO
PRINT N'Creating [pers].[Users]';
GO
CREATE TABLE [pers].[Users]
(
[UserId] [int] NOT NULL IDENTITY(1, 1),
[SubscriptionTypeId] [int] NOT NULL,
[FirstName] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[LastName] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Email] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[UserName] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[BirthDate] [date] NOT NULL,
[SubscriptionDate] [date] NULL
);
GO
IF @@ERROR <> 0 SET NOEXEC ON;
GO
PRINT N'Creating primary key [PK__Users] on [pers].[Users]';
GO
ALTER TABLE [pers].[Users] ADD CONSTRAINT [PK__Users] PRIMARY KEY CLUSTERED ([UserId]);
GO
IF @@ERROR <> 0 SET NOEXEC ON;
GO
PRINT N'Creating index [IX_Users] on [pers].[Users]';
GO
CREATE NONCLUSTERED INDEX [IX_Users] ON [pers].[Users] ([UserId]);
GO
IF @@ERROR <> 0 SET NOEXEC ON;
GO
PRINT N'Creating [pers].[Followers]';
GO
CREATE TABLE [pers].[Followers]
(
[FollowerId] [int] NOT NULL,
[FollowingId] [int] NOT NULL,
[StartDate] [date] NOT NULL
);
GO
IF @@ERROR <> 0 SET NOEXEC ON;
GO
PRINT N'Creating primary key [PK__Follower] on [pers].[Followers]';
GO
ALTER TABLE [pers].[Followers] ADD CONSTRAINT [PK__Follower] PRIMARY KEY CLUSTERED ([FollowerId], [FollowingId]);
GO
IF @@ERROR <> 0 SET NOEXEC ON;
GO
PRINT N'Creating [activity].[Listens]';
GO
CREATE TABLE [activity].[Listens]
(
[ListenId] [int] NOT NULL IDENTITY(1, 1),
[UserId] [int] NOT NULL,
[TrackId] [int] NOT NULL,
[ListenDate] [datetime] NOT NULL,
[DeviceId] [int] NULL
);
GO
IF @@ERROR <> 0 SET NOEXEC ON;
GO
PRINT N'Creating primary key [PK__Listens] on [activity].[Listens]';
GO
ALTER TABLE [activity].[Listens] ADD CONSTRAINT [PK__Listens] PRIMARY KEY CLUSTERED ([ListenId]);
GO
IF @@ERROR <> 0 SET NOEXEC ON;
GO
PRINT N'Creating [music].[Tracks]';
GO
CREATE TABLE [music].[Tracks]
(
[TrackId] [int] NOT NULL IDENTITY(1, 1),
[AlbumId] [int] NOT NULL,
[GenreId] [int] NOT NULL,
[TrackTitle] [nvarchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Duration] [int] NOT NULL
);
GO
IF @@ERROR <> 0 SET NOEXEC ON;
GO
PRINT N'Creating primary key [PK__Tracks] on [music].[Tracks]';
GO
ALTER TABLE [music].[Tracks] ADD CONSTRAINT [PK__Tracks] PRIMARY KEY CLUSTERED ([TrackId]);
GO
IF @@ERROR <> 0 SET NOEXEC ON;
GO
PRINT N'Creating [usercontent].[Playlists]';
GO
CREATE TABLE [usercontent].[Playlists]
(
[PlaylistId] [int] NOT NULL IDENTITY(1, 1),
[UserId] [int] NOT NULL,
[PlaylistName] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[CreatedDate] [date] NOT NULL
);
GO
IF @@ERROR <> 0 SET NOEXEC ON;
GO
PRINT N'Creating primary key [PK__Playlists] on [usercontent].[Playlists]';
GO
ALTER TABLE [usercontent].[Playlists] ADD CONSTRAINT [PK__Playlists] PRIMARY KEY CLUSTERED ([PlaylistId]);
GO
IF @@ERROR <> 0 SET NOEXEC ON;
GO
PRINT N'Creating [usercontent].[PlaylistTracks]';
GO
CREATE TABLE [usercontent].[PlaylistTracks]
(
[PlaylistId] [int] NOT NULL,
[TrackId] [int] NOT NULL
);
GO
IF @@ERROR <> 0 SET NOEXEC ON;
GO
PRINT N'Creating primary key [PK__PlaylistTracks] on [usercontent].[PlaylistTracks]';
GO
ALTER TABLE [usercontent].[PlaylistTracks] ADD CONSTRAINT [PK__PlaylistTracks] PRIMARY KEY CLUSTERED ([PlaylistId], [TrackId]);
GO
IF @@ERROR <> 0 SET NOEXEC ON;
GO
PRINT N'Creating [usercontent].[Reviews]';
GO
CREATE TABLE [usercontent].[Reviews]
(
[ReviewId] [int] NOT NULL IDENTITY(1, 1),
[UserId] [int] NOT NULL,
[AlbumId] [int] NOT NULL,
[ReviewText] [nvarchar] (500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Rating] [int] NULL,
[ReviewDate] [date] NOT NULL
);
GO
IF @@ERROR <> 0 SET NOEXEC ON;
GO
PRINT N'Creating primary key [PK__Reviews] on [usercontent].[Reviews]';
GO
ALTER TABLE [usercontent].[Reviews] ADD CONSTRAINT [PK__Reviews] PRIMARY KEY CLUSTERED ([ReviewId]);
GO
IF @@ERROR <> 0 SET NOEXEC ON;
GO
PRINT N'Creating [music].[Artists]';
GO
CREATE TABLE [music].[Artists]
(
[ArtistId] [int] NOT NULL IDENTITY(1, 1),
[ArtistName] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
);
GO
IF @@ERROR <> 0 SET NOEXEC ON;
GO
PRINT N'Creating primary key [PK__Artists] on [music].[Artists]';
GO
ALTER TABLE [music].[Artists] ADD CONSTRAINT [PK__Artists] PRIMARY KEY CLUSTERED ([ArtistId]);
GO
IF @@ERROR <> 0 SET NOEXEC ON;
GO
PRINT N'Creating [music].[TrackAuthors]';
GO
CREATE TABLE [music].[TrackAuthors]
(
[TrackAuthorId] [int] NOT NULL IDENTITY(1, 1),
[TrackId] [int] NOT NULL,
[ArtistId] [int] NOT NULL
);
GO
IF @@ERROR <> 0 SET NOEXEC ON;
GO
PRINT N'Creating primary key [PK_TrackCollaborations] on [music].[TrackAuthors]';
GO
ALTER TABLE [music].[TrackAuthors] ADD CONSTRAINT [PK_TrackCollaborations] PRIMARY KEY CLUSTERED ([TrackAuthorId]);
GO
IF @@ERROR <> 0 SET NOEXEC ON;
GO
PRINT N'Creating [music].[Genres]';
GO
CREATE TABLE [music].[Genres]
(
[GenreId] [int] NOT NULL IDENTITY(1, 1),
[GenreName] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
);
GO
IF @@ERROR <> 0 SET NOEXEC ON;
GO
PRINT N'Creating primary key [PK__Genres] on [music].[Genres]';
GO
ALTER TABLE [music].[Genres] ADD CONSTRAINT [PK__Genres] PRIMARY KEY CLUSTERED ([GenreId]);
GO
IF @@ERROR <> 0 SET NOEXEC ON;
GO
PRINT N'Creating index [NIX_Genres_Name] on [music].[Genres]';
GO
CREATE UNIQUE NONCLUSTERED INDEX [NIX_Genres_Name] ON [music].[Genres] ([GenreName]);
GO
IF @@ERROR <> 0 SET NOEXEC ON;
GO
PRINT N'Creating [pers].[SubscriptionTypes]';
GO
CREATE TABLE [pers].[SubscriptionTypes]
(
[SubscriptionTypeId] [int] NOT NULL IDENTITY(1, 1),
[SubscriptionTypeName] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[MonthlyPrice] [decimal] (6, 2) NOT NULL
);
GO
IF @@ERROR <> 0 SET NOEXEC ON;
GO
PRINT N'Creating primary key [PK__SubscriptionTypes] on [pers].[SubscriptionTypes]';
GO
ALTER TABLE [pers].[SubscriptionTypes] ADD CONSTRAINT [PK__SubscriptionTypes] PRIMARY KEY CLUSTERED ([SubscriptionTypeId]);
GO
IF @@ERROR <> 0 SET NOEXEC ON;
GO
PRINT N'Adding constraints to [usercontent].[Reviews]';
GO
ALTER TABLE [usercontent].[Reviews] ADD CONSTRAINT [CK__Reviews__Rating__5441852A] CHECK (([Rating]>=(1) AND [Rating]<=(5)));
GO
IF @@ERROR <> 0 SET NOEXEC ON;
GO
PRINT N'Adding foreign keys to [activity].[Devices]';
GO
ALTER TABLE [activity].[Devices] WITH NOCHECK  ADD CONSTRAINT [FK_Devices_DeviceTypes] FOREIGN KEY ([DeviceTypeId]) REFERENCES [activity].[DeviceTypes] ([DeviceTypeId]);
GO
ALTER TABLE [activity].[Devices] WITH NOCHECK  ADD CONSTRAINT [FK_Devices_OperatingSystems] FOREIGN KEY ([OperatingSystemId]) REFERENCES [activity].[OperatingSystems] ([OperatingSystemId]);
GO
IF @@ERROR <> 0 SET NOEXEC ON;
GO
PRINT N'Adding foreign keys to [activity].[Listens]';
GO
ALTER TABLE [activity].[Listens] WITH NOCHECK  ADD CONSTRAINT [FK_Listens_Device] FOREIGN KEY ([DeviceId]) REFERENCES [activity].[Devices] ([DeviceId]);
GO
ALTER TABLE [activity].[Listens] WITH NOCHECK  ADD CONSTRAINT [FK_Listens_Tracks] FOREIGN KEY ([TrackId]) REFERENCES [music].[Tracks] ([TrackId]);
GO
ALTER TABLE [activity].[Listens] WITH NOCHECK  ADD CONSTRAINT [FK_Listens_User] FOREIGN KEY ([UserId]) REFERENCES [pers].[Users] ([UserId]);
GO
IF @@ERROR <> 0 SET NOEXEC ON;
GO
PRINT N'Adding foreign keys to [music].[TrackAuthors]';
GO
ALTER TABLE [music].[TrackAuthors] WITH NOCHECK  ADD CONSTRAINT [FK_TrackCollaborations_Artists] FOREIGN KEY ([ArtistId]) REFERENCES [music].[Artists] ([ArtistId]);
GO
ALTER TABLE [music].[TrackAuthors] WITH NOCHECK  ADD CONSTRAINT [FK_TrackCollaborations_Tracks1] FOREIGN KEY ([TrackId]) REFERENCES [music].[Tracks] ([TrackId]);
GO
IF @@ERROR <> 0 SET NOEXEC ON;
GO
PRINT N'Adding foreign keys to [music].[Tracks]';
GO
ALTER TABLE [music].[Tracks] WITH NOCHECK  ADD CONSTRAINT [FK_Tracks_Album] FOREIGN KEY ([AlbumId]) REFERENCES [music].[Albums] ([AlbumId]);
GO
ALTER TABLE [music].[Tracks] WITH NOCHECK  ADD CONSTRAINT [FK_Tracks_Genre] FOREIGN KEY ([GenreId]) REFERENCES [music].[Genres] ([GenreId]);
GO
IF @@ERROR <> 0 SET NOEXEC ON;
GO
PRINT N'Adding foreign keys to [pers].[Users]';
GO
ALTER TABLE [pers].[Users] WITH NOCHECK  ADD CONSTRAINT [FK_Users_SubType] FOREIGN KEY ([SubscriptionTypeId]) REFERENCES [pers].[SubscriptionTypes] ([SubscriptionTypeId]);
GO
IF @@ERROR <> 0 SET NOEXEC ON;
GO
PRINT N'Adding foreign keys to [usercontent].[PlaylistTracks]';
GO
ALTER TABLE [usercontent].[PlaylistTracks] WITH NOCHECK  ADD CONSTRAINT [FK_PlaylistTracks_Playlist] FOREIGN KEY ([PlaylistId]) REFERENCES [usercontent].[Playlists] ([PlaylistId]);
GO
ALTER TABLE [usercontent].[PlaylistTracks] WITH NOCHECK  ADD CONSTRAINT [FK_PlaylistTracks_Tracks] FOREIGN KEY ([TrackId]) REFERENCES [music].[Tracks] ([TrackId]);
GO
IF @@ERROR <> 0 SET NOEXEC ON;
GO
PRINT N'Adding foreign keys to [music].[Albums]';
GO
ALTER TABLE [music].[Albums] ADD CONSTRAINT [FK_Albums_Label] FOREIGN KEY ([LabelId]) REFERENCES [music].[Labels] ([LabelId]);
GO
IF @@ERROR <> 0 SET NOEXEC ON;
GO
PRINT N'Adding foreign keys to [pers].[Followers]';
GO
ALTER TABLE [pers].[Followers] ADD CONSTRAINT [FK_Followers_Follower] FOREIGN KEY ([FollowerId]) REFERENCES [pers].[Users] ([UserId]);
GO
ALTER TABLE [pers].[Followers] ADD CONSTRAINT [FK_Followers_Following] FOREIGN KEY ([FollowingId]) REFERENCES [pers].[Users] ([UserId]);
GO
IF @@ERROR <> 0 SET NOEXEC ON;
GO
PRINT N'Adding foreign keys to [usercontent].[Playlists]';
GO
ALTER TABLE [usercontent].[Playlists] ADD CONSTRAINT [FK_Playlists_User] FOREIGN KEY ([UserId]) REFERENCES [pers].[Users] ([UserId]);
GO
IF @@ERROR <> 0 SET NOEXEC ON;
GO
PRINT N'Adding foreign keys to [usercontent].[Reviews]';
GO
ALTER TABLE [usercontent].[Reviews] ADD CONSTRAINT [FK_Reviews_Album] FOREIGN KEY ([AlbumId]) REFERENCES [music].[Albums] ([AlbumId]);
GO
ALTER TABLE [usercontent].[Reviews] ADD CONSTRAINT [FK_Reviews_User] FOREIGN KEY ([UserId]) REFERENCES [pers].[Users] ([UserId]);
GO
IF @@ERROR <> 0 SET NOEXEC ON;
GO
COMMIT TRANSACTION;
GO
IF @@ERROR <> 0 SET NOEXEC ON;
GO
-- This statement writes to the SQL Server Log so SQL Monitor can show this deployment.
IF HAS_PERMS_BY_NAME(N'sys.xp_logevent', N'OBJECT', N'EXECUTE') = 1
BEGIN
    DECLARE @databaseName AS nvarchar(2048), @eventMessage AS nvarchar(2048);
    SET @databaseName = REPLACE(REPLACE(DB_NAME(), N'\', N'\\'), N'"', N'\"');
    SET @eventMessage = N'Redgate SQL Compare: { "deployment": { "description": "Redgate SQL Compare deployed to ' + @databaseName + N'", "database": "' + @databaseName + N'" }}';
    EXECUTE sys.xp_logevent 55000, @eventMessage;
END;
GO
DECLARE @Success AS BIT;
SET @Success = 1;
SET NOEXEC OFF;
IF (@Success = 1) PRINT 'The database update succeeded';
ELSE BEGIN
	IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
	PRINT 'The database update failed';
END;
GO
