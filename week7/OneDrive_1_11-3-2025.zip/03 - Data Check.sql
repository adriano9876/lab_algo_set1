USE MusicStreaming_Light;
GO
CREATE OR ALTER PROCEDURE sp_DBCheck
AS
BEGIN
	DECLARE @Message VARCHAR(MAX) = 'Everything is OK!!';
	DECLARE @ErrorMessage VARCHAR(MAX) = '';

	IF
	(
		SELECT COUNT(*)FROM music.Labels
	) <> 15
		SET @ErrorMessage += 'music.Labels KO' + CHAR(13) + CHAR(10);
	IF
	(
		SELECT COUNT(*)FROM music.Albums
	) <> 12053
		SET @ErrorMessage += 'music.Albums KO' + CHAR(13) + CHAR(10);
	IF
	(
		SELECT COUNT(*)FROM activity.DeviceTypes
	) <> 0
		SET @ErrorMessage += 'activity.DeviceTypes KO' + CHAR(13) + CHAR(10);
	IF
	(
		SELECT COUNT(*)FROM activity.Devices
	) <> 29
		SET @ErrorMessage += 'activity.Devices KO' + CHAR(13) + CHAR(10);
	IF
	(
		SELECT COUNT(*)FROM activity.OperatingSystems
	) <> 23
		SET @ErrorMessage += 'activity.OperatingSystems KO' + CHAR(13) + CHAR(10);
	IF
	(
		SELECT COUNT(*)FROM pers.Users
	) <> 1499
		SET @ErrorMessage += 'pers.Users KO' + CHAR(13) + CHAR(10);
	IF
	(
		SELECT COUNT(*)FROM pers.Followers
	) <> 5624
		SET @ErrorMessage += 'pers.Followers KO' + CHAR(13) + CHAR(10);
	IF
	(
		SELECT COUNT(*)FROM activity.Listens
	) <> 19351
		SET @ErrorMessage += 'activity.Listens KO' + CHAR(13) + CHAR(10);
	IF
	(
		SELECT COUNT(*)FROM music.Tracks
	) <> 14009
		SET @ErrorMessage += 'music.Tracks ';
	IF
	(
		SELECT COUNT(*)FROM usercontent.Playlists
	) <> 470
		SET @ErrorMessage += 'usercontent.Playlists KO' + CHAR(13) + CHAR(10);
	IF
	(
		SELECT COUNT(*)FROM usercontent.PlaylistTracks
	) <> 15934
		SET @ErrorMessage += 'usercontent.PlaylistTracks KO' + CHAR(13) + CHAR(10);
	IF
	(
		SELECT COUNT(*)FROM usercontent.Reviews
	) <> 8626
		SET @ErrorMessage += 'usercontent.Reviews KO' + CHAR(13) + CHAR(10);
	IF
	(
		SELECT COUNT(*)FROM music.Artists
	) <> 6702
		SET @ErrorMessage += 'music.Artists KO' + CHAR(13) + CHAR(10);
	IF
	(
		SELECT COUNT(*)FROM music.TrackAuthors
	) <> 14345
		SET @ErrorMessage += 'music.TrackAuthors KO' + CHAR(13) + CHAR(10);
	IF
	(
		SELECT COUNT(*)FROM music.Genres
	) <> 25
		SET @ErrorMessage += 'music.Genres KO' + CHAR(13) + CHAR(10);
	IF
	(
		SELECT COUNT(*)FROM pers.SubscriptionTypes
	) <> 3
		SET @ErrorMessage += 'pers.SubscriptionTypes KO' + CHAR(13) + CHAR(10);

	IF @ErrorMessage = ''
		PRINT @Message;
	ELSE
		PRINT @ErrorMessage;


END;
GO
EXEC sp_DBCheck;