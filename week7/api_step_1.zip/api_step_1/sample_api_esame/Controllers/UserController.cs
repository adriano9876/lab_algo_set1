﻿using Microsoft.AspNetCore.Mvc;
using sample_api_esame.Dto;
using sample_api_esame.Models;

namespace sample_api_esame.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        public static  List<User> Users = new List<User>
        {
            new User () {Id = 1, Age = 10 , Name = "ste", JobTitle ="cybercoso", Surname = "st"   },
            new User () {Id = 2, Age = 20 , Name = "luca", JobTitle ="informatico", Surname = "lu"   },
            new User () {Id = 3, Age = 30 , Name = "mateo", JobTitle ="cuoco", Surname = "mat"   },
            new User () {Id = 4, Age = 40 , Name = "andreina", JobTitle ="software developer", Surname = "an"   },
            new User () {Id = 5, Age = 50 , Name = "giacomo", JobTitle ="racer", Surname = "gi"   },

        };




        /*  ------------------------------ APIS ------------------------------   */
        // GET: api/<UserController>
        [HttpGet]
        [Route ("getAll")]
        public ActionResult<ICollection<UserDto>> Get()
        {
            var users = Users.ToList();
            List<UserDto> usersRet = users.Select( u => new UserDto()
            {
                Name = u.Name,
                Surname = u.Surname,
                Age = u.Age,
                JobTitle = u.JobTitle
            }).ToList();

            return Ok(usersRet);
        }


        [HttpGet("{id}")]
        public ActionResult<UserDto> get(int id)
        {
            var user = Users.FirstOrDefault(u => u.Id == id);
            if (user == null)
            {
                return BadRequest();// non esiste il dato ,
            }
            UserDto userRet = new UserDto()
            {
                Name = user.Name,
                Surname = user.Surname,
                Age = user.Age,
                JobTitle = user.JobTitle
            };

            return Ok(userRet);
        }

        // POST api/<UserController>
        [HttpPost]
        public ActionResult<int> Post([FromBody] UserDto userDto)
        {
            //if (userDto == null)// controllo inutile xk userDto c'è sempre 
            //{
            //    return BadRequest();
            //}

            User userToList = new User()
            {
                Id = Users.Max( _=> _.Id) + 1,//  Count() + 1,
                Name = userDto.Name,
                Surname = userDto.Surname,
                Age = userDto.Age,
                JobTitle = userDto.JobTitle
            };

            Users.Add(userToList);
            // qua trycatch nel futuro, poi status messag e poi l'oggetto errore, ok ,ecc
            // una clase come le altre , tutto al interno gli errori 
            return Ok(userToList.Id);

        }

        // PUT api/<UserController>/5
        [HttpPut("{id}")]
        public ActionResult <UserDto> Put(int id, [FromBody] UserDto dto)
        {
            var user = Users.FirstOrDefault(u => u.Id==id);

            if (user == null)
            {
                return BadRequest();
            }

            user.Name = dto.Name;
            user.Surname = dto.Surname;
            user.Age = dto.Age;
            user.JobTitle = dto.JobTitle;

            UserDto toRet = new UserDto()
            {
                Name = dto.Name,
                Surname = dto.Surname,
                Age = dto.Age,
                JobTitle = dto.JobTitle
            };

            return Ok(toRet);
        }

        // DELETE api/<UserController>/5
        [HttpDelete("{id}")]
        public ActionResult <int> Delete(int id)
        {
            var user = Users.FirstOrDefault(_ => _.Id == id);
            if (user == null)
            {
                return NotFound();
            }
            Users.Remove(user);
            return Ok(true);
        }











    }
}
