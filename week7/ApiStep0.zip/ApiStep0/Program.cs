﻿
using System.Text.Json;
using System.Threading.Tasks;

namespace ApiStep0
{   
    internal class Program
    {
        public class WeatherForecast
        {
            public DateOnly Date { get; set; }

            public int TemperatureC { get; set; }

            public int TemperatureF => 32 + (int)(TemperatureC / 0.5556);

            public string? Summary { get; set; }
        }

        public class WeatherForecastDto
        {
            public DateOnly Date { get; set; }

            public int TemperatureC { get; set; }

        }




        static async Task Main(string[] args)
        {
            Console.WriteLine("Hello, World!");

            using var  client = new HttpClient();
            client.BaseAddress = new Uri("http://localhost:5156");

            try
            {
                var response = await client.GetAsync("/WeatherForecast/getOk01g");
                if (response.IsSuccessStatusCode)
                {
                    var json = await response.Content.ReadAsStringAsync();
                    var forecasts = JsonSerializer.Deserialize<WeatherForecast[]>(json,
                        new JsonSerializerOptions
                        {
                            PropertyNameCaseInsensitive = true
                        });

                    foreach (var forecast in forecasts)
                    {
                        Console.WriteLine($" {forecast.Date}" +
                            $"\n{forecast.TemperatureF}");
                    }

                }

                else
                {
                    Console.WriteLine($"Error detected {response.StatusCode}");

                }





            }


            catch (Exception)
            {
                Console.WriteLine("errore non va");
                int a = 0;
                throw;
            }

            /**/

            try
            {
                var content = new StringContent("a",System.Text.Encoding.UTF8,
                    "application/json" );
                var response = await client.PostAsync("/WeatherForecast/PostOk",
                    content);

            }
            catch (Exception)
            {

                throw;
            }




        }




    }




}













