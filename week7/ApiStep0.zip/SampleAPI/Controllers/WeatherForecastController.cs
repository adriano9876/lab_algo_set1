using Microsoft.AspNetCore.Mvc;
using SampleAPI.Dto;

namespace SampleAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        public static List<UdatableWheatherForecast> UweatherForecast
            = new List<UdatableWheatherForecast>()
        {
            new UdatableWheatherForecast
            {
                Id=1,
                Date = DateOnly.FromDateTime(DateTime.Now),
                TemperatureC = 32,
                Summary = "Freschino"
            },
            new UdatableWheatherForecast
            {
                Id=2,
                Date = DateOnly.FromDateTime(DateTime.Now),
                 TemperatureC = 82,
                Summary = "Bella"
            },
            new UdatableWheatherForecast
            {
                Id=3,
                Date = DateOnly.FromDateTime(DateTime.Now),
                 TemperatureC = 312,
                Summary = "Caldo"
            },
                        new UdatableWheatherForecast
            {
                Id=4,
                Date = DateOnly.FromDateTime(DateTime.Now),
                 TemperatureC = 322,
                Summary = "Caldo e freddo"
            }


        };

        private static readonly string[] Summaries = new[]
        {
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };



        private readonly ILogger<WeatherForecastController> _logger;

        public WeatherForecastController(ILogger<WeatherForecastController> logger)
        {
            _logger = logger;
        }

        [HttpGet(Name = "GetWeatherForecast")]
        public IEnumerable<WeatherForecast> Get()
        {
            return Enumerable.Range(1, 5).Select(index => new WeatherForecast
            {
                Date = DateOnly.FromDateTime(DateTime.Now.AddDays(index)),
                TemperatureC = Random.Shared.Next(-20, 55),
                Summary = Summaries[Random.Shared.Next(Summaries.Length)]
            })
            .ToArray();
        }

        [HttpGet]
        [Route ("getOk01")]
        public ActionResult<IEnumerable<WeatherForecast>> GetOk()
        {
            var ret= Enumerable.Range(1, 5).Select(index => new WeatherForecast
            {
                Date = DateOnly.FromDateTime(DateTime.Now.AddDays(index)),
                TemperatureC = Random.Shared.Next(-20, 55),
                Summary = Summaries[Random.Shared.Next(Summaries.Length)]
            })
            .ToArray();

            //return BadRequest(ret);
            return BadRequest( new {StatusCodes.Status418ImATeapot });
        }

        [HttpPost]
        [Route("createOk")]
        public ActionResult<WeatherForecastDto> CreateWeatherForecast
            ( [FromBody] WeatherForecast wf)
        {
            var dtoRet = new WeatherForecastDto
            {
                Date = wf.Date,
                TemperatureC = wf.TemperatureC
                
            };
           // Console.WriteLine($"{wf.Date}");
            return Ok(dtoRet);
        }


        [HttpPut]
        [Route ("putok/{id}")]
        public ActionResult PutWeatherForecast(int id, [FromBody]
        //WeatherForecast wf)
        UdatableWheatherForecast wf)

        {
            var x = UweatherForecast.FirstOrDefault( y => y.Id==id);

            if(x== null)
            {
                return NotFound();
            }

            x.Summary = wf.Summary;
            x.TemperatureC = wf.TemperatureC;
             x.Date = wf.Date;
            //return Ok(x); non corretto

            //qua fare un trycatsch dopo per gestire in valore reale 
            return NoContent();
        }





    }
}
