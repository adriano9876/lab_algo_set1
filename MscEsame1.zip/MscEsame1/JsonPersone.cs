﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MscEsame1
{
    public class JsonPersone
    {
        public List<Persona> ListaPersone { get; set; }
        public JsonPersone()
        {
            ListaPersone = new List<Persona>();
        }

    }
}
