﻿namespace MscEsame1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Sono in MSC esame\n");

            List<Persona> listaPersone = new List<Persona> { 
                new Persona ("luca milano",10),
                new Persona ("bea firenze",20),
                new Persona ("mario roma",30),
                new Persona ("dug parigi",5)
            };


            var ris = listaPersone.Count();
            Console.WriteLine(ris);



          

        }



    }
}
