﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MscEsame1
{
    internal enum Giorni
    {
        Lunedi,Martedi,Mercoledi,Giovedi,Venerdi,Sabato,Domenica
    }
}
