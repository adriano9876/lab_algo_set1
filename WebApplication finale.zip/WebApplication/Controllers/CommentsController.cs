﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplicationEF.Dtos;
using WebApplicationEF.Models;

namespace WebApplicationEF.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class CommentsController: ControllerBase
    {
        private readonly DatabaseFirstDbContext _context;

        public CommentsController(DatabaseFirstDbContext context)
        {
            _context = context;
        }


        // GET: api/products -adri
        [HttpGet]
        public async Task<ActionResult<IEnumerable<CommentDto>>> GetProducts()
        {
            var query = _context.Comments
                .Select(x => new CommentDto
                {
                    Id = x.Id,
                    Description = x.Description,            

                });//.ToListAsync();   // Include related Warehouse data

            // return await query;
            var sql = query.ToQueryString();

            return await query.ToListAsync();
        }

        // POST: api/Comments
        [HttpPost]        
        public async Task<ActionResult<Comment>> CreateProduct(CommentDto commentDto)
        {
            //var commentExists = await _context.Comments
            //    .AnyAsync(w => w.Id == comment.Id);
            //if (!commentExists)
            //    return BadRequest($"Comment with ID {comment.Id} does not exist.");

            Comment toDbComment = new Comment
            {
                Description = commentDto.Description,
                ProdottoId = commentDto.ProductId,
            };
            var ret =_context.Comments.Add(toDbComment);          
            await _context.SaveChangesAsync();
            return Ok();
        }


        // DELETE: api/products/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteProduct(int id)
        {
            var comment = await _context.Comments.FindAsync(id);
            if (comment == null)
                return NotFound();

            _context.Comments.Remove(comment);
            await _context.SaveChangesAsync();
            return NoContent();
        }

        // GET: api/products/5
        [HttpGet("{id}")]
        public async Task<ActionResult<CommentDto>> GetProduct(int id)
        {
            var comment = await _context.Comments.AsNoTracking()
                .Select(x => new CommentDto
                {
                    Id = x.Id,
                    Description = x.Description,
                    ProductId = x.ProdottoId,
                }).FirstOrDefaultAsync(p => p.Id == id);
          

            if (comment == null)
                return NotFound();

            return Ok(comment);
        }

        // PUT: api/Comments/5
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateComment(int id, CommentDtoIdDes updatedComment)
        {
            if (id <= 0)
                return BadRequest();

            var existingComment = await _context.Comments           
            .FirstOrDefaultAsync(p => p.Id == id);

            if (existingComment == null)
                return NotFound();

            existingComment.Description = updatedComment.Description;

            var comment = await _context.Comments.FindAsync();
            if (comment == null)
                return BadRequest($"Warehouse with ID {updatedComment.id} does not exist.");
             
      

            await _context.SaveChangesAsync();
            return NoContent();
        }










    }
}
