﻿namespace WebApplicationEF.Dtos
{
    public class CommentDtoIdDes
    {
        public int? id { get; set; }
        public string? Description { get; set; }
    }
}
