﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplicationEF.Dtos;

namespace WebApplicationEF.Dtos
{
    public class CommentDto
    {
        public int Id { get; set; }

        public string? Description { get; set; }
        public int ProductId {  get; set; } 
    }
}


// PUT: api/products/5
//[HttpPut("{id}")]
//public async Task<IActionResult> UpdateProduct(int id, ProductDto updatedProduct)
//{
//    if (id <= 0)
//        return BadRequest();

//    var existingProduct = await _context.Products
//    .Include(p => p.Warehouse)
//    .FirstOrDefaultAsync(p => p.Id == id);

//    if (existingProduct == null)
//        return NotFound();

//    var warehouse = await _context.Warehouses.FindAsync(updatedProduct.WarehouseId);
//    if (warehouse == null)
//        return BadRequest($"Warehouse with ID {updatedProduct.WarehouseId} does not exist.");

//    existingProduct.Name = updatedProduct.Name;
//    existingProduct.Price = updatedProduct.Price;
//    existingProduct.WarehouseId = updatedProduct.WarehouseId;

//    await _context.SaveChangesAsync();

//    return NoContent();
//}
