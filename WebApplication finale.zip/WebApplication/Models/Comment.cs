﻿using System;
using System.Collections.Generic;

namespace WebApplicationEF.Models;

public partial class Comment
{
    public int Id { get; set; }

    public string? Description { get; set; }

    public int ProdottoId { get; set; }

    public virtual Product Prodotto { get; set; } = null!;
}
