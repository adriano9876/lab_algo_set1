﻿namespace sample_api_esame.Models
{
    public  class User
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }
        public int Age { get; set; }
        public string JobTitle { get; set; }

    }
}