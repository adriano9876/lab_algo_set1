﻿using sample_api_esame.Dto;
using System.Text.Json;

namespace Console_api_esame
{
    public class Program
    {
        static async Task Main(string[] args)
        {

            int a1 = 333;

            string url="https://localhost:7266/api/User/getAll";

            using var client = new HttpClient();
            client.BaseAddress = new Uri("https://localhost:7266");


            try
            {
                var response = await client.GetAsync("api/User/getAll");
                if (response.IsSuccessStatusCode)
                {
                    var json = await response.Content.ReadAsStringAsync();
                    var usersdto = JsonSerializer.Deserialize<UserDto[]>(json,
                    new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true
                    });

                    foreach (var tmp in usersdto)
                    {
                        Console.WriteLine($"{tmp.Name} -> {tmp.Surname} -> {tmp.Age}");
                    }
                }

            }
            catch (Exception)
            {
                int a = 0;
                throw;
            }
            int b = 1;

        }






    }
}
