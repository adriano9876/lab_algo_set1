﻿using Microsoft.AspNetCore.Mvc;
using sample_api_esame.Dto;
using sample_api_esame.ModelsDue;
using sample_api_esame.Repository;
using sample_api_esame.Service;


namespace sample_api_esame.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserService _userService;

        public UserController(IUserService userService)
        {
            _userService = userService;
        }


        /*  ------------------------------ APIS ------------------------------   */
        // GET: api/<UserController>
        [HttpGet]
        public ActionResult<ICollection<User>> Get()
        {
            var users = _userService.GetAllUsers();
            return Ok(users);
        }


    }
}
