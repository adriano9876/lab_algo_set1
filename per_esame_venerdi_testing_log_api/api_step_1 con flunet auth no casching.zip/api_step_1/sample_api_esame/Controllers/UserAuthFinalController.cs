﻿using Microsoft.AspNetCore.Mvc;
using sample_api_esame.Dto;
using sample_api_esame.MiddlewareFolder.Interfaces;

namespace sample_api_esame.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserAuthfinalController : ControllerBase
    {
  
        private readonly IJwtService _jwtService;
        public UserAuthfinalController(IJwtService service)
        {
            _jwtService = service;
        }


        // POST api/<UserController>
        [HttpPost]
        public ActionResult Post([FromBody] AuthDto auth )
        {    
            var token = _jwtService.GenerateToken(auth.UserName, auth.Password);

            if (token == null)
            {
                return Unauthorized();
            }

            var cookieOptions = new CookieOptions()
            {
            HttpOnly = true,
            Secure = true,
            SameSite = SameSiteMode.Strict,
            Expires = DateTime.UtcNow.AddHours(1)

            };

            Response.Cookies.Append("token", token, cookieOptions);

            return Ok( new { token });

        }








    }
}
