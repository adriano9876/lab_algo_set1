﻿namespace sample_api_esame.Dto
{
    public class UserAuthDto
    {
        public string Name { get; set; }
        public string Surname { get; set; }
        public int Age { get; set; }
        public string JobTitle { get; set; }

    }



}
