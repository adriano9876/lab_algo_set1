﻿using FluentValidation;
using sample_api_esame.Dto;

namespace sample_api_esame.Validatore
{
    public class UserCreateRequestValidator : AbstractValidator<AuthDto>
    {
        public UserCreateRequestValidator() 
        {
            RuleFor(x => x.UserName)
                .NotEmpty().WithMessage("nome obbligatorio")
                .MinimumLength(4).WithMessage("piu di 4 caratteri");    
        
        }


    }
}
