﻿using Microsoft.EntityFrameworkCore;

namespace sample_api_esame.ModelsDue
{
    public class MyRepoContext : DbContext
    {
        public MyRepoContext(DbContextOptions<MyRepoContext> options)
            : base(options) { }

        public virtual DbSet<User> Users { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {


        }

    }

}
