﻿namespace sample_api_esame.ModelsDue
{
    public class User
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Ruolo { get; set; } 
        public string Cognome { get; set; } 
        public string Stati { get; set; } 
        public string Email { get; set; } 
        public string Sesso { get; set; } 
        public string Password { get; set; } 
        public DateOnly DataDiNascita { get; set; } 



        /*
         nome
         ruolo
         cognome
         stati
         email
        sesso
        dataDiNascita
         */


    }
}
