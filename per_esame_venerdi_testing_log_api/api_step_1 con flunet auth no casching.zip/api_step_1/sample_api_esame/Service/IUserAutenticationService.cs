﻿using sample_api_esame.Dto;
using sample_api_esame.ModelsDue;

namespace sample_api_esame.Service
{
    public interface IUserAutenticationService
    {
       public string CreateTokenByUser(AuthDto user);


    }
}