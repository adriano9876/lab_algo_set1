﻿using Azure;
using sample_api_esame.Dto;
using sample_api_esame.MiddlewareFolder.Interfaces;
using sample_api_esame.ModelsDue;
using sample_api_esame.Repository;

namespace sample_api_esame.Service
{
    public class UserAutenticationService : IUserAutenticationService
    {
        private readonly IUserRepository _repository;
        private readonly IJwtService _jwtService;

        public UserAutenticationService(IUserRepository repository, IJwtService service)
        {
            _repository = repository;
            _jwtService = service;
        }

        public string CreateTokenByUser(AuthDto userDto)
        {
            User ris = _repository.ExistUserByName(userDto.UserName);

            if(ris == null)
            {
                return null;
            }
            var token = _jwtService.GenerateToken(ris.Nome, ris.Ruolo);

            var cookieOptions = new CookieOptions()
            {
                HttpOnly = true,
                Secure = true,
                SameSite = SameSiteMode.Strict,
                Expires = DateTime.UtcNow.AddHours(1)

            };     

            return token;

        }
    }


}
