﻿using sample_api_esame.ModelsDue;
using sample_api_esame.Repository;

namespace sample_api_esame.Service
{
    public class UserService : IUserService
    {

        private readonly IUserRepository _repository;

        public UserService(IUserRepository repository)
        {
            _repository = repository;
        }

        public ICollection<User> GetAllUsers()
        {
            List<User> users = _repository.GetUsersRepo();
            return users;
        }
    }
}
