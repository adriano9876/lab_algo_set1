﻿using sample_api_esame.ModelsDue;

namespace sample_api_esame.Service
{
    public interface IUserService
    {
        public ICollection<User> GetAllUsers();

    }
}
