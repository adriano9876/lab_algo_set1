﻿namespace sample_api_esame.Middleware
{
    public class LoggingMiddleware
    {
        private readonly RequestDelegate _next;
      
        /*to del */
        public static int contatore = 0;

        public LoggingMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task InvokeAsync (HttpContext context)
        {
            //var cookie = context.Response.Cookies.GetType;
            //Console.WriteLine(cookie);
                
            //Console.WriteLine($"Request :{context.Request} ");
            Console.WriteLine("Sono in m1: "+ contatore++);
            await _next(context); //prossimo middleware
        }

    }



}
