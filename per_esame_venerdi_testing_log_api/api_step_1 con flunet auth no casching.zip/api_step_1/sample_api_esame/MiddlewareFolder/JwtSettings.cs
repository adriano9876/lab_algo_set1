﻿namespace sample_api_esame.MiddlewareFolder
{
    public class JwtSettings

    {

        public string Key { get; set; }

        public bool ValidateIssuer { get; set; }

        public bool ValidateAudience { get; set; }

        public bool ValidateLifetime { get; set; }

        public bool ValidateIssuerSigningKey { get; set; }

    }




}
