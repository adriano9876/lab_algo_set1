﻿using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Runtime;
using System.Text;

namespace sample_api_esame.MiddlewareFolder
{
    public class AuthMiddleware
    {

        private readonly RequestDelegate _next;
        private readonly JwtSettings _jwSettings;
        public AuthMiddleware(RequestDelegate next, IOptions<JwtSettings> jwSettings)
        {
            _next = next;
            _jwSettings = jwSettings.Value;
        }

        public async Task InvokeAsync(HttpContext context )
        {
            var token = context.Request.Headers["Authorization"].ToString()
                .Replace("Bearer ", "");

            if (!string.IsNullOrEmpty(token))
            {
                try
                {
                    
                    var tokenHandler = new JwtSecurityTokenHandler();
                    var temp = tokenHandler.ValidateToken(token,
                        new TokenValidationParameters
                        {
                            ValidateIssuer = false,
                            ValidateAudience = false,
                            ValidateLifetime = true,
                            ValidateIssuerSigningKey = true,
                            IssuerSigningKey = new SymmetricSecurityKey(
                                Encoding.UTF8.GetBytes(_jwSettings.Key))

                        }, out SecurityToken validatedToken);

                    context.User = temp;
                    await _next(context);  
                }
                catch (Exception)
                {
                    context.Response.StatusCode = StatusCodes
                        .Status401Unauthorized;
                    await context.Response.WriteAsync("token not valid");
                    return;                    
                }
                context.Response.StatusCode = StatusCodes .Status401Unauthorized;
                await context.Response.WriteAsync("Token missing");
                return;
         

            }


        }


    }



}
