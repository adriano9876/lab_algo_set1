﻿namespace sample_api_esame.MiddlewareFolder.Interfaces
{
    public interface IJwtService
    {
        public string GenerateToken(string username, string password);
    }

}
