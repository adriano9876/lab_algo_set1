﻿using Microsoft.Extensions.Options;
using System.Security.Claims;
using System.Text;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using sample_api_esame.MiddlewareFolder.Interfaces;
using sample_api_esame.Repository;
using sample_api_esame.ModelsDue;
using Microsoft.Extensions.Caching.Memory;

namespace sample_api_esame.MiddlewareFolder
{
    public class JwtService : IJwtService
    {
        private readonly JwtSettings _jwtSettings;
        private readonly IUserRepository _repository;


        public JwtService (IOptions <JwtSettings> jwtSettings,
                           IUserRepository repository                           
                           )
        {
            _jwtSettings = jwtSettings.Value;
            _repository = repository;
        }

        public string GenerateToken(string username, string password)
        {
            User user = _repository.ExistUserByName(username);
            if (user == null)
            {
                return null;
            }
            if (user.Password != password)
            {
                return null;
            }

            string role = user.Ruolo;
            var claims = new[] {
            new Claim(ClaimTypes.Name, username),
            new Claim(ClaimTypes.Role, role)
            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_jwtSettings.Key));
            var credentials = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                claims: claims,
                expires: DateTime.UtcNow.AddHours(1),
                signingCredentials: credentials
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

  


    }



}



