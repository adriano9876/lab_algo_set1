
using Microsoft.EntityFrameworkCore;
using sample_api_esame.Middleware;
using sample_api_esame.MiddlewareFolder;
using sample_api_esame.MiddlewareFolder.Interfaces;
using sample_api_esame.ModelsDue;
using sample_api_esame.Repository;
using FluentValidation;
using FluentValidation.AspNetCore;
using sample_api_esame.Dto;
using sample_api_esame.Service;

namespace sample_api_esame
{
    public class Program
    {
        static async Task Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            //builder.Services.AddAuthentication(JwtBearerDefaults)

            // Add services to the container.

            builder.Services.AddControllers();
            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

            /*per validare*/
            builder.Services.AddFluentValidationAutoValidation();
            builder.Services.AddValidatorsFromAssemblyContaining<AuthDto>();



            builder.Services.AddDbContext<MyRepoContext>
            (options => options.UseSqlServer(builder.Configuration
            .GetConnectionString("DefaultConnection")));


            builder.Services.AddScoped<IJwtService, JwtService>();
            builder.Services.AddScoped<IUserRepository, UserRepository>();
            builder.Services.AddScoped<IUserService, UserService>();


            builder.Services.Configure<JwtSettings>(builder.Configuration
                .GetSection("Jwt"));

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseMiddleware<LoggingMiddleware>();
            //app.Use(async (context, next) =>
            //{
            //    Console.WriteLine("1 prima di invoke");
            //    await next.Invoke();//.Invoke();
            //    Console.WriteLine("3 dopo invoke");
            //});
            //app.Use(async (context, next) =>
            //{
            //    Console.WriteLine("2 prima di invoke");
            //    await next();//.Invoke();
            //});

            app.UseWhen(
                context => !context.Request.Path.StartsWithSegments("/api/UserAuthFinal"),
                appBuilder =>
                {
                    appBuilder.UseMiddleware<AuthMiddleware>();
                }
            );


            app.UseHttpsRedirection();

            app.UseAuthorization();

            app.MapControllers();

            app.Run();
        }
    }
}
