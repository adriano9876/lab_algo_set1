﻿using sample_api_esame.ModelsDue;
using System;

namespace sample_api_esame.Repository
{
    public class UserRepository : IUserRepository
    {
        private readonly MyRepoContext _context;

        public UserRepository(MyRepoContext context)
        {
            _context = context;
        }

        public User ExistUserByName(string nome)
        {
            var userRet = _context.Users
                .FirstOrDefault(u => u.Nome == nome); 
            return userRet;
        }

        public List<User> GetUsersRepo()
        {
            var ret = _context.Users.ToList();
            return ret;         
        }
    }
}
