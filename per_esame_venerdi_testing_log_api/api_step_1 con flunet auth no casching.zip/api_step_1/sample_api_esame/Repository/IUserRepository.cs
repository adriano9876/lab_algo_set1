﻿using sample_api_esame.Dto;
using sample_api_esame.ModelsDue;

namespace sample_api_esame.Repository
{
    public interface IUserRepository
    {
        public User ExistUserByName(string nome);
        List<User> GetUsersRepo();
    }
}
