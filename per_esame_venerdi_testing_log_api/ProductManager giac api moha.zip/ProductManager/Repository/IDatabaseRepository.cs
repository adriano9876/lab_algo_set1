﻿using DataAccess.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository
{
    public interface IDatabaseRepository
    {
        public Task<IEnumerable<Product>> GetAllProductsAsync();
        public Task<IEnumerable<Category>> GetAllCategoriesAsync();

        public Task<Product> GetProductByIdAsync(int id);

        public Task<IEnumerable<Product>> GetProductByNameAsync(string name);
        public Task<Category> GetCategoryByIdAsync(int id);
        public Task<Product> CreateProductAsync(Product product);
        public Task<Product> UpdateProductAsync(int id, Product product);
        public Task<Category> CreateCategoryAsync(Category category);
        public Task<Category> UpdateCategoryAsync(int id, Category category);
        public Task DeleteProductAsync(int id);
        public Task DeleteCategoryAsync(int id);
    }
}
