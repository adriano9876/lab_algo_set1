﻿using DataAccess.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess.Context;
using Microsoft.EntityFrameworkCore;

namespace Repository.Impl
{
    public class DatabaseRepository : IDatabaseRepository
    {

        private readonly ProductManagerContext _context;

        public DatabaseRepository(ProductManagerContext context)
        {
            _context = context;   
        }

        public async Task<Category> CreateCategoryAsync(Category category)
        {
            var newCategory = _context.Categories.Add(category).Entity;
            await _context.SaveChangesAsync();
            return newCategory;
        }

        public async Task<Product> CreateProductAsync(Product product)
        {
            var newProduct = _context.Products.Add(product).Entity;
            await _context.SaveChangesAsync();
            return newProduct;
        }

        public async Task DeleteCategoryAsync(int id)
        {
            var categoryFound = await GetCategoryByIdAsync(id);
            _context.Categories.Remove(categoryFound);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteProductAsync(int id)
        {
            var product = await GetProductByIdAsync(id);
            _context.Products.Remove(product);
            await _context.SaveChangesAsync();
        }

        public async Task<IEnumerable<Category>> GetAllCategoriesAsync()
        {
            var categories = _context.Categories.AsNoTracking().ToListAsync();
            return await categories;
        }

        public async Task<IEnumerable<Product>> GetAllProductsAsync()
        {
            var products = _context.Products.AsNoTracking().Include(p => p.Category).ToListAsync();
            return await products;
        }

        public async Task<Category> GetCategoryByIdAsync(int id)
        {
            var category = _context.Categories.AsNoTracking().SingleOrDefaultAsync(c => c.Id == id);
            return await category;
        }

        public async Task<Product> GetProductByIdAsync(int id)
        {
            var product = _context.Products.AsNoTracking().Include(p => p.Category).SingleOrDefaultAsync(p => p.Id == id);
            return await product;
        }

        public async Task<Category> UpdateCategoryAsync(int id, Category category)
        {
            var categoryFound = await GetCategoryByIdAsync(id);
            categoryFound.Name = category.Name;
            _context.Entry(categoryFound).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return categoryFound;
        }

        public async Task<Product> UpdateProductAsync(int id, Product product)
        {
            var productFound = await GetProductByIdAsync(id);
            productFound.Name = product.Name;
            productFound.Price = product.Price;
            productFound.Quantity = product.Quantity;
            productFound.IsAvailable = product.IsAvailable;
            productFound.ProductionDate = product.ProductionDate;
            productFound.CategoryId = product.CategoryId;
            _context.Entry(productFound).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return productFound;
        }

        public async Task<IEnumerable<Product>> GetProductByNameAsync(string name)
        {
            var products = _context.Products.AsNoTracking().Include(p => p.Category).Where(p => p.Name.Contains(name)).ToListAsync();
            return await products;
        }
    }
}
