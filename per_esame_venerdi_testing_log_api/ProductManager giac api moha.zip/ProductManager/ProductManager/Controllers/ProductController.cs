﻿using Business.Dto;
using Business.Services;
using Microsoft.AspNetCore.Mvc;

namespace ProductManager.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProductController : Controller
    {
        private readonly IProductService _service;
        public ProductController(IProductService service)
        {
            _service = service;
        }

        [HttpGet("GetAllProducts")]
        public async Task<ActionResult<IEnumerable<GetAllProductDto>>> GetAllProductsAsync()
        {
            var products = await _service.GetAllProductDtoAsync();
            return Ok(products);
        }

        [HttpGet("GetProductsByName")]
        public async Task<ActionResult<IEnumerable<ProductDto>>> GetProductByNameAync([FromQuery(Name = "Filter")]string name)
        {
            var products = await _service.GetProductByNameAsync(name);
            if (products.Count() < 1)
            {
                return NotFound();
            }
            return Ok(products);
        }

        [HttpGet("GetProductById")]
        public async Task<ActionResult<ProductDto>> GetProductByIdAsync(int id)
        {
            var product = await _service.GetProductByIdAsync(id);
            if (product == null)
            {
                return NotFound();
            }
            return Ok(product);
        }

        [HttpPost]
        public async Task<ActionResult<ResponseProductDto>> CreateProduct([FromBody] RequestProductDto requestProductDto)
        {
            var product = await _service.CreateProductAsync(requestProductDto);
            return Ok(product);
        }

        [HttpPut]
        public async Task<ActionResult<ResponseProductDto>> UpdateProduct(int id, [FromBody]RequestProductDto requestProductDto)
        {
            var product = await _service.UpdateProductAsync(id, requestProductDto);
            return Ok(product);
        }

        [HttpDelete]
        public async Task<ActionResult> DeleteProduct(int id)
        {
            await _service.DeleteProductAsync(id);
            return Ok();
        }
    }
}
