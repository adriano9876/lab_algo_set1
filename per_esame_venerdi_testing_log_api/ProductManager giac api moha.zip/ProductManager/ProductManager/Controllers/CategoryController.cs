﻿using Business.Dto;
using Business.Services;
using Microsoft.AspNetCore.Mvc;

namespace ProductManager.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CategoryController : Controller
    {
        private readonly ICategoryService _service;
        private readonly ILogger<CategoryController> _logger;
        public CategoryController(ICategoryService categoryService, ILogger<CategoryController> logger)
        {
            _service = categoryService;
            _logger = logger;
        }

        [HttpGet("GetAllcategories")]
        public async Task<ActionResult<IEnumerable<CategoryDto>>> GetAllProductsAsync()
        {
            var categories = await _service.GetAllCategoriesAsync();
            return Ok(categories);
        }

        [HttpGet("GetCategoryById")]
        public async Task<ActionResult<CategoryDto>> GetProductByIdAsync(int id)
        {
            var category = await _service.GetCategoryByIdAsync(id);
            if (category == null)
            {
                return NotFound();
            }
            return Ok(category);
        }

        [HttpPost]
        public async Task<ActionResult<ResponseCategoryDto>> CreateCateogry([FromBody] RequestCategoryDto requestCategoryDto)
        {
            var category = await _service.CreateCategoryAsync(requestCategoryDto);
            _logger.LogInformation($"Created category: {category}");
            return Ok(category);
        }

        [HttpPut]
        public async Task<ActionResult<ResponseCategoryDto>> UpdateProduct(int id, [FromBody] RequestCategoryDto requestCategoryDto)
        {
            var category = await _service.UpdateCategoryAsync(id, requestCategoryDto);
            return Ok(category);
        }

        [HttpDelete]
        public async Task<ActionResult> DeleteProduct(int id)
        {
            await _service.DeleteCategoryAsync(id);
            return Ok();
        }
    }
}
