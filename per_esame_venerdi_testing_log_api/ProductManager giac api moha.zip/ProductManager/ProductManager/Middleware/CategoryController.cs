﻿using Business.Dto;
using Business.Services;
using Business.Services.Impl;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using System;

namespace ProductManager.Controllers
{

    public class CacheMiddleware 
    {

        private readonly RequestDelegate _next;
        private Dictionary<string, string> _cacheControl = new();
        private DateTime? GetId;


        public CacheMiddleware(RequestDelegate next)
        {
            _next = next;
        }
        public async Task InvokeAsync(HttpContext context)
        {
            if (context?.Request?.Path.Value is not null)
            {
                if (context?.Request?.Path.Value is not null && context.Request.Path.Value.ToLower().Contains("getproduct"))
                {
                    _cacheControl.TryGetValue(context.Request.Path.Value, out var cachedResponse);

                    if (cachedResponse is not null)
                    {
                        if (GetId is not null)
                        {
                            var isExpired = GetId - DateTime.UtcNow < TimeSpan.FromSeconds(30);

                            if (!isExpired)
                            {
                                await context.Response.WriteAsync(cachedResponse.ToString());
                            }

                            else
                            {
                                await _next(context);

                                GetId = DateTime.UtcNow;

                                _cacheControl.Add(context.Request.Path.Value, context.Response.Body.ToString());

                            }
                        }
                        else
                        {

                            _cacheControl.Remove(context.Request.Path.Value);

                            await _next(context);

                            GetId = DateTime.UtcNow;

                            var cachableResult = context.Response.Body.ToString();

                            _cacheControl.Add(context.Request.Path.Value, cachableResult);
                        }
                    }
                    else
                    {
                        await _next(context);

                        GetId = DateTime.UtcNow;

                        var cachableResult = context.Response.Body.ToString();

                        _cacheControl.Add(context.Request.Path.Value, cachableResult);
                    }

                }
                else
                {
                    await _next(context);
                }
            }
            else {
                await _next(context);
            }
        }

    }
}
