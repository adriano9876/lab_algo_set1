﻿using Business.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business.Services
{
    public interface IProductService
    {
        public Task<IEnumerable<GetAllProductDto>> GetAllProductDtoAsync();

        public Task<IEnumerable<ProductDto>> GetProductByNameAsync(string name);
        public Task<ProductDto> GetProductByIdAsync(int id);
        public Task<ResponseProductDto> CreateProductAsync(RequestProductDto productDto);
       
        public Task<ResponseProductDto> UpdateProductAsync(int id, RequestProductDto productDto);

        public Task DeleteProductAsync(int id);


    }
}
