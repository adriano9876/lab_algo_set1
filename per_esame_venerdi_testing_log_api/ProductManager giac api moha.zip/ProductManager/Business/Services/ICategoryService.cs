﻿using Business.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business.Services
{
    public interface ICategoryService
    {
        public Task<CategoryDto> GetCategoryByIdAsync(int id);
        public Task<IEnumerable<CategoryDto>> GetAllCategoriesAsync();
        public Task<ResponseCategoryDto> CreateCategoryAsync(RequestCategoryDto categoryDto);
        public Task<ResponseCategoryDto> UpdateCategoryAsync(int id, RequestCategoryDto categoryDto);
        public Task DeleteCategoryAsync(int id);
    }
}
