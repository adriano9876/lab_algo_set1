﻿using Business.Dto;
using DataAccess.Models;
using Microsoft.Extensions.Logging;
using Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business.Services.Impl
{
    public class CategoryService : ICategoryService
    {
        private readonly IDatabaseRepository _repository;
        private readonly ILogger<CategoryService> _logger;
        public CategoryService(IDatabaseRepository repository, ILogger<CategoryService> logger)
        {
            _logger = logger;
            _repository = repository;
        }
        public async Task<ResponseCategoryDto> CreateCategoryAsync(RequestCategoryDto categoryDto)
        {
            _logger.LogInformation("Chiamata create category");
            var newCategory = await _repository.CreateCategoryAsync(new Category
            {
                Id = 0,
                Name = categoryDto.Name,
            });
            return new ResponseCategoryDto
            {
                Id = newCategory.Id,
                Name = newCategory.Name
            };
        }

        public async Task DeleteCategoryAsync(int id)
        {
            await _repository.DeleteCategoryAsync(id);
        }

        public async Task<IEnumerable<CategoryDto>> GetAllCategoriesAsync()
        {
            var categories = await _repository.GetAllCategoriesAsync();
            var categoryDtos = categories.Select(c => new CategoryDto
            {
                Id= c.Id,
                Name = c.Name,
            }).ToList();
            return categoryDtos;
        }

        public async Task<CategoryDto> GetCategoryByIdAsync(int id)
        {
            var category = await _repository.GetCategoryByIdAsync(id);
            if(category == null)
            {
                _logger.LogError("Category Not Found");
                _logger.LogCritical("Category Not Found");
            }
            return new CategoryDto
            {
                Id = category.Id,
                Name = category.Name,
            };
        }

        public async Task<ResponseCategoryDto> UpdateCategoryAsync(int id, RequestCategoryDto categoryDto)
        {
            var updateCategory = await _repository.UpdateCategoryAsync(id, new Category
            {
                Id = id,
                Name = categoryDto.Name,
            });
            return new ResponseCategoryDto
            {
                Id = updateCategory.Id,
                Name = updateCategory.Name
            };
        }
    }
}
