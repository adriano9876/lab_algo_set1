﻿using Business.Dto;
using DataAccess.Models;
using Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business.Services.Impl
{
    public class ProductService : IProductService
    {
        private readonly IDatabaseRepository _repository;
        public ProductService(IDatabaseRepository repository)
        {
            _repository = repository;
        }

        public async Task<ResponseProductDto> CreateProductAsync(RequestProductDto productDto)
        {
            var newProduct = await _repository.CreateProductAsync(new Product
            {
                Id = 0,
                Name = productDto.Name,
                Price = productDto.Price,
                Quantity = productDto.Quantity,
                ProductionDate = productDto.ProductionDate,
                IsAvailable = productDto.IsAvailable,
                CategoryId = productDto.CategoryId
            });

            return new ResponseProductDto
            {
                Id = newProduct.Id,
                Name = newProduct.Name,
                Price = newProduct.Price,
                Quantity = newProduct.Quantity,
                ProductionDate= newProduct.ProductionDate,
                IsAvailable = newProduct.IsAvailable,
                CategoryId = newProduct.CategoryId
            };
        }

        public async Task DeleteProductAsync(int id)
        {
            await _repository.DeleteProductAsync(id);
        }

        public async Task<IEnumerable<GetAllProductDto>> GetAllProductDtoAsync()
        {
            var products = await _repository.GetAllProductsAsync();
            var productsDto = products.Select(x => new GetAllProductDto
            {
                Id = x.Id,
                Name = x.Name,
                Price = x.Price,
                Quantity = x.Quantity,
                IsAvailable = x.IsAvailable,
                ProductionDate = x.ProductionDate,
                CategoryDto = new CategoryDto
                {
                    Id = x.CategoryId,
                    Name = x.Category.Name
                }
            }).ToList();
            return productsDto;
        }

        public async Task<ProductDto> GetProductByIdAsync(int id)
        {
            var product = await _repository.GetProductByIdAsync(id);
            return new ProductDto
            {
                Id = product.Id,
                Name = product.Name,
                Price = product.Price,
                Quantity = product.Quantity,
                IsAvailable = product.IsAvailable,
                ProductionDate = product.ProductionDate,
                CategoryName = product.Category.Name
            };
        }

        public async Task<IEnumerable<ProductDto>> GetProductByNameAsync(string name)
        {
            var products = await _repository.GetProductByNameAsync(name);
            var productsDto = products.Select(x => new ProductDto
            {
                Id = x.Id,
                Name = x.Name,
                Price = x.Price,
                Quantity = x.Quantity,
                IsAvailable = x.IsAvailable,
                ProductionDate = x.ProductionDate,
                CategoryName = x.Category.Name
            }).ToList();
            return productsDto;
        }

        public async Task<ResponseProductDto> UpdateProductAsync(int id, RequestProductDto productDto)
        {
            var productUpdated = await _repository.UpdateProductAsync(id, new Product
            {
                Name = productDto.Name,
                Price = productDto.Price,
                Quantity = productDto.Quantity,
                IsAvailable = productDto.IsAvailable,
                ProductionDate = productDto.ProductionDate,
                CategoryId = productDto.CategoryId
            });
            return new ResponseProductDto
            {
                Id = productUpdated.Id,
                Name = productUpdated.Name,
                Price = productUpdated.Price,
                Quantity = productUpdated.Quantity,
                IsAvailable = productUpdated.IsAvailable,
                ProductionDate = productUpdated.ProductionDate,
                CategoryId = productUpdated.CategoryId
            };
        }
    }
}
