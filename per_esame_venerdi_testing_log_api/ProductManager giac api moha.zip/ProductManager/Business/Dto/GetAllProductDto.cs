﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business.Dto
{
    public class GetAllProductDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public double Price { get; set; }
        public int Quantity { get; set; }
        public bool IsAvailable { get; set; }
        public DateTime ProductionDate { get; set; }
        public CategoryDto CategoryDto { get; set; }
    }
}
