﻿using DataAccess.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Context
{
    public class ProductManagerContext : DbContext
    {
        public ProductManagerContext(DbContextOptions<ProductManagerContext> options): base(options) { }

        public DbSet<Product> Products { get; set; }
        public DbSet<Category> Categories { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Category>()
                .HasMany(c => c.Products)
                .WithOne(p => p.Category)
                .HasForeignKey(p => p.CategoryId)
                .IsRequired();

            modelBuilder.Entity<Category>().HasData(
                new Category { Id = 1, Name = "Informatica"},
                new Category { Id = 2, Name = "Cancellaeria"},
                new Category { Id = 3, Name = "Giocatttoli"}
            );

            modelBuilder.Entity<Product>().HasData(
                new Product { Id = 1, Name = "Mouse", IsAvailable = true, ProductionDate = DateTime.UtcNow, Price = 22.31, CategoryId = 1, Quantity = 35},
                new Product { Id = 2, Name = "Tastiera", IsAvailable = false, ProductionDate = DateTime.UtcNow, Price = 36.89, CategoryId = 1, Quantity = 89 },
                new Product { Id = 3, Name = "Penna", IsAvailable = true, ProductionDate = DateTime.UtcNow, Price = 3.6, CategoryId = 2, Quantity = 12 },
                new Product { Id = 4, Name = "Quaderno", IsAvailable = false, ProductionDate = DateTime.UtcNow, Price = 5.9, CategoryId = 2, Quantity = 26 },
                new Product { Id = 5, Name = "Macchinina", IsAvailable = true, ProductionDate = DateTime.UtcNow, Price = 12.57, CategoryId = 3, Quantity = 46 },
                new Product { Id = 6, Name = "Trenino", IsAvailable = false, ProductionDate = DateTime.UtcNow, Price = 300.65, CategoryId = 3, Quantity = 4 }
            );
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.ConfigureWarnings(warnings =>
            warnings.Ignore(RelationalEventId.PendingModelChangesWarning));
        }
    }
}
