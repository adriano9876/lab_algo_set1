﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Models
{
    public class Product
    {
        [Required]
        public int Id { get; set; }
        [Required]
        [DataType("nvarchar(150)")]
        public string Name { get; set; }
        [Required]
        [DataType("decimal(10,2)")]
        public double Price { get; set; }
        [Required]
        public int Quantity { get; set; }

        [Required]
        public bool IsAvailable { get; set; }
        [Required]
        public DateTime ProductionDate { get; set; }
        [Required]
        public int CategoryId { get; set; }
        public Category Category { get; set; }
    }
}
