﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace DataAccess.Migrations
{
    /// <inheritdoc />
    public partial class FirstMigration : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Categories",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Categories", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Products",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Price = table.Column<double>(type: "float", nullable: false),
                    Quantity = table.Column<int>(type: "int", nullable: false),
                    IsAvailable = table.Column<bool>(type: "bit", nullable: false),
                    ProductionDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CategoryId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Products", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Products_Categories_CategoryId",
                        column: x => x.CategoryId,
                        principalTable: "Categories",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Categories",
                columns: new[] { "Id", "Name" },
                values: new object[,]
                {
                    { 1, "Informatica" },
                    { 2, "Cancellaeria" },
                    { 3, "Giocatttoli" }
                });

            migrationBuilder.InsertData(
                table: "Products",
                columns: new[] { "Id", "CategoryId", "IsAvailable", "Name", "Price", "ProductionDate", "Quantity" },
                values: new object[,]
                {
                    { 1, 1, true, "Mouse", 22.309999999999999, new DateTime(2025, 11, 7, 9, 26, 9, 206, DateTimeKind.Utc).AddTicks(3447), 35 },
                    { 2, 1, false, "Tastiera", 36.890000000000001, new DateTime(2025, 11, 7, 9, 26, 9, 206, DateTimeKind.Utc).AddTicks(4290), 89 },
                    { 3, 2, true, "Penna", 3.6000000000000001, new DateTime(2025, 11, 7, 9, 26, 9, 206, DateTimeKind.Utc).AddTicks(4292), 12 },
                    { 4, 2, false, "Quaderno", 5.9000000000000004, new DateTime(2025, 11, 7, 9, 26, 9, 206, DateTimeKind.Utc).AddTicks(4293), 26 },
                    { 5, 3, true, "Macchinina", 12.57, new DateTime(2025, 11, 7, 9, 26, 9, 206, DateTimeKind.Utc).AddTicks(4295), 46 },
                    { 6, 3, false, "Trenino", 300.64999999999998, new DateTime(2025, 11, 7, 9, 26, 9, 206, DateTimeKind.Utc).AddTicks(4296), 4 }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Products_CategoryId",
                table: "Products",
                column: "CategoryId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Products");

            migrationBuilder.DropTable(
                name: "Categories");
        }
    }
}
