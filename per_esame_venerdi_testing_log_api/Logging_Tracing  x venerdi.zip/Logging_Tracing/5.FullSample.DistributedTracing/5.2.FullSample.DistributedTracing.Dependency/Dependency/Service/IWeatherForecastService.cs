﻿using Week9.Observability;

namespace Dependency.Service
{
    public interface IWeatherForecastService
    {
        IList<WeatherForecast> GetWeatherForecastPlusDays(int year, int month, int day, int plusDays);
    }
}