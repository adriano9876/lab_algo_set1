using Controller.Tracing;
using Dependency.Service;
using HealthChecks.UI.Client;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using OpenTelemetry.Exporter;
using OpenTelemetry.Metrics;
using OpenTelemetry.Resources;
using OpenTelemetry.Trace;
using Serilog;
using Serilog.Events;
using Serilog.Sinks.SystemConsole.Themes;
using System.Diagnostics;

namespace Week9.Observability.Controllers
{
    public class Program
    {
        public static void Main(string[] args)
        {
            // ------------------ TEST ACTIVITY WHEN LOCAL DEV ------------------ //
#if DEBUG
            var listener = new ActivityListener
            {
                ShouldListenTo = _ => true,
                Sample = (ref ActivityCreationOptions<ActivityContext> _) => ActivitySamplingResult.AllData,
                //ActivityStarted = a => Console.WriteLine($"START: {a.DisplayName}"),
                //ActivityStopped = a => Console.WriteLine($"STOP: {a.DisplayName}")
            };
            ActivitySource.AddActivityListener(listener);
#endif

            var builder = WebApplication.CreateBuilder(args);




            // configuring LOGGING with SeriLog
            builder
               .Logging
               // Remove all the Logging Providers before adding the ones that i want
               // to be sure to use only the ones added by me and not automatically added by ASP.NET
               .ClearProviders();

            // create configuration for Serilog
            var configSerilog = new LoggerConfiguration()
                .MinimumLevel.Information() // <- Only logs AT OR ABOVE this logLevel will be emitted
                .MinimumLevel.Override("Microsoft", LogEventLevel.Information) // suppress ASP.NET Core info logs
                .MinimumLevel.Override("System", LogEventLevel.Warning)    // suppress system logs

                // SINK CONSOLE added to Serilog
                .WriteTo.Console(
                    outputTemplate: "[{HH:mm:ss} {Level:u3}] {Message:lj}{NewLine}{Exception}",
                    theme: SystemConsoleTheme.Colored
                )
                .CreateLogger();

            builder.Services.AddSerilog(configSerilog); // <-- This method, provided by Serilog Nuget, add Serilog as Logging Provider of ILOGGER with the proper configuration


            // configuring TRACING AND METRICS with OpenTelemetry exporter
            builder.Services
                .AddOpenTelemetry()
                .ConfigureResource(resource => resource.Clear())
                .WithTracing(tracing =>
                {
                    tracing
                        .AddProcessor(new ActivityFilteringProcessor()) // <-- reduce the noise exporting only traces emitted by us (for example not the server)
                        .AddSource(Tracing.ActivitySource.Name)     // <-- must match your ActivitySource name
                        .SetResourceBuilder(ResourceBuilder.CreateDefault().AddService("WeatherForecastService"))
                        .AddAspNetCoreInstrumentation()
                        .AddConsoleExporter();                      // <-- this shows spans in console
                })
                .WithMetrics(metrics =>
                {
                    metrics
                        .AddMeter("dependency")
                        .AddConsoleExporter(); // <-- required to see metrics in console
                });

            // CONFIGURING HEALTH CHECK
            builder.Services.AddHealthChecks();



            builder.Services.AddSingleton<IWeatherForecastService, WeatherForecastService>();

            builder.Services.AddControllers();
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseHttpsRedirection();

            app.UseAuthorization();


            app.MapControllers();

            app.MapHealthChecks("/health/live", new HealthCheckOptions
            {
                // this Predicate is to "filter" the Health Checks registered above
                // in this case I filter everything --> So when I call the "/health/live" endpoint, ANY Health Checks is runned
                Predicate = _ => false,
                ResponseWriter = UIResponseWriter.WriteHealthCheckUIResponse // <- the Health Check will respond in JSON format and not just "Healthy string"
            });

            app.MapHealthChecks("/health/ready", new HealthCheckOptions
            {
                // this Predicate is to "filter" the Health Checks registered above
                // in this case I don't filter anything --> So when I call the "/health/ready" endpoint, EVERY Health Checks is runned
                Predicate = _ => true,
                ResponseWriter = UIResponseWriter.WriteHealthCheckUIResponse // <- the Health Check will respond in JSON format and not just "Healthy string"
            });

            app.Run();
        }
    }
}