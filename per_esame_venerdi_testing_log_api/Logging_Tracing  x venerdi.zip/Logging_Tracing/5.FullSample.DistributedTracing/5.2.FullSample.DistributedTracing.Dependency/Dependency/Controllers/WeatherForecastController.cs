using Controller.Tracing;
using Dependency.Service;
using Microsoft.AspNetCore.Http.Json;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Diagnostics.Metrics;
using System.Net;
using System.Reflection;

namespace Week9.Observability.Controllers;

[ApiController]
[Route("[controller]")]
public class WeatherForecastController : ControllerBase
{
    private readonly ILogger<WeatherForecastController> _logger;
    private readonly IWeatherForecastService _weatherForecastService;

    // attributes for metrics
    private readonly IMeterFactory _meterFactory;
    private readonly Counter<int> _counterRequestTotal;
    private readonly Counter<int> _counterRequestSuccess;
    private readonly Counter<int> _counterRequestError;


    public WeatherForecastController(ILogger<WeatherForecastController> logger, IMeterFactory meterFactory, IWeatherForecastService weatherForecastService)
    {
        _logger = logger;

        _meterFactory = meterFactory;
        var meter = meterFactory.Create("dependency");
        _counterRequestTotal = meter.CreateCounter<int>("requests.total");
        _counterRequestSuccess = meter.CreateCounter<int>("requests.success");
        _counterRequestError = meter.CreateCounter<int>("requests.error");

        _weatherForecastService = weatherForecastService;
    }

    [HttpGet(Name = "InternalWeatherForecast")]
    public async Task<ActionResult<IEnumerable<WeatherForecast>>> InternalWeatherForecastPlusDays(int year, int month, int day, int plusDays)
    {
        // incremente request received (independently if it will be ok or not ok)
        _counterRequestTotal.Add(1);

        using (var activity = Tracing.ActivitySource.StartActivity($"Assembly:{nameof(Assembly.FullName)} | InternalWeatherForecastPlusDays DEPENDENCY requested"))
        {
            // requested arrived
            _logger.LogInformation("Requested receveid with this parameters: {year},{month},{day},{plusDays}", year, month, day, plusDays);

            try
            {
                var result = _weatherForecastService.GetWeatherForecastPlusDays(year, month, day, plusDays);

                activity.SetStatus(ActivityStatusCode.Ok);

                return Ok(result);
            }
            catch (Exception ex)
            {
                // response is NOT OK

                _logger.LogError(ex, "Error elaborating the request.");

                // incremente requests error
                _counterRequestError.Add(1);

                activity.SetStatus(ActivityStatusCode.Error);

                return BadRequest();
            }
        }
    }
}