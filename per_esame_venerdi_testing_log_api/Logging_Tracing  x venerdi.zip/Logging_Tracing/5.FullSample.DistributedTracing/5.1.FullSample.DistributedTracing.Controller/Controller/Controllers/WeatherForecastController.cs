using Controller.Tracing;
using Microsoft.AspNetCore.Http.Json;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Diagnostics.Metrics;
using System.Net;
using System.Reflection;

namespace Week9.Observability.Controllers;

[ApiController]
[Route("[controller]")]
public class WeatherForecastController : ControllerBase
{
    private readonly ILogger<WeatherForecastController> _logger;

    // attributes for metrics
    private readonly IMeterFactory _meterFactory;
    private readonly Counter<int> _counterRequestTotal;
    private readonly Counter<int> _counterRequestSuccess;
    private readonly Counter<int> _counterRequestError;


    public WeatherForecastController(ILogger<WeatherForecastController> logger, IMeterFactory meterFactory)
    {
        _logger = logger;

        _meterFactory = meterFactory;
        var meter = meterFactory.Create("controller");
        _counterRequestTotal = meter.CreateCounter<int>("requests.total");
        _counterRequestSuccess = meter.CreateCounter<int>("requests.success");
        _counterRequestError = meter.CreateCounter<int>("requests.error");
    }

    [HttpGet(Name = "GetWeatherForecastPlusDaysFromOtherService")]
    public async Task<ActionResult<IEnumerable<WeatherForecast>>> GetWeatherForecastPlusDaysFromOtherService(int year, int month, int day, int plusDays)
    {
        // incremente request received (independently if it will be ok or not ok)
        _counterRequestTotal.Add(1);

        using (var activity = Tracing.ActivitySource.StartActivity($"Assembly:{nameof(Assembly.FullName)} | GetWeatherForecastPlusDays CONTROLLER requested"))
        {
            // creating an HttpClient
            // object that is able to perform HTTP calls (like POSTMAN...)
            // DON'T create HttpClient by hand. Study the official .NET documentation
            HttpClient httpClient = new HttpClient();

            // calling the other project -> passing the arguments received by this controller
            _logger.LogInformation("Calling other project");

            try
            {
                var response = await httpClient.GetAsync($"https://localhost:7093/WeatherForecast?year={year}&month={month}&day={day}&plusDays={plusDays}");

                response.EnsureSuccessStatusCode();

                // response is OK
                _logger.LogInformation("Response received is OK");

                // incremente requests success
                _counterRequestSuccess.Add(1);


                activity.SetStatus(ActivityStatusCode.Ok);

                // from the response (a string in json format -> Deserialize in the expected type)
                var forecasts = await response.Content.ReadFromJsonAsync<IList<WeatherForecast>>();

                return Ok(forecasts);
            }
            catch (Exception ex)
            {
                // response is NOT OK

                _logger.LogError(ex, "Response received is NOT OK. Status code received.");

                // incremente requests error
                _counterRequestError.Add(1);

                activity.SetStatus(ActivityStatusCode.Error);

                return BadRequest();
            }
        }
    }
}