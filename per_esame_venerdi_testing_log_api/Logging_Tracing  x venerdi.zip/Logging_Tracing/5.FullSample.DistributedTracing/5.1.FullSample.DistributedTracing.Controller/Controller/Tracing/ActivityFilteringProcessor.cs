﻿using OpenTelemetry;
using System.Diagnostics;

namespace Controller.Tracing
{
    // https://learn.microsoft.com/en-us/azure/azure-monitor/app/opentelemetry-filter?tabs=aspnetcore
    public class ActivityFilteringProcessor : BaseProcessor<Activity>
    {
        // The OnStart method is called when an activity is started. This is the ideal place to filter activities.
        public override void OnStart(Activity activity)
        {
            // prevents all exporters from exporting internal activities
            if (activity.Kind == ActivityKind.Server)
            {
                activity.IsAllDataRequested = false;
            }
        }
    }
}
