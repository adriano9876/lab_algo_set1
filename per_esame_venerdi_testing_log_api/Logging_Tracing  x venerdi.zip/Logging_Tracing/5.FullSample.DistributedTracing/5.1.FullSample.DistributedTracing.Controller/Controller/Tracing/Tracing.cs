﻿using System.Diagnostics;

namespace Controller.Tracing
{
    public static class Tracing
    {
        public static ActivitySource ActivitySource = new ActivitySource("myapp.controller");
    }
}
