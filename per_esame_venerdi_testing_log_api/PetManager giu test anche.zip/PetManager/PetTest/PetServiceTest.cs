using DataAccess.Model;
using Moq;
using PetManager.Repository;
using PetManager.Service;
using PetManager.Service.Dto;

namespace PetTest
{
    public class PetServiceTest
    {
        private readonly Mock<IPetRepository> _repoMock;
        private readonly IPetService _service;
        private readonly Mock<IRandomGenerator> _randomGeneratorMock;

        public PetServiceTest()
        {
            _randomGeneratorMock = new Mock<IRandomGenerator>();
            _repoMock = new Mock<IPetRepository>();
            _service = new PetService(_repoMock.Object,_randomGeneratorMock.Object);
        }

        [Fact]
        public async Task  GetAll_ReturnsAllPets()
        {
            // Arrange
            var pets = new List<Pet>
            {
                 new Pet { Id = 1, Name = "Pippo", Description = "bel cane", Weight = 8.8, CategoryId = 1, OwnerId = 1 }
            };
            _repoMock.Setup(r => r.GetAllPets()).ReturnsAsync(pets);

            // Act
            var result = await _service.GetAllPets();

            // Assert
            Assert.Equal(pets[0].Name, result.First().Name);
            _repoMock.Verify(r => r.GetAllPets(), Times.Once);
        }

        [Fact]
        public async Task GetById_ExistingId_ReturnsPet()
        {
            // Arrange
            var pet = new Pet { Id = 1, Name = "Pippo", Description = "bel cane", Weight = 8.8, CategoryId = 1, OwnerId = 1 };
            _repoMock.Setup(r => r.GetPetByid(1)).ReturnsAsync(pet);

            // Act
            var result =await _service.GetPetByid(1);

            // Assert
            Assert.Equal(pet.Name, result.Name);    
            _repoMock.Verify(r => r.GetPetByid(1), Times.Once);
        }


        //[Fact]
        //public void GetById_NonExistingId_ReturnsNull()
        //{
        //    // Arrange
        //    _repoMock.Setup(r => r.GetById(2)).Returns((Contact?)null);

        //    // Act
        //    var result = _service.GetById(2);

        //    // Assert
        //    Assert.Null(result);
        //    _repoMock.Verify(r => r.GetById(2), Times.Once);
        //}

        [Fact]
        public async Task Add_CallsRepositoryAdd()
        {
            // Arrange
            var newPet = new PetDto {  Name = "Pippo", Description = "bel cane", Weight = 8.8, CategoryId = 1, OwnerId = 1 };
            _randomGeneratorMock.Setup(r => r.GiveNumber()).Returns(20000);
            _repoMock.Setup(a => a.GetCategoryNameById(1)).ReturnsAsync("Cane");
            // Act
            var result = await _service.InsertPet(newPet);
            

            // Assert
            _repoMock.Verify(r => r.InsertPet(It.IsAny<Pet>()), Times.Once);
            Assert.Equal($"Cane_Po520000", result.PetTag);

            Tree
        }

        //[Fact]
        //public void Update_CallsRepositoryUpdate()
        //{
        //    // Arrange
        //    var contact = new Contact { Id = 1, Name = "Mario", Surname = "Rossi", PhoneNumber = "123", Email = "mario@rossi.it" };

        //    // Act
        //    _service.Update(contact);

        //    // Assert
        //    _repoMock.Verify(r => r.Update(contact), Times.Once);
        //}

        //[Fact]
        //public void Delete_CallsRepositoryDelete()
        //{
        //    // Arrange
        //    int id = 1;

        //    // Act
        //    _service.Delete(id);

        //    // Assert
        //    _repoMock.Verify(r => r.Delete(id), Times.Once);
        //}

        //[Fact]
        //public void GetEldestContact_ReturnsContactWithMaxAge()
        //{
        //    // Arrange
        //    var contacts = new List<Contact>
        //    {
        //        new Contact { Id = 1, Name = "Alice", Surname = "Smith", Age = 30 },
        //        new Contact { Id = 2, Name = "Bob", Surname = "Jones", Age = 45 },
        //        new Contact { Id = 3, Name = "Charlie", Surname = "Brown", Age = 40 }
        //    };

        //    // Act
        //    var result = _service.GetEldestContact(contacts);

        //    // Assert
        //    Assert.NotNull(result);
        //    Assert.Equal(45, result.Age);
        //    Assert.Equal("Bob", result.Name);
        //}

        //[Fact]
        //public void GetEldestContact_EmptyList_ReturnsNull()
        //{
        //    // Arrange
        //    var contacts = new List<Contact>();

        //    // Act
        //    var result = _service.GetEldestContact(contacts);

        //    // Assert
        //    Assert.Null(result);
        //}

        //[Fact]
        //public void GetEldestContact_NullContacts_ThrowsArgumentNullException()
        //{
        //    // Act & Assert
        //    Assert.Throws<ArgumentNullException>(() => _service.GetEldestContact(null!));
        //}

        //public static IEnumerable<object[]> ElderContactTestData =>
        //new List<object[]>
        //{
        //    new object[] { new Contact { Name = "A", Age = 30 }, new Contact { Name = "B", Age = 25 }, "A" },
        //    new object[] { new Contact { Name = "A", Age = 25 }, new Contact { Name = "B", Age = 30 }, "B" },
        //    new object[] { new Contact { Name = "A", Age = 40 }, new Contact { Name = "B", Age = 40 }, "A" },
        //};

        //[Theory]
        //[MemberData(nameof(ElderContactTestData))]
        //public void GetElderContact_ReturnsElderContact(Contact first, Contact second, string expectedName)
        //{
        //    // Act
        //    var result = _service.GetElderContact(first, second);

        //    // Assert
        //    Assert.NotNull(result);
        //    Assert.Equal(expectedName, result.Name);
        //}

        //[Theory]
        //[InlineData(40, 30, true)]
        //[InlineData(30, 40, false)]
        //[InlineData(25, 25, true)]
        //public void GetElderContact_ReturnsCorrectContact_InlineData(int age1, int age2, bool firstIsElder)
        //{
        //    var first = new Contact { Id = 1, Name = "A", Surname = "B", Age = age1 };
        //    var second = new Contact { Id = 2, Name = "C", Surname = "D", Age = age2 };

        //    var result = _service.GetElderContact(first, second);

        //    Assert.Equal(firstIsElder, result == first);
        //}

        //[Fact]
        //public void GetElderContact_ThrowsArgumentNullException_WhenFirstIsNull()
        //{
        //    // Arrange
        //    var second = new Contact { Name = "B", Age = 20 };

        //    // Act & Assert
        //    Assert.Throws<ArgumentNullException>(() => _service.GetElderContact(null!, second));
        //}

        //[Fact]
        //public void GetElderContact_ThrowsArgumentNullException_WhenSecondIsNull()
        //{
        //    // Arrange
        //    var first = new Contact { Name = "A", Age = 20 };

        //    // Act & Assert
        //    Assert.Throws<ArgumentNullException>(() => _service.GetElderContact(first, null!));
        //}

        //[Fact]
        //public void GetGreetingForContact_ReturnsData()
        //{
        //    // Arrange
        //    var contact = new Contact { Name = "Alice" };

        //    // Act
        //    var result = _service.GetGreetingForContact(contact);

        //    // Assert
        //    Assert.NotNull(result);
        //    //Assert.Equal($"Good afternoon Alice", result); <-- Non-deterministic assertion
        //}
    }
}