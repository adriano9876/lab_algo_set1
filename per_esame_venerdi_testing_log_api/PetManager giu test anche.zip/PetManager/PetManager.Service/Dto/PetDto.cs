﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PetManager.Service.Dto
{
    public class PetDto
    {
       
        public string Name { get; set; }
        public string Description { get; set; }
        public double Weight { get; set; }
        public int? CategoryId { get; set; }
        public int? OwnerId { get; set; }
        public string? PetTag { get; set; }
    }
}
