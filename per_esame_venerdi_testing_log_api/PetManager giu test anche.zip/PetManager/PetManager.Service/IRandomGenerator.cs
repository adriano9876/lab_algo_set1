﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PetManager.Service
{
    public interface IRandomGenerator
    {

        public int GiveNumber();
    }
}
