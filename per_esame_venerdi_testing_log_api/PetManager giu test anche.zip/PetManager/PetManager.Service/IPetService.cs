﻿using DataAccess.Model;
using PetManager.Service.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PetManager.Service
{
    public interface IPetService
    {
        Task<PetDto> GetPetByid(int id);
        Task<ICollection<PetDto>> GetAllPets();

        Task<PetDto> InsertPet(PetDto pet);
        Task<bool> DeletePet(int id);
        Task<bool> UpdatePet(int id,PetDto pet);
        Task<List<string>> GetAllTags();
        Task<double> CalculateDailyIntake();
    }
}
