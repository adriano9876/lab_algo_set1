﻿using DataAccess.Model;
using Microsoft.EntityFrameworkCore;
using PetManager.Repository;
using PetManager.Service.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PetManager.Service
{
    public class PetService : IPetService
    {
        private readonly IPetRepository _petRepository;
        private readonly IRandomGenerator _randomGenerator;

        public PetService(IPetRepository petRepository, IRandomGenerator randomGenerator)
        {
            _petRepository = petRepository;
            _randomGenerator = randomGenerator;
        }

        public double CalculateDailyIntake(double peso , double eta )
        {
            var ration = peso * 0.03;
            if (eta <= 1)
            {
                ration = ration + ration / 2;
            }
            if (eta > 10)
            {
                ration = ration - (ration * 0.3);
            }
            return ration;
        }

        public async Task<bool> DeletePet(int id)
        {
            await _petRepository.DeletePet(id);
            return true;
        }

        public async Task<ICollection<PetDto>> GetAllPets()
        {
            var pets = await _petRepository.GetAllPets();

            return pets.Select(pet => new PetDto
            {
                Weight = pet.Weight,
                OwnerId = pet.OwnerId,
                Name = pet.Name,

                CategoryId = pet.CategoryId,
                Description = pet.Description,
                PetTag = pet.PetTag

            }).ToList();

        }

        public async Task<List<string>> GetAllTags()
        {
            var listTags = await _petRepository.GetAllTags();
            return listTags;
        }

        public async Task<PetDto> GetPetByid(int id)
        {
            var petToFind = await _petRepository.GetPetByid(id);
            var petDto = new PetDto
            {
                CategoryId = petToFind.CategoryId,
                Description = petToFind.Description,

                Name = petToFind.Name,
                OwnerId = petToFind.OwnerId,
                Weight = petToFind.Weight,
                PetTag = petToFind.PetTag,

            };

            return petDto;
        }


        public async Task<PetDto> InsertPet(PetDto petToAdd)
        {
            var category = await _petRepository.GetCategoryNameById((int)petToAdd.CategoryId);
            var firstpart = "";
            var secondpart = "";
            if (petToAdd.Name == null || petToAdd.Name == "")
            {
                firstpart = "N";
                secondpart = "A";
            }
            else
            {

                firstpart = petToAdd.Name[0].ToString();
                secondpart = petToAdd.Name[petToAdd.Name.Length - 1].ToString();
            }
            var tag = $"{category}{"_"}{firstpart}" +
                    $"{secondpart}" +
                    $"{petToAdd.Name.Length}{_randomGenerator.GiveNumber()}";
            var tagList = await GetAllTags();

            while (!tagList.Contains(tag))
            {

                tag = $"{category}{"_"}{firstpart}" +
                 $"{secondpart}" +
                 $"{petToAdd.Name.Length}{_randomGenerator.GiveNumber()}";
            }
            petToAdd.PetTag = tag;


            var petToEntity = await _petRepository.InsertPet(new Pet
            {
                Description = petToAdd.Description,
                CategoryId = petToAdd.CategoryId,
                Name = petToAdd.Name,
                Weight = petToAdd.Weight,
                OwnerId = petToAdd.OwnerId,
                PetTag = tag

            });
            return petToAdd;
        }

        public async Task<bool> UpdatePet(int id, PetDto pet)
        {
            var petToAdd = await _petRepository.UpdatePet(new Pet
            {
                Description = pet.Description,
                CategoryId = pet.CategoryId,
                Name = pet.Name,
                Weight = pet.Weight,
                OwnerId = pet.OwnerId,
                Id = id

            });
            return true;
        }


    }
}
