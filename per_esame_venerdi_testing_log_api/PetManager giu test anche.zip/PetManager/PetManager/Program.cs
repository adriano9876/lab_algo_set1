
using Microsoft.EntityFrameworkCore;
using PetManager.DataAccess.PetManagerDbContext;
using PetManager.Repository;
using PetManager.Service;

namespace PetManager
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.

            builder.Services.AddControllers();
            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();
            builder.Services.AddScoped<IPetRepository, PetRepository>();
            builder.Services.AddScoped<IRandomGenerator, RandomGenerator>();
            builder.Services.AddScoped<IPetService, PetService>();
            builder.Services.AddDbContext<PetDbContext>(option => option.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));
            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseHttpsRedirection();

            app.UseAuthorization();


            app.MapControllers();

            app.Run();
        }
    }
}
