﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PetManager.Service;
using PetManager.Service.Dto;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace PetManager.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class PetController : ControllerBase
    {
        // GET: api/<PetController>
        private readonly IPetService _service;

        public PetController(IPetService service)
        {
            _service = service;
        }

        [HttpPost]
        public async Task<IActionResult> InsertPet(PetDto pet)
        {

            await _service.InsertPet(pet);
            return Ok();
        }

        //b) Ritorna la lista di tutti i corsi
        [HttpGet("pets")]
        public async Task<ActionResult<IEnumerable<PetDto>>> GetAllPets()
        {
            var allpets = await _service.GetAllPets();
            return Ok(allpets);
        }

        //c) Aggiorna i dati di un corso
        [HttpPut("Pet/update")]
        public async Task<IActionResult> UpdateDto(int id, PetDto pet)
        {
            await _service.UpdatePet( id, pet);
            return Ok();

        }

        //d) Cancella un corso
        [HttpDelete("pet/delete")]
        public async Task<IActionResult> DeletePet(int id)
        {
            await _service.DeletePet( id);
            return Ok();
        }
    }
}
