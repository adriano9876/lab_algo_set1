﻿using PetManager.DataAccess.Model;

namespace DataAccess.Model
{
    public class Pet : BaseEntity
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public double Weight { get; set; }
        public int? CategoryId { get; set; }
        public int? OwnerId { get; set; }
        public string? PetTag { get; set; }
        public virtual Category Category { get; set; }

        public virtual Owner Owner { get; set; }
    }
}
