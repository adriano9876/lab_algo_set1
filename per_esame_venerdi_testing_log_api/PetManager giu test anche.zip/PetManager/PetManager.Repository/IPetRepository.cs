﻿using DataAccess.Model;

namespace PetManager.Repository
{
    public interface IPetRepository
    {
        Task<Pet> GetPetByid(int id);
        Task<ICollection<Pet>> GetAllPets();

        Task<bool> InsertPet(Pet pet);
        Task<bool> DeletePet(int id);
        Task<bool> UpdatePet(Pet pet);
        Task<string> GetCategoryNameById(int id);
        Task<List<string>> GetAllTags();
    }
}
