﻿using DataAccess.Model;
using Microsoft.EntityFrameworkCore;
using PetManager.DataAccess.PetManagerDbContext;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PetManager.Repository
{
    public class PetRepository : IPetRepository
    {

        private readonly PetDbContext _context;

        public PetRepository(PetDbContext context)
        {
            _context = context;
        }

        public async Task<bool> DeletePet(int id)
        {
            var petToDelete = await _context.Pets.SingleOrDefaultAsync(a => a.Id == id);
            if (petToDelete == null) { return false; }
            _context.Pets.Remove(petToDelete);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<ICollection<Pet>> GetAllPets()
        {
            var pets = await _context.Pets.AsNoTracking().ToListAsync();
            return pets;
        }

        public async Task<List<string>> GetAllTags()
        {
           var tags =  await _context.Pets.AsNoTracking().Select(a=>a.PetTag).ToListAsync();
            return tags;
        }

        public async Task<string> GetCategoryNameById(int id)
        {
            var categoryName = await _context.Categories.SingleOrDefaultAsync(a => a.Id == id);
            return categoryName.Name;
        }

        

        public async Task<Pet> GetPetByid(int id)
        {
            var pet = await _context.Pets.AsNoTracking().SingleOrDefaultAsync(a => a.Id == id);

            return pet;
        }

        public async Task<bool> InsertPet(Pet petToAdd)
        {
            
            await _context.Pets.AddAsync(petToAdd);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> UpdatePet(Pet pet)
        {
            var petToUpdate = await _context.Pets.SingleOrDefaultAsync(a => a.Id == pet.Id);
            if (petToUpdate == null) return false;
            petToUpdate.Name = pet.Name;
            petToUpdate.Weight = pet.Weight;
            petToUpdate.Description = pet.Description;
            return true;
        }
    }
}
