﻿using Microsoft.EntityFrameworkCore.Storage.Internal;
using Repository.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Zoo.DataAccess.Model;
using Zoo.Service.Dto;
using Zoo.Service.Interfaces;

namespace Zoo.Service.Implementation
{
    public class PetService : IPetService
    {
        private readonly IPetRepository _repository;

        public PetService(IPetRepository repository)
        {
            _repository = repository;
        }

        public async Task<IEnumerable<GetAllPetsResponse>> GetAllPets()
        {
            var pets = await _repository.GetAllPets();
            return pets.Select(x => new GetAllPetsResponse
            {
                Id = x.Id,
                Name = x.Name,
                Description = x.Description,
                Weight = x.Weight,
                CategoryId = x.CategoryId,
                OwnerId = x.OwnerId,
                Tag = x.Tag,
                Age = x.Age,
                Food = CalculateFood(x.Weight, x.Age)

            }).ToList();

        }

        public async Task<GetAllPetsResponse> GetPetById(int id)
        {
            var pet = await _repository.GetPetById(id);
            if (pet == null)
            {
                return null;
            }
            return new GetAllPetsResponse { Name = pet.Name, Description = pet.Description, Weight = pet.Weight, CategoryId = pet.CategoryId, OwnerId = pet.OwnerId, Age = pet.Age, Food = CalculateFood(pet.Weight, pet.Age), Tag = pet.Tag, Id = pet.Id };
        }

        public async Task<AddPetResponse> AddPet(AddPetRequest request)
        {
            var generatedTag = GenerateTag(request.Name, await GetCategoryNameById(request.CategoryId));
            if(! await CheckTag(generatedTag))
            {
                generatedTag = GenerateTag(request.Name, await GetCategoryNameById(request.CategoryId));
            }
            var pet = await _repository.AddPet(new Pet
            {
                CategoryId = request.CategoryId,
                Tag = generatedTag,
                Name = request.Name,
                Description = request.Description,
                Weight = request.Weight,
                OwnerId = request.OwnerId,
                Age = request.Age
            });

            var response = new AddPetResponse
            {
                Weight = pet.Weight,
                CategoryId = pet.CategoryId,
                Name = pet.Name,
                Description = pet.Description,
                Id = pet.Id,
                OwnerId = pet.OwnerId,
                Tag = pet.Tag,
                Age = pet.Age,
                Food = CalculateFood(pet.Weight, pet.Age),
            };

            return response;
        }

        public async Task<bool> CheckTag(string tag)
        {
           return await _repository.CheckTag(tag);
        }

        public async Task<string> GetCategoryNameById(int id)
        {
            var categoryName =await _repository.GetCategoryNameById(id);
            return categoryName.Name;
        }

        public async Task UpdatePet(int id, AddPetRequest requst)
        {
            var update = await _repository.UpdatePet(id, new Pet
            {
                Id = id,
                Name = requst.Name,
                Description = requst.Description,
                Weight = requst.Weight,
                OwnerId = requst.OwnerId,
                CategoryId = requst.CategoryId,
                Age = requst.Age,
            });
            
        }

        public async Task<bool> DeletePet(int id)
        {
            if(await _repository.DeletePet(id))
            {
                return true; 
            } 
            return false;
            
        }




        public string GenerateTag(string nome, string categoria)
        {
            Random _random = new Random();
            //int length = 5;
            //const string s = "0123456789";
            //string tag = new string(Enumerable.Repeat(s, length).Select(x => x[_random.Next(s.Length)]).ToArray());
            int tag = Random.Shared.Next(10000, 100000);
            char n = ' ';
            char a = ' ';
            if (nome == null)
            {
                n = 'N';
                a = 'A';
            }
            else
            {
                n = nome[0];
                a = nome[nome.Length - 1];
            }
            return categoria + '_' + n + a + '-' + nome.Length + '-' + tag;
        }


        public double CalculateFood(double weight, double age)
        {
            double food = 0.0;
            if(age < 1)
            {
                food = (weight * 0.03) + (weight * 0.03) * 0.5;
            }
            else if(age > 10)
            {
                food = (weight * 0.03) - (weight * 0.03) * 0.3;
            }
            else
            {
                food = (weight * 0.03);
            }
            return food;
        }
    }
}
