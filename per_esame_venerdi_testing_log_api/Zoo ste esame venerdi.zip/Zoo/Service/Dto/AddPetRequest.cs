﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zoo.Service.Dto
{
    public class AddPetRequest
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public double Weight { get; set; }
        public int CategoryId { get; set; }
        public int OwnerId { get; set; }
        public double Age { get; set; }
    }
}
