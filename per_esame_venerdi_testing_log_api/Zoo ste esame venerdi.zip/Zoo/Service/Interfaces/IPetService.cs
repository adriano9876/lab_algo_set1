﻿using Microsoft.Identity.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Zoo.DataAccess.Model;
using Zoo.Service.Dto;

namespace Zoo.Service.Interfaces
{
    public interface IPetService
    {
        public Task<IEnumerable<GetAllPetsResponse>> GetAllPets();
        public Task<GetAllPetsResponse> GetPetById(int id);
        public Task<AddPetResponse> AddPet(AddPetRequest request);
        public Task UpdatePet(int id, AddPetRequest requst);
        public Task<bool> DeletePet(int id);
    }
}
