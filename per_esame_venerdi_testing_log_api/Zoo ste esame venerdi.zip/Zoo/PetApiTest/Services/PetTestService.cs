﻿using Microsoft.OpenApi.Validations;
using Moq;
using Repository.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Zoo.Controllers;
using Zoo.DataAccess.Model;
using Zoo.Service.Dto;
using Zoo.Service.Implementation;
using Zoo.Service.Interfaces;

namespace PetApiTest.Services
{
    public class PetTestService
    {
        private readonly Mock<IPetRepository> _repoMock;
        private readonly PetService _service;

        public PetTestService()
        {
            _repoMock = new Mock<IPetRepository>();
            _service = new PetService(_repoMock.Object);
        }


        [Fact]
        public async Task GetAll_ReturnsAllContacts()
        {
            // Arrange
            var pets = new List<Pet>
            {
                new Pet {Id=1, Name = "Pippo", Weight = 8.8, CategoryId = 1, OwnerId = 1, Description = "bel cane" }
            };
            _repoMock.Setup(r => r.GetAllPets()).ReturnsAsync(pets);

            // Act
            var result = await _service.GetAllPets();

            // Assert
            Assert.Equal(pets[0].Id, result.First().Id);
            _repoMock.Verify(r => r.GetAllPets(), Times.Once);
        }



        [Fact]
        public async Task GetById_ExistingId_ReturnsPet()
        {
            // Arrange
            var pet = new Pet { Id = 1, Name = "Pippo", Weight = 8.8, CategoryId = 1, OwnerId = 1, Description = "bel cane" };

            _repoMock.Setup(r => r.GetPetById(1)).ReturnsAsync(pet);

            // Act
            var result = await _service.GetPetById(1);

            // Assert
            Assert.Equal(pet.Id, result.Id);
            _repoMock.Verify(r => r.GetPetById(1), Times.Once);
        }


        [Fact]
        public async Task GetById_NonExistingId_ReturnsNull()
        {
            // Arrange
            _repoMock.Setup(r => r.GetPetById(20)).ReturnsAsync((Pet?)null);

            // Act
            var result =await _service.GetPetById(20);

            // Assert
            Assert.Null(result);
            _repoMock.Verify(r => r.GetPetById(20), Times.Once);
        }



        [Fact]
        public async Task Add_CallsRepositoryAdd()
        {
            // Arrange
            var pet = new Pet { Id = 1, Name = "Pippo", Weight = 8.8, CategoryId = 1, OwnerId = 1, Description = "bel cane", Age = 5.3};
            var petRequest = new AddPetRequest {Name = "Pippo", Weight = 8.8, CategoryId = 1, OwnerId = 1, Description = "bel cane" , Age = 5.3 };
            var cat = new Category { Id = 1, Name = "prova" };
            _repoMock.Setup(r => r.AddPet(It.IsAny<Pet>())).ReturnsAsync(pet);
            _repoMock.Setup(r => r.GetCategoryNameById(1)).ReturnsAsync(cat);

            // Act
            var response = await _service.AddPet(petRequest);

            // Assert
            Assert.Equal(pet.Id, response.Id);
            _repoMock.Verify(r => r.AddPet(It.IsAny<Pet>()), Times.Once);
        }



        [Fact]
        public async Task Update_CallsRepositoryUpdate()
        {
            // Arrange
            var pet = new Pet { Id = 1, Name = "Pippo", Weight = 8.8, CategoryId = 1, OwnerId = 1, Description = "bel cane", Age = 5.3 };
            _repoMock.Setup(r => r.UpdatePet(1, (It.IsAny<Pet>()))).ReturnsAsync(pet);
            var petRequest = new AddPetRequest { Age = 1, CategoryId=1, OwnerId = 1,  Description="c", Name = "name",  Weight= 2};

            // Act
            await _service.UpdatePet(1, petRequest);

            // Assert
            _repoMock.Verify(r => r.UpdatePet(1, (It.IsAny<Pet>())), Times.Once);
        }


        [Fact]
        public void Delete_CallsRepositoryDelete()
        {
            // Arrange
            int id = 1;

            // Act
            _service.DeletePet(id);

            // Assert
            _repoMock.Verify(r => r.DeletePet(id), Times.Once);
        }



        public void GetTag()
        {
            //Arrange
            var pet = new Pet { Id = 1, Name = "Pippo", Weight = 8.8, CategoryId = 1, OwnerId = 1, Description = "bel cane", Age = 5.3 };
            var category = new Category { Id = 1, Name = "ciao" };
            //_repoMock.Setup(r => r.CheckTag())

            ////Act
            //_service.GenerateTag(pet.Name, category.Name);

            ////Assert
            //_repoMock.Verify(r => r.)
        }
    }

}
