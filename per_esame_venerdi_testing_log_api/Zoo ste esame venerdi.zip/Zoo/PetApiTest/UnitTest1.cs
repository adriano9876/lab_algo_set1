namespace PetApiTest
{
    public class UnitTest1
    {
        [Fact]
        public void GetAllPetNull()
        {

        }
    }
}