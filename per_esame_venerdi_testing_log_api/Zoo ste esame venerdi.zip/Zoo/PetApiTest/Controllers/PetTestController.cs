﻿using Microsoft.AspNetCore.Mvc;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Zoo.Controllers;
using Zoo.DataAccess.Model;
using Zoo.Service.Dto;
using Zoo.Service.Interfaces;

namespace PetApiTest.Controllers
{
    public class PetTestController
    {
        private readonly Mock<IPetService> _serviceMock;
        private readonly PetController _controller;

        public PetTestController()
        {
            _serviceMock = new Mock<IPetService>();
            _controller = new PetController(_serviceMock.Object);
        }

        [Fact]
        public async Task GetAll_ReturnOkResult_WithListOfPets()
        {
            //Arrange
            var pets = new List<GetAllPetsResponse>
            {
                new GetAllPetsResponse { Name = "Pippo", Weight = 8.8, CategoryId = 1, OwnerId = 1, Description = "bel cane" },
                new GetAllPetsResponse { Name = "Pippo", Weight = 8.8, CategoryId = 1, OwnerId = 1, Description = "bel cane" }
            };
            _serviceMock.Setup(s => s.GetAllPets()).ReturnsAsync(pets);

            //Act
            var result = await _controller.GetPets();

            //Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var returnPets = Assert.IsAssignableFrom<IEnumerable<GetAllPetsResponse>>(okResult.Value);
            Assert.Equal(pets, returnPets);
        }


        [Fact]
        public async Task GetById_ExistingId_ReturnOkResult()
        {
            //Arrange
            var pet = new GetAllPetsResponse {Id = 1, Age = 1 , CategoryId = 1, Description="c", Name = "p", OwnerId = 1, Weight = 1.1, Tag ="kljab"};
            _serviceMock.Setup(s => s.GetPetById(1)).ReturnsAsync(pet);
            
            //Act
            var result = _controller.GetPetById(1);

            //Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var returnPet = Assert.IsType<GetAllPetsResponse>(okResult.Value);
            Assert.Equal(1, returnPet.Id);
        }


        [Fact]
        public async Task GetById_NonExistingId_ReturnsNotFound()
        {
            // Arrange
            _serviceMock.Setup(s => s.GetPetById(2)).ReturnsAsync((GetAllPetsResponse?)null);

            // Act
            var result = _controller.GetPetById(2);

            // Assert
            Assert.IsType<NotFoundResult>(result.Result);
        }


        [Fact]
        public async Task Create_ValidPet_ReturnsCreatedAtAction()
        {
            // Arrange
            var pet = new AddPetRequest { Name = "cane", Age = 1.4, CategoryId = 1, Description = "prova", Weight = 8.1, OwnerId = 1};

            // Act
            var result = _controller.Post(pet);

            // Assert
            var createdAtAction = Assert.IsType<OkObjectResult>(result.Result);
            var returnPet = Assert.IsType<AddPetResponse>(createdAtAction.Value);
            Assert.Equal(result.Id , returnPet.Id);
        }
    }
}
