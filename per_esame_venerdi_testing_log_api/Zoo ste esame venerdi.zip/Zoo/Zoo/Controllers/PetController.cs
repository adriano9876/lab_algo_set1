﻿using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Zoo.Service.Dto;
using Zoo.Service.Interfaces;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Zoo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PetController : ControllerBase
    {
        private readonly IPetService _service;

        public PetController(IPetService service)
        {
            _service = service;
        }

        // GET: api/<PetController>
        [HttpGet]
        public async Task<ActionResult<IEnumerable<GetAllPetsResponse>>> GetPets()
        {
            var get =await _service.GetAllPets();
            if(get == null)
            {
                return NotFound();
            }
            return Ok(get);
        }

        // GET api/<PetController>/5
        [HttpGet("{id}")]
        public async Task<ActionResult> GetPetById(int id)
        {
            var get = await _service.GetPetById(id);
            if (get == null)
            {
                return NotFound();
            }
            return Ok(get);
        }

        // POST api/<PetController>
        [HttpPost]
        public async Task<ActionResult<AddPetResponse>> Post([FromBody] AddPetRequest pet)
        {
            var petAdd = await _service.AddPet(pet);
            if(petAdd == null)
            {
                return BadRequest();
            }
            return Ok(petAdd);
        }

        // PUT api/<PetController>/5
        [HttpPut("{id}")]
        public async Task<ActionResult> Put(int id, [FromBody] AddPetRequest pet)
        {
            try
            {
                await _service.UpdatePet(id, pet);
                return NoContent();
            }
             catch (Exception ex)
            {
                
            }
            return NotFound();
        }

        // DELETE api/<PetController>/5
        [HttpDelete("{id}")]
        public async Task<ActionResult> Delete(int id)
        {
            if (await _service.DeletePet(id))
            {
                return Ok();
            }
            return NotFound();
        }
    }
}
