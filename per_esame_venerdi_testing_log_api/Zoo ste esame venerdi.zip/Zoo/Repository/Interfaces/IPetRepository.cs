﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Zoo.DataAccess.Model;

namespace Repository.Interfaces
{
    public interface IPetRepository
    {
        public Task<IEnumerable<Pet>> GetAllPets();
        public Task<Pet> GetPetById(int id);
        public Task<Pet> AddPet(Pet pet);
        public Task<Pet> UpdatePet(int id, Pet requst);
        public Task<bool> DeletePet(int id);
        public Task<Category> GetCategoryNameById(int id);
        public Task<bool> CheckTag(string tag);
    }
}
