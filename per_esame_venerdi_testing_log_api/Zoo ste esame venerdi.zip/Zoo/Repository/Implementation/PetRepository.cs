﻿using Microsoft.EntityFrameworkCore;
using Repository.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Zoo.DataAccess.Model;
using Zoo.DataAccess.ZooDbContext;

namespace Repository.Implementation
{
    public class PetRepository : IPetRepository
    {
        private readonly ZooManagerDbContext _context;

        public PetRepository(ZooManagerDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Pet>> GetAllPets()
        {
            var pets = _context.Pets.AsNoTracking().ToListAsync();
            return await pets;
        }

        public async Task<Pet> GetPetById(int id)
        {
            var pet = await _context.Pets.AsNoTracking().SingleOrDefaultAsync(p => p.Id == id);
            return pet;
        }


        public async Task<Pet> AddPet(Pet pet)
        {
            _context.Add(pet);
            await _context.SaveChangesAsync();
            return pet;
        }

        public async Task<Pet> UpdatePet(int id, Pet pet)
        {
            var update = await _context.Pets.FindAsync(id);
            update.Name = pet.Name;
            update.Description = pet.Description;
            update.Weight = pet.Weight;
            update.CategoryId = pet.CategoryId;
            update.OwnerId = pet.OwnerId;
            await _context.SaveChangesAsync();

            return update;
        }

        public async Task<bool> DeletePet(int id)
        {
            var petDelete = await _context.Pets.FindAsync(id);
            if (petDelete == null)
            {
                return false;
            }
            _context.Remove(petDelete);
            await _context.SaveChangesAsync();
            return true;
        }



        public async Task<Category> GetCategoryNameById(int id)
        {
            
            var result= await _context.Categories.FirstOrDefaultAsync(x => x.Id == id);
            if(result == null)
            {
                return null;
            }
            return result;
        }

        public async Task<bool> CheckTag(string tag)
        {
            if (await _context.Pets.SingleOrDefaultAsync(x => x.Tag == tag) != null)
            {
                return false;
            }
            return true;
        }
    }
}
