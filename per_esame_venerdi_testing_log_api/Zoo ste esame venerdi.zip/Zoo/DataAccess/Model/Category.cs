﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zoo.DataAccess.Model
{
    public class Category : BaseEntity
    {
        public string Name { get; set; }
        public virtual ICollection<Pet> Pets { get; set;  } = new List<Pet>();
    }
}
