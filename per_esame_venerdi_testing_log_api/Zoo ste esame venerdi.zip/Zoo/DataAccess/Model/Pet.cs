﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zoo.DataAccess.Model
{
    public class Pet : BaseEntity
    {
        public string? Name { get; set; }
        public string Description { get; set; }
        public double Age { get; set; }
        public double Weight { get; set; }
        public double Food { get; set; }
        public string Tag { get; set; }
        public int CategoryId {  get; set; }
        public int OwnerId { get; set; }
        public virtual Owner Owner { get; set; }
        public virtual Category Category { get; set; }
    }
}
