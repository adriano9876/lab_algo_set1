﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zoo.DataAccess.Model
{
    public class BaseEntity
    {
        public int Id { get; set; }
    }
}
