﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Zoo.DataAccess.Model;

namespace Zoo.DataAccess.ZooDbContext
{
    public class ZooManagerDbContext : DbContext
    {
        public ZooManagerDbContext(DbContextOptions options) : base(options)
        {
        }

        public DbSet<Pet> Pets { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Owner> Owners { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Pet>()
                .HasOne(a => a.Category)
                .WithMany(a => a.Pets)
                .HasForeignKey(a => a.CategoryId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Owner>()
                .HasMany(a=>a.Pets)
                .WithOne(a=>a.Owner)
                .HasForeignKey(a=>a.OwnerId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Category>()
                .HasData(
                new Category { Id = 1, Name = "Cane" },
                new Category { Id = 2, Name = "Gatto" },
                new Category { Id = 3, Name = "Criceto" }
                );


            modelBuilder.Entity<Owner>()
                .HasData(
                new Owner { Id = 1, Name = "Adreina", Surname = "Tritto" },
                new Owner { Id = 2, Name = "Tommaso", Surname = "Trevisan" },
                new Owner { Id = 3, Name = "Federico", Surname = "Pariolino" }
                );

            modelBuilder.Entity<Pet>()
                .HasData(
                new Pet { Id = 1, Name = "Pippo", Description = "bel cane", Weight = 8.8, CategoryId = 1, OwnerId = 1 , Tag = "prova1", Age = 4},
                new Pet { Id = 2, Name = "Birba", Description = "bel gatto", Weight = 5.8, CategoryId = 2, OwnerId = 2 , Tag = "prova2", Age = 11},
                new Pet { Id = 3, Name = "Eddy 2.0", Description = "bel criceto", Weight = 0.4, CategoryId = 3, OwnerId = 3, Tag = "prova3" , Age = 1}
                );
        }

    }
}
