using Business.Dto;
using Business.Mappers;
using Business.Services;
using Business.Services.ServiceImpl;
using DataAccess.Models;
using Moq;
using Repository;

namespace PetManagerNew.Test
{
    public class PetServiceTests
    {
        private readonly PetService _service;
        private readonly Mock<IRepository> _repoMock;
        private readonly Mock<IRandomGenerator> _randomGenMock;

        public PetServiceTests()
        {
            _repoMock = new Mock<IRepository>();
            _randomGenMock = new Mock<IRandomGenerator>();
            _service = new PetService(_repoMock.Object, _randomGenMock.Object);
        }

        [Fact]
        public async Task GetAllPets_ReturnAllPets()
        {
            //Arrange
            var pets = new List<Pet>
            {
                  new Pet { Id = 1, Name = "Pippo", Description = "bel cane", Weight = 8.8, CategoryId = 1, OwnerId = 1 },
            };
            _repoMock.Setup(r => r.GetAllPets()).ReturnsAsync(pets);

            //Act
            var result = await _service.GetAllPets();

            //Assert
            Assert.Equal(pets[0].Id, result.First().Id);
            _repoMock.Verify(r => r.GetAllPets(), Times.Once);
        }
        
        [Fact]
        public async Task GetPetById_ReturnPetById()
        {
            //Arrange
            var pet = new Pet { Id = 1, Name = "Pippo", Description = "bel cane", Weight = 8.8, CategoryId = 1, OwnerId = 1 };
            _repoMock.Setup(r => r.GetPetById(1)).ReturnsAsync(pet);

            //Act
            var result = await _service.GetPetById(1);

            //Assert
            Assert.NotNull(result);
            Assert.Equal(pet.Id, result.Id);
            _repoMock.Verify(r => r.GetPetById(1), Times.Once);
        }

        [Fact]
        public async Task GetPetById_NonExistingId_ReturnsNull()
        {
            //Arrange
            _repoMock.Setup(r => r.GetPetById(34)).ReturnsAsync((Pet?)null);

            //Act
            var result = await _service.GetPetById(34);

            // Assert
            Assert.Null(result);
            _repoMock.Verify(r => r.GetPetById(34), Times.Once);
        }

        [Fact]
        public async Task CreatePet_CallsRepositoryCreate()
        {
            //Arrange
            var pet = new PetDto { Id = 1, Name = "Pippo", Description = "bel cane", Weight = 8.8, CategoryId = 1, OwnerId = 1, Age = 3 };
            var cat = new Category { Id = 1, Name = "Cane" };
            _repoMock.Setup(r => r.CreatePet(It.IsAny<Pet>())).ReturnsAsync(pet.ToModel());
            _repoMock.Setup(r => r.GetCategoryById(1)).ReturnsAsync(cat);

            //Act
            var result = await _service.CreatePet(pet);

            //Assert
            Assert.Equal(pet.Name, result.Name);
            Assert.NotNull(result);
            _repoMock.Verify(r => r.CreatePet(It.IsAny<Pet>()), Times.Once);
        }
        
        [Fact]
        public async Task CreatePetWithTag_ReturnTag()
        {
            //Arrange
            var pet = new Pet { Id = 1, Name = "Pippo", Description = "bel cane", Weight = 8.8, CategoryId = 1, OwnerId = 1, Age = 3 };
            var cat = new Category { Id = 1, Name = "Cane" };
            _randomGenMock.Setup(r => r.GiveNumber()).Returns(20000);
            _repoMock.Setup(x => x.FindTagAlreadyExists("Cane_PO-5-20000")).ReturnsAsync(false);
            //_repoMock.Setup(x => x.GetAllPets()).ReturnsAsync(new List<Pet>() { pet });

            //Act
            var result = _service.GenerateTagByPet(cat, pet);

            //Asser
            Assert.NotNull(result);
            Assert.Equal("Cane_PO-5-20000", result);
        }
        
        [Fact]
        public async Task CreatePetWithTag_ReturnUniqueTag()
        {
            //Arrange
            var pets = new List<Pet>()
            {
                new Pet { Id = 1, Name = "Pippo", Description = "bel cane", Weight = 8.8, CategoryId = 1, OwnerId = 1, Age = 3, Tag = "Cane_PO-5-20000" },
                new Pet { Id = 1, Name = "Pippo", Description = "bel cane", Weight = 8.8, CategoryId = 1, OwnerId = 1, Age = 3 },
            };
            var cat = new Category { Id = 1, Name = "Cane" };
            _repoMock.Setup(x => x.GetAllPets()).ReturnsAsync(pets);
            _repoMock.Setup(x => x.FindTagAlreadyExists(It.IsAny<string>())).ReturnsAsync(false);
            _repoMock.Setup(x => x.FindTagAlreadyExists("Cane_PO-5-20000")).ReturnsAsync(true);
            _randomGenMock.SetupSequence(r => r.GiveNumber()).Returns(20000).Returns(20001);
            _repoMock.Setup(r => r.GetCategoryById(1)).ReturnsAsync(cat);
            _repoMock.Setup(r => r.CreatePet(It.IsAny<Pet>())).ReturnsAsync(pets[1]);

            var dto = pets[1].ToDto();

            //Act
            var result = await _service.CreatePet(dto);

            //Asser
            Assert.NotNull(result);
            //Assert.Equal("Cane_PO-5-20001", result.Tag);
            _repoMock.Verify(x => x.FindTagAlreadyExists(It.IsAny<string>()), Times.Exactly(2));
        }

        [Fact]
        public async Task UpdatePet_CallsRepositoryUpdate()
        {
            //Arrange
            var pet = new Pet { Id = 1, Name = "Pippo", Description = "bel cane", Weight = 8.8, CategoryId = 1, OwnerId = 1, Age = 3 };
            _repoMock.Setup(r => r.UpdatePet(1, It.IsAny<Pet>())).ReturnsAsync(true);
            var dto = pet.ToDto();

            //Act
            var result = await _service.UpdatePet(1, dto);

            //Assert
            Assert.True(result);
            _repoMock.Verify(r => r.UpdatePet(1, It.IsAny<Pet>()), Times.Once);
        }
        
        [Fact]
        public async Task DeletePet_CallsRepositoryDelete()
        {
            //Arrange
            _repoMock.Setup(r => r.DeletePet(1)).ReturnsAsync(true);

            //Act
            var result = await _service.DeletePet(1);

            //Assert
            _repoMock.Verify(r => r.DeletePet(1), Times.Once);
        }
        
        [Fact]
        public void GetPetFoodRatio_ReturnsDoubleRatio()
        {
            //Arrange
            var pet = new Pet { Id = 1, Name = "Pippo", Description = "bel cane", Weight = 8.8, CategoryId = 1, OwnerId = 1, Age = 11 };
            var ratio = 8.8 * 0.03 * 0.7;

            //Act
            var result = _service.GetPetFoodRatio(pet.Weight, (double)pet.Age);

            //Assert
            Assert.Equal(ratio, result);
        }
    }
}