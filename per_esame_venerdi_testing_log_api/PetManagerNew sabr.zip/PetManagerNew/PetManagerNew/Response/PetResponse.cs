﻿namespace PetManagerNew.Response
{
    public class PetResponse
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public double Weight { get; set; }
        public int Age { get; set; }
        public string Tag { get; set; }
        public int CategoryId { get; set; }
        public int? OwnerId { get; set; }
        public double FoodRatio { get; set; }
    }
}