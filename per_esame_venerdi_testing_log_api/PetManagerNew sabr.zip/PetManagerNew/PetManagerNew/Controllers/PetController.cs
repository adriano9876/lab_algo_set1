﻿using Business.Dto;
using Business.Services;
using DataAccess.Models;
using Microsoft.AspNetCore.Mvc;
using PetManagerNew.Requests;
using PetManagerNew.Response;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace PetManagerNew.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PetController : ControllerBase
    {
        private readonly IPetService _service;

        public PetController(IPetService service)
        {
            _service = service;
        }

        // GET: api/<PetController>
        [HttpGet]
        public async Task<ActionResult<IEnumerable<PetResponse>>> GetAllPets()
        {
            var pets = await _service.GetAllPets();
            var response = pets.Select(x => new PetResponse
            {
                Name = x.Name,
                Description = x.Description,
                Weight = x.Weight,
                Age = x.Age,
                Tag = x.Tag,
                CategoryId = x.CategoryId,
                OwnerId = x.OwnerId,
                FoodRatio = _service.GetPetFoodRatio(x.Weight, (double)x.Age),
            }).ToList();

            return Ok(response);
        }

        // GET api/<PetController>/5
        [HttpGet("{id}")]
        public async Task<ActionResult<PetResponse>> GetPetById(int id)
        {
            var pet = await _service.GetPetById(id);
            if(pet == null)
            {
                return NotFound();
            }

            var response = new PetResponse
            {
                Name = pet.Name,
                Description = pet.Description,
                Weight = pet.Weight,
                Age = pet.Age,
                Tag = pet.Tag,
                CategoryId = pet.CategoryId,
                OwnerId = pet.OwnerId,
                FoodRatio = _service.GetPetFoodRatio(pet.Weight, (double)pet.Age)
            };

            return Ok(response);
        }

        // POST api/<PetController>
        [HttpPost]
        public async Task<IActionResult> InsertPet([FromBody]PetRequest petReq)
        {
            var petDto = new PetDto
            {
                Name = petReq.Name,
                Description = petReq.Description,
                Weight = petReq.Weight,
                Age = petReq.Age,
                CategoryId = petReq.CategoryId,
                OwnerId = petReq.OwnerId,
            };

            var newPet = await _service.CreatePet(petDto);

            return CreatedAtAction(nameof(GetPetById), new { id = newPet.Id }, newPet);
        }

        // PUT api/<PetController>/5
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdatePet(int id, [FromBody] PetRequest petReq)
        {
            var petDto = new PetDto
            {
                Name = petReq.Name,
                Description = petReq.Description,
                Weight = petReq.Weight,
                Age = petReq.Age,
                CategoryId = petReq.CategoryId,
                OwnerId = petReq.OwnerId,
            };

            var isUpdated = await _service.UpdatePet(id, petDto);
            if (!isUpdated)
            {
                return NotFound();
            }

            return NoContent();
        }

        // DELETE api/<PetController>/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeletePet(int id)
        {
            var isDeleted = await _service.DeletePet(id);
            if (!isDeleted)
            {
                return NotFound();
            }

            return NoContent();
        }

        [HttpGet]
        [Route("getFoodRatio")]
        public double DeletePet(double weight, double age)
        {
            return _service.GetPetFoodRatio(weight, age);
        }

    }
}
