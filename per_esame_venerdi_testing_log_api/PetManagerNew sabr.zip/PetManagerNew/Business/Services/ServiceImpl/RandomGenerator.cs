﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business.Services.ServiceImpl
{
    public class RandomGenerator : IRandomGenerator
    {
        public int GiveNumber()
        {
            return Random.Shared.Next(10000, 100000);
        }
    }
}
