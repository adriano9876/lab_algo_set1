﻿using Azure;
using Business.Dto;
using Business.Mappers;
using DataAccess.Models;
using Microsoft.EntityFrameworkCore;
using Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business.Services.ServiceImpl
{
    public class PetService : IPetService
    {
        private readonly IRepository _repo;
        private readonly IRandomGenerator _randomGenerator;

        public PetService(IRepository repo, IRandomGenerator randomGenerator)
        {
            _repo = repo;
            _randomGenerator = randomGenerator;
        }

        public async Task<PetDto> CreatePet(PetDto dto)
        {
            var pet = dto.ToModel();
            var category = await _repo.GetCategoryById(pet.CategoryId);
            if(category == null)
            {
                throw new ArgumentNullException();
            }
            
            do
            {
                pet.Tag = GenerateTagByPet(category, pet);

            }
            while (await _repo.FindTagAlreadyExists(pet.Tag));
            
            var newPet = await _repo.CreatePet(pet);
            return newPet.ToDto();
        }

        public string GenerateTagByPet(Category category, Pet pet)
        {
            string tag;
            var firstLetter = !string.IsNullOrEmpty(pet.Name) ? pet.Name.ToUpper().First() : 'N';
            var lastLetter = !string.IsNullOrEmpty(pet.Name) ? pet.Name.ToUpper().Last() : 'A';

            tag = $"{category.Name}_{firstLetter}{lastLetter}-{pet.Name?.Length ?? 0}-{_randomGenerator.GiveNumber()}";

            return tag;
        }

        public async Task<bool> DeletePet(int id)
        {
            return await _repo.DeletePet(id);
        }

        public async Task<IEnumerable<PetDto>> GetAllPets()
        {
            var pets = await _repo.GetAllPets();

            return pets.Select(x => x.ToDto());
        }

        public async Task<PetDto?> GetPetById(int id)
        {
            var pet = await _repo.GetPetById(id);
            if(pet == null)
            {
                return null;
            }

            return pet.ToDto();
        }

        public async Task<bool> UpdatePet(int id, PetDto dto)
        {
            var pet = dto.ToModel();
            return await _repo.UpdatePet(id, pet);
        }

        public double GetPetFoodRatio(double weight, double age)
        {
            double ageMultiplier = 1;
            if(age < 1)
            {
                ageMultiplier = 1.5;
            }
            else if(age > 10)
            {
                ageMultiplier =  0.7;
            }

            return (weight * 0.03) * ageMultiplier;
        }
    }
}
