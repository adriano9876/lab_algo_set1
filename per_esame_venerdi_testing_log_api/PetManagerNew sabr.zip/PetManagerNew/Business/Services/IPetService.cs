﻿using Business.Dto;
using DataAccess.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business.Services
{
    public interface IPetService
    {
        Task<IEnumerable<PetDto>> GetAllPets();
        Task<PetDto?> GetPetById(int id);
        Task<PetDto> CreatePet(PetDto pet);
        Task<bool> UpdatePet(int id, PetDto pet);
        Task<bool> DeletePet(int id);
        string GenerateTagByPet(Category category, Pet pet);
        double GetPetFoodRatio(double weight, double age);
    }
}
