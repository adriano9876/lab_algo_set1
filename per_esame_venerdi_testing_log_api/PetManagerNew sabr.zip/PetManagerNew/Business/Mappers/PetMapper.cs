﻿using Business.Dto;
using DataAccess.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business.Mappers
{
    public static class PetMapper
    {
        public static PetDto ToDto(this Pet pet)
        {
            return new PetDto
            {
                Id = pet.Id,
                Name = pet.Name,
                Description = pet.Description,
                Weight = pet.Weight,
                Age = pet.Age,
                Tag = pet.Tag,
                CategoryId = pet.CategoryId,
                OwnerId = pet.OwnerId
            };
        }

        public static Pet ToModel(this PetDto dto)
        {
            return new Pet
            {
                Id = dto.Id,
                Name = dto.Name,
                Description = dto.Description,
                Weight = dto.Weight,
                Age = dto.Age,
                Tag = dto.Tag,
                CategoryId = dto.CategoryId,
                OwnerId = dto.OwnerId
            };
        }
    }
}
