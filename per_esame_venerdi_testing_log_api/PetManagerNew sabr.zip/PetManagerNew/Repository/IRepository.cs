﻿using DataAccess.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository
{
    public interface IRepository
    {
        Task<IEnumerable<Pet>> GetAllPets();
        Task<Pet?> GetPetById(int id);
        Task<Pet> CreatePet(Pet pet);
        Task<bool> UpdatePet(int id, Pet pet);
        Task<bool> DeletePet(int id);
        Task<Category> GetCategoryById(int id);
        Task<bool> FindTagAlreadyExists(string tag);
    }
}
