﻿using DataAccess.Models;
using DataAccess.PetDbContext;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository
{
    public class PetRepository : IRepository
    {
        private readonly PetManagerDbContext _context;

        public PetRepository(PetManagerDbContext context)
        {
            _context = context;
        }

        public async Task<Pet> CreatePet(Pet pet)
        {
            //var cat = await _context.Categories.SingleAsync(x => x.Id == pet.CategoryId);
            //var owner = await _context.Owners.SingleOrDefaultAsync(x => x.Id == pet.OwnerId);

            await _context.Pets.AddAsync(pet);
            await _context.SaveChangesAsync();
            return pet;
        }

        public async Task<bool> FindTagAlreadyExists(string tag)
        {
            return await _context.Pets.AnyAsync(x => x.Tag == tag);
        }

        public async Task<bool> DeletePet(int id)
        {
            var pet = await _context.Pets.SingleOrDefaultAsync(x => x.Id == id);
            _context.Pets.Remove(pet);
            return await _context.SaveChangesAsync() > 0;
        }


        public async Task<IEnumerable<Pet>> GetAllPets()
        {
            return await _context.Pets.AsNoTracking().ToListAsync();
        }

        public async Task<Category?> GetCategoryById(int id)
        {
            return await _context.Categories.AsNoTracking().SingleOrDefaultAsync(x => x.Id == id);
        }

        public async Task<Pet?> GetPetById(int id)
        {
            return await _context.Pets.AsNoTracking().SingleOrDefaultAsync(x => x.Id == id);
        }

        public async Task<bool> UpdatePet(int id, Pet pet)
        {
            var cat = await _context.Categories.FindAsync(pet.CategoryId);
            var owner = await _context.Owners.FindAsync(pet.OwnerId);
            var toUpdate = await _context.Pets.SingleOrDefaultAsync(x => x.Id == id);
            if(cat == null || owner == null || toUpdate == null)
            {
                return false;
            }
            toUpdate.Name = pet.Name;
            toUpdate.Description = pet.Description;
            toUpdate.Weight = pet.Weight;
            toUpdate.Age = pet.Age;
            toUpdate.CategoryId = pet.CategoryId;
            toUpdate.OwnerId = pet.OwnerId;

            return await _context.SaveChangesAsync() > 0;
        }
    }
}
