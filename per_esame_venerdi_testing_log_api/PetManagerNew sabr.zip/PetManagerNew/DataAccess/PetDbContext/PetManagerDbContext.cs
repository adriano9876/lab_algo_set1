﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using DataAccess.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.PetDbContext
{
    public class PetManagerDbContext : DbContext
    {
        public PetManagerDbContext(DbContextOptions<PetManagerDbContext> options) : base(options)
        {
        }

        public DbSet<Category> Categories { get; set; }
        public DbSet<Pet> Pets { get; set; }
        public DbSet<Owner> Owners { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            modelBuilder.Entity<Pet>()
                .HasOne(p => p.Category)
                .WithMany(c => c.Pets)
                .HasForeignKey(p => p.CategoryId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Pet>()
                .HasOne(p => p.Owner)
                .WithMany(c => c.Pets)
                .HasForeignKey(p => p.OwnerId)
                .OnDelete(DeleteBehavior.SetNull);

            modelBuilder.Entity<Category>()
             .HasData(
                 new Category { Id = 1, Name = "Gatto" },
                 new Category { Id = 2, Name = "Cane" },
                 new Category { Id = 3, Name = "Criceto" },
                 new Category { Id = 4, Name = "Pappagallo" }
             );

            modelBuilder.Entity<Owner>()
                .HasData(
                new Owner { Id = 1, Name = "Adreina", Surname = "Tritto" },
                new Owner { Id = 2, Name = "Tommaso", Surname = "Trevisan" },
                new Owner { Id = 3, Name = "Federico", Surname = "Pariolino" }
                );

            modelBuilder.Entity<Pet>()
                .HasData(
                new Pet { Id = 1, Name = "Pippo", Description = "bel cane", Weight = 8.8, CategoryId = 1, OwnerId = 1 },
                new Pet { Id = 2, Name = "Birba", Description = "bel gatto", Weight = 5.8, CategoryId = 2, OwnerId = 2 },
                new Pet { Id = 3, Name = "Eddy 2.0", Description = "bel criceto", Weight = 0.4, CategoryId = 3, OwnerId = 3 }
                );

        }
    }
}
