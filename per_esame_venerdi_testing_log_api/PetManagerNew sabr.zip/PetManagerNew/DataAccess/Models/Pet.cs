﻿using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Models
{
    public class Pet : BaseEntity
    {
        public string? Name { get; set; }
        public string Description { get; set; }
        [Column(TypeName = "decimal(10, 2)")]
        public double Weight { get; set; }
        public int Age { get; set; }
        public int CategoryId { get; set; }
        public int? OwnerId { get; set; }
        public string? Tag { get; set; }
        public virtual Category Category { get; set; }
        public virtual Owner Owner { get; set; }

    }
}
