﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Models
{
    public class Owner : BaseEntity 
    {
        public string Name { get; set; }
        public string Surname { get; set; }
        public virtual ICollection<Pet> Pets { get; set; }
    }
}
