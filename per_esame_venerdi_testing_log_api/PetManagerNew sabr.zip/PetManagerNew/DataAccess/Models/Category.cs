﻿namespace DataAccess.Models
{
    public class Category : BaseEntity
    {
        public string Name { get; set; }
        public virtual ICollection<Pet> Pets { get; set; }
    }
}
