﻿using DataAccess.Context;
using DataAccess.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Repository
{
    public class DbRepository : IRepository
    {
        private readonly ProductManagerDbContext _context;

        public DbRepository(ProductManagerDbContext context)
        {
            _context = context;
        }

        public async Task<Category> CreateCategory(Category category)
        {
            var newCategory = _context.Categories.Add(category).Entity;
            await _context.SaveChangesAsync();

            return newCategory;
        }

        public async Task<Product> CreateProduct(Product product)
        {
            var newProduct = _context.Products.Add(product).Entity;
            await _context.SaveChangesAsync();

            return newProduct;
        }

        public async Task<Warehouse> CreateWarehouse(Warehouse warehouse)
        {
            var newWarehouse = _context.Warehouses.Add(warehouse).Entity;
            await _context.SaveChangesAsync();

            return newWarehouse;
        }

        public async Task<bool> DeleteCategoryById(int id)
        {
            var toDelete = await _context.Categories.SingleOrDefaultAsync(category => category.Id == id);
            if(toDelete == null)
            {
                return false;
            }

            _context.Remove(toDelete);

            return await _context.SaveChangesAsync() > 1;
        }

        public async Task<bool> DeleteProductById(int id)
        {
            var toDelete = await _context.Products.SingleOrDefaultAsync(product => product.Id == id);
            if (toDelete == null)
            {
                return false;
            }

            _context.Remove(toDelete);

            return await _context.SaveChangesAsync() > 1;
        }

        public async Task<bool> DeleteWarehouseById(int id)
        {
            var toDelete = await _context.Warehouses.SingleOrDefaultAsync(warehouse => warehouse.Id == id);
            if (toDelete == null)
            {
                return false;
            }

            _context.Remove(toDelete);

            return await _context.SaveChangesAsync() > 1;
        }

        public async Task<IEnumerable<Category>> GetCategories()
        {
            var categories = await _context.Categories
                .AsNoTracking()
                .ToListAsync();
            return categories;
        }

        public async Task<Category?> GetCategoryById(int id)
        {
            var category = await _context.Categories
                .AsNoTracking()
                .SingleOrDefaultAsync(c => c.Id == id);
            return category;
        }

        public async Task<Category?> GetCategoryByName(string name)
        {
            var category = await _context.Categories
                .AsNoTracking()
                .SingleOrDefaultAsync(c => c.Name == name);
            return category;
        }

        public async Task<Product?> GetProductById(int id)
        {
            var product = await _context.Products
                .AsNoTracking()
                .Include(prod => prod.Category)
                .SingleOrDefaultAsync(p => p.Id == id);
            return product;
        }

        public async Task<IEnumerable<Product>> GetProducts()
        {
            var products = await _context.Products
                .AsNoTracking()
                .Include(prod => prod.Category)
                .ToListAsync();
            return products;
        }

        public async Task<IEnumerable<Product>> GetProducts(Expression<Func<Product, bool>> filter)
        {
            var products = await _context.Products
                .AsNoTracking()
                .Include(prod => prod.Category)
                .Where(filter)
                .ToListAsync();
            return products;
        }

        public async Task<IEnumerable<Product>> GetProductsByCategoryId(int categoryId)
        {
            var products = await _context.Products
                .AsNoTracking()
                .Where(p => p.CategoryId == categoryId)
                .ToListAsync();
            return products;
        }

        public async Task<IEnumerable<Product>> GetProductsByWarehouseId(int warehouseId)
        {
            var products = await _context.Warehouses
                .AsNoTracking()
                .Include(warehouse => warehouse.Products)
                .Where(warehouse => warehouse.Id == warehouseId)
                .Select(warehouse => warehouse.Products)
                .SelectMany(x => x)
                .ToListAsync();

            //var query = products.ToQueryString();

            return products;
        }

        public async Task<IEnumerable<Warehouse>> GetWarehousesByIdentifiers(IEnumerable<int> warehouseIdentifiers)
        {
            return await _context.Warehouses
                .AsNoTracking()
                .Where(warehouse => warehouseIdentifiers.Contains(warehouse.Id))
                .ToListAsync();

        }

        public async Task<Warehouse?> GetWarehouseById(int id)
        {
            var warehouse = await _context.Warehouses
                .AsNoTracking()
                .SingleOrDefaultAsync(w => w.Id == id);
            return warehouse;
        }

        public async Task<IEnumerable<Warehouse>> GetWarehouses()
        {
            var warehouses = await _context.Warehouses
                .AsNoTracking()
                .ToListAsync();
            return warehouses;
        }

        public async Task<IEnumerable<Warehouse>> GetWarehousesByProductId(int productId)
        {
            var warehouses = await _context.Products
                .AsNoTracking()
                .Include(product => product.Warehouses)
                .Where(product => product.Id == productId)
                .Select(product => product.Warehouses)
                .SelectMany(x => x)
                .ToListAsync();

            //var query = products.ToQueryString();

            return warehouses;
        }

        public async Task<bool> UpdateCategory(Category category)
        {
            var toUpdate = await _context.Categories.SingleOrDefaultAsync(cat => cat.Id == category.Id);
            if (toUpdate == null)
            {
                return false;
            }

            toUpdate.Name = category.Name;

            _context.Entry<Category>(toUpdate).State = EntityState.Modified;

            return await _context.SaveChangesAsync() > 1;
        }

        public async Task<bool> UpdateProduct(Product product)
        {
            var toUpdate = await _context.Products.SingleOrDefaultAsync(prod => prod.Id == product.Id);
            if (toUpdate == null)
            {
                return false;
            }

            toUpdate.Name = product.Name;
            toUpdate.Price = product.Price;
            toUpdate.ProductionDate = product.ProductionDate;
            toUpdate.CategoryId = product.CategoryId;
            toUpdate.Category = await _context.Categories.SingleAsync(cat => cat.Id == product.CategoryId);
            toUpdate.Count = product.Count;

            _context.Entry<Product>(toUpdate).State = EntityState.Modified;

            return await _context.SaveChangesAsync() > 1;
        }

        public async Task<bool> UpdateWarehouse(Warehouse warehouse)
        {
            var toUpdate = await _context.Warehouses.SingleOrDefaultAsync(wh => wh.Id == warehouse.Id);
            if (toUpdate == null)
            {
                return false;
            }

            toUpdate.City = warehouse.City;

            _context.Entry<Warehouse>(toUpdate).State = EntityState.Modified;

            return await _context.SaveChangesAsync() > 1;
        }

        public async Task CreateProductWarehouse(int productId, IEnumerable<Warehouse> warehouses)
        {
            var prod = await _context.Products.FindAsync(productId);

            foreach (var wh in warehouses)
            {
                prod.Warehouses.Add(wh);
            }

            _context.Entry<Product>(prod).State = EntityState.Modified;
            await _context.SaveChangesAsync();
        }
    }
}
