﻿using DataAccess.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Repository
{
    public interface IRepository
    {
        //Product
        Task<Product?> GetProductById(int id);
        Task<IEnumerable<Product>> GetProducts();
        Task<IEnumerable<Product>> GetProducts(Expression<Func<Product, bool>> filter);
        Task<Product> CreateProduct(Product product);
        Task<bool> UpdateProduct(Product product);
        Task<bool> DeleteProductById(int id);
        Task<IEnumerable<Product>> GetProductsByCategoryId(int categoryId);
        Task<IEnumerable<Product>?> GetProductsByWarehouseId(int warehouseId);
        Task CreateProductWarehouse(int productId, IEnumerable<Warehouse> warehouses);

        //Category
        Task<Category?> GetCategoryById(int id);
        Task<Category?> GetCategoryByName(string name);
        Task<IEnumerable<Category>> GetCategories();
        Task<Category> CreateCategory(Category category);
        Task<bool> UpdateCategory(Category category);
        Task<bool> DeleteCategoryById(int id);
        
        //Warehouse
        Task<Warehouse?> GetWarehouseById(int id);
        Task<IEnumerable<Warehouse>> GetWarehouses();
        Task<Warehouse> CreateWarehouse(Warehouse warehouse);
        Task<bool> UpdateWarehouse(Warehouse warehouse);
        Task<bool> DeleteWarehouseById(int id);
        Task<IEnumerable<Warehouse>> GetWarehousesByProductId(int productId);

        Task<IEnumerable<Warehouse>> GetWarehousesByIdentifiers(IEnumerable<int> warehouseIdentifiers);

    }
}
