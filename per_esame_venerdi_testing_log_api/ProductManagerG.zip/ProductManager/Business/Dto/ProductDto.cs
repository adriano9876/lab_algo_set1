﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business.Dto
{
    public class ProductDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public double Price { get; set; }
        public int Count { get; set; }
        public bool IsAvailable => Count > 0;
        public DateTime ProductionDate { get; set; } = DateTime.UtcNow;
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
        public CategoryDto Category { get; set; }
        public ICollection<int> WarehouseIds { get; set; }
        public ICollection<WarehouseDto> Warehouses { get; set; } = new List<WarehouseDto>();
    }
}
