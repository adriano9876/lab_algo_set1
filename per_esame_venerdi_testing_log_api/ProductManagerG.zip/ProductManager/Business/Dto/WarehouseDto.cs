﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Business.Dto
{
    public class WarehouseDto
    {
        public int Id { get; set; }
        public string City { get; set; }
        public ICollection<ProductDto> Products { get; set; } = new List<ProductDto>();
    }
}