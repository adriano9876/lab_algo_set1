﻿using Business.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Business.Services
{
    public interface IProductService
    {
        Task<ProductDto?> GetProductById(int id);
        Task<IEnumerable<ProductDto>> GetProducts(string? name);
        Task<ProductDto> CreateProduct(ProductDto product);
        Task<bool> UpdateProduct(ProductDto product);
        Task<bool> DeleteProductById(int id);
        Task<IEnumerable<ProductDto>> GetProductsByCategoryId(int categoryId);
        Task<IEnumerable<ProductDto>> GetProductsByWarehouseId(int warehouseId);
    }
}
