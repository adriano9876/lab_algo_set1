﻿using Business.Dto;
using Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess.Models;
using Microsoft.EntityFrameworkCore;

namespace Business.Services.ServicesImpl
{
    public class ProductService : IProductService
    {
        private readonly IRepository _repo;

        public ProductService(IRepository repo)
        {
            _repo = repo;
        }

        public async Task<ProductDto> CreateProduct(ProductDto product)
        {
            var warehouses = await _repo.GetWarehousesByIdentifiers(product.WarehouseIds);

            if (!warehouses.Any() || warehouses.Count() > product.WarehouseIds.Count() )
            {
                throw new ArgumentNullException();
            }

            var category = await _repo.GetCategoryByName(product.CategoryName);
            
            if(category == null)
            {
                category = await _repo.CreateCategory(new Category { Name = product.CategoryName });
            }

            var newProduct = await _repo.CreateProduct(new Product
            {
                Name = product.Name,
                Price = product.Price,
                ProductionDate = product.ProductionDate,
                CategoryId = category.Id,    
                Count = product.Count
            });

            _repo.CreateProductWarehouse(newProduct.Id, warehouses);

            var createdProduct = await _repo.GetProductById(newProduct.Id);

            return new ProductDto
            {
                Id = newProduct.Id,
                Name = newProduct.Name,
                Price = newProduct.Price,
                ProductionDate = newProduct.ProductionDate,
                CategoryId = createdProduct.CategoryId,
                CategoryName = createdProduct.Category.Name,
                Category = new CategoryDto {
                    Id = createdProduct.CategoryId,
                    Name = createdProduct.Category.Name,
                },
                Count = newProduct.Count
            };
        }

        public Task<bool> DeleteProductById(int id)
        {
            var isDeleted = _repo.DeleteProductById(id);
            return isDeleted;
        }

        public async Task<ProductDto?> GetProductById(int id)
        {
            var product = await _repo.GetProductById(id);
            return new ProductDto
            {
                Id = product.Id,
                Name = product.Name,
                Price = product.Price,
                ProductionDate = product.ProductionDate,
                CategoryId = product.CategoryId,
                CategoryName = product.Category.Name,
                Category = new CategoryDto
                {
                    Id = product.CategoryId,
                    Name = product.Category.Name,
                },
                Count = product.Count
            };
        }

        public async Task<IEnumerable<ProductDto>> GetProducts(string? name)
        {
            var products = name == null ? await _repo.GetProducts() : await _repo.GetProducts(p => p.Name.Contains(name));
            return products.Select(product => new ProductDto
            {
                Id = product.Id,
                Name = product.Name,
                Price = product.Price,
                ProductionDate = product.ProductionDate,
                CategoryId = product.CategoryId,
                CategoryName = product.Category.Name,
                Category = new CategoryDto
                {
                    Id = product.CategoryId,
                    Name = product.Category.Name,
                },
                Count = product.Count
            });
        }

        public async Task<IEnumerable<ProductDto>> GetProductsByCategoryId(int categoryId)
        {
            var products = await _repo.GetProductsByCategoryId(categoryId);

            return products.Select(product => new ProductDto
            {
                Id = product.Id,
                Name = product.Name,
                Price = product.Price,
                ProductionDate = product.ProductionDate,
                CategoryId = product.CategoryId,
                CategoryName = product.Category.Name,
                Category = new CategoryDto
                {
                    Id = product.CategoryId,
                    Name = product.Category.Name,
                },
                Count = product.Count
            });
        }

        public async Task<IEnumerable<ProductDto>> GetProductsByWarehouseId(int warehouseId)
        {
            var products = await _repo.GetProductsByWarehouseId(warehouseId);

            return products.Select(product => new ProductDto
            {
                Id = product.Id,
                Name = product.Name,
                Price = product.Price,
                ProductionDate = product.ProductionDate,
                CategoryId = product.CategoryId,
                CategoryName = product.Category.Name,
                Category = new CategoryDto
                {
                    Id = product.CategoryId,
                    Name = product.Category.Name,
                },
                Count = product.Count
            });
        }

        public async Task<bool> UpdateProduct(ProductDto product)
        {
            var warehouses = await _repo.GetWarehousesByIdentifiers(product.WarehouseIds);

            if (!warehouses.Any() || warehouses.Count() > product.WarehouseIds.Count())
            {
                throw new ArgumentNullException();
            }

            var category = await _repo.GetCategoryByName(product.CategoryName);

            if (category == null)
            {
                category = await _repo.CreateCategory(new Category { Name = product.CategoryName });
            }

            return await _repo.UpdateProduct(new Product
            {
                Name = product.Name,
                Price = product.Price,
                ProductionDate = product.ProductionDate,
                CategoryId = product.CategoryId,
                Warehouses = (ICollection<Warehouse>)warehouses,
                Count = product.Count
            });
        }
    }
}
