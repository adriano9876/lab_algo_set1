﻿using DataAccess.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Context
{
    public class ProductManagerDbContext : DbContext
    {
        public ProductManagerDbContext(DbContextOptions<ProductManagerDbContext> options) : base(options)
        {
        }

        public DbSet<Product> Products { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Warehouse> Warehouses { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //modelBuilder.Entity<Product>()
            //    .HasMany(p => p.Warehouses)
            //    .WithMany(w => w.Products)
            //    .UsingEntity(
            //        "ProductWarehouses",
            //        l => l.HasOne(typeof(Warehouse)).WithMany().HasForeignKey("WarehouseId").HasPrincipalKey(nameof(Warehouse.Id)).OnDelete(DeleteBehavior.Cascade),
            //        r => r.HasOne(typeof(Product)).WithMany().HasForeignKey("ProductId").HasPrincipalKey(nameof(Product.Id)).OnDelete(DeleteBehavior.Cascade),
            //        j => j.HasKey("ProductId", "WarehouseId")
            //    );


            modelBuilder.Entity<Product>()
                        .HasMany(product => product.Warehouses)
                        .WithMany(warehouse => warehouse.Products)
                        .UsingEntity(
                            "ProductWarehouses",
                            l => l.HasOne(typeof(Warehouse)).WithMany().HasForeignKey("WarehouseId").HasPrincipalKey(nameof(Warehouse.Id)).OnDelete(DeleteBehavior.Cascade),
                            r => r.HasOne(typeof(Product)).WithMany().HasForeignKey("ProductId").HasPrincipalKey(nameof(Product.Id)).OnDelete(DeleteBehavior.Cascade),
                            j => j.HasKey("WarehouseId", "ProductId")
                        );


            modelBuilder.Entity<Product>()
                .HasOne(p => p.Category)
                .WithMany(w => w.Products)
                .HasForeignKey(p => p.CategoryId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Warehouse>()
                .HasData(
                    new Warehouse { Id = 1, City = "Turin" },
                    new Warehouse { Id = 2, City = "Milan" },
                    new Warehouse { Id = 3, City = "Florence" },
                    new Warehouse { Id = 4, City = "Rome" }
                );

            modelBuilder.Entity<Category>()
                .HasData(
                    new Category { Id = 1, Name = "Technology" },
                    new Category { Id = 2, Name = "Food" },
                    new Category { Id = 3, Name = "Toys" },
                    new Category { Id = 4, Name = "Stationary" }
                );

            modelBuilder.Entity<Product>()
                .HasData(
                    new Product { Id = 1, Name = "Mouse", Price = 49.00, Count = 12, CategoryId = 1, ProductionDate = DateTime.UtcNow},
                    new Product { Id = 2, Name = "Tomato Sauce", Price = 15.50, Count = 35, CategoryId = 2, ProductionDate = DateTime.UtcNow },
                    new Product { Id = 3, Name = "Lego House", Price = 180.00, Count = 4, CategoryId = 3, ProductionDate = DateTime.UtcNow },
                    new Product { Id = 4, Name = "Puzzle", Price = 20.20, Count = 100, CategoryId = 3, ProductionDate = DateTime.UtcNow },
                    new Product { Id = 5, Name = "Train", Price = 157.20, Count = 20, CategoryId = 3, ProductionDate = DateTime.UtcNow },
                    new Product { Id = 6, Name = "Glitter Pen", Price = 7.80, Count = 200, CategoryId = 4, ProductionDate = DateTime.UtcNow },
                    new Product { Id = 7, Name = "Notebook", Price = 12.80, Count = 57, CategoryId = 4, ProductionDate = DateTime.UtcNow }
                );

            modelBuilder.Entity("ProductWarehouses")
                .HasData(
                    new { WarehouseId = 1, ProductId = 1},
                    new { WarehouseId = 2, ProductId = 1},
                    new { WarehouseId = 4, ProductId = 1},
                    new { WarehouseId = 1, ProductId = 2},
                    new { WarehouseId = 3, ProductId = 2},
                    new { WarehouseId = 4, ProductId = 3},
                    new { WarehouseId = 3, ProductId = 3},
                    new { WarehouseId = 1, ProductId = 3},
                    new { WarehouseId = 1, ProductId = 4},
                    new { WarehouseId = 2, ProductId = 4},
                    new { WarehouseId = 3, ProductId = 4},
                    new { WarehouseId = 2, ProductId = 5},
                    new { WarehouseId = 4, ProductId = 5},
                    new { WarehouseId = 3, ProductId = 5},
                    new { WarehouseId = 1, ProductId = 5},
                    new { WarehouseId = 2, ProductId = 6},
                    new { WarehouseId = 3, ProductId = 6},
                    new { WarehouseId = 4, ProductId = 6},
                    new { WarehouseId = 1, ProductId = 7},
                    new { WarehouseId = 4, ProductId = 7}
                );
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.ConfigureWarnings(warnings =>
            warnings.Ignore(RelationalEventId.PendingModelChangesWarning));
        }
    }
}
