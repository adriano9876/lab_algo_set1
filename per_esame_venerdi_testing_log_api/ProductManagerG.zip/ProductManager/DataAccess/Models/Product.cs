﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace DataAccess.Models
{
    public class Product
    {
        [Required]
        public int Id { get; set; }
        [Required]
        [Column(TypeName = "nvarchar(50)")]
        public string Name { get; set; }
        [Required]
        [Column(TypeName = "decimal(10,2)")]
        public double Price { get; set; }
        [Required]
        public int Count { get; set; } 
        [Required]
        public bool IsAvailable => Count > 0;
        [Column(TypeName = "datetime")]
        public DateTime ProductionDate { get; set; } = DateTime.UtcNow;
        [Required]
        public int CategoryId { get; set; }
        public virtual Category Category { get; set; }
        public ICollection<Warehouse> Warehouses { get; set; } = new List<Warehouse>();

    }
}
