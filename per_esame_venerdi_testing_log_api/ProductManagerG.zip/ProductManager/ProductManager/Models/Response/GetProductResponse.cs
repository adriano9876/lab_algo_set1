﻿using Business.Dto;

namespace ProductManager.Models.Response
{
    public class GetProductResponse
    {
        public string Name { get; set; }
        public double Price { get; set; }
        public int Count { get; set; }
        public bool IsAvailable => Count > 0;
        public DateTime ProductionDate { get; set; } = DateTime.UtcNow;
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
        public CategoryDto Category { get; set; }
    }
}