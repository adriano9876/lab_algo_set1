﻿namespace ProductManager.Models.Requests
{
    public class CreateProductRequest
    {
        public string Name { get; set; }
        public double Price { get; set; }
        public int Count { get; set; }
        public bool IsAvailable => Count > 0;
        public string CategoryName { get; set; }
        public ICollection<int> WarehouseIds { get; set; }

    }
}