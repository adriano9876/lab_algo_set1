﻿using Business.Dto;
using Business.Services;
using DataAccess.Models;
using Microsoft.AspNetCore.Mvc;
using ProductManager.Models.Requests;
using ProductManager.Models.Response;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ProductManager.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly IProductService _productService;

        public ProductController(IProductService productService)
        {
            _productService = productService;
        }

        // GET: api/<ProductController>
        [HttpGet]
        [Route("search")]
        public async Task<ActionResult<IEnumerable<GetProductResponse>>> GetProducts([FromQuery(Name = "name")]string? search)
        {
            var products = await _productService.GetProducts(search);
            var responses = products.Select(product => new GetProductResponse
            {
                Name = product.Name,
                Price = product.Price,
                    ProductionDate = product.ProductionDate,
                CategoryId = product.CategoryId,
                CategoryName = product.Category.Name,
                Category = new CategoryDto {
                    Id = product.CategoryId,
                    Name = product.Category.Name,
                },
                Count = product.Count
            });

            return Ok(responses);
        }

        // GET api/<ProductController>/5
        [HttpGet]
        [Route("{id}")]
        public async Task<ActionResult<GetProductResponse>> GetProductById(int id)
        {
            var product = await _productService.GetProductById(id);
            if(product == null)
            {
                return NotFound();
            }

            var response = new GetProductResponse
            {
                Name = product.Name,
                Price = product.Price,
                ProductionDate = product.ProductionDate,
                CategoryId = product.CategoryId,
                CategoryName = product.Category.Name,
                Category = new CategoryDto
                {
                    Id = product.CategoryId,
                    Name = product.Category.Name,
                },
                Count = product.Count
            };

            return Ok(response);
        }

        // POST api/<ProductController>
        [HttpPost]
        public async Task<ActionResult<CreateUserResponse>> CreateProduct([FromBody]CreateProductRequest productRequest)
        {
            var dto = new ProductDto
            {
                Name = productRequest.Name,
                Price = productRequest.Price,
                CategoryName = productRequest.CategoryName,
                Count = productRequest.Count,
                WarehouseIds = productRequest.WarehouseIds
            };

            var product = await _productService.CreateProduct(dto);

            var response = new CreateUserResponse
            {
                Id = product.Id,
                Name = product.Name,
                Price = product.Price,
                ProductionDate = product.ProductionDate,
                CategoryId = product.CategoryId,
                CategoryName = product.Category.Name,
                Category = new CategoryDto
                {
                    Id = product.CategoryId,
                    Name = product.Category.Name,
                },
                Count = product.Count,
                Warehouses = product.Warehouses.Select(w => new WarehouseDto
                {
                    Id = w.Id,
                    City = w.City
                }).ToList()
            };

            // CreatedAtAction(nameof(Product), new { id = product.Id }, product);
            return Ok(product);
        }

        // PUT api/<ProductController>/5
        [HttpPut("{id}")]
        public async Task<ActionResult> Put(int id, [FromBody]CreateProductRequest productRequest)
        {
            return NoContent();
        }

        // DELETE api/<ProductController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
