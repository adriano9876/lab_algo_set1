﻿using AddUtenteMvvm.ViewModel.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AddUtenteMvvm.ViewModel
{
    class AddUtenteViewmodel : ViewModelBase
    {




    }

}
