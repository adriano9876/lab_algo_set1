﻿using AddUtenteMvvm.Model;
using AddUtenteMvvm.Repositories;
using AddUtenteMvvm.View;
using AddUtenteMvvm.ViewModel.Base;
using AddUtenteMvvm.ViewModel.Command;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace AddUtenteMvvm.ViewModel
{
    public class MainViewModel : ViewModelBase
    {
        private ObservableCollection<User> _users;
        private IUserRepository _repository;
        public RelayCommand AddNewUser { get; set; }
        public RelayCommand DeleteUserSelected { get; set; }
        public RelayCommand OpenWindow { get; set; }

        private AddUserWindows _addUserWindow;



        private User _user;

        public User User
        {
            get => _user;
            set
            {
                _user = value;
                OnPropertyChanged(nameof(User));
            }
        }


        private User _userSelected;

        public User UserSelected
        {
            get => _userSelected;
            set
            {
                _userSelected = value;
                OnPropertyChanged(nameof(User));
            }
        }




        public MainViewModel()
        {
            _users = new ObservableCollection<User>();
            _repository = new UserRepository(); 
            var lista = _repository.AllUsers();
            lista.ForEach(x => Users.Add(x));
            AddNewUser = new RelayCommand(x => AddNewUserFunc());
            DeleteUserSelected = new RelayCommand(x=>DeleteUserSelectedFunc());
            OpenWindow = new RelayCommand(_ => OpenWindowFunc());
        }

        public ObservableCollection<User> Users
        {
            get => _users;
            set
            {
                _users = value;
                OnPropertyChanged(nameof(Users));

            }
        }

        private string _name;
        public string Name
        {
            get => _name;
            set
            {
                _name = value;
                OnPropertyChanged(nameof(Name));                
            }
        }
        private string _email;
        public string Email
        {
            get => _email;
            set
            {
                _email = value;
                OnPropertyChanged(nameof(Email));
            }
        }
        private string _phone;
        public string Phone
        {
            get => _phone;
            set
            {
                _phone = value;
                OnPropertyChanged(nameof(Phone));
            }
        }

        private int _age;
        public int Age
        {
            get => _age;
            set
            {
                _age = value;
                OnPropertyChanged(nameof(Age));
            }
        }
        
        public void AddNewUserFunc()
        {
            var userToAdd = new User()
            {
                Name = _name,
                Email = _email,
                Age = _age,
                Phone = _phone
            };
            Users.Add(userToAdd);
        }

        public void DeleteUserSelectedFunc()
        {
            Users.Remove(UserSelected);
        }

        public void OpenWindowFunc()
        {
            _addUserWindow = new AddUserWindows();
            _addUserWindow.DataContext = this;
            _addUserWindow.Show();
        }





    }
}
