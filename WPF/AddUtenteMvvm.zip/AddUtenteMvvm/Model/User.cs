﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AddUtenteMvvm.Model
{
    public class User
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public int Age { get; set; }

        public override string? ToString()
        {
            return $"{Name} - {Email} - {Phone} - {Age}";
        }
    }

}
