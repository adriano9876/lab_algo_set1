﻿using AddUtenteMvvm.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace AddUtenteMvvm.Repositories
{
    public class UserRepository :IUserRepository
    {
        private readonly List<User> _users;
        public UserRepository() 
        {
            _users = new List<User>() { 
                new User {Name="Ste", Email="ste@msc.com",Phone ="12345",Age=20 },
                new User {Name="sara", Email="sara@msc.com",Phone ="454543",Age=30 },
                new User {Name="Bea", Email="bea@msc.com",Phone ="544542",Age=37 },
                new User {Name="luca", Email="luca@msc.com",Phone ="543454",Age=110 }
            };       

        }        

        public List<User> AllUsers()
        {
            return _users;
        }
    }
}
