﻿using AddUtenteMvvm.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AddUtenteMvvm.Repositories
{
    public interface IUserRepository
    {
        public List<User> AllUsers();
    }
}
