﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersoneSearchPatterOO._3.Model
{
    public class Pet
    {
        public string PetName { get; set; }
        public string PetType { get; set; }
   
    }
}
