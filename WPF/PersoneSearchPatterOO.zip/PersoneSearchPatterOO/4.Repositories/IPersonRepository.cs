﻿using PersoneSearchPatterOO._3.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersoneSearchPatterOO._4.Repositories
{
    public interface IPersonRepository
    {
        List<Persona> GetAll();
        void Add(Persona person);
        void Remove(Persona person);
        List<Persona> GetByName(string search);

    }
}
