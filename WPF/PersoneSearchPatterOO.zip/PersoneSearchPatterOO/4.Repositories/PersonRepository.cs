﻿using PersoneSearchPatterOO._3.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersoneSearchPatterOO._4.Repositories
{
    public class PersonRepository : IPersonRepository
    {
        private readonly List<Persona> _persone= new () 
        {

            new Persona {Nome="Stefano", Cognome="Bilinio", Age=55,
                    CanSwim = true,
                    PetPerson = new Pet{PetName="birba",PetType="Dog" },
                    Telefono="3333333", Verificato= false ,
                                    },

                new Persona {Nome="Andreina", Cognome="Tritto", Age=15,
                    CanSwim = true,
                    PetPerson = new Pet{PetName="fishi",PetType="Fish" },
                    Telefono="3333333", Verificato= true    },
                new Persona {Nome="Fede", Cognome="Fedez", Age=26,
                    CanSwim = false,
                    PetPerson = new Pet{PetName="wii",PetType="Cat" },
                    Telefono="3333333", Verificato= true     }
        };

        public List<Persona> Persone { get => _persone; }

        public List<Persona> GetAll()
        {
            return _persone;
        }

        public void Add(Persona person)
        {
            if (person != null)
                _persone.Add(person);
        }

        public void Remove(Persona person)
        {
            if (person != null)
                _persone.Remove(person);
        }

        // Returns people whose name or last name contains the given string (case-insensitive)
        public List<Persona> GetByName(string search)
        {
            if (string.IsNullOrWhiteSpace(search))
            {
                return _persone;
            }

            var lower = search.ToLowerInvariant();
            return _persone.Where(p =>
                (!string.IsNullOrEmpty(p.Nome) && p.Nome.ToLowerInvariant().Contains(lower)) ||
                (!string.IsNullOrEmpty(p.Cognome) && p.Cognome.ToLowerInvariant().Contains(lower))
            ).ToList();
        }




    }
}





