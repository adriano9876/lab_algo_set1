﻿using PersoneSearchPatterOO._0.Interface;
using PersoneSearchPatterOO._2.ViewModel.BaseClass;
using PersoneSearchPatterOO._4.Repositories;
using PersoneSearchPatterOO.Command;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace PersoneSearchPatterOO._2.ViewModel
{
    public class PersonaSearchViewModel: BaseViewModel
    {
        private string _searchNome;
        private List<ISearchResultObserver> _observers;
        private readonly IPersonRepository _personRepository;
        /* Commands */
        public ICommand SearchCommand { get; }


        public string SearchNome
        {
            get => _searchNome;
            set
            {
                if (_searchNome != value)
                {
                    _searchNome = value;
                    OnPropertyChanged(nameof(SearchNome));
                }
            }
        }

        public PersonaSearchViewModel()
        {
            _observers = new();
            _personRepository = new PersonRepository();
            SearchCommand = new RelayCommand(_ => Search(), _ => !string.IsNullOrWhiteSpace(SearchNome));
        }

        public void Attach(ISearchResultObserver observer)
        {
            if (!_observers.Contains(observer))
            {
                _observers.Add(observer);
            }
        }

        public void Detach(ISearchResultObserver observer)
        {
            if (_observers.Contains(observer))
            {
                _observers.Remove(observer);
            }
        }


        private void Search()
        {
            // Notify listeners that a search has been requested
            var name = SearchNome?.Trim();
            var persons = _personRepository.GetByName(name);

            foreach (var observer in _observers)
            {
                observer.Update(persons);
            }
        }
 





    }
}
