﻿using PersoneSearchPatterOO._0.Interface;
using PersoneSearchPatterOO._2.ViewModel.BaseClass;
using PersoneSearchPatterOO._3.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersoneSearchPatterOO._2.ViewModel
{
    public class PersoneListViewModel : BaseViewModel, ISearchResultObserver
    {

        private ObservableCollection<Persona> _persone = new();

        public ObservableCollection<Persona> Persone
        {
            get => _persone;
            set
            {
                if (_persone != value)
                {
                    _persone = value;
                    OnPropertyChanged(nameof(_persone));
                }
            }
        }


        public void Update(IEnumerable<Persona> searchResults)
        {
            if (searchResults == null || !searchResults.Any())
            {
                return;
            }

            _persone.Clear();
            foreach (var person in searchResults)
            {
                _persone.Add(person);
            }
        }
    }
}
