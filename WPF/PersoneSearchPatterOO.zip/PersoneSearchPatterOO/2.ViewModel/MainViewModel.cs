﻿using PersoneSearchPatterOO._2.ViewModel.BaseClass;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersoneSearchPatterOO._2.ViewModel
{
    public class MainViewModel : BaseViewModel
    {
        private string _title = "Subscriber Application OO";
        private PersonaSearchViewModel _personaSearchViewModel;
        private PersoneListViewModel _personeListViewModel;
        public string Title
        {
            get => _title;
            set
            {
                if (_title != value)
                {
                    _title = value;
                    OnPropertyChanged(nameof(Title));
                }
            }
        }

        public PersonaSearchViewModel PersonaSearchViewModel
        {
            get => _personaSearchViewModel;
            set
            {
                _personaSearchViewModel = value;
                OnPropertyChanged(nameof(PersonaSearchViewModel));
            }
        }

        public PersoneListViewModel PersoneListViewModel
        {
            get => _personeListViewModel;
            set
            {
                _personeListViewModel = value;
                OnPropertyChanged(nameof(PersoneListViewModel));
            }
        }

        public MainViewModel()
        {
            _personaSearchViewModel = new PersonaSearchViewModel();
            _personeListViewModel = new PersoneListViewModel();
            _personaSearchViewModel.Attach(_personeListViewModel);
        }



    }
}
