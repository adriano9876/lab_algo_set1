﻿using PersoneSearchPatterOO._3.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersoneSearchPatterOO._0.Interface
{
    public interface ISearchResultObserver
    {
        void Update(IEnumerable<Persona> searchResult);
    }
}
