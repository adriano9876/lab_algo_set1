﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Progetto_Contatti._3.Model
{
    public  class Persona 
    {
            
        public string Nome { get; set; }
        public string Cognome { get; set; }
        public int Age { get; set; }
        public bool CanSwim { get; set; }
        public DrivingLicence DrivingLicence { get; set; }
        public Pet PetPerson { get; set; }

        /*altri dati*/
        public string Telefono { get; set; }
        public bool Verificato { get; set; }


    }

    public enum DrivingLicence
    {
        Car,
        Bike,
        Bus
    }

}
