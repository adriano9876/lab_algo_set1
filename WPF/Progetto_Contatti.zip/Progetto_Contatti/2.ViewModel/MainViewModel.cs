﻿using Progetto_Contatti._3.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;

namespace Progetto_Contatti._2.ViewModel
{
    public class MainViewModel : ViewModelBase
    {
        public ObservableCollection<Persona> Persone { get; set; }
          
        private  CollectionViewSource _viewSource;
        public ICollectionView PersoneView 
        {
            get => _viewSource.View;
        }

        public MainViewModel()
        {
            Persone = new ObservableCollection<Persona>
            {
                new Persona {Nome="Stefano", Cognome="Bilinio", Age=55,
                    CanSwim = true,
                    DrivingLicence= DrivingLicence.Bike,
                    PetPerson = new Pet{PetName="birba",PetType="Dog" },
                    Telefono="3333333", Verificato= false },
                new Persona {Nome="Andreina", Cognome="Tritto", Age=15,
                    CanSwim = true,
                    DrivingLicence= DrivingLicence.Car,
                    PetPerson = new Pet{PetName="fishi",PetType="Fish" },
                    Telefono="3333333", Verificato= true },
                new Persona {Nome="Fede", Cognome="Fedez", Age=26,
                    CanSwim = false,
                    DrivingLicence= DrivingLicence.Bus,
                    PetPerson = new Pet{PetName="wii",PetType="Cat" },
                    Telefono="3333333", Verificato= true }

            };
    
            /*CollectionViewSource*/
            _viewSource = new CollectionViewSource();
            _viewSource.Source = Persone;
            _viewSource.View.Refresh();


        }

        private string _mioFilterText;
        public string MioFilterText
        {
            get => _mioFilterText;
            set
            {
                _mioFilterText = value;
                OnPropertyChanged(nameof(MioFilterText));
                //Search();
                //PersonaView.Refresh();
            }
        }






        private bool Search(object obj)
        {
            if (obj is Persona p)
            {
                if (string.IsNullOrEmpty(MioFilterText))
                {
                    return false;
                }
                return p.Nome.Contains(MioFilterText, StringComparison.OrdinalIgnoreCase);
            }
            return false;

        }


        //public PersonaViewModel PersonaSelezionata
        //{
        //    get { return _personaSelezionata; }
        //    set
        //    {
        //        if (_personaSelezionata != value)
        //        {
        //            _personaSelezionata = value;
        //            OnPropertyChanged(nameof(_personaSelezionata));
        //        }
        //    }
        //}
        // private PersonaViewModel _personaSelezionata { get; set; }




    }


}
