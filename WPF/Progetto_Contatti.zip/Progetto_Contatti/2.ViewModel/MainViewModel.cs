﻿using Progetto_Contatti._3.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Progetto_Contatti._2.ViewModel
{
    public class MainViewModel : ViewModelBase
    {
        public List<Contatto> Contatti { get; set; }
        private ContattoViewModel _contattoSelezionato { get; set; }

        public MainViewModel() {
            Contatti = new List<Contatto>()
            {
                new Contatto {Nome="Stefano", Cognome="Bilinio",Telefono="3333333", Verificato= true },
                new Contatto {Nome="Andreina", Cognome="Tritto",Telefono="2222222", Verificato= true },
                new Contatto {Nome="Mario", Cognome="Marius",Telefono="111111", Verificato= false },
            };
        }  

        public ContattoViewModel ContattoSelezionato
        {
            get { return _contattoSelezionato; }
            set
            {
                if (_contattoSelezionato != value)
                {
                    _contattoSelezionato = value;
                    OnPropertyChanged(nameof(_contattoSelezionato));
                }
            }
        }


    }


}
