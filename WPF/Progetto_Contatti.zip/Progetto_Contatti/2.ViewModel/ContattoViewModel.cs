﻿using Progetto_Contatti._3.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Progetto_Contatti._2.ViewModel
{
    public class ContattoViewModel : ViewModelBase
    {
        private readonly Contatto _contattoModel;
        public ContattoViewModel(Contatto contattoModel) {
            _contattoModel = contattoModel;
        }



        /* Properties */
        public string Nome
        {
            get { return _contattoModel.Nome; }
            set
            {
                if (_contattoModel.Nome != value)
                {
                    _contattoModel.Nome = value;
                    OnPropertyChanged(nameof(_contattoModel.Nome));
                }
            }
        }

        public string Cognome
        {
            get { return _contattoModel.Cognome; }
            set
            {
                if (_contattoModel.Cognome != value)
                {
                    _contattoModel.Cognome = value;
                    OnPropertyChanged(nameof(_contattoModel.Cognome));
                }
            }
        }


        public string Telefono
        {
            get { return _contattoModel.Telefono; }
            set
            {
                if (_contattoModel.Telefono != value)
                {
                    _contattoModel.Telefono = value;
                    OnPropertyChanged(nameof(_contattoModel.Telefono));
                }
            }
        }

        public bool Verificato
        {
            get { return _contattoModel.Verificato; }
            set
            {
                if (_contattoModel.Verificato != value)
                {
                    _contattoModel.Verificato = value;
                    OnPropertyChanged(nameof(_contattoModel.Verificato));
                }
            }
        }



    }

}
