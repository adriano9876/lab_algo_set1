﻿using MyQuotes.Events;
using MyQuotes.Models;
using System.Collections.ObjectModel;
using System.Windows.Input;

namespace MyQuotes.ViewModels
{
    public class BasketViewModel : BindableBase
    {
        #region Field members

        private readonly IEventAggregator eventAggregator;

        #endregion

        #region Commands

        public ICommand RequestApprovalCommand { get; }

        #endregion

        #region Constructor

        public BasketViewModel()
        {
            eventAggregator = EventAggregator.Current;
            RequestApprovalCommand = new DelegateCommand(RequestApproval_Action);
            Items = [new BasketItem { Description = "potatos", Price = 10 }, new BasketItem { Description = "apples", Price = 5 }];
        }

        #endregion

        #region Properties

        public ObservableCollection<BasketItem> Items { get; }

        #endregion

        #region Methods

        private void RequestApproval_Action()
        {
            var basket = new BasketModel(Items);
            eventAggregator.GetEvent<BasketApprovalRequest>().Publish(basket);
        }

        #endregion
    }
}
