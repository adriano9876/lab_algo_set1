﻿using MyQuotes.Events;
using MyQuotes.Models;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Input;

namespace MyQuotes.ViewModels
{
    public class ApprovalViewModel : BindableBase, IDisposable
    {
        private readonly IEventAggregator eventAggregator;

        public ICommand ClearCommand { get; }

        public ICommand SendToCustomerCommand { get; }

        #region Constructor

        public ApprovalViewModel()        
        {
            ClearCommand = new DelegateCommand(() => Items?.Clear());
            SendToCustomerCommand = new DelegateCommand(SendToCustomerAction);
            
            Items = [];

            eventAggregator = EventAggregator.Current;
            eventAggregator.GetEvent<BasketApprovalRequest>().Subscribe(ApprovalRequest_Action);
        }

        #endregion

        #region Properties

        public ObservableCollection<BasketItem> Items { get; }

        #endregion

        #region Methods

        public void Dispose()
        {
            eventAggregator.GetEvent<BasketApprovalRequest>().Unsubscribe(ApprovalRequest_Action);
        }

        private void ApprovalRequest_Action(BasketModel model)
        {
            if (model != null)
            {
                Items.Clear();
                Items.AddRange(model.BasketItems);
            }
        }

        private void SendToCustomerAction()
        {
            var basket = new BasketModel(Items.Where(x => x.IsApproved));
            MessageBox.Show(basket.ToString(), "Send to Customer");
        }

        #endregion
    }
}
