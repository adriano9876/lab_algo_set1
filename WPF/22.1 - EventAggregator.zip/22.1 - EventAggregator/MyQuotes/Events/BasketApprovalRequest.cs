﻿using MyQuotes.Models;

namespace MyQuotes.Events
{
    public class BasketApprovalRequest: PubSubEvent<BasketModel>
    {
    }
}
