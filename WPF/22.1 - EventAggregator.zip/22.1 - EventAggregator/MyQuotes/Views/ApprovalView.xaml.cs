﻿using MyQuotes.ViewModels;
using System.Windows.Controls;

namespace MyQuotes.Views
{
    /// <summary>
    /// Interaction logic for ApprovalVIew.xaml
    /// </summary>
    public partial class ApprovalView : UserControl
    {
        public ApprovalView()
        {
            InitializeComponent();
            this.DataContext = new ApprovalViewModel();
        }
    }
}
