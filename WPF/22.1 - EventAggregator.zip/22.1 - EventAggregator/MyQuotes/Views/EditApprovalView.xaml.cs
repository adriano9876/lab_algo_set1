﻿using MyQuotes.ViewModels;
using System.Windows.Controls;

namespace MyQuotes.Views
{
    /// <summary>
    /// Interaction logic for EditApprovalView.xaml
    /// </summary>
    public partial class EditApprovalView : UserControl
    {
        public EditApprovalView()
        {
            InitializeComponent();
            this.DataContext = new ApprovalViewModel();
        }
    }
}
