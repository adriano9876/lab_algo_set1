﻿using MyQuotes.Events;
using MyQuotes.Models;
using MyQuotes.ViewModels;
using System.Windows.Controls;

namespace MyQuotes.Views
{
    /// <summary>
    /// Interaction logic for BasketView.xaml
    /// </summary>
    public partial class BasketView : UserControl
    {
        public BasketView()
        {
            InitializeComponent();
            this.DataContext = new BasketViewModel();
            var eventAggregator = EventAggregator.Current;
            eventAggregator.GetEvent<BasketApprovalRequest>().Subscribe(ApprovalRequest_Action);

        }

        private void ApprovalRequest_Action(BasketModel model)
        {
            this.Focus();
        }
    }
}
