﻿using System.Text;

namespace MyQuotes.Models
{
    public class BasketModel
    {
        public List<BasketItem> BasketItems { get; } = new List<BasketItem>();

        public BasketModel()
        {
        }

        public BasketModel(IEnumerable<BasketItem> items)
        {
            BasketItems.AddRange(items ?? Enumerable.Empty<BasketItem>());
        }

        public override string ToString()
        {
            if (BasketItems.Count == 0)
            {
                return "[Empty]";
            }

            StringBuilder sb = new StringBuilder();
            BasketItems.ForEach(item => sb.AppendLine($"{item.Description} - ${item.Price} USD"));
            return sb.ToString();
        }
    }
}
