﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyQuotes.Models
{
    public class BasketItem: BindableBase
    {
        private string description;
        private decimal price;
        private bool approved;

        public string Description
        {
            get => description;
            set =>  SetProperty(ref description, value);
        }

        public decimal Price
        {
            get => price;
            set => SetProperty(ref price, value);
        }

        public bool IsApproved
        {
            get => approved;
            set => SetProperty(ref approved, value);
        }
    }
}
