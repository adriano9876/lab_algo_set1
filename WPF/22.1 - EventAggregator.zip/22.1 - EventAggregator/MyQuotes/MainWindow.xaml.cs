﻿using MyQuotes.Events;
using MyQuotes.Models;
using MyQuotes.Views;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace MyQuotes
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        #region Field and Constant members

        public const string ApprovalViewName = "Approval";

        public const string EditApprovalViewName = "Edit Approval";

        private readonly IEventAggregator eventAggregator;

        #endregion

        #region Commands

        public ICommand CloseTabItemCommand {  get; }

        public ICommand MenuItemCommand { get; }

        #endregion

        #region Constructor

        public MainWindow()
        {
            CloseTabItemCommand = new DelegateCommand<object>(CloseTabItem_Action);
            MenuItemCommand = new DelegateCommand<object>(MenuItem_Action);

            InitializeComponent();

            eventAggregator = EventAggregator.Current;
            eventAggregator.GetEvent<BasketApprovalRequest>().Subscribe(ApprovalRequest_Action);
        }

        #endregion

        #region Methods

        private void ApprovalRequest_Action(BasketModel model)
        {
            string approvalViewName = ApprovalViewName;

            if (CreateNavigateTabItem(approvalViewName))
            {
                eventAggregator.GetEvent<BasketApprovalRequest>().Publish(model);
            }            
        }

        private void CloseTabItem_Action(object obj)
        {
            var tab = this.PART_TabControl.Items.OfType<TabItem>().FirstOrDefault(x => $"{x.Header}" == $"{obj}");
            this.PART_TabControl.Items.Remove(tab);
            DisposeTabDatacontext(tab);
        }

        private void DisposeTabDatacontext(TabItem tabItem)
        {
            ((tabItem.Content as UserControl)?.DataContext as IDisposable)?.Dispose();
        }

        private void MenuItem_Action(object obj)
        {
            var header = $"{(obj as MenuItem)?.Header}";
            CreateNavigateTabItem(header);
        }

        private bool CreateNavigateTabItem(string header)
        {
            var tabItem = this.PART_TabControl.Items.OfType<TabItem>().FirstOrDefault(x => $"{x.Header}" == header);
            if (tabItem != null)
            {
                this.PART_TabControl.SelectedItem = tabItem;
                return false;
            }

            int addedIndex = -1;
            switch (header)
            {
                case ApprovalViewName:
                    addedIndex = this.PART_TabControl.Items.Add(new TabItem
                    {
                        Header = header,
                        Content = new ApprovalView(),
                    });
                    this.PART_TabControl.SelectedIndex = addedIndex;
                    break;

                case EditApprovalViewName:
                    addedIndex = this.PART_TabControl.Items.Add(new TabItem
                    {
                        Header = header,
                        Content = new EditApprovalView(),
                    });
                    this.PART_TabControl.SelectedIndex = addedIndex;
                    break;
            }
            return true;
        }

        #endregion
    }
}