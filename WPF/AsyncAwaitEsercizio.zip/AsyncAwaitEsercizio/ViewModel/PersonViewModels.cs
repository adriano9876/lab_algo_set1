﻿using AsyncAwaitEsercizio.Models;
using AsyncAwaitEsercizio.Repositories;
using AsyncAwaitEsercizio.ViewModel.Base;
using AsyncAwaitEsercizio.ViewModel.Command;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Documents;

namespace AsyncAwaitEsercizio.ViewModel
{
    public class PersonViewModels :ViewModelBase
    {
        private ObservableCollection<Person> _people = new ObservableCollection<Person>();
        private PersonRepository _repository;
        private string _searchText;
        public RelayCommand SearchAllHeavy { get; set; }
        public RelayCommand SearchAllHeavyAsync { get; set; }
        public RelayCommand SearchAsync { get; set; }
        public RelayCommand Clear { get; set; }

        
        public PersonViewModels()
        {
            SearchAllHeavy = new RelayCommand(x => SearchAllFuncHeavy());
            SearchAsync = new RelayCommand(x => SearchAsyncFunc());
            Clear = new RelayCommand(x => ClearFunc());
            SearchAllHeavyAsync = new RelayCommand(x => SearchAllFuncHeavyAsync());
            _repository = new PersonRepository();
            
        }

        public ObservableCollection<Person> People
        {
            get => _people;
            set
            {
                _people = value;
                OnPropertyChanged(nameof(People));
               
            }
        }

        public string SearchText
        {
            get => _searchText;
            set
            {
                _searchText = value;
                OnPropertyChanged(nameof(SearchText));                
            }
        }

        public async void SearchAllFuncHeavyAsync()
        {
            _people.Clear();
            var lista = await Task.Run(() => _repository.GetAll_VeryHeavy());
            lista.ForEach(x=>People.Add(x));

            //await Task.Run(() =>
            // _repository.GetAll_VeryHeavy().ForEach(x => People.Add(x))
            //);            


        }

        public  void SearchAllFuncHeavy() 
        {
            var list = _repository.GetAll_VeryHeavy();
            _people.Clear();
            list.ForEach(x => People.Add(x));           
        }
        public async  void SearchAsyncFunc() 
        {
            //var lista = await _repository.GetAllAsync();
        }
        public void ClearFunc() {
            _people.Clear();
        }




    }
}
