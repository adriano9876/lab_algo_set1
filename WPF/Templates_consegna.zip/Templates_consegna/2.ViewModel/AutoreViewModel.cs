﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using Templates_consegna._3.Model;

namespace Templates_consegna._2.ViewModel
{
    public class AutoreViewModel : INotifyPropertyChanged
    {
        private ObservableCollection<Autore> _autori;
        public ObservableCollection<Autore> Autori
        {
            get => _autori;
            set
            {
                _autori = value;
                OnPropertyChanged(nameof(Autori));
            }
        }

        public AutoreViewModel()
        {

            Autori = new ObservableCollection<Autore>
            {
                new Autore { Id = 1, FirstName = "Luca", LastName = "Rossi" },
                new Autore { Id = 2, FirstName = "Stefano", LastName = "Bilinio" },
                new Autore { Id = 3, FirstName = "Andreina", LastName = "Tritto" }
            };
        }
        public event PropertyChangedEventHandler? PropertyChanged;
        protected virtual void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }


    }
}
