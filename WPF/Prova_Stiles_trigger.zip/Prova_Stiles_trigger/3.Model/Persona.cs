﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prova_Stiles_trigger._3.Model
{
    public class Persona : INotifyPropertyChanged
    {
        public string UserName
        {
            get { return UserName; }
            set
            {
                if (UserName != value)
                {
                    UserName = value;
                    OnPropertyChanged(nameof(UserName));
                }
            }
        }

        public string Cognome
        {
            get { return Cognome; }
            set
            {
                if (Cognome != value)
                {
                    Cognome = value;
                    OnPropertyChanged(nameof(Cognome));
                }
            }
        }


        public bool Stato
        {
            get { return Stato; }
            set
            {
                if (Stato != value)
                {
                    Stato = value;
                    OnPropertyChanged(nameof(Stato));
                }
            }
        }



        public event PropertyChangedEventHandler? PropertyChanged;
        public void OnPropertyChanged(string propName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propName));
        }
    }



}
