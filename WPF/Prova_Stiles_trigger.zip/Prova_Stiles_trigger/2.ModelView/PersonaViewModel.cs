﻿using Prova_Stiles_trigger._3.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Prova_Stiles_trigger._2.ModelView
{
    public class PersonaViewModel
    {
        public Persona p1 { get; set; } = new Persona() { UserName = "luca", Cognome = "lucas" };


    }
}
