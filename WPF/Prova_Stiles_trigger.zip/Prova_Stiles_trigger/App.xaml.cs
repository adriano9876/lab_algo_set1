﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace Prova_Stiles_trigger
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
