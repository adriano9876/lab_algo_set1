﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MegaCell
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
           
        }

        private void Button_Click_Negozio(object sender, RoutedEventArgs e)
        {
            this.cambio_finestra.SelectedIndex = 0;
            
        }
        private void Button_Click_Mazzo(object sender, RoutedEventArgs e)
        {
            this.cambio_finestra.SelectedIndex = 1;
        }
        private void Button_Click_Battaglie(object sender, RoutedEventArgs e)
        {
            this.cambio_finestra.SelectedIndex = 2;
        }
        private void Button_Click_Carte(object sender, RoutedEventArgs e)
        {
            this.cambio_finestra.SelectedIndex = 3;
        }
    }
}