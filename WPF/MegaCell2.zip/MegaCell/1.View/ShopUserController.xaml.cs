﻿using MegaCell._2.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MegaCell._1.View
{
    /// <summary>
    /// Interaction logic for ShopUserController.xaml
    /// </summary>
    public partial class ShopUserController : UserControl
    {
        public ShopUserController()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if(DataContext is MegaCellVM vm)
            {
                vm.UserVM.Credito -= 1; 
                    //ListaPacchetti[0].Costo=11;
            }
        }
    }
}
