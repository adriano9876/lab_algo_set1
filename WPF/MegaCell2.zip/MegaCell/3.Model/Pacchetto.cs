﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace MegaCell._3.Model
{
    public class Pacchetto
    { 
        public string Nome {  get; set; }
        public int Costo { get; set; }
        public List<Carte> Carte { get; set; } = new List<Carte>();


    }
}
