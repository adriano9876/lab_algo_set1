﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace MegaCell._3.Model
{
    public class Shop
    {
        public List<Pacchetto> ListaPacchetti { get; set; } = new List<Pacchetto>(); 
        public int NumeroPacchetti {  set; get; } 

        public void InitPachetto()
        {
            string path = "5.DatiJson/Pachetto.json";
            if (File.Exists(path))
            {
                var pacchetto = JsonSerializer.Deserialize<List<Pacchetto>>(File.ReadAllText(path));
                ListaPacchetti = pacchetto;
            }
            else
            {
                var carta = new Carte { Nome = "Cavaliere", Rarità = "Comune" };
                var pacchetto = new Pacchetto
                {
                    Nome = "Baule d'Oro",
                    Costo = 500,
                    Carte = new List<Carte>()
                };
                this.ListaPacchetti.Add(pacchetto);
            }

        }


    }//
}
