﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MegaCell._3.Model
{
    public class Carte
    {
        public string Nome { get; set; }
        public string Rarità { get; set; }
    }
}
