﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace MegaCell._3.Model
{

    public class User
    {
        public string? UserName { get; set; }
        public int Livello { get; set; }
        public string? CartaDicredito { get; set; }
        public int Credito { get; set; }
        public int Gemme { get; set; }

        public void InitUser()
        {
            string path = "5.DatiJson/User.json";
            if (File.Exists(path))
            {
                User? user = JsonSerializer.Deserialize<User>(File.ReadAllText(path));

                UserName =user.UserName;
                Livello =user.Livello;
                CartaDicredito = user.CartaDicredito;
                Credito = user.Credito;
                Gemme = user.Gemme;
            }
            else
            {
                UserName = "wii007";
                Livello = 57;
                CartaDicredito = "5355279273296";
                Credito = 19999;
                Gemme = 1000;
            }
        }


    }//


}
