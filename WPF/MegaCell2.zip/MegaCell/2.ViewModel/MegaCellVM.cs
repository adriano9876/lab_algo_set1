﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MegaCell._2.ViewModel
{
    public class MegaCellVM
    {
        public UserVM UserVM {  get; set; }= new UserVM();
        public NegozioVM NegozioVM { get; set; } = new NegozioVM();
        public MazzoVM MazzoVM { get; set; } = new MazzoVM();
        public BattaglieVM BattaglieVM { get; set;} = new BattaglieVM();

    }//
}
