﻿using MegaCell._3.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace MegaCell._2.ViewModel
{
    public class UserVM: INotifyPropertyChanged
    {
        public User Utente { get; set; } = new User();
        public ICommand LoadUserCommand { get; }

        public void LoadUser()
        {
            Random rnd = new Random();
            int numeroIntero = rnd.Next(0, 101);
            Utente.Gemme = numeroIntero;
            Utente.UserName = "sdfgh"+numeroIntero;
        }
        public UserVM()
        {
            Utente.InitUser();
            LoadUserCommand = new RelayCommand((x) => LoadUser() );
        }

        public string UserName
        {
            get { return Utente.UserName; }
            set
            {
                if (Utente.UserName != value)
                {
                    Utente.UserName = value;
                    OnPropertyChanged(nameof(Utente.UserName));
                }
            }
        }

        public int Livello
        {
            get { return Utente.Livello; }
            set
            {
                if (Utente.Livello != value)
                {
                    Utente.Livello = value;
                    OnPropertyChanged(nameof(Utente.Livello));
                }
            }
        }

        public int Credito
        {
            get { return Utente.Credito; }
            set
            {
                if (Utente.Credito != value)
                {
                    Utente.Credito = value;
                    OnPropertyChanged(nameof(Utente.Credito));
                }
            }
        }

        public int Gemme
        {
            get { return Utente.Gemme; }
            set
            {
                if (Utente.Gemme != value)
                {
                    Utente.Gemme = value;
                    OnPropertyChanged(nameof(Utente.Gemme));
                }
            }
        }



        public event PropertyChangedEventHandler? PropertyChanged;
        public void OnPropertyChanged(string propName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propName));
        }

    }
}
