﻿using MegaCell._3.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace MegaCell._2.ViewModel
{
    public class NegozioVM : INotifyPropertyChanged
    {
        public Shop Shop {  get; set; } = new Shop();
        public ObservableCollection<Pacchetto> PacchettiCollection { get; set; } = new ObservableCollection<Pacchetto>();
        //carico la lista 
        private Pacchetto _pacchettoSelezionato;


        public NegozioVM() 
        {
            Shop.InitPachetto();          

            if (Shop.ListaPacchetti != null)
            {
                foreach (var pacchetto in Shop.ListaPacchetti)
                {
                    PacchettiCollection.Add(pacchetto);
                }
            }

            if (PacchettiCollection.Count > 0)
            {
                PacchettoSelezionato = PacchettiCollection.First();
            }

        }

        public Pacchetto PacchettoSelezionato
        {
            get => _pacchettoSelezionato;
            set
            {
                _pacchettoSelezionato = value;
                OnPropertyChanged();

            }
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        protected virtual void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }





    }
}
