﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace MegaCell._3.Model
{
    public class Pacchetto
    { 
        public int Costo { get; set; }
        public Carte[] Carte { get; set; }


    }
}
