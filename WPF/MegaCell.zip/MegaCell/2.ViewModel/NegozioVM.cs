﻿using MegaCell._3.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace MegaCell._2.ViewModel
{
    public class NegozioVM
    {
        public List<Pacchetto> ListaPacchetti { get; set;} = new List<Pacchetto>();

        public NegozioVM() 
        {
            InitPachetto();
        }
        public void InitPachetto()
        {
            string path = "5.DatiJson/Pachetto.json";
            if (File.Exists(path))
            {
                var pacchetto = JsonSerializer.Deserialize<List<Pacchetto>>(File.ReadAllText(path));
                ListaPacchetti = pacchetto;
            }
            else
            {
                ListaPacchetti = new List<Pacchetto>();
            }
           
        }


    }
}
