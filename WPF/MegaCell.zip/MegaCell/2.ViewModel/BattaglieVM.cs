﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MegaCell._2.ViewModel
{
    public class BattaglieVM
    {
    }
}
