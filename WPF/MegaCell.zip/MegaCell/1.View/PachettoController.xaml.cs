﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MegaCell._1.View
{
    /// <summary>
    /// Interaction logic for PachettoController.xaml
    /// </summary>
    public partial class PachettoController : UserControl
    {
        public PachettoController()
        {
            InitializeComponent();
        }

        /* ------------------------------------------- */

        /* property per Nome pacchetto  */
        public static readonly DependencyProperty NomePacchetoProperty =
            DependencyProperty.Register(
        "NomePachetto",
        typeof(string),
        typeof(PachettoController),
        default);

        public string NomePachetto
        {
            get => (string)GetValue(NomePacchetoProperty);
            set => SetValue(NomePacchetoProperty, value);
        }

        /* property per costo */

        public static readonly DependencyProperty CostoPachettoProperty =
            DependencyProperty.Register(
        "CostoPachetto",
        typeof(string),
        typeof(PachettoController),
        default);

        public string PrezzoStazione
        {
            get => (string)GetValue(CostoPachettoProperty);
            set => SetValue(CostoPachettoProperty, value);
        }

        

        /* property per colore */

        public static readonly DependencyProperty ColorePacchettoProperty =
        DependencyProperty.Register(
        "ColorePacchetto",
        typeof(SolidColorBrush),
        typeof(PachettoController),
        default);

        public SolidColorBrush ColoreStazione
        {
            get => (SolidColorBrush)GetValue(ColorePacchettoProperty);
            set => SetValue(ColorePacchettoProperty, value);
        }







    }
}
