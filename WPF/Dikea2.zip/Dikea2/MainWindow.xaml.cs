﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Dikea2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        
        public MainWindow()
        {
            //Thread.CurrentThread.CurrentUICulture =
            //    new System.Globalization.CultureInfo("es-ES");
            InitializeComponent();
     //       this.DataContext = new Anagrafica("giaveno",100);
        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            if (this.menuLingue.SelectedItem is ComboBoxItem item)
            {
                switch (item.Content.ToString())
                {
                    case "Italiano":

                        Thread.CurrentThread.CurrentUICulture =
                        new System.Globalization.CultureInfo("it-IT");
                        break;
                    case "Español":
                        Thread.CurrentThread.CurrentUICulture =
                        new System.Globalization.CultureInfo("es-ES");
                        break;
                    case "English":
                        Thread.CurrentThread.CurrentUICulture =
                        new System.Globalization.CultureInfo("en-EN");
                        break;

                    default:
                        break;
                }
                var nuovo = new MainWindow();
                nuovo.Show();
                this.Close();
                //string testo = item.Content.ToString();
                //MessageBox.Show("hai scelto " + testo);
            }
        }

        private void Box_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}