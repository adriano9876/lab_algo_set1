﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dikea2
{
    public class Carrello : INotifyPropertyChanged
    {
        public Carrello() { }
        private string _nomeOggetto;
        private string _prezzo;        
        private string _quantita;        
        public string NomeOggetto
        {
            get { return _nomeOggetto; }
            set
            {
                if (_nomeOggetto != value)
                {
                    _nomeOggetto = value;
                }
            }
        }

        public string Prezzorname
        {
            get { return _prezzo; }
            set
            {
                if (_prezzo != value)
                {
                    _prezzo = value;
                }
            }
        }

        public string Quantita
        {
            get { return _quantita; }
            set
            {
                if (_quantita != value)
                {
                    _quantita = value;
                }
            }
        }

   

        public event PropertyChangedEventHandler? PropertyChanged;

        public void OnPropertyChanged(string propName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propName));
        }

    }//
}
