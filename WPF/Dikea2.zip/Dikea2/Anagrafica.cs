﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dikea2
{
    public class Anagrafica
    {
        public Anagrafica(string nome, int lunghezza)
        {
            Nome = nome;
            Lunghezza = lunghezza;
        }
        public Anagrafica() { }

        public string Nome {  get; set; }
        public int Lunghezza { get; set; }
    }

}
