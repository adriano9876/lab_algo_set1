﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Dikea2
{
    public class User : INotifyPropertyChanged
    {
        private string _nameUser;
        private string _surname;
        public string NameUser
        {
            get { return _nameUser; }
            set 
            {
                if (_nameUser != value)
                {
                    _nameUser = value;
                    OnPropertyChanged(nameof(NameUser));
                }
            }
        }

        public string Surname
        {
            get { return _surname; }
            set
            {
                if (_surname != value)
                {
                    _surname = value;
                    OnPropertyChanged(nameof(Surname));
                }
            }
        }
        public User() { } 
   
        public event PropertyChangedEventHandler? PropertyChanged;

        public void OnPropertyChanged(string propName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propName));
        }

    }//

}
