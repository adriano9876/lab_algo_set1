﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Monopoli.Casella
{
    /// <summary>
    /// Interaction logic for CasellaRettangolo.xaml
    /// </summary>
    public partial class CasellaRettangolo : UserControl
    {
        public CasellaRettangolo()
        {
            InitializeComponent();
        }

        /* property per nome */
        public static readonly DependencyProperty NomeStazioneProperty =
            DependencyProperty.Register(
        "NomeStazione",
        typeof(string),
        typeof(CasellaRettangolo),
        default);

        public string NomeStazione
        {
            get => (string)GetValue(NomeStazioneProperty);
            set => SetValue(NomeStazioneProperty, value);
        }

        /* property per prezzo */

        public static readonly DependencyProperty PrezzoStazioneProperty =
            DependencyProperty.Register(
        "PrezzoStazione",
        typeof(string),
        typeof(CasellaRettangolo),
        default);

        public string PrezzoStazione
        {
            get => (string)GetValue(PrezzoStazioneProperty);
            set => SetValue(PrezzoStazioneProperty, value);
        }

        /* property per rotazione */

        public static readonly DependencyProperty RotazioneStazioneProperty =
        DependencyProperty.Register(
        "RotazioneStazione",
        typeof(RotateTransform),
        typeof(CasellaRettangolo),
        default);

        public RotateTransform RotazioneStazione
        {
            get => (RotateTransform)GetValue(RotazioneStazioneProperty);
            set => SetValue(RotazioneStazioneProperty, value);
        }

        /* property per colore */

        public static readonly DependencyProperty ColoreStazioneProperty =
        DependencyProperty.Register(
        "ColoreStazione",
        typeof(SolidColorBrush),
        typeof(CasellaRettangolo),
        default);

        public SolidColorBrush ColoreStazione
        {
            get => (SolidColorBrush)GetValue(ColoreStazioneProperty);
            set => SetValue(ColoreStazioneProperty, value);
        }


    }
}
