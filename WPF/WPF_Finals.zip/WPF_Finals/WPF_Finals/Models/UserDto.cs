﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPF_Finals.Models
{
    public class UserDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }
        public DateTime BirthDate { get; set; }
        public string Email { get; set; }
        public ServiceEnum SelectedService { get; set; }
        public PaymentStatusEnum PaymentStatus { get; set; }
        public int HappinessLevel { get; set; }
    }
}
