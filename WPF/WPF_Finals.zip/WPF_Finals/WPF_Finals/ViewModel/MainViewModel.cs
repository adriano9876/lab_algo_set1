﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Documents;
using WPF_Finals.Models;
using WPF_Finals.View.Windows;
using WPF_Finals.ViewModel.Base;
using WPF_Finals.ViewModel.Command;

namespace WPF_Finals.ViewModel
{
    public class MainViewModel : ViewModelBase
    {
        private ObservableCollection<UserDto> _users;        
        private UserDto _userSelectedToDelete;
        private UserDto _userSelectedToModify;
        private UserDto _userSelected;
        private UserDto _userToDb;
        private RegisterNewUserWindow _registerNewWindow;
        private ModifyUserWindow _modifyUserWindow;
        private string _search;
 
        public string Search
        {
            get => _search;
            set
            {
                _search = value;
                OnPropertyChanged(nameof(Search));
            }
        }

        public RelayCommand RegisterNewUserButtonCommand { get; }
        public RelayCommand DeleteUserButtonCommand { get; }
        public RelayCommand ModifyUserButtonCommand { get; }
        public RelayCommand OpenWindowAddNewUserCommand { get; }
        public RelayCommand OpenWindowModifyUserCommand { get; }
        public RelayCommand SearchUsersCommand { get; }
        public List<ServiceEnum> ListaServiceEnum { get; }
            = new List<ServiceEnum>() 
            {
                ServiceEnum.NetFlox,
                ServiceEnum.Pottify,
                ServiceEnum.PrimoAmazzone,
                ServiceEnum.XBaxGamePass,
            };
        public List<PaymentStatusEnum> ListaPaymentStatusEnum { get; }
            = new List<PaymentStatusEnum>()
            {
                        PaymentStatusEnum.NotPayed,
                        PaymentStatusEnum.Processing,
                        PaymentStatusEnum.Payed
            };

        private ServiceEnum _selectedServiceEnum;
        public ServiceEnum SelectedServiceEnum
        {
            get { return _selectedServiceEnum; }
            set 
            { 
                _selectedServiceEnum = value;
                OnPropertyChanged(nameof(SelectedServiceEnum));
            }
        }
        public MainViewModel() 
        { 
            _users = new ObservableCollection<UserDto>();
            var list = UserHandler.GetAllUsers();
            list.ForEach(x => Users.Add(x));
            DeleteUserButtonCommand = new RelayCommand(x => DeleteUserSelectedFunc());
            OpenWindowAddNewUserCommand = new RelayCommand(x => OpenWindowAddNewRegistratioUserFunc());
            RegisterNewUserButtonCommand = new RelayCommand(x=> RegisterNewUserButtonCommandFunc());
            OpenWindowModifyUserCommand = new RelayCommand( x=> OpenWindowModifyUserCommandFunc());
            ModifyUserButtonCommand = new RelayCommand( x=> ModifyUserButtonCommandFunc() );
            SearchUsersCommand = new RelayCommand( x=> SearchBarButtonCommandfunc());
        }

        /* Dati per creare un nuovo user dto */
        public ObservableCollection<UserDto> Users
        {
            get => _users;
            set
            {
                _users = value;
                OnPropertyChanged(nameof(Users));

            }
        }

        private int _id;
        public int Id
        {
            get => _id;
            set
            {
                _id = value;
                OnPropertyChanged(nameof(Id));
            }
        }

        private string _name;
        public string Name
        {
            get => _name;
            set
            {
                _name = value;
                OnPropertyChanged(nameof(Name));
            }
        }

        private string _surname;
        public string Surname
        {
            get => _surname;
            set
            {
                _surname = value;
                OnPropertyChanged(nameof(Surname));
            }
        }

        private DateTime _birthDate;
        public DateTime  BirthDate
        {
            get => _birthDate;
            set
            {
                _birthDate = value;
                OnPropertyChanged(nameof(BirthDate));
            }
        }

        private string _email;
        public string Email
        {
            get => _email;
            set
            {
                _email = value;
                OnPropertyChanged(nameof(Email));
            }
        }

        private ServiceEnum _selectedService;
        public ServiceEnum SelectedService
        {
            get => _selectedService;
            set
            {
                _selectedService = value;
                OnPropertyChanged(nameof(SelectedService));
            }
        }

        private PaymentStatusEnum _selectedStatusPayment;
        public PaymentStatusEnum SelectedStatusPayment
        {
            get => _selectedStatusPayment;
            set
            {
                _selectedStatusPayment = value;
                OnPropertyChanged(nameof(SelectedStatusPayment));
            }
        }

        private int _happiness;
        public int Happiness
        {
            get => _happiness;
            set
            {
                _happiness = value;
                OnPropertyChanged(nameof(Happiness));
            }
        }
        public UserDto UserSelected
        {
            get => _userSelected;
            set
            {
                _userSelected = value;
                OnPropertyChanged(nameof(UserSelected));
            }
        }
        public void DeleteUserSelectedFunc()
        {
            Users.Remove(UserSelected);
        }
        public void OpenWindowAddNewRegistratioUserFunc()
        {
            _registerNewWindow = new RegisterNewUserWindow();
            _registerNewWindow.DataContext = this;
            _registerNewWindow.Show();
        }

        public void OpenWindowModifyUserCommandFunc()
        {
            _modifyUserWindow = new ModifyUserWindow();
            _modifyUserWindow.DataContext = this;
            _modifyUserWindow.Show();
        }

        public void RegisterNewUserButtonCommandFunc()
        {
            UserDto userDto = new UserDto();
            userDto.Id = _users.Count + 1;
            userDto.Name =_name; 
            userDto.Surname =_surname;
            userDto.BirthDate = _birthDate;
            userDto.Email = _email;
            userDto.PaymentStatus = _selectedStatusPayment;
            userDto.SelectedService = _selectedService;
            userDto.HappinessLevel = _happiness;         
            Users.Add(userDto);
            _registerNewWindow.Close();      
        }
        public void ModifyUserButtonCommandFunc()
        {            
            
            UserDto newUserToAdd = new UserDto();
            newUserToAdd.Id = UserSelected.Id;
            newUserToAdd.Name = _name;
            newUserToAdd.Surname = _surname;
            newUserToAdd.BirthDate = _birthDate;
            newUserToAdd.Email = _email;
            newUserToAdd.PaymentStatus = _selectedStatusPayment;
            newUserToAdd.SelectedService = _selectedService;
            newUserToAdd.HappinessLevel = _happiness;
            Users.Remove(UserSelected);
            Users.Add(newUserToAdd);
            _modifyUserWindow.Close();
        }

        public void SearchBarButtonCommandfunc()
        {  

            var lower = Search.ToLowerInvariant();
           
            var lista =  _users.Where(p =>
                (!string.IsNullOrEmpty(p.Name ) && p.Name.ToLowerInvariant().Contains(lower)) ||
                (!string.IsNullOrEmpty(p.Surname) && p.Surname.ToLowerInvariant().Contains(lower))
            ).ToList();
            Users.Clear();
            lista.ForEach(x => Users.Add(x));
        }



    }

}
