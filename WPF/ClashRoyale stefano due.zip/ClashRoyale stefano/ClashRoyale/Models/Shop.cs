﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace ClashRoyale.Models
{
    public class Shop
    {
        public List<Pacchetto> Pacchetti { get; set; } = new List<Pacchetto>();

        public void InizializeShop()
        {
            if (File.Exists("Models/Shop.json"))
            {

                var datiCaricati = JsonSerializer.Deserialize<List<Pacchetto>>(File.ReadAllText("Models/Shop.json"));

                if (datiCaricati != null)
                {
                    this.Pacchetti = datiCaricati;
                }
            }
            else
            {
                var carta = new Carte { Nome = "Cavaliere", Rarità = "Comune" };
                var pacchetto = new Pacchetto
                {
                    Nome = "Baule d'Oro",
                    Costo = 500,
                    Carte = new List<Carte> { carta }
                };
                this.Pacchetti.Add(pacchetto);
            }

        }

        public class Pacchetto
        {
            public string Nome { get; set; } = string.Empty;
            public int Costo { get; set; }
            public List<Carte> Carte { get; set; } = new List<Carte>();
        }

        public class Carte
        {
            public string Nome { get; set; } = string.Empty;
            public string Rarità { get; set; } = string.Empty;
        }

    }
}
