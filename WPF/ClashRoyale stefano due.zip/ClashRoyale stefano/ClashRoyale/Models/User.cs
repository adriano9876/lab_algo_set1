﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Threading.Tasks;

namespace ClashRoyale.Models
{
    public class User
    {
        public string Username { get; set; }
        public int Livello { get; set; }
        public int Gemme { get; set; }
        public int Monete { get; set; }

        public void InizializeUser()
        {
            if (File.Exists("Models/User.json"))
            {
                var user = JsonSerializer.Deserialize<User>(File.ReadAllText("Models/User.json"));
                Username = user.Username;
                Livello = user.Livello;
                Gemme = user.Gemme;
                Monete = user.Monete;
            }
            else
            {
                Username = "stebli";
                Livello = 0;
                Gemme = 0;
                Monete = 0;
                
            }

        }
    }
}
