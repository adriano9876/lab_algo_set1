﻿using ClashRoyale.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using static ClashRoyale.Models.Shop;

namespace ClashRoyale
{
    public class ShopWindowViewModel : INotifyPropertyChanged
    {
        public ShopWindowViewModel()
        {
            this.Shop.InizializeShop();

            if (this.Shop.Pacchetti != null)
            {
                foreach (var pacchetto in this.Shop.Pacchetti)
                {
                    PacchettiCollection.Add(pacchetto);
                }
            }

            if (PacchettiCollection.Count > 0)
            {
                PacchettoSelezionato = PacchettiCollection.First();
            }
        }

        //public ObservableCollection<Carte> CarteCollections { get; set; } = new ObservableCollection<Carte>();
        public Shop Shop { get; set; } = new Shop();
        public ObservableCollection<Pacchetto> PacchettiCollection { get; set; } = new ObservableCollection<Pacchetto>();

        private Pacchetto _pacchettoSelezionato;
        public Pacchetto PacchettoSelezionato
        {
            get => _pacchettoSelezionato;
            set
            {
                _pacchettoSelezionato = value;
                OnPropertyChanged();
                
            }
        }        

        public event PropertyChangedEventHandler? PropertyChanged;
        protected virtual void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

}
