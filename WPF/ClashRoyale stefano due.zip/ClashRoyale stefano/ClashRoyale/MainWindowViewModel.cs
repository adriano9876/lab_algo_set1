﻿using ClashRoyale.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace ClashRoyale
{
    public class MainWindowViewModel : INotifyPropertyChanged
    {
        public ShopWindowViewModel ShopWindowViewModel { get; set; } = new ShopWindowViewModel();
        public User User { get; set; } = new User();
        public MainWindowViewModel()
        {
            User.InizializeUser();
        }

        public int Gemme
        {
            get => User.Gemme;
            set
            {
                User.Gemme = value;
                OnPropertyChanged();
            }
        }
        public int Monete
        {
            get => User.Monete;
            set
            {
                User.Monete = value;
                OnPropertyChanged();
            }
        }

        public string Username
        {
            get => User.Username;
            set
            {
                User.Username = value;
                OnPropertyChanged();
            }
        }

        public int Livello
        {
            get => User.Livello;
            set { 
                    User.Livello = value;
                    OnPropertyChanged();
                }
        }


        public event PropertyChangedEventHandler? PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }


    }
}
