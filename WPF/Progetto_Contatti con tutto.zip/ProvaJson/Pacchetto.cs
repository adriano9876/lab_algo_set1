﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProvaJson
{
    public class Pacchetto
    {
        public string Nome { get; set; }
        public int Costo { get; set; }
        public List<Carte> Carte { get; set; } = new List<Carte>();


    }
}
