﻿// See https://aka.ms/new-console-template for more information
using ProvaJson;

Console.WriteLine("Hello, World!");


Shop _shop = new Shop();
_shop.InitPachetto();
var ris = _shop.ListaPacchetti;
int a = 0;
     