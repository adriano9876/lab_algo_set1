﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace ProvaJson
{
    public class Shop
    {
        public List<Pacchetto> ListaPacchetti { get; set; } = new List<Pacchetto>();
        public int NumeroPacchetti { set; get; }

        public void InitPachetto()
        {
            //string path = "DatiJson/Pachetto.json";
            string path = "C:\\Users\\vale-01\\Desktop\\Esame WPF test finale\\ProvaJson\\DatiJson\\Pacchetto.json";
            if (File.Exists(path))
            {
                var pacchetto = JsonSerializer.Deserialize<List<Pacchetto>>(File.ReadAllText(path));
                ListaPacchetti = pacchetto;
            }
            else
            {
                var carta = new Carte { Nome = "Cavaliere", Rarità = "Comune" };
                var pacchetto = new Pacchetto
                {
                    Nome = "Baule d'Oro",
                    Costo = 500,
                    Carte = new List<Carte>()
                };
                this.ListaPacchetti.Add(pacchetto);
            }

        }
    }
}