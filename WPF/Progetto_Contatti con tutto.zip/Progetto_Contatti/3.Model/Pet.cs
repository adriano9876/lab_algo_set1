﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Progetto_Contatti._3.Model
{
    public class Pet
    {
        public string PetName { get; set; }
        public string PetType { get; set; }

        //public override string? ToString()
        //{
        //    return $"{PetName} - {PetType} ";
        //}

        //public int CompareTo(Pet? other)
        //{
        //    if (other == null) return 1;

        //    return string.Compare(
        //        this.PetName,
        //        other.PetName,
        //        StringComparison.OrdinalIgnoreCase
        //    );
        //}
    }
}
