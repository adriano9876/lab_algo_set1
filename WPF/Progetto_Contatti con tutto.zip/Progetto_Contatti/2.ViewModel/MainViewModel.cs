﻿using Progetto_Contatti._3.Model;
using Progetto_Contatti.Command;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;

namespace Progetto_Contatti._2.ViewModel
{
    public class MainViewModel : ViewModelBase
    {
        public ObservableCollection<Persona> Persone { get; set; }
          
        private  CollectionViewSource _viewSource;
        public RelayCommand SortByName {  get; set; }
        public RelayCommand SortBySurname {  get; set; }
        public RelayCommand SortByAge {  get; set; }
        public ICollectionView PersoneView 
        {
            get => _viewSource.View;
        }

        private string _searchText;
        public string SearchText
        {
            get => _searchText;
            set
            {
                _searchText = value;
                OnPropertyChanged(nameof(SearchText));
                Search();
            }
        }


        public MainViewModel()
        {
            SortByName = new RelayCommand( x => SortByNameFunc()  );
            SortBySurname = new RelayCommand( x => SortBySurnameFunc()  );
            SortByAge = new RelayCommand( x => SortByAgeFunc()  );
            List<DrivingLicence> drivingLicences1 = new();
            drivingLicences1.Add(DrivingLicence.Bike);
            drivingLicences1.Add(DrivingLicence.Car);
            drivingLicences1.Add(DrivingLicence.Bus);

            Persone = new ObservableCollection<Persona>
            {

                new Persona {Nome="Stefano", Cognome="Bilinio", Age=55,
                    CanSwim = true,
                    PetPerson = new Pet{PetName="birba",PetType="Dog" },
                    Telefono="3333333", Verificato= false ,
                    DrivingLicence = drivingLicences1                    
                },
                  
                new Persona {Nome="Andreina", Cognome="Tritto", Age=15,
                    CanSwim = true,
                    PetPerson = new Pet{PetName="fishi",PetType="Fish" },
                    Telefono="3333333", Verificato= true ,DrivingLicence = drivingLicences1    },
                new Persona {Nome="Fede", Cognome="Fedez", Age=26,
                    CanSwim = false,
                    PetPerson = new Pet{PetName="wii",PetType="Cat" },
                    Telefono="3333333", Verificato= true ,DrivingLicence = drivingLicences1    }

            };
    
            /*CollectionViewSource*/
            _viewSource = new CollectionViewSource();
            _viewSource.Source = Persone;
            _viewSource.View.Refresh();


        }

        public void SortByNameFunc()
        {
            PersoneView.SortDescriptions.Clear();

            PersoneView.SortDescriptions.Add(new SortDescription("Nome", ListSortDirection.Ascending));

            PersoneView.Refresh();
        }

        public void SortBySurnameFunc()
        {
            PersoneView.SortDescriptions.Clear();

            PersoneView.SortDescriptions.Add(new SortDescription("Cognome", ListSortDirection.Ascending));

            PersoneView.Refresh();
        }

        public void SortByAgeFunc()
        {
            PersoneView.SortDescriptions.Clear();

            PersoneView.SortDescriptions.Add(new SortDescription("Age", ListSortDirection.Ascending));

            PersoneView.Refresh();
        }

        public void Search()
        {
            if (string.IsNullOrWhiteSpace(SearchText))
            {
                PersoneView.Filter = null;
            }
            else
            {
                string searchLower = SearchText.ToLower().Trim();
                PersoneView.Filter = obj =>
                {
                    if (obj is Persona person)
                    {
                        return person.Nome?.ToLower().Contains(searchLower) == true ||
                               person.Cognome?.ToLower().Contains(searchLower) == true;
                    }
                    return false;
                };
            }
            PersoneView.Refresh();
        }







    }


}






















//public PersonaViewModel PersonaSelezionata
//{
//    get { return _personaSelezionata; }
//    set
//    {
//        if (_personaSelezionata != value)
//        {
//            _personaSelezionata = value;
//            OnPropertyChanged(nameof(_personaSelezionata));
//        }
//    }
//}
// private PersonaViewModel _personaSelezionata { get; set; }
