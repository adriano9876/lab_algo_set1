﻿using Progetto_Contatti._3.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Progetto_Contatti._2.ViewModel
{
    public class PersonaViewModel : ViewModelBase
    {
        private readonly Persona _personaModel;
        public PersonaViewModel(Persona personaModel) {
            _personaModel = personaModel;
        }


        /* Properties */
        public string Nome
        {
            get { return _personaModel.Nome; }
            set
            {
                if (_personaModel.Nome != value)
                {
                    _personaModel.Nome = value;
                    OnPropertyChanged(nameof(_personaModel.Nome));
                }
            }
        }

        public string Cognome
        {
            get { return _personaModel.Cognome; }
            set
            {
                if (_personaModel.Cognome != value)
                {
                    _personaModel.Cognome = value;
                    OnPropertyChanged(nameof(_personaModel.Cognome));
                }
            }
        }

        public int Age
        {
            get { return _personaModel.Age; }
            set
            {
                if (_personaModel.Age != value)
                {
                    _personaModel.Age = value;
                    OnPropertyChanged(nameof(_personaModel.Age));
                }
            }
        }

        public bool CanSwim
        {
            get { return _personaModel.CanSwim; }
            set
            {
                if (_personaModel.CanSwim != value)
                {
                    _personaModel.CanSwim = value;
                    OnPropertyChanged(nameof(_personaModel.CanSwim));
                }
            }
        }

        public List<DrivingLicence> DrivingLicence
        {
            get { return _personaModel.DrivingLicence; }
            set
            {
                if (_personaModel.DrivingLicence != value)
                {
                    _personaModel.DrivingLicence = value;
                    OnPropertyChanged(nameof(_personaModel.DrivingLicence));
                }
            }
        }

        public Pet Pet
        {
            get { return _personaModel.PetPerson; }
            set
            {
                if (_personaModel.PetPerson != value)
                {
                    _personaModel.PetPerson = value;
                    OnPropertyChanged(nameof(_personaModel.PetPerson));
                }
            }
        }

        public string PetNameType
        {
            get { return _personaModel.PetPerson.PetName; }
            set
            {
                if (_personaModel.PetPerson.PetName != value)
                {
                    _personaModel.PetPerson.PetName = value;
                    OnPropertyChanged(nameof(_personaModel.PetPerson.PetName));
                }
            }
        }



        public string Telefono
        {
            get { return _personaModel.Telefono; }
            set
            {
                if (_personaModel.Telefono != value)
                {
                    _personaModel.Telefono = value;
                    OnPropertyChanged(nameof(_personaModel.Telefono));
                }
            }
        }

        public bool Verificato
        {
            get { return _personaModel.Verificato; }
            set
            {
                if (_personaModel.Verificato != value)
                {
                    _personaModel.Verificato = value;
                    OnPropertyChanged(nameof(_personaModel.Verificato));
                }
            }
        }



    }

}
