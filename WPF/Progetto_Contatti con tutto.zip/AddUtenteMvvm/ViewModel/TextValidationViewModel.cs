﻿using AddUtenteMvvm.ViewModel.Base;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AddUtenteMvvm.ViewModel
{
    public class TextValidationViewModel : ViewModelBase, IDataErrorInfo
    {

        private string _text;

        public string Text
        {
            get => _text;
            set
            {
                _text = value;
                OnPropertyChanged(nameof(Text));
            }

        }

        public string this[string columnName] //indexer
        {
            get
            {
                if (columnName == nameof(Text))
                {
                    if (string.IsNullOrWhiteSpace(Text) || Text.Length <= 3)
                        return "Devono essserci piu di 3 caratteri bello mio!! ";
                }
                return null;
            }
        }

        public string Error => null; //poco usato, cercare esempi quando si usa !!
    }
}
