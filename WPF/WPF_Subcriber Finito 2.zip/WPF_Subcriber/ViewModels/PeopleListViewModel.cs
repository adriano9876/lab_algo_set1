using DatGrid_MVVM.Models;
using DatGrid_MVVM.Repository;
using System.Collections.ObjectModel;
using WPF_Subcriber.Interfaces;

namespace WPF_Subcriber.ViewModels
{
    public class PeopleListViewModel : BaseViewModel, ISearchResultObserver
    {
        
        private ObservableCollection<Person> _people = new();
        

        public ObservableCollection<Person> People
        {
            get => _people;
            set
            {
                if (_people != value)
                {
                    _people = value;
                    OnPropertyChanged(nameof(People));
                }
            }
        }
        

        
        public PeopleListViewModel()
        {
        }

        

        
        public void Update(IEnumerable<Person> searchResults)
        {
            if (searchResults == null || !searchResults.Any())
            {
                return;
            }

            _people.Clear();
            foreach (var person in searchResults)
            {
                _people.Add(person);
            }
        }

        
    }
}