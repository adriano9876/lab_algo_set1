﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WPF_Subcriber.Events;

namespace WPF_Subcriber.ViewModels.MyViewModels
{
    public class WriteMessageTextViewModel : BaseViewModel
    {
        private readonly IEventAggregator _eventAggregator;
        private string _messageText;
        public RelayCommand SendCommand;

        public WriteMessageTextViewModel()
        {
            _eventAggregator = EventAggregator.Current;
            SendCommand = new RelayCommand(x=>SendMessageText(MessageText));


        }

        public string MessageText
        {
            get => _messageText;
            set
            {

                _messageText = value;
                OnPropertyChanged(nameof(MessageText));
            }
        }

 

        private void SendMessageText(string message)
        {
            _eventAggregator.GetEvent<MessageTextEvent>().Publish(message);
        }

    }

}
