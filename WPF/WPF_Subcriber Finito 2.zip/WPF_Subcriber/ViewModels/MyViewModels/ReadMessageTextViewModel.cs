﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WPF_Subcriber.Events;

namespace WPF_Subcriber.ViewModels.MyViewModels
{
    public class ReadMessageTextViewModel : BaseViewModel
    {
        private readonly IEventAggregator eventAggregator;
        private string _messageText;

        public string MessageText
        {
            get => _messageText;
            set
            {
                _messageText = value;
                OnPropertyChanged(nameof(MessageText));
            }
        }

        public ReadMessageTextViewModel()
        {
            eventAggregator = new EventAggregator();
            eventAggregator.GetEvent<MessageTextEvent>().Subscribe(HandleEvent);
        }

        private void HandleEvent(string messageText) 
        {
            MessageText = messageText;
        }

    }

}
