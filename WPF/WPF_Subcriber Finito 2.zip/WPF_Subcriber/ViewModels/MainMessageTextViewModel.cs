﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WPF_Subcriber.ViewModels.MyViewModels;

namespace WPF_Subcriber.ViewModels
{
    public class MainMessageTextViewModel : BaseViewModel
    {
        private ReadMessageTextViewModel _readMessageTextViewModel;  
        private WriteMessageTextViewModel _writeMessageTextViewModel;

        public MainMessageTextViewModel( )
        {
            _readMessageTextViewModel = new ReadMessageTextViewModel();
            _writeMessageTextViewModel = new WriteMessageTextViewModel();
        }

        public ReadMessageTextViewModel ReadMessageTextViewModel
        {
            get => _readMessageTextViewModel;
            set
            {
                _readMessageTextViewModel = value;
                OnPropertyChanged(nameof(ReadMessageTextViewModel));
            }
        }

        public WriteMessageTextViewModel WriteMessageTextViewModel
        {
            get => _writeMessageTextViewModel;
            set
            {
                _writeMessageTextViewModel = value;
                OnPropertyChanged(nameof(WriteMessageTextViewModel));
            }
        }


    }

}
