using System.ComponentModel;

namespace WPF_Subcriber.ViewModels
{
    public class MainViewModel : BaseViewModel
    {
        private string _title = "Subscriber Application";
        private PersonSearchViewModel _personSearchViewModel;
        private PeopleListViewModel _peopleListViewModel;


        public string Title
            {
            get => _title;
            set
            {
                if (_title != value)
                {
                    _title = value;
                    OnPropertyChanged(nameof(Title));
                }
            }
        }

        public PersonSearchViewModel PersonSearchViewModel
        {
            get => _personSearchViewModel;
            set
            {
                _personSearchViewModel = value;
                OnPropertyChanged(nameof(PersonSearchViewModel));
            }
        }

        public PeopleListViewModel PeopleListViewModel
        { 
            get => _peopleListViewModel; 
            set 
            { 
                _peopleListViewModel = value; 
                OnPropertyChanged(nameof(PeopleListViewModel)); 
            } 
        }

        public MainViewModel()
        {
            _personSearchViewModel = new PersonSearchViewModel();
            _peopleListViewModel = new PeopleListViewModel();
            _personSearchViewModel.Attach(_peopleListViewModel);
        }

    }
}
