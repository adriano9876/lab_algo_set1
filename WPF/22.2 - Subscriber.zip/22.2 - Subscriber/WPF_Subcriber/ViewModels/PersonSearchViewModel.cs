using DatGrid_MVVM.Models;
using DatGrid_MVVM.Repository;
using System.DirectoryServices;
using System.Windows.Input;
using WPF_Subcriber.Interfaces;

namespace WPF_Subcriber.ViewModels
{
    public class PersonSearchViewModel : BaseViewModel
    {
        private string _searchName;
        private List<ISearchResultObserver> _observers;
        private readonly IPersonRepository _personRepository;

        public string SearchName
        {
            get => _searchName;
            set
            {
                if (_searchName != value)
                {
                    _searchName = value;
                    OnPropertyChanged(nameof(SearchName));
                }
            }
        }


        public ICommand SearchCommand { get; }

        public PersonSearchViewModel()
        {
            _observers = new();
            _personRepository = new PersonRepository();
            SearchCommand = new RelayCommand(_ => Search(), _ => !string.IsNullOrWhiteSpace(SearchName));
        }

        public void Attach(ISearchResultObserver observer)
        {
            if (!_observers.Contains(observer))
            {
                _observers.Add(observer);
            }
        }

        public void Detach(ISearchResultObserver observer)
        {
            if (_observers.Contains(observer))
            {
                _observers.Remove(observer);
            }
        }

        private void Search()
        {
            // Notify listeners that a search has been requested
            var name = SearchName?.Trim();
            var persons = _personRepository.GetByName(name);

            foreach (var observer in _observers)
            {
                observer.Update(persons);
            }
        }
    }
}