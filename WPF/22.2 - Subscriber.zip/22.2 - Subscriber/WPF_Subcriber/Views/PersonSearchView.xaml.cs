﻿using System.Windows.Controls;

namespace WPF_Subcriber.Views
{
    /// <summary>
    /// Interaction logic for PersonSearchView.xaml
    /// </summary>
    public partial class PersonSearchView : UserControl
    {
        public PersonSearchView()
        {
            InitializeComponent();
        }
    }
}
