﻿using DatGrid_MVVM.Models;

namespace WPF_Subcriber.Interfaces
{
    public interface ISearchResultObserver
    {
        void Update(IEnumerable<Person> searchResult);
    }
}
