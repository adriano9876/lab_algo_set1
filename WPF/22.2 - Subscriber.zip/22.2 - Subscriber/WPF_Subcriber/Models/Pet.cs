namespace DatGrid_MVVM.Models
{
    public class Pet
    {
        public Pet(string name, string type)
        {
            Name = name;
            Type = type;
        }

        public string Name { get; set; }
        public string Type { get; set; }

        public override string ToString()
        {
            return $"{Name} ({Type})";
        }   
    }
}