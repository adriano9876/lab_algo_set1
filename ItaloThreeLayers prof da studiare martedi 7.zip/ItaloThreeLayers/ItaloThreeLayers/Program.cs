﻿using ItaloThreeLayers.Business;
using ItaloThreeLayers.DataAccess;
using ItaloThreeLayers.Presentation;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Presentation;

namespace ItaloThreeLayers
{
    public static class Program
    {
        public static void Main()
        {
            var applicationBuilder = Host.CreateApplicationBuilder();
            applicationBuilder.Services.AddSingleton<IBookingRepository, BookingRepository>();
            applicationBuilder.Services.AddSingleton<IBookingConverter, BookingConverter>();
            applicationBuilder.Services.AddSingleton<IBookingService, BookingService>();
            applicationBuilder.Services.AddSingleton<IConsoleView, ConsoleView>();

            using var host = applicationBuilder.Build();
            using IServiceScope serviceScope = host.Services.CreateScope();

            var consoleView = serviceScope.ServiceProvider.GetService<IConsoleView>();
            if (consoleView != null)
            {
                consoleView.ShowMenu();
            }
        }
    }
}