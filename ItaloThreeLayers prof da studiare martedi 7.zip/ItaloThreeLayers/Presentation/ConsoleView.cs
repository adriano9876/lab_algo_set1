﻿using ItaloThreeLayers.Business;
using ItaloThreeLayers.Presentation;

namespace Presentation
{
    public class ConsoleView : IConsoleView
    {
        private readonly IBookingService bookingService;

        public ConsoleView(IBookingService bookingService)
        {
            if (bookingService == null)
            {
                throw new ArgumentNullException(nameof(bookingService), "No service found");
            }

            this.bookingService = bookingService;
        }

        public void ShowMenu()
        {
            var exit = false;

            do
            {
                Console.WriteLine("=================== Menu ===================");
                Console.WriteLine("0) Exit");
                Console.WriteLine("1) Create booking");

                var chosenFunctionality = Console.ReadLine();
                if (chosenFunctionality == "0")
                {
                    exit = true;
                    break;
                }
                else if (chosenFunctionality != "1")
                {
                    Console.WriteLine("Invalid choice");
                    break;
                }

                Console.Write("Insert departure station: ");
                var departure = Console.ReadLine();

                Console.Write("Insert arrival station: ");
                var arrival = Console.ReadLine();

                Console.Write("Insert passenger name: ");
                var name = Console.ReadLine();

                Console.Write("Insert passenger surname: ");
                var surname = Console.ReadLine();

                var command = new BookingCommand
                {
                    DepartureStation = departure,
                    ArrivalStation = arrival,
                    Name = name,
                    Surname = surname
                };

                var dto = this.bookingService.CreateBooking(command);

                this.ShowBookings(dto);
            } while (!exit);

            Environment.Exit(0);
        }

        private void ShowBookings(BookingDto dto)
        {
            if (dto == null)
            {
                Console.WriteLine("Error while saving the booking");
                return;
            }

            Console.WriteLine("Booking saved succesfully:");
            Console.WriteLine($"{dto.DepartureStation} - {dto.ArrivalStation} for {dto.Surname} {dto.Name}");
        }
    }
}
