﻿namespace ItaloThreeLayers.Presentation
{
    public interface IConsoleView
    {
        void ShowMenu();
    }
}
