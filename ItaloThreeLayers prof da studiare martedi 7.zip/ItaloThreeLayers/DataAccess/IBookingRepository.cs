﻿using ItaloThreeLayers.Entity;

namespace ItaloThreeLayers.DataAccess
{
    public interface IBookingRepository
    {
        Booking CreateBooking(Booking booking);
    }
}
