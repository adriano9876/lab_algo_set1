﻿using ItaloThreeLayers.DataAccess;
using ItaloThreeLayers.Entity;

namespace DataAccess
{
    public class BookingJsonRepository : IBookingRepository
    {
        public Booking CreateBooking(Booking booking)
        {
            if (booking == null)
            {
                throw new ArgumentNullException(nameof(booking), "Invalid booking");
            }

            var path = "";
        }
    }
}
