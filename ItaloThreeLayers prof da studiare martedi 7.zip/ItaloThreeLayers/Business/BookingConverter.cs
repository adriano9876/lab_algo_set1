﻿using ItaloThreeLayers.Entity;

namespace ItaloThreeLayers.Business
{
    public class BookingConverter : IBookingConverter
    {
        public BookingDto GetDto(Booking booking)
        {
            if (booking == null)
            {
                throw new ArgumentNullException(nameof(booking), "Invalid booking");
            }

            var dto = new BookingDto(
                booking.DepartureStation,
                booking.ArrivalStation,
                booking.Name,
                booking.Surname);

            return dto;
        }

        public Booking GetModel(BookingDto bookingDto)
        {
            if (bookingDto == null)
            {
                throw new ArgumentNullException(nameof(bookingDto), "Invalid booking dto");
            }

            var model = new Booking(
                bookingDto.DepartureStation,
                bookingDto.ArrivalStation,
                bookingDto.Name,
                bookingDto.Surname);

            return model;
        }
    }
}
