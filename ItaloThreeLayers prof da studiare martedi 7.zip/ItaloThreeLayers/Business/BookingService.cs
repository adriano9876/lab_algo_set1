﻿using ItaloThreeLayers.DataAccess;
using ItaloThreeLayers.Entity;

namespace ItaloThreeLayers.Business
{
    public class BookingService : IBookingService
    {
        private readonly IBookingRepository bookingRepository;
        private readonly IBookingConverter bookingConverter;

        public BookingService(
            IBookingRepository bookingRepository,
            IBookingConverter bookingConverter)
        {
            if (bookingRepository == null)
            {
                throw new ArgumentNullException(nameof(bookingRepository), "No repository found");
            }

            if (bookingConverter == null)
            {
                throw new ArgumentNullException(nameof(bookingConverter), "No converter found");
            }

            this.bookingRepository = bookingRepository;
            this.bookingConverter = bookingConverter;
        }

        public BookingDto CreateBooking(BookingCommand command)
        {
            if (command == null)
            {
                throw new ArgumentNullException(nameof(command), "Invalid command");
            }

            var inputModel = new Booking(
                command.DepartureStation,
                command.ArrivalStation,
                command.Name,
                command.Surname);

            var model = this.bookingRepository.CreateBooking(inputModel);

            var dto = this.bookingConverter.GetDto(model);

            return dto;
        }
    }
}
