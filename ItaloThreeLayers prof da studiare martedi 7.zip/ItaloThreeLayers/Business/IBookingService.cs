﻿namespace ItaloThreeLayers.Business
{
    public interface IBookingService
    {
        BookingDto CreateBooking(BookingCommand command);
    }
}
