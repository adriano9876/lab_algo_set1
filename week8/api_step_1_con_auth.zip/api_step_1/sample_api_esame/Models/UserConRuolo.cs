﻿namespace sample_api_esame.Models
{
    public class UserConRuolo
    {
        public int Id { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public string Ruolo { get; set; } // user admin

    }
}
