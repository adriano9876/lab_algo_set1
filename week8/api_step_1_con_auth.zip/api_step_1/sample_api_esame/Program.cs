
using sample_api_esame.Middleware;
using sample_api_esame.MiddlewareFolder;

namespace sample_api_esame
{
    public class Program
    {
        static async Task Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            //builder.Services.AddAuthentication(JwtBearerDefaults)

            // Add services to the container.

            builder.Services.AddControllers();
            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

            builder.Services.AddSingleton<IJwtService,JwtService>();
            builder.Services.Configure<JwtSettings>(builder.Configuration
                .GetSection("Jwt"));



            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseMiddleware<LoggingMiddleware>();
            //app.Use(async (context, next) =>
            //{
            //    Console.WriteLine("1 prima di invoke");
            //    await next.Invoke();//.Invoke();
            //    Console.WriteLine("3 dopo invoke");
            //});
            //app.Use(async (context, next) =>
            //{
            //    Console.WriteLine("2 prima di invoke");
            //    await next();//.Invoke();
            //});

            app.UseWhen(
                context => !context.Request.Path.StartsWithSegments("/api/UserAuth"),
                appBuilder =>
                {
                    appBuilder.UseMiddleware<AuthMiddleware>();
                }
            );


            app.UseHttpsRedirection();

            app.UseAuthorization();

            app.MapControllers();

            app.Run();
        }
    }
}
