﻿namespace sample_api_esame.MiddlewareFolder
{
    public interface IJwtService
    {
        public string GenerateToken(string username, string role);
    }

}
