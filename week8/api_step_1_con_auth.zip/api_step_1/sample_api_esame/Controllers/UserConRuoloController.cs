﻿using Microsoft.AspNetCore.Mvc;
using sample_api_esame.Dto;
using sample_api_esame.Models;

namespace sample_api_esame.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserConRuoloController : ControllerBase
    {
        public static  List<UserConRuolo> UsersConRuolo = new List<UserConRuolo>
        {
            new UserConRuolo ()  {Id = 1,UserName = "stefano", Password ="ciao", Ruolo = "user"   },
            new UserConRuolo ()  {Id = 2,UserName = "andreina", Password ="12345", Ruolo = "admin"  },
            new UserConRuolo ()  {Id = 3,UserName = "marcello", Password ="qwerty", Ruolo = "user"  },
            new UserConRuolo ()  {Id = 4,UserName = "giacomo", Password ="giakgiak", Ruolo = "admin"  },

        };


        /*  ------------------------------ APIS ------------------------------   */
        // GET: api/<UserController>
        [HttpGet]
        [Route("getAll")]
        public ActionResult<ICollection<UserDto>> Get()
        {
            var usersRet = UsersConRuolo.ToList();
            return Ok(usersRet); 
        }


        [HttpGet("{id}")]
        public ActionResult<UserDto> get(int id)
        {
            var userRet = UsersConRuolo.FirstOrDefault(u => u.Id == id);
            if (userRet == null)
            {
                return BadRequest();// non esiste il dato ,
            }

            return Ok(userRet);
        }

        // POST api/<UserController>
        //[HttpPost]
        //public ActionResult<bool> Post([FromBody] AuthDto auth )
        //{
        //    var ris = UsersConRuolo.FirstOrDefault( u => u.UserName == auth.UserName 
        //                                            && u.Password == auth.Password);
        //    if(ris == null)
        //    {
        //        return Ok(false);
        //    }
        //    return Ok(true);

        //}








    }
}
