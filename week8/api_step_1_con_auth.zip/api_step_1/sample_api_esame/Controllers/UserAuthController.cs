﻿using Microsoft.AspNetCore.Mvc;
using sample_api_esame.Dto;
using sample_api_esame.MiddlewareFolder;
using sample_api_esame.Models;

namespace sample_api_esame.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserAuthController : ControllerBase
    {

        //private readonly IUserService _userService;
        private readonly IJwtService _jwtService;
        public UserAuthController(IJwtService service)
        {
            _jwtService = service;
        }



        public static  List<UserConRuolo> UsersConRuolo = new List<UserConRuolo>
        {
            new UserConRuolo ()  {Id = 1,UserName = "stefano", Password ="stefano", Ruolo = "user"   },
            new UserConRuolo ()  {Id = 2,UserName = "andreina", Password ="andreina", Ruolo = "admin"  },
            new UserConRuolo ()  {Id = 3,UserName = "marcello", Password ="marcello", Ruolo = "user"  },
            new UserConRuolo ()  {Id = 4,UserName = "giacomo", Password ="giacomo", Ruolo = "admin"  },
            new UserConRuolo ()  {Id = 4,UserName = "string", Password ="string", Ruolo = "admin"  },

        };




        // POST api/<UserController>
        [HttpPost]
        public ActionResult Post([FromBody] AuthDto auth )
        {
            var ris = UsersConRuolo.FirstOrDefault( u => u.UserName == auth.UserName 
                                        && u.Password == auth.Password);
            if (ris == null)
            {
            return Unauthorized();
            }

            var token = _jwtService.GenerateToken(ris.UserName, ris.Ruolo);

            var cookieOptions = new CookieOptions()
            {
            HttpOnly = true,
            Secure = true,
            SameSite = SameSiteMode.Strict,
            Expires = DateTime.UtcNow.AddHours(1)

            };

            Response.Cookies.Append("token", token, cookieOptions);

            return Ok( new { token });

        }








    }
}
