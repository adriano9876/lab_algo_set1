﻿using MscEsame1;
using Newtonsoft.Json;

namespace Testing
{
    internal class ProgramTesting
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Sono in testing\n");

            string testoJsonSerializzato = "";
            string cartella = @"C:\Users\val1\Desktop\PreparazioneTestMsc\Testing\Datos";
            string percorsoFile = Path.Combine(cartella, "MioFile.json");

            JsonPersone listaPersoneJson = new JsonPersone();
            listaPersoneJson.ListaPersone.Add(new Persona("luca", 20));
            listaPersoneJson.ListaPersone.Add(new Persona("bea", 25));
            listaPersoneJson.ListaPersone.Add(new Persona("tomas", 31));
            listaPersoneJson.ListaPersone.Add(new Persona("zara", 27));
            /* deserializzare , serializzare */

            testoJsonSerializzato = JsonConvert.SerializeObject(listaPersoneJson.ListaPersone, Formatting.Indented);
            SalvoInFileJson(percorsoFile, testoJsonSerializzato);

            string testoJson = PrendoFileJson(percorsoFile);
            List<Persona> persone = JsonConvert.DeserializeObject<List<Persona>>(testoJson);

            /**/



        }
        public static void SalvoInFileJson(string percorsoFile,string jsonTesto)
        {
            try
            {

                //if (!Directory.Exists(percorsoFile))
                //{
                //    Directory.CreateDirectory(percorsoFile);
                   
                //}
                using (StreamWriter writer = new StreamWriter(percorsoFile, false))
                {
                    writer.WriteLine(jsonTesto);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Si è verificato un errore: {ex.Message}");
            }




        }
        public static string PrendoFileJson(string percorsoFile)
        {
            string contenuto="";
            try
            {                
                contenuto = File.ReadAllText(percorsoFile);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Si è verificato un errore: {ex.Message}");
            }
            return contenuto;
        }


    }
}
