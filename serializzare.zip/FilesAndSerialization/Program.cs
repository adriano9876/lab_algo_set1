﻿namespace FilesAndSerialization
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");


            string[] righe = File.ReadAllLines("file.txt");
            foreach (string riga in righe)
            {
                Console.WriteLine(riga);
            }

        }
    }
}
