﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeFirstDue.Models
{
    public class Comment
    {
        public int Id { get; set; }
        public string Text { get; set; }

        public User User { get; set; }

        public VideoGame VideoGame { get; set; }

    }
}
