﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeFirstDue.Models
{
    public class User
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public List<Comment> Comments { get; set; }
        public List<Like> Like { get; set; }

       // public List<VideoGame> VideoGames { get; set; }

        
    }

}
