﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeFirstDue.Models
{
    public  class Tag
    {
        public string Id { get; set; }
        public string Nometag { get; set; }

        public List<VideoGame> videoGames { get; set; }


    }
}
