﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeFirstDue.Models
{
    public  class VideoGame
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Riassunto { get; set; }
        public Publisher Publisher { get; set; } = new Publisher();
        public List<Descrizione> Descrizioni { get; set; }
        public List<Tag> Tags { get; set; }

        /* seconda parte */
        //public User User { get; set; }
        public List<Comment> Comments { get; set; }
        public List<Like> likes { get; set; }


    }


}
