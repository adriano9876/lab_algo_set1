﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeFirstDue.Models
{
    public class Publisher
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public List<VideoGame> VideoGames { get; set; }
        public List<Descrizione> Descrizioni { get; set; }

    }
}
