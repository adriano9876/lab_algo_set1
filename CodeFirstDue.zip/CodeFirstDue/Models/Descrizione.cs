﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeFirstDue.Models
{
    public  class Descrizione
    {
        public int Id { get; set; }
        public string TestoDescrizione { get; set; }
        //public VideoGame VideoGame { get; set; }
        


    }
}
