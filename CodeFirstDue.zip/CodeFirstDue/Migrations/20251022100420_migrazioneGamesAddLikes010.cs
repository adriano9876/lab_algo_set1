﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CodeFirstDue.Migrations
{
    /// <inheritdoc />
    public partial class migrazioneGamesAddLikes010 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "VideoGameId",
                table: "Like",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_Like_VideoGameId",
                table: "Like",
                column: "VideoGameId");

            migrationBuilder.AddForeignKey(
                name: "FK_Like_VideoGame_VideoGameId",
                table: "Like",
                column: "VideoGameId",
                principalTable: "VideoGame",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Like_VideoGame_VideoGameId",
                table: "Like");

            migrationBuilder.DropIndex(
                name: "IX_Like_VideoGameId",
                table: "Like");

            migrationBuilder.DropColumn(
                name: "VideoGameId",
                table: "Like");
        }
    }
}
