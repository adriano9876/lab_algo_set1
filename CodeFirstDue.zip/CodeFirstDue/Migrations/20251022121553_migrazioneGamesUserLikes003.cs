﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CodeFirstDue.Migrations
{
    /// <inheritdoc />
    public partial class migrazioneGamesUserLikes003 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_VideoGame_User_UserId",
                table: "VideoGame");

            migrationBuilder.DropIndex(
                name: "IX_VideoGame_UserId",
                table: "VideoGame");

            migrationBuilder.DropColumn(
                name: "UserId",
                table: "VideoGame");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "UserId",
                table: "VideoGame",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_VideoGame_UserId",
                table: "VideoGame",
                column: "UserId");

            migrationBuilder.AddForeignKey(
                name: "FK_VideoGame_User_UserId",
                table: "VideoGame",
                column: "UserId",
                principalTable: "User",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
