﻿using CodeFirstDue.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeFirstDue
{
    public class AppGames
    {
        private readonly GamesContext _context;

        public AppGames(GamesContext gamesDbContext)
        {
            _context = gamesDbContext;
        }

        public void Run()
        {
            

        }
    }
}
