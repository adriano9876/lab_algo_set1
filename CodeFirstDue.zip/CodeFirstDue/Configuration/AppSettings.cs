﻿using CodeFirstExample.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeFirstDue.Configuration
{
    public  class AppSettings
    {

        public ConnectionStrings ConnectionStrings { get; set; }
    }
}
