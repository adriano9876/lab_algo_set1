﻿using CodeFirstDue.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeFirstDue.Data
{
    public class GamesContext: DbContext
    {
        public GamesContext(DbContextOptions<GamesContext> options)
        : base(options)
        {
        }

        public DbSet<Comment> Comment { get; set; }
        public DbSet<User> User { get; set; }
        public DbSet<VideoGame> VideoGame { get; set; }
        public DbSet<Descrizione> Descrizione { get; set; }
        public DbSet<Publisher> Publisher { get; set; }
        public DbSet<Tag> Tag { get; set; }
        public DbSet<Like> Like { get; set; }








    }
}
