﻿using CodeFirstDue;
using CodeFirstDue.Configuration;
using CodeFirstDue.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;



var host = Host.CreateDefaultBuilder(args).ConfigureAppConfiguration((context, config) =>
   {
       config.AddJsonFile("appsettingsDue.json", optional: false, reloadOnChange: true); 
   })
    .ConfigureServices((context,services) => {
        var config = context.Configuration;
        services.Configure<AppSettings>(context.Configuration.GetSection("AppSettings"));
        var connectionString = config.GetSection("AppSettings:ConnectionStrings:DefaultConnection").Value;
        services.AddDbContext<GamesContext>(options => options.UseSqlServer(connectionString));
        services.AddTransient<AppGames>();
    }).Build();


var app = host.Services.GetRequiredService<AppGames>();
app.Run();
