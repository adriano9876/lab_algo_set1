﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logic.Core.Array
{
    public static class ArrayHelper
    {
        public static int Conta(int[] collezione)
        {
            int conta = 0;
            foreach (int tmp in collezione){
                conta ++;
            }
            return conta;
        }

        public static bool Cerca(int[] collezione, int obiettivo)
        {          
            foreach (int tmp in collezione)
            {
                if (tmp==obiettivo)
                {
                    return true;
                }   
            }
            return false;

        }

        public static int CercaValoreMinimo(int[] collezione)
        {
            int min = collezione[0];
            foreach (int tmp in collezione)
            {
                if (min > tmp )
                {
                    min = tmp;
                }
            }
            return min;
        }

        public static int CercaValoreMassimo(int[] collezione, int estremoSuperiore = int.MaxValue)
        {
            int max = int.MinValue;
            foreach(int tmp in collezione)
            {
                if (tmp > max)
                {
                    max = tmp;
                }
            }
            return max;
        }

        public static int Somma(int[] collezione)
        {
            int somma = 0;
            foreach(int tmp in collezione)
            {
                somma = somma + tmp;
            }

            return somma;
        }

        public static double CalcolaMedia(int[] collezione)
        {
            double somma = 0;
            foreach(int tmp in collezione)
            {
                somma = somma + tmp;
            }
            return somma / collezione.Length;
            //return double.NaN;
        }

        public static int ContaIntervallo(int[] collezione, int minimo, int massimo)
        {
            int contatore = 0;
            foreach(int tmp in collezione)
            {
                if(tmp>=minimo && tmp <= massimo)
                {
                    contatore++;
                }
            }

            return contatore;
        }

        public static int ContaSe(int[] collezione, int opzione)
        {
            int contatore = 0;
            foreach (int tmp in collezione)
            {
                if (opzione == 0)
                {
                    if (tmp == 0)
                    {
                        contatore++;
                    }
                }
                if (opzione == 1)
                {
                    if (tmp > 0)
                    {
                        contatore++;
                    }

                }
                if (opzione == -1)
                {
                    if (tmp < 0)
                    {
                        contatore++;
                    }

                }
            }
            if(opzione==0 || opzione ==-1 || opzione==1)
            {
                return contatore;
            }
            else
            {               
                throw new Exception("errore in SE") ;
            }
            //return contatore;
            
        }

    }
}
