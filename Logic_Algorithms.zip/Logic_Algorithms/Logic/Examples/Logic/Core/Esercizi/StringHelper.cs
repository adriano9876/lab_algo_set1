﻿using System.Linq.Expressions;

namespace Logic.Core.Esercizi
{
    public class StringHelper
    {
        // substring , 
        public static bool Contiene(string sorgente, string blocco)
        {
            bool flag = true;
            if (blocco.Length > sorgente.Length )
                return false;

            for(int i=0; i<sorgente.Length ; i++) {
                if (sorgente[i] == blocco[0]  ) {
                    for(int j=0; j<blocco.Length  ; j++){
                        if (sorgente[i+j] != blocco[j] ){
                            flag = false;
                        }                      
                    }
                }
            }
            return flag;
        }

        public static int TrovaInizioDi(string sorgente, string blocco)
        {
            return -1;
        }

        /*fatto*/
        public static bool IniziaCon(string sorgente, string blocco)
        {
            bool inizia = true;
            if(sorgente.Length < blocco.Length)
            {
                return false;
            }
            for(int i=0; i<blocco.Length; i++)
            {
                if (sorgente[i] != blocco[i])
                {
                    inizia = false;
                }
            }


            return inizia;
        }

        /*fatto*/
        public static int TrovaPosizioneDi(string sorgente, char obiettivo)
        {
            for(int i=0; i<sorgente.Length; i++)
            {
                if (sorgente[i] == obiettivo)
                {
                    return i;
                }
            }
            return -1;
        }

        public static string RimpiazzaSemplice(string sorgente, string blocco, string rimpiazzo)
        {
            return string.Empty;
        }

        public static string Rimpiazza(string sorgente, string blocco, string rimpiazzo)
        {
            return string.Empty;
        }
    }
}
