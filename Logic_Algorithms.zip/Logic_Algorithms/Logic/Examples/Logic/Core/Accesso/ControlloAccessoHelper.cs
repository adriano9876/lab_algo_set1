﻿namespace Logic.Core.Accesso
{
    public static class ControlloAccessoHelper
    {
        public static LivelloAccesso VerificaAccesso(ControlloAccesso controllo)
        {
            bool main_access = false;
            bool sec_access = false;
            bool emer_access = false;
            int bio_count = 0;
            if (controllo.RetinaValidata)
               bio_count++;            
            if (controllo.CodiceDnaCorretto)
                bio_count++;
            if (controllo.ImprontaDigitaleCorretta)
                bio_count++;

            /*main access*/
            if (controllo.BadgeValido && controllo.LivelloAutorizzazione>=3 
                && bio_count>=2)
            {
                main_access = true;
            }

            /*secondary access*/
            if(controllo.BadgeValido && controllo.CodiceInserito.Equals("1970")
                && bio_count >= 1)
            {
                sec_access = true;
            }

            /* emergency access */
            if (controllo.StatoDiEmergenza && !controllo.StatoDiBlackout)
            {
                emer_access = true;
            }

            /* «access allowed», code 1 */
            if ((main_access || sec_access || emer_access ) && 
                controllo.OrarioConsentito && !controllo.LavoraATorino &&
                controllo.GiorniInAzienda >= 5)
            {
                return LivelloAccesso.Consentito;
            }

            /* «accesso sorvegliato», code 2 */
            if (emer_access && controllo.LavoraATorino)
            {
                return LivelloAccesso.Sorvegliato;
            }           
        
           /* «Access forbidden», code 3 */

            return LivelloAccesso.Negato;
            
            
        }
    }
}
