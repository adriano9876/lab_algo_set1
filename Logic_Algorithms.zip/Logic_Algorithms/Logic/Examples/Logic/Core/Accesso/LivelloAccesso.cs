﻿namespace Logic.Core.Accesso
{
    public enum LivelloAccesso
    {
        Consentito = 1,
        Sorvegliato = 2,
        Negato = 3,
    }
}
