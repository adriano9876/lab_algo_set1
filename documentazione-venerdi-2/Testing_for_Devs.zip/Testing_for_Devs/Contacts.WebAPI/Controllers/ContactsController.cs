using Contacts.WebAPI.Models;
using Contacts.WebAPI.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace Contacts.WebAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ContactsController : ControllerBase
    {
        private readonly IContactService _service;

        public ContactsController(IContactService service)
        {
            _service = service;
        }

        [HttpGet]
        public ActionResult<IEnumerable<Contact>> GetAll() => Ok(_service.GetAll());

        [HttpGet("{id}")]
        public ActionResult<Contact> GetById(int id)
        {
            var contact = _service.GetById(id);
            if (contact is null) return NotFound();
            return Ok(contact);
        }

        [HttpPost]
        public ActionResult<Contact> Create(Contact contact)
        {
            _service.Add(contact);
            return CreatedAtAction(nameof(GetById), new { id = contact.Id }, contact);
        }

        [HttpPut("{id}")]
        public IActionResult Update(int id, Contact contact)
        {
            if (id != contact.Id) return BadRequest();
            var existing = _service.GetById(id);
            if (existing is null) return NotFound();
            _service.Update(contact);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var existing = _service.GetById(id);
            if (existing is null) return NotFound();
            _service.Delete(id);
            return NoContent();
        }

        [HttpPost("eldest")]
        public ActionResult<Contact> GetEldestContact(IEnumerable<Contact> contacts)
        {
            var eldestContact = _service.GetEldestContact(contacts);
            if (eldestContact is null) return NotFound();
            return Ok(eldestContact);
        }
    }
}
