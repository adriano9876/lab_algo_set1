using Contacts.WebAPI.Data;
using Contacts.WebAPI.Repositories;
using Contacts.WebAPI.Repositories.Interfaces;
using Contacts.WebAPI.Services;
using Contacts.WebAPI.Services.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Contacts.WebAPI
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            builder.Services.AddDbContext<ContactsDbContext>(options =>
                options.UseInMemoryDatabase("ContactsDb"));

            builder.Services.AddScoped<IContactRepository, ContactRepository>();

            builder.Services.AddScoped<IContactService, ContactService>();

            builder.Services.AddControllers();

            var app = builder.Build();

            app.UseHttpsRedirection();

            app.UseAuthorization();

            app.MapControllers();

            app.Run();
        }
    }
}
