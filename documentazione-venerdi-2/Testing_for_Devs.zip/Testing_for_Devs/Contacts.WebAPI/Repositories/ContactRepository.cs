using Contacts.WebAPI.Models;
using Contacts.WebAPI.Repositories.Interfaces;
using Contacts.WebAPI.Data;
using Microsoft.EntityFrameworkCore;

namespace Contacts.WebAPI.Repositories
{
    public class ContactRepository : IContactRepository
    {
        private readonly ContactsDbContext _context;

        public ContactRepository(ContactsDbContext context)
        {
            _context = context;
        }

        public IEnumerable<Contact> GetAll() =>
            _context.Contacts.AsNoTracking().ToList();

        public Contact? GetById(int id) =>
            _context.Contacts.AsNoTracking().FirstOrDefault(c => c.Id == id);

        public void Add(Contact contact)
        {
            _context.Contacts.Add(contact);
            _context.SaveChanges();
        }

        public void Update(Contact contact)
        {
            var existing = _context.Contacts.Find(contact.Id);
            if (existing is null) return;
            existing.Name = contact.Name;
            existing.Surname = contact.Surname;
            existing.PhoneNumber = contact.PhoneNumber;
            existing.Email = contact.Email;
            _context.SaveChanges();
        }

        public void Delete(int id)
        {
            var contact = _context.Contacts.Find(id);
            if (contact is null) return;
            _context.Contacts.Remove(contact);
            _context.SaveChanges();
        }
    }
}