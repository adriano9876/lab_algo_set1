using Contacts.WebAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace Contacts.WebAPI.Data
{
    public class ContactsDbContext : DbContext
    {
        public ContactsDbContext(DbContextOptions<ContactsDbContext> options)
            : base(options) { }

        public DbSet<Contact> Contacts => Set<Contact>();
    }
}
