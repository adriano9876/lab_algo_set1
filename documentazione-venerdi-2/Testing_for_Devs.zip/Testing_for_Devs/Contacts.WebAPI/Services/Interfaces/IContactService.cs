﻿using Contacts.WebAPI.Models;

namespace Contacts.WebAPI.Services.Interfaces
{
    public interface IContactService
    {
        IEnumerable<Contact> GetAll();
        Contact? GetById(int id);
        void Add(Contact contact);
        void Update(Contact contact);
        void Delete(int id);
        Contact GetEldestContact(IEnumerable<Contact> contacts);
        Contact? GetElderContact(Contact first, Contact second);
        public string GetGreetingForContact(Contact contact);
    }
}
