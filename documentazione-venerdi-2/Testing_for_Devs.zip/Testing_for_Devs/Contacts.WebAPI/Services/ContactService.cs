using Contacts.WebAPI.Models;
using Contacts.WebAPI.Repositories.Interfaces;
using Contacts.WebAPI.Services.Interfaces;

namespace Contacts.WebAPI.Services
{
    public class ContactService : IContactService
    {
        private readonly IContactRepository _repository;

        public ContactService(IContactRepository repository)
        {
            _repository = repository;
        }

        public IEnumerable<Contact> GetAll() => _repository.GetAll();

        public Contact? GetById(int id) => _repository.GetById(id);

        public void Add(Contact contact) => _repository.Add(contact);

        public void Update(Contact contact) => _repository.Update(contact);

        public void Delete(int id) => _repository.Delete(id);

        public Contact? GetEldestContact(IEnumerable<Contact> contacts)
        {
            if (contacts == null)
            {
                throw new ArgumentNullException(nameof(contacts));
            }

            return contacts.OrderByDescending(c => c.Age).FirstOrDefault();
        }

        public Contact? GetElderContact(Contact first, Contact second)
        {
            if (first == null)
            {
                throw new ArgumentNullException(nameof(first));
            }

            if (second == null)
            {
                throw new ArgumentNullException(nameof(second));
            }

            return first.Age >= second.Age ? first : second;
        }

        public string GetGreetingForContact(Contact contact)
        {
            if (contact == null)
            {
                throw new ArgumentNullException(nameof(contact));
            }

            var greeting = 
                DateTime.Now.Hour < 12 ? "Good morning" :
                DateTime.Now.Hour < 18 ? "Good afternoon" :
                DateTime.Now.Hour < 22 ? "Good evening" : "Good night";

            return $"{greeting} {contact.Name}";
        }
    }
}
