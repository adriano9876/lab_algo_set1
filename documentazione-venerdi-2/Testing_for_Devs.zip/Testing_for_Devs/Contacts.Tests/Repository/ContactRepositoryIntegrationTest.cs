﻿using Xunit;
using Contacts.WebAPI.Models;
using Contacts.WebAPI.Repositories;
using Contacts.WebAPI.Data;
using Microsoft.EntityFrameworkCore;
using System.Linq;

namespace Contacts.Tests.Repository
{
    public class ContactRepositoryIntegrationTest
    {
        private ContactsDbContext CreateDbContext(string dbName)
        {
            var options = new DbContextOptionsBuilder<ContactsDbContext>()
                .UseInMemoryDatabase(databaseName: dbName)
                .Options;
            return new ContactsDbContext(options);
        }

        [Fact]
        public void Add_And_GetById_Works()
        {
            // Arrange
            var dbName = nameof(Add_And_GetById_Works);
            using var context = CreateDbContext(dbName);
            var repo = new ContactRepository(context);
            var contact = new Contact { Name = "Mario", Surname = "Rossi", PhoneNumber = "123", Email = "mario@rossi.it" };

            // Act
            repo.Add(contact);
            var result = repo.GetById(contact.Id);

            // Assert
            Assert.NotNull(result);
            Assert.Equal("Mario", result.Name);
        }

        [Fact]
        public void GetAll_ReturnsAllContacts()
        {
            // Arrange
            var dbName = nameof(GetAll_ReturnsAllContacts);
            using var context = CreateDbContext(dbName);
            var repo = new ContactRepository(context);
            repo.Add(new Contact { Name = "Mario", Surname = "Rossi", PhoneNumber = "123", Email = "mario@rossi.it" });
            repo.Add(new Contact { Name = "Luigi", Surname = "Verdi", PhoneNumber = "456", Email = "luigi@verdi.it" });

            // Act
            var all = repo.GetAll().ToList();

            // Assert
            Assert.Equal(2, all.Count);
        }

        [Fact]
        public void Update_ChangesContactData()
        {
            // Arrange
            var dbName = nameof(Update_ChangesContactData);
            using var context = CreateDbContext(dbName);
            var repo = new ContactRepository(context);
            var contact = new Contact { Name = "Mario", Surname = "Rossi", PhoneNumber = "123", Email = "mario@rossi.it" };
            repo.Add(contact);

            // Act
            contact.Name = "Giovanni";
            repo.Update(contact);
            var updated = repo.GetById(contact.Id);

            // Assert
            Assert.NotNull(updated);
            Assert.Equal("Giovanni", updated.Name);
        }

        [Fact]
        public void Delete_RemovesContact()
        {
            // Arrange
            var dbName = nameof(Delete_RemovesContact);
            using var context = CreateDbContext(dbName);
            var repo = new ContactRepository(context);
            var contact = new Contact { Name = "Mario", Surname = "Rossi", PhoneNumber = "123", Email = "mario@rossi.it" };
            repo.Add(contact);

            // Act
            repo.Delete(contact.Id);
            var deleted = repo.GetById(contact.Id);

            // Assert
            Assert.Null(deleted);
        }
    }
}
