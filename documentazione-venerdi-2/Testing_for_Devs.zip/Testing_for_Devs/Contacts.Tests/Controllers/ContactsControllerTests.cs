using Xunit;
using Moq;
using Contacts.WebAPI.Controllers;
using Contacts.WebAPI.Models;
using Contacts.WebAPI.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace Contacts.Tests
{
    public class ContactsControllerTests
    {
        private readonly Mock<IContactService> _serviceMock;
        private readonly ContactsController _controller;

        public ContactsControllerTests()
        {
            _serviceMock = new Mock<IContactService>();
            _controller = new ContactsController(_serviceMock.Object);
        }

        [Fact]
        public void GetAll_ReturnsOkResult_WithListOfContacts()
        {
            // Arrange
            var contacts = new List<Contact>
            {
                new Contact { Id = 1, Name = "Mario", Surname = "Rossi", PhoneNumber = "123", Email = "mario@rossi.it" }
            };
            _serviceMock.Setup(s => s.GetAll()).Returns(contacts);

            // Act
            var result = _controller.GetAll();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var returnContacts = Assert.IsAssignableFrom<IEnumerable<Contact>>(okResult.Value);
            Assert.Single(returnContacts);
        }

        [Fact]
        public void GetById_ExistingId_ReturnsOkResult()
        {
            // Arrange
            var contact = new Contact { Id = 1, Name = "Mario", Surname = "Rossi", PhoneNumber = "123", Email = "mario@rossi.it" };
            _serviceMock.Setup(s => s.GetById(1)).Returns(contact);

            // Act
            var result = _controller.GetById(1);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var returnContact = Assert.IsType<Contact>(okResult.Value);
            Assert.Equal(1, returnContact.Id);
        }

        [Fact]
        public void GetById_NonExistingId_ReturnsNotFound()
        {
            // Arrange
            _serviceMock.Setup(s => s.GetById(2)).Returns((Contact?)null);

            // Act
            var result = _controller.GetById(2);

            // Assert
            Assert.IsType<NotFoundResult>(result.Result);
        }

        [Fact]
        public void Create_ValidContact_ReturnsCreatedAtAction()
        {
            // Arrange
            var contact = new Contact { Id = 1, Name = "Mario", Surname = "Rossi", PhoneNumber = "123", Email = "mario@rossi.it" };

            // Act
            var result = _controller.Create(contact);

            // Assert
            var createdAtAction = Assert.IsType<CreatedAtActionResult>(result.Result);
            var returnContact = Assert.IsType<Contact>(createdAtAction.Value);
            Assert.Equal(contact.Id, returnContact.Id);
        }

        [Fact]
        public void Update_IdMismatch_ReturnsBadRequest()
        {
            // Arrange
            var contact = new Contact { Id = 2, Name = "Mario", Surname = "Rossi", PhoneNumber = "123", Email = "mario@rossi.it" };

            // Act
            var result = _controller.Update(1, contact);

            // Assert
            Assert.IsType<BadRequestResult>(result);
        }

        [Fact]
        public void Update_NonExistingContact_ReturnsNotFound()
        {
            // Arrange
            var contact = new Contact { Id = 1, Name = "Mario", Surname = "Rossi", PhoneNumber = "123", Email = "mario@rossi.it" };
            _serviceMock.Setup(s => s.GetById(1)).Returns((Contact?)null);

            // Act
            var result = _controller.Update(1, contact);

            // Assert
            Assert.IsType<NotFoundResult>(result);
        }

        [Fact]
        public void Update_ExistingContact_ReturnsNoContent()
        {
            // Arrange
            var contact = new Contact { Id = 1, Name = "Mario", Surname = "Rossi", PhoneNumber = "123", Email = "mario@rossi.it" };
            _serviceMock.Setup(s => s.GetById(1)).Returns(contact);

            // Act
            var result = _controller.Update(1, contact);

            // Assert
            Assert.IsType<NoContentResult>(result);
        }

        [Fact]
        public void Delete_NonExistingContact_ReturnsNotFound()
        {
            // Arrange
            _serviceMock.Setup(s => s.GetById(1)).Returns((Contact?)null);

            // Act
            var result = _controller.Delete(1);

            // Assert
            Assert.IsType<NotFoundResult>(result);
        }

        [Fact]
        public void Delete_ExistingContact_ReturnsNoContent()
        {
            // Arrange
            var contact = new Contact { Id = 1, Name = "Mario", Surname = "Rossi", PhoneNumber = "123", Email = "mario@rossi.it" };
            _serviceMock.Setup(s => s.GetById(1)).Returns(contact);

            // Act
            var result = _controller.Delete(1);

            // Assert
            Assert.IsType<NoContentResult>(result);
        }

        [Fact]
        public void GetEldestContact_ContactExists_ReturnsOkResult()
        {
            // Arrange
            var contacts = new List<Contact> 
            { 
                new Contact { Id = 1, Name = "John", Surname = "Doe", Age = 30 },
                new Contact { Id = 2, Name = "Mike", Surname = "Smith", Age = 40 },
            };
            var eldest = contacts[1];
            _serviceMock.Setup(s => s.GetEldestContact(contacts)).Returns(eldest);

            // Act
            var result = _controller.GetEldestContact(contacts);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            Assert.Equal(eldest, okResult.Value);
        }

        [Fact]
        public void GetEldestContact_NoContact_ReturnsNotFound()
        {
            // Arrange
            var contacts = new List<Contact>();
            _serviceMock.Setup(s => s.GetEldestContact(contacts)).Returns((Contact)null);

            // Act
            var result = _controller.GetEldestContact(contacts);

            // Assert
            Assert.IsType<NotFoundResult>(result.Result);
        }
    }
}
