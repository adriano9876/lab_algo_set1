using Xunit;
using Moq;
using Contacts.WebAPI.Models;
using Contacts.WebAPI.Services;
using Contacts.WebAPI.Repositories.Interfaces;
using System.Collections.Generic;

namespace Contacts.Tests.Services
{
    public class ContactServiceTests
    {
        private readonly Mock<IContactRepository> _repoMock;
        private readonly ContactService _service;

        public ContactServiceTests()
        {
            _repoMock = new Mock<IContactRepository>();
            _service = new ContactService(_repoMock.Object);
        }

        [Fact]
        public void GetAll_ReturnsAllContacts()
        {
            // Arrange
            var contacts = new List<Contact>
            {
                new Contact { Id = 1, Name = "Mario", Surname = "Rossi", PhoneNumber = "123", Email = "mario@rossi.it" }
            };
            _repoMock.Setup(r => r.GetAll()).Returns(contacts);

            // Act
            var result = _service.GetAll();

            // Assert
            Assert.Equal(contacts, result);
            _repoMock.Verify(r => r.GetAll(), Times.Once);
        }

        [Fact]
        public void GetById_ExistingId_ReturnsContact()
        {
            // Arrange
            var contact = new Contact { Id = 1, Name = "Mario", Surname = "Rossi", PhoneNumber = "123", Email = "mario@rossi.it" };
            _repoMock.Setup(r => r.GetById(1)).Returns(contact);

            // Act
            var result = _service.GetById(1);

            // Assert
            Assert.Equal(contact, result);
            _repoMock.Verify(r => r.GetById(1), Times.Once);
        }

        [Fact]
        public void GetById_NonExistingId_ReturnsNull()
        {
            // Arrange
            _repoMock.Setup(r => r.GetById(2)).Returns((Contact?)null);

            // Act
            var result = _service.GetById(2);

            // Assert
            Assert.Null(result);
            _repoMock.Verify(r => r.GetById(2), Times.Once);
        }

        [Fact]
        public void Add_CallsRepositoryAdd()
        {
            // Arrange
            var contact = new Contact { Id = 1, Name = "Mario", Surname = "Rossi", PhoneNumber = "123", Email = "mario@rossi.it" };

            // Act
            _service.Add(contact);

            // Assert
            _repoMock.Verify(r => r.Add(contact), Times.Once);
        }

        [Fact]
        public void Update_CallsRepositoryUpdate()
        {
            // Arrange
            var contact = new Contact { Id = 1, Name = "Mario", Surname = "Rossi", PhoneNumber = "123", Email = "mario@rossi.it" };

            // Act
            _service.Update(contact);

            // Assert
            _repoMock.Verify(r => r.Update(contact), Times.Once);
        }

        [Fact]
        public void Delete_CallsRepositoryDelete()
        {
            // Arrange
            int id = 1;

            // Act
            _service.Delete(id);

            // Assert
            _repoMock.Verify(r => r.Delete(id), Times.Once);
        }

        [Fact]
        public void GetEldestContact_ReturnsContactWithMaxAge()
        {
            // Arrange
            var contacts = new List<Contact>
            {
                new Contact { Id = 1, Name = "Alice", Surname = "Smith", Age = 30 },
                new Contact { Id = 2, Name = "Bob", Surname = "Jones", Age = 45 },
                new Contact { Id = 3, Name = "Charlie", Surname = "Brown", Age = 40 }
            };

            // Act
            var result = _service.GetEldestContact(contacts);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(45, result.Age);
            Assert.Equal("Bob", result.Name);
        }

        [Fact]
        public void GetEldestContact_EmptyList_ReturnsNull()
        {
            // Arrange
            var contacts = new List<Contact>();

            // Act
            var result = _service.GetEldestContact(contacts);

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public void GetEldestContact_NullContacts_ThrowsArgumentNullException()
        {
            // Act & Assert
            Assert.Throws<ArgumentNullException>(() => _service.GetEldestContact(null!));
        }

        public static IEnumerable<object[]> ElderContactTestData =>
        new List<object[]>
        {
            new object[] { new Contact { Name = "A", Age = 30 }, new Contact { Name = "B", Age = 25 }, "A" },
            new object[] { new Contact { Name = "A", Age = 25 }, new Contact { Name = "B", Age = 30 }, "B" },
            new object[] { new Contact { Name = "A", Age = 40 }, new Contact { Name = "B", Age = 40 }, "A" },
        };

        [Theory]
        [MemberData(nameof(ElderContactTestData))]
        public void GetElderContact_ReturnsElderContact(Contact first, Contact second, string expectedName)
        {
            // Act
            var result = _service.GetElderContact(first, second);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(expectedName, result.Name);
        }

        [Theory]
        [InlineData(40, 30, true)]
        [InlineData(30, 40, false)]
        [InlineData(25, 25, true)]
        public void GetElderContact_ReturnsCorrectContact_InlineData(int age1, int age2, bool firstIsElder)
        {
            var first = new Contact { Id = 1, Name = "A", Surname = "B", Age = age1 };
            var second = new Contact { Id = 2, Name = "C", Surname = "D", Age = age2 };

            var result = _service.GetElderContact(first, second);

            Assert.Equal(firstIsElder, result == first);
        }

        [Fact]
        public void GetElderContact_ThrowsArgumentNullException_WhenFirstIsNull()
        {
            // Arrange
            var second = new Contact { Name = "B", Age = 20 };

            // Act & Assert
            Assert.Throws<ArgumentNullException>(() => _service.GetElderContact(null!, second));
        }

        [Fact]
        public void GetElderContact_ThrowsArgumentNullException_WhenSecondIsNull()
        {
            // Arrange
            var first = new Contact { Name = "A", Age = 20 };

            // Act & Assert
            Assert.Throws<ArgumentNullException>(() => _service.GetElderContact(first, null!));
        }

        [Fact]
        public void GetGreetingForContact_ReturnsData()
        {
            // Arrange
            var contact = new Contact { Name = "Alice" };

            // Act
            var result = _service.GetGreetingForContact(contact);

            // Assert
            Assert.NotNull(result);
            //Assert.Equal($"Good afternoon Alice", result); <-- Non-deterministic assertion
        }
    }
}
