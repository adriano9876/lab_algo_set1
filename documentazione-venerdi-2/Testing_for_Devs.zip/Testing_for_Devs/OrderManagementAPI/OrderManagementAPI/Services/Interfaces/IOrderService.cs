﻿using OrderManagementAPI.Models;

namespace OrderManagementAPI.Services.Interfaces
{
    public interface IOrderService
    {
        /// <summary>
        /// Get order by id.
        /// </summary>
        /// <param name="id">The Id of the order to retrieve.</param>
        /// <returns>The matching order or null if not found.</returns>
        Task<Order?> GetOrderAsync(int id);

        /// <summary>
        /// Get all orders.
        /// </summary>
        /// <returns>All the orders.</returns>
        Task<IEnumerable<Order>> GetAllOrdersAsync();

        /// <summary>
        /// Add a new order.
        /// </summary>
        /// <param name="order"></param>
        /// <returns>The added order.</returns>
        Task<Order> AddOrderAsync(Order order);

        /// <summary>
        /// Update the status of an order.
        /// </summary>
        /// <param name="orderId">The order id.</param>
        /// <param name="newStatus">The new status</param>
        /// <returns></returns>
        Task UpdateOrderStatusAsync(int orderId, OrderStatus newStatus);

        /// <summary>
        /// Delete an order by id.
        /// </summary>
        /// <param name="id">The order id.</param>
        /// <returns>A bool telling whether or not the Delete was successful.</returns>
        Task<bool> DeleteOrderAsync(int id);
    }
}
