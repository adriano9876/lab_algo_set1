﻿using OrderManagementAPI.Models;
using OrderManagementAPI.Repositories.Interfaces;
using OrderManagementAPI.Services.Interfaces;

namespace OrderManagementAPI.Services
{
    public class OrderService : IOrderService
    {
        private readonly IOrderRepository _repository;

        public OrderService(IOrderRepository repository)
        {
            _repository = repository;
        }

        /// <inheritdoc/>
        public async Task<Order?> GetOrderAsync(int id)
        {
            return await _repository.GetOrderAsync(id);
        }

        /// <inheritdoc/>
        public async Task<IEnumerable<Order>> GetAllOrdersAsync()
        {
            return await _repository.GetAllOrdersAsync();
        }

        /// <inheritdoc/>
        public async Task<Order> AddOrderAsync(Order order)
        {
            return await _repository.AddOrderAsync(order);
        }

        /// <inheritdoc/>
        public async Task UpdateOrderStatusAsync(int orderId, OrderStatus newStatus)
        {
            // To be implemented based on business logic
            throw new NotImplementedException();
        }

        /// <inheritdoc/>
        public async Task<bool> DeleteOrderAsync(int id)
        {
            return await _repository.DeleteOrderAsync(id);
        }
    }
}
