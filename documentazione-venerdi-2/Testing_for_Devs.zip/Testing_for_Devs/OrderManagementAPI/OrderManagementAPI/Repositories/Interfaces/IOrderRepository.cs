﻿using OrderManagementAPI.Models;

namespace OrderManagementAPI.Repositories.Interfaces
{
    public interface IOrderRepository
    {
        /// <summary>
        /// Get order by id.
        /// </summary>
        /// <param name="id">The Id of the order to retrieve.</param>
        /// <returns>The matching order or null if not found.</returns>
        Task<Order?> GetOrderAsync(int id);

        /// <summary>
        /// Get all orders.
        /// </summary>
        /// <returns>All the orders.</returns>
        Task<IEnumerable<Order>> GetAllOrdersAsync();

        /// <summary>
        /// Add a new order.
        /// </summary>
        /// <param name="order"></param>
        /// <returns>The added order.</returns>
        Task<Order> AddOrderAsync(Order order);

        /// <summary>
        /// Update an existing order.
        /// </summary>
        /// <param name="order">The order to update.</param>
        /// <returns>A bool telling whether or not the Update was successful.</returns>
        Task<bool> UpdateOrderAsync(Order order);

        /// <summary>
        /// Delete an order by id.
        /// </summary>
        /// <param name="id">The order id.</param>
        /// <returns>A bool telling whether or not the Delete was successful.</returns>
        Task<bool> DeleteOrderAsync(int id);
    }
}
