using Microsoft.AspNetCore.Mvc;
using OrderManagementAPI.Models;
using OrderManagementAPI.Services.Interfaces;

namespace OrderManagementAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class OrdersController : ControllerBase
    {
        private readonly ILogger<OrdersController> _logger;
        private readonly IOrderService _orderService;
        
        public OrdersController(ILogger<OrdersController> logger, IOrderService orderService)
        {
            _logger = logger;
            _orderService = orderService;
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetOrderAsync(int id)
        {
            _logger.LogInformation($"Fetching order with id {id}");

            var order = await _orderService.GetOrderAsync(id);

            if (order is null)
            {
                _logger.LogWarning($"Order with id {id} not found!");
                return NotFound();
            }

            return Ok(order);
        }

        [HttpGet]
        public async Task<IActionResult> GetAllOrdersAsync()
        {
            _logger.LogInformation("Fetching all orders");
            var orders = await _orderService.GetAllOrdersAsync();
            return Ok(orders);
        }

        [HttpPost]
        public async Task<IActionResult> AddOrderAsync([FromBody] Order order)
        {
            _logger.LogInformation("Adding a new order");
            if (order == null)
            {
                return BadRequest();
            }

            var createdOrder = await _orderService.AddOrderAsync(order);
            return CreatedAtAction(nameof(AddOrderAsync), new { id = createdOrder.Id }, createdOrder);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateOrderAsync(int id, [FromBody] Order order)
        {
            _logger.LogInformation($"Updating order with id {id}");
            if (order == null || order.Id != id)
            {
                return BadRequest();
            }

            var updated = await _orderService.UpdateOrderAsync(order);
            if (!updated)
            {
                return NotFound();
            }

            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteOrderAsync(int id)
        {
            _logger.LogInformation($"Deleting order with id {id}");
            var deleted = await _orderService.DeleteOrderAsync(id);
            if (!deleted)
            {
                return NotFound();
            }

            return NoContent();
        }
    }
}
