﻿namespace OrderManagementAPI.Models
{
    public class Order
    {
        public int Id { get; set; }

        public int CustomerId { get; set; }

        public List<OrderItem> Items { get; set; } = new();

        public decimal Total => Items.Sum(i => i.Quantity * i.UnitPrice);

        public OrderStatus Status { get; set; } = OrderStatus.Pending;

        public DateTime CreatedAt { get; private set; } = DateTime.UtcNow;
    }
}
