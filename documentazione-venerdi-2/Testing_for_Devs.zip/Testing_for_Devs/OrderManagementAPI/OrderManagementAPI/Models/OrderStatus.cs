﻿namespace OrderManagementAPI.Models
{
    public enum OrderStatus
    {
        /// <summary>
        /// Order is pending and yet to be processed.
        /// </summary>
        Pending = 0,

        /// <summary>
        /// Order is being processed.
        /// </summary>
        Processing = 1,

        /// <summary>
        /// Order has been shipped.
        /// </summary>
        Shipped = 2,

        /// <summary>
        /// Order has been delivered.
        /// </summary>
        Delivered = 3,

        /// <summary>
        /// Order has been cancelled.
        /// </summary>
        Cancelled = 4
    }
}
