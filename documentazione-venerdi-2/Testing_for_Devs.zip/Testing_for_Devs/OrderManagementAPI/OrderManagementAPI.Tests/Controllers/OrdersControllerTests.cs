﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using OrderManagementAPI.Controllers;
using OrderManagementAPI.Models;
using OrderManagementAPI.Services.Interfaces;

namespace OrderManagementAPI.Tests.Controllers
{
    public class OrdersControllerTests
    {
        private readonly Mock<ILogger<OrdersController>> _loggerMock;
        private readonly Mock<IOrderService> _orderServiceMock;
        private readonly OrdersController _controller;

        public OrdersControllerTests()
        {
            _loggerMock = new Mock<ILogger<OrdersController>>();
            _orderServiceMock = new Mock<IOrderService>();
            _controller = new OrdersController(_loggerMock.Object, _orderServiceMock.Object);
        }

        [Fact]
        public async Task GetOrderAsync_ReturnsOk_WhenOrderExists()
        {
            // Arrange
            var orderId = 1;
            var order = new Order
            {
                Id = orderId,
                CustomerId = 123,
                Items = new List<OrderItem> { new OrderItem { Id = 1, ProductName = "Test", Quantity = 1, UnitPrice = 1.00M } },
                Status = OrderStatus.Pending,
            };
            _orderServiceMock.Setup(s => s.GetOrderAsync(orderId)).ReturnsAsync(order);

            // Act
            var result = await _controller.GetOrderAsync(orderId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(order, okResult.Value);
        }

        [Fact]
        public async Task GetOrderAsync_ReturnsNotFound_WhenOrderDoesNotExist()
        {
            // Arrange
            var orderId = 2;
            _orderServiceMock.Setup(s => s.GetOrderAsync(orderId)).ReturnsAsync((Order?)null);

            // Act
            var result = await _controller.GetOrderAsync(orderId);

            // Assert
            Assert.IsType<NotFoundResult>(result);
        }
    }
}
