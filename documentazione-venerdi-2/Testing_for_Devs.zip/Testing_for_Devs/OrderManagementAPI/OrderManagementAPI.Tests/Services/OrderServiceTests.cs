﻿using Moq;
using OrderManagementAPI.Models;
using OrderManagementAPI.Repositories.Interfaces;
using OrderManagementAPI.Services;

namespace OrderManagementAPI.Tests.Services
{
    public class OrderServiceTests
    {
        private readonly Mock<IOrderRepository> _repoMock;
        private readonly OrderService _service;

        public OrderServiceTests()
        {
            _repoMock = new Mock<IOrderRepository>();
            _service = new OrderService(_repoMock.Object);
        }

        [Fact]
        public async Task GetOrderAsync_ReturnsOrder_WhenOrderExists()
        {
            // Arrange
            var orderId = 1;
            var expectedOrder = new Order { Id = orderId, CustomerId = 123, Status = OrderStatus.Pending };
            _repoMock.Setup(r => r.GetOrderAsync(orderId)).ReturnsAsync(expectedOrder);

            // Act
            var result = await _service.GetOrderAsync(orderId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(expectedOrder.Id, result!.Id);
            Assert.Equal(expectedOrder.CustomerId, result.CustomerId);
            Assert.Equal(expectedOrder.Status, result.Status);
        }

        [Fact]
        public async Task GetOrderAsync_ReturnsNull_WhenOrderDoesNotExist()
        {
            // Arrange
            var orderId = 99;
            _repoMock.Setup(r => r.GetOrderAsync(orderId)).ReturnsAsync((Order?)null);

            // Act
            var result = await _service.GetOrderAsync(orderId);

            // Assert
            Assert.Null(result);
        }
    }
}
