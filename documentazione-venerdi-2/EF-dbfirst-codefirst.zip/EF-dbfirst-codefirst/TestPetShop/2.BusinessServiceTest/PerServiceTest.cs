﻿using Moq;
using NuGet.Protocol.Core.Types;
using PetShot_Codefirst._2.BussinessService;
using PetShot_Codefirst._2.Model;
using PetShot_Codefirst._3.Repository;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace TestPetShop._2.BusinessServiceTest
{
    public class PerServiceTest
    {
        private readonly PetService _service;
        private readonly Mock<IPetRepository> _repoMock;

        public PerServiceTest()
        {
            _repoMock = new Mock<IPetRepository>();
            _service = new PetService(_repoMock.Object);
        }

        [Fact]
        public async Task GetAllUsers_ReturnAllUSers()
        {
            //Arrange
            var users = new List<User>
            {
                  new User {
                      Id =1,
                      Cognome = "lucaC",
                      DataCreazione = new DateOnly(2000,1,1),
                      Nome = "luca"
                  },
            };

            _repoMock.Setup(r => r.GetAllUsersAsync_Repo ()).ReturnsAsync(users);

            //Act
            var result = await _service.GetAllUsersAsync_Service();

            //Assert
            Assert.Equal(users[0].Nome, result.First().Nome);
            _repoMock.Verify(r => r.GetAllUsersAsync_Repo() , Times.Once);


        }


        [Fact]
        public async Task GetUserById_ReturnUserById()
        {
            //Arrange
            User user = new User
            {
                Id = 5,
                Cognome = "lucaC",
                DataCreazione = new DateOnly(2000, 1, 1),
                Nome = "luca"
            };


            _repoMock.Setup(r=>r.GetUserByIdAsync_Repo(5)).ReturnsAsync(user);

            //Act 
           
            var result = await _service.GetUserByIdAsync_Service(5);

            //Assert 

            Assert.NotNull(result);
            Assert.Equal(user.Id, result.Id);
            _repoMock.Verify(r => r.GetUserByIdAsync_Repo(5) , Times.Once);
        }

        [Fact]
        public async void GetUserById_NonExistingId_ReturnsNull()
        {
            // Arrange
            _repoMock.Setup(r => r.GetUserByIdAsync_Repo (200)).ReturnsAsync((User?)null);

            // Act
            var result = await _service.GetUserByIdAsync_Service(200);

            // Assert
            Assert.Null(result);
            _repoMock.Verify(r => r.GetUserByIdAsync_Repo(200), Times.Once);
        }


        [Fact]
        public async void Delete_CallsRepositoryDelete()
        {
            // Arrange
            int id = 1;

            // Act
            await _service.DeleteUserByIdAsync_Service(id);

            // Assert
            _repoMock.Verify(r => r.DeleteUserByIdAsync_Repo(id), Times.Once);
        }

        [Fact]
        public async void Update_CallsRepositoryUpdate()
        {
            // Arrange
            //var user = new User { Id = 1, Nome = "Mario", Cognome ="bu" };

            //// Act
            //await _service.UpdateUserAsync_Service(1,user);

            //// Assert
            //_repoMock.Verify(r => r.UpdateUserAsync_Repo(user), Times.Once);
        }




    }

}
