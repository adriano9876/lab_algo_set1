﻿using Microsoft.EntityFrameworkCore;
using PetShot_Codefirst._1.Context;
using PetShot_Codefirst._2.Model;

namespace PetShot_Codefirst._3.Repository
{
    public class PetRepository : IPetRepository
    {
        private readonly PetShotDbContext _context;

        public PetRepository(PetShotDbContext context)
        {
            _context = context;
        }

        /* -------------------------------------------------------- */
        public async Task<int> CreateUserAsync_Repo(User user)
        {
            var toDb =  await _context.Users.AddAsync(user);
            var ris = _context.SaveChanges();
            return user.Id;
        }

        public async Task<int> DeleteUserByIdAsync_Repo(int id)
        {
            var ris = await _context.Users.SingleOrDefaultAsync(u => u.Id == id);
            if(ris == null)
            {
                return -1;
            }

            var ris2= _context.Users.Remove(ris);          
            _context.SaveChanges();
            return id;                         
        }

        public async Task<ICollection<User>> GetAllUsersAsync_Repo()
        {
            var users = await _context.Users
                .AsNoTracking()
                .Include(u => u.CreditCards)
                .Include(u => u.Animals)
                .ToListAsync();
            return users;
        }

        public async Task<User?> GetUserByIdAsync_Repo(int id)
        {
            var user = await _context.Users
                .SingleOrDefaultAsync(u => u.Id == id);
            return user;
        }

        public async Task<int> UpdateUserAsync_Repo(int id, User user)
        {
            User userToMod = await _context.Users.SingleOrDefaultAsync(u => u.Id == id);
            if (user == null)
            {
                return -1;
            }
            userToMod.Nome = user.Nome;
            userToMod.Cognome = user.Cognome;
            _context.SaveChanges();
            return id;
        }


    }

}
