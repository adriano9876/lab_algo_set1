﻿using PetShot_Codefirst._2.Model;

namespace PetShot_Codefirst._3.Repository
{
    public interface IPetRepository
    {

        /* User */
        public Task<ICollection<User>> GetAllUsersAsync_Repo();
        public Task<User?> GetUserByIdAsync_Repo(int id);
        public Task<int> DeleteUserByIdAsync_Repo(int id);
        public Task<int> UpdateUserAsync_Repo (int id, User user);
        public Task<int> CreateUserAsync_Repo(User user);

        /* Animal */

        //public Task<ICollection<Animal>> GetAllAnimalsAsync_Repo();
        //public Task<Animal> GetAnimalByIdAsync_Repo(int id);
        //public Task<int> CreateAnimalAsync_Repo(Animal animal);
        //public Task<int> UpdateAnimalAsync_Repo(int id, Animal animal);
        //public Task<int> DeleteAnimalAsync_Repo(Animal animal);

        /* Credit Card CRUD */

        //public Task<ICollection<CreditCard>> GetAllCreditCardsAsync_Repo();
        //public Task<CreditCard> GetCreditCardByIdAsync_Repo(int id);
        //public Task<int> DeleteCreditCardByIdAsync_Repo(int id);
        //public Task<int> UpdateCreditCardAsync_Repo(int id, CreditCard creditCard);
        //public Task<int> CreateUserAsync_Repo(CreditCard creditCard);





    }

}
