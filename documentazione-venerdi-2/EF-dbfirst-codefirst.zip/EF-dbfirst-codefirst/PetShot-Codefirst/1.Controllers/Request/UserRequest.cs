﻿using PetShot_Codefirst._2.Model;

namespace PetShot_Codefirst._1.Controllers.Request
{
    public class UserRequest
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string? Cognome { get; set; }
        public DateOnly DataCreazione { get; set; }

    }

}
