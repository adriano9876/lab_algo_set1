﻿namespace PetShot_Codefirst._1.Controllers.Request
{
    public class AnimalRequest
    {
    }
}
