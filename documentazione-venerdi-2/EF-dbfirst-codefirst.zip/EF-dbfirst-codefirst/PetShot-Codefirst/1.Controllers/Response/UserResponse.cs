﻿using PetShot_Codefirst._2.Model;

namespace PetShot_Codefirst._1.Controllers.Response
{
    public class UserResponse
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string? Cognome { get; set; }
        public DateOnly DataCreazione { get; set; }

        /*Navigazione*/

        //public virtual ICollection<AnimalResponse> Animals { get; set; } = new List<AnimalResponse>();
        //public virtual ICollection<CreditCardResponse> CreditCards { get; set; } = new List<CreditCardResponse>();

    }

}
