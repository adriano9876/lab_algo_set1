﻿using PetShot_Codefirst._2.Model;

namespace PetShot_Codefirst._1.Controllers.Response
{
    public class AnimalResponse
    {
        public int Id { get; set; }
        public string NomeAnimale { get; set; }
        public string? Razza { get; set; }
        public DateOnly DataCreazione { get; set; }
        public int Eta { get; set; }


    }

}
