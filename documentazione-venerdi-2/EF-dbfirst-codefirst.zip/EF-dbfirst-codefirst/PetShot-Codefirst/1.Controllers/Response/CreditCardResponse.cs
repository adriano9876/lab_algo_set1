﻿using PetShot_Codefirst._2.Model;

namespace PetShot_Codefirst._1.Controllers.Response
{
    public class CreditCardResponse
    {
        public int Id { get; set; }
        public string NomeCarta { get; set; }
        public string NumeroCarta { get; set; }
        public DateOnly DataCreazione { get; set; }



    }
}
