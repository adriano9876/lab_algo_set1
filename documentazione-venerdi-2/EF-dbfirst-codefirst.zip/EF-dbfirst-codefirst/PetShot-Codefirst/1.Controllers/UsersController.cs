﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PetShot_Codefirst._1.Context;
using PetShot_Codefirst._1.Controllers.Request;
using PetShot_Codefirst._1.Controllers.Response;
using PetShot_Codefirst._2.BussinessService;
using PetShot_Codefirst._2.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PetShot_Codefirst._1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {

        private readonly IPetService _servicePet;

        public UsersController(IPetService petService)
        {
            _servicePet = petService;
        }


        /* -------------------------------------------------------- */


        // GET: api/Users
        [HttpGet]
        public async Task<ActionResult<IEnumerable<UserResponse>>> GetUsers()
        {
            var usersDto = await _servicePet.GetAllUsersAsync_Service();
            if (usersDto == null)
            {
                return NotFound();
            }

            return Ok(usersDto);
        }

        // GET: api/Users/5
        [HttpGet("{id}")]
        public async Task<ActionResult<UserResponse>> GetUser(int id)
        {
            var userDto = await _servicePet.GetUserByIdAsync_Service(id);

            if (userDto == null)
            {
                return NotFound();
            }

            return Ok(userDto);
        }

        // POST: api/Animals
        [HttpPost]
        public async Task<ActionResult<int>> PostAnimal([FromBody] UserRequest userRequest )
        {
            var ris1 = await _servicePet.CreateUserAsync_Service(userRequest);
                      

            return Ok(ris1);
        }

        // DELETE: api/Animals/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<int>> DeleteAnimal(int id)
        {
            var risDel = await _servicePet.DeleteUserByIdAsync_Service(id);
            return Ok(risDel);            
        }


        // PUT: api/Animals/5
        [HttpPut("{id}")]
        public async Task<ActionResult<int>> PutAnimal(int id, [FromBody] UserRequest userDto)
        {
            if (id != userDto.Id)
            {
                return BadRequest();
            }

            var ris = _servicePet.UpdateUserAsync_Service(id, userDto);

            return Ok(ris);
        }



    }
}
