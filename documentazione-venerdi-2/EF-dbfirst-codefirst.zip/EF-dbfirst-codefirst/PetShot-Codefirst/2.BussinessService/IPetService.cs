﻿using PetShot_Codefirst._1.Controllers.Request;
using PetShot_Codefirst._1.Controllers.Response;
using PetShot_Codefirst._2.Model;

namespace PetShot_Codefirst._2.BussinessService
{
    public interface IPetService
    {
        /* User */
        public Task<ICollection<UserResponse>> GetAllUsersAsync_Service();
        public Task<UserResponse?> GetUserByIdAsync_Service(int id);
        public Task<int> DeleteUserByIdAsync_Service(int id);
        public Task<int> UpdateUserAsync_Service(int id, UserRequest userDto);
        public Task<int> CreateUserAsync_Service(UserRequest user);


    }

}
