﻿using Microsoft.EntityFrameworkCore;
using PetShot_Codefirst._1.Controllers.Request;
using PetShot_Codefirst._1.Controllers.Response;
using PetShot_Codefirst._2.Model;
using PetShot_Codefirst._3.Repository;

namespace PetShot_Codefirst._2.BussinessService
{
    public class PetService : IPetService
    {
        private readonly IPetRepository _repositoryPet;

        public PetService(IPetRepository petRepository)
        {
            _repositoryPet = petRepository;
        }

        /* -----------------------------------------------------------   */


        public async Task<UserResponse?> GetUserByIdAsync_Service(int id)
        {
            var user = await _repositoryPet.GetUserByIdAsync_Repo(id); 
            if(user == null)
            {
                return null;
            } 
            UserResponse userDto = new()
            {
                Id = user.Id,
                Cognome = user.Cognome,
                DataCreazione = user.DataCreazione,
                Nome = user.Nome
            };

            return userDto;
        }

        public async Task<ICollection<UserResponse>> GetAllUsersAsync_Service()
        {
            var users = await _repositoryPet.GetAllUsersAsync_Repo();


            List<UserResponse> usersDto = users.Select(u => new UserResponse
            {
                Id = u.Id,
                Cognome = u.Cognome,
                DataCreazione = u.DataCreazione,
                Nome = u.Nome
            }).ToList();

            return usersDto;
        }

        public async Task<int> CreateUserAsync_Service(UserRequest userDto)
        {

            User toRepo = new()
            {
                Id = userDto.Id,
                Cognome = userDto.Cognome,
                DataCreazione = userDto.DataCreazione,
                Nome = userDto.Nome
            };

            var ret = await _repositoryPet.CreateUserAsync_Repo(toRepo);
            return ret;
        }

        public async Task<int> DeleteUserByIdAsync_Service(int id)
        {
            var ris = await _repositoryPet.DeleteUserByIdAsync_Repo(id);
            return ris;
        }

        public async Task<int> UpdateUserAsync_Service(int id, UserRequest userDto)
        {

            var toDb = new User
            {
                Id = userDto.Id,
                Cognome = userDto.Cognome,
                Nome = userDto.Nome

            };
            var ris = await _repositoryPet.UpdateUserAsync_Repo(id,toDb);
            return ris;
        }



    }//
}
