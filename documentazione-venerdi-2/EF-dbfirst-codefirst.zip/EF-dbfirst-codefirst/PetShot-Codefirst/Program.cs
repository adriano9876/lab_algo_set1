


using Microsoft.EntityFrameworkCore;
using PetShot_Codefirst._0.Middleware;
using PetShot_Codefirst._1.Context;
using PetShot_Codefirst._2.BussinessService;
using PetShot_Codefirst._3.Repository;
using FluentValidation;


var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

//builder.Services.AddFluentValidationAutoValidation();
//builder.Services.AddValidatorsFromAssemblyContaining<UserCreateValidator>();


/* My injections */
builder.Services.AddDbContext<PetShotDbContext>
(options => options.UseSqlServer(builder.Configuration
.GetConnectionString("DefaultConnection")));


builder.Services.AddScoped<IPetRepository, PetRepository>();
builder.Services.AddScoped<IPetService, PetService>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}


app.UseHttpsRedirection();

app.UseAuthorization();

//app.UseMiddleware<PetShopMiddleware>();

app.UseWhen(ctx => ctx.Request.Path.StartsWithSegments("/api"), subApp =>
{
    subApp.UseMiddleware<PetShopMiddleware>();
});

app.MapControllers();

app.Run();


/*My middleware */

//app.Use( async (context, next) =>
//{
//    Console.WriteLine("1 prima di invoke");

//    await next.Invoke();//.Invoke();
//    Console.WriteLine("3 dopo invoke");
//});

//app.Use(async (context, next) =>
//{
//    Console.WriteLine("2 prima di invoke");
//    await next();//.Invoke();
//});


//app.UseMiddleware<LoggingMiddleware>();
//app.UseMiddleware<FinalMiddleware>();