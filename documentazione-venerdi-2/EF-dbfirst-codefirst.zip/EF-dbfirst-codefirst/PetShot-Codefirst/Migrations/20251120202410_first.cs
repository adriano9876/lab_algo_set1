﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace PetShot_Codefirst.Migrations
{
    /// <inheritdoc />
    public partial class first : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Users",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nome = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Cognome = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DataCreazione = table.Column<DateOnly>(type: "date", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Users", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Animals",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    NomeAnimale = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Razza = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DataCreazione = table.Column<DateOnly>(type: "date", nullable: false),
                    Eta = table.Column<int>(type: "int", nullable: false),
                    UserId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Animals", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Animals_Users_UserId",
                        column: x => x.UserId,
                        principalTable: "Users",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "CreditCards",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    NomeCarta = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    NumeroCarta = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DataCreazione = table.Column<DateOnly>(type: "date", nullable: false),
                    UserId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CreditCards", x => x.Id);
                    table.ForeignKey(
                        name: "FK_CreditCards_Users_UserId",
                        column: x => x.UserId,
                        principalTable: "Users",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.InsertData(
                table: "Users",
                columns: new[] { "Id", "Cognome", "DataCreazione", "Nome" },
                values: new object[,]
                {
                    { 1, "rosso", new DateOnly(2020, 1, 1), "luca" },
                    { 2, "len", new DateOnly(2020, 1, 1), "sara" },
                    { 3, "wik", new DateOnly(2020, 1, 1), "bea" }
                });

            migrationBuilder.InsertData(
                table: "Animals",
                columns: new[] { "Id", "DataCreazione", "Eta", "NomeAnimale", "Razza", "UserId" },
                values: new object[,]
                {
                    { 1, new DateOnly(2020, 1, 1), 10, "pimpa", "cane", 1 },
                    { 2, new DateOnly(2020, 1, 1), 1, "pippo", "giraffa", 2 },
                    { 3, new DateOnly(2020, 1, 1), 5, "pluto", "rinoceronte", 3 }
                });

            migrationBuilder.InsertData(
                table: "CreditCards",
                columns: new[] { "Id", "DataCreazione", "NomeCarta", "NumeroCarta", "UserId" },
                values: new object[,]
                {
                    { 1, new DateOnly(2020, 1, 1), "master", "12345", 1 },
                    { 2, new DateOnly(2020, 1, 1), "visa", "12346", 2 },
                    { 3, new DateOnly(2020, 1, 1), "amex", "12347", 3 }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Animals_UserId",
                table: "Animals",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_CreditCards_UserId",
                table: "CreditCards",
                column: "UserId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Animals");

            migrationBuilder.DropTable(
                name: "CreditCards");

            migrationBuilder.DropTable(
                name: "Users");
        }
    }
}
