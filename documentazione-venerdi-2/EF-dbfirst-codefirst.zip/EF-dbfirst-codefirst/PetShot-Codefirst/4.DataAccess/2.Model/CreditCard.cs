﻿namespace PetShot_Codefirst._2.Model
{
    public class CreditCard
    {
        public int Id { get; set; }
        public string NomeCarta { get; set; }
        public string NumeroCarta { get; set; }
        public DateOnly DataCreazione { get; set; }

        /* Navigazione */

        public int UserId { get; set; }
        public virtual User User { get; set; }




    }
}
