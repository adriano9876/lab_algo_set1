﻿namespace PetShot_Codefirst._2.Model
{
    public class Animal
    {
        public int Id { get; set; }
        public string NomeAnimale { get; set; }
        public string? Razza { get; set; }
        public DateOnly DataCreazione { get; set; }
        public int Eta {get; set; } 

        /* Navigazione */
        public int UserId { get; set; }
        public virtual User User { get; set; }


    }

}
