﻿namespace PetShot_Codefirst._2.Model
{
    public class User
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string? Cognome { get; set; }
        public DateOnly DataCreazione { get; set; }

        /*Navigazione*/

        public virtual ICollection<Animal> Animals { get; set; } = new List<Animal>();
        public virtual ICollection<CreditCard> CreditCards { get; set; }= new List<CreditCard>();



    }


}
