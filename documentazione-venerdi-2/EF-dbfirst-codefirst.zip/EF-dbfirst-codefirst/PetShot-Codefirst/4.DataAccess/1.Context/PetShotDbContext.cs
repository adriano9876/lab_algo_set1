﻿using Microsoft.EntityFrameworkCore;
using PetShot_Codefirst._2.Model;
using System.Data.Common;

namespace PetShot_Codefirst._1.Context
{
    public class PetShotDbContext : DbContext
    {
        public PetShotDbContext(DbContextOptions<PetShotDbContext> options) : base(options) { }

        public virtual DbSet<User> Users { get; set; }
        public virtual DbSet<Animal> Animals { get; set; }
        public virtual DbSet<CreditCard> CreditCards { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder) {

            modelBuilder.Entity<Animal>()
              .HasOne(a => a.User)
              .WithMany(u => u.Animals)
              .HasForeignKey(u => u.UserId)
              .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<CreditCard>()
                .HasOne(c=>c.User)
                .WithMany(u=>u.CreditCards)
                .HasForeignKey(u => u.UserId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<User>().HasData(
                new User { Id=1, Nome ="luca", Cognome="rosso", DataCreazione = new DateOnly(2020,1,1)  },
                new User { Id=2, Nome ="sara", Cognome="len", DataCreazione = new DateOnly(2020,1,1)  },
                new User { Id=3, Nome ="bea", Cognome="wik", DataCreazione = new DateOnly(2020,1,1)  }

                );

            modelBuilder.Entity<Animal>().HasData(
                new Animal {Id = 1, NomeAnimale ="pimpa", Razza ="cane", DataCreazione = new DateOnly(2020, 1, 1), Eta=10 ,UserId=1 },
                new Animal {Id = 2, NomeAnimale ="pippo", Razza ="giraffa", DataCreazione = new DateOnly(2020, 1, 1), Eta=1 ,UserId=2 },
                new Animal {Id = 3, NomeAnimale ="pluto", Razza ="rinoceronte", DataCreazione = new DateOnly(2020, 1, 1), Eta=5 ,UserId=3 }
                
                );

            modelBuilder.Entity<CreditCard>().HasData(
                new CreditCard { Id =1 , NomeCarta = "master", NumeroCarta ="12345", DataCreazione= new DateOnly(2020, 1, 1),UserId =1 },
                new CreditCard { Id =2 , NomeCarta = "visa", NumeroCarta ="12346", DataCreazione= new DateOnly(2020, 1, 1),UserId =2 },
                new CreditCard { Id =3 , NomeCarta = "amex", NumeroCarta ="12347", DataCreazione= new DateOnly(2020, 1, 1),UserId =3 }
                
                );



        }



    }

}
