﻿using FluentValidation; 
using PetShot_Codefirst._1.Controllers.Request;
namespace PetShot_Codefirst._0.Middleware

{
    public class UserCreateValidator : AbstractValidator<UserRequest>
    {
        public UserCreateValidator()
        {
            RuleFor(x => x.Nome).NotEmpty().WithMessage("ci deve essere almeno un carattere");
            RuleFor(x => x.Id).GreaterThan(0).WithMessage("inserisci un numero positivo");
        }

    }

}
