﻿namespace PetShot_Codefirst._0.Middleware
{
    public class PetShopMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<PetShopMiddleware> _logger;

        public PetShopMiddleware(RequestDelegate next, ILogger<PetShopMiddleware> logger)
        {
            _next = next;
            _logger = logger;
        }

        public async Task Invoke(HttpContext context)
        {

            //Console.WriteLine("prima next M1 : ----> " + context.Request);
            _logger.LogInformation($"{context.Request.Method} --> {context.Request.Path}");
            await _next(context);
            if (context.Response.StatusCode > 300)
            {
                _logger.LogError($"{context.Response} --> {context.Request.Path}");
            }
            else
            {
                _logger.LogInformation($"{context.Response} --> {context.Request.Path}");
            }
            //Console.WriteLine("dopo next M1 : ----> " + context.Response);
        }
    }
}
