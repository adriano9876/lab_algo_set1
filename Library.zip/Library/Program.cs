﻿using Library.Business;
using Library.Data;
using Library.Presentation;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace Library
{
    public class Program
    {
        public static async Task Main(string[] args)
        {
            await RegisterDependencyInjectionContainerAsync();
        }

        private static async Task RegisterDependencyInjectionContainerAsync()
        {
            var applicationBuilder = Host.CreateApplicationBuilder();
            AddDependencies(applicationBuilder);

            using var host = applicationBuilder.Build();
            await StartAsync(host.Services);
        }

        private static async Task StartAsync(IServiceProvider sp)
        {
            using IServiceScope serviceScope = sp.CreateScope();

            var consoleView = serviceScope.ServiceProvider.GetService<ConsoleView>();
            if (consoleView != null)
            {
                await consoleView.OpenMenuAsync(CancellationToken.None);
            }
        }

        private static void AddDependencies(HostApplicationBuilder hostApplicationBuilder)
        {
            hostApplicationBuilder.Services.AddSingleton<ConsoleView>();
            //hostApplicationBuilder.Services.AddSingleton<BookRepositoryBase, BookRepositoryStatic>();
            hostApplicationBuilder.Services.AddSingleton<BookRepositoryBase, BookRepositoryJson>();
            hostApplicationBuilder.Services.AddScoped<BookService>();
            hostApplicationBuilder.Services.AddScoped<BookConverter>();
        }
    }
}