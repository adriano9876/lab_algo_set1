﻿using Library.Data;
using Library.Presentation;

namespace Library.Business
{
    public class BookService
    {
        private readonly BookConverter converter;
        private readonly BookRepositoryBase bookRepository;

        public BookService(
            BookConverter converter,
            BookRepositoryBase bookRepository)
        {
            this.converter = converter;
            this.bookRepository = bookRepository;
        }

        public async Task<IReadOnlyList<BookDto>> GetBooksAsync(BookQuery query, CancellationToken cancellationToken)
        {
            var books = await this.bookRepository.GetBooksAsync(query, cancellationToken);
            return books.Select(book => this.converter.GetBookDto(book)).ToList().AsReadOnly();
        }

        public async Task AddBookAsync(BookDto bookDto, CancellationToken cancellationToken)
        {
            var model = this.converter.GetBook(bookDto);
            await this.bookRepository.AddBookAsync(model, cancellationToken);
        }

        public async Task UpdateBookAsync(BookDto bookDto, CancellationToken cancellationToken)
        {
            var model = this.converter.GetBook(bookDto);
            await this.bookRepository.UpdateBookAsync(model, cancellationToken);
        }

        public async Task DeleteBookAsync(BookDto bookDto, CancellationToken cancellationToken)
        {
            var model = this.converter.GetBook(bookDto);
            await this.bookRepository.DeleteBookAsync(model, cancellationToken);
        }
    }
}
