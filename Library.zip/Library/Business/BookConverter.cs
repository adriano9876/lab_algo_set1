﻿using Library.Data;
using Library.Presentation;

namespace Library.Business
{
    public class BookConverter
    {
        public BookDto GetBookDto(Book book)
            => new BookDto(book.Author, book.Title, book.YearOfPublication);

        public Book GetBook(BookDto bookDto)
            => new Book(bookDto.Author, bookDto.Title, bookDto.YearOfPublication ?? default);
    }
}