﻿using Library.Presentation;

namespace Library.Data
{
    public class BookRepositoryStatic : BookRepositoryBase
    {
        private static readonly List<Book> Books = new List<Book>();

        public override Task<List<Book>> GetBooksAsync(BookQuery query, CancellationToken cancellationToken)
        {
            ValidateQuery(query);

            var result = new List<Book>();
            result.AddRange(Books);
            result = FilterBooksByQuery(query, result);

            return Task.FromResult(result);
        }

        public override Task<Book> AddBookAsync(Book book, CancellationToken cancellationToken)
        {
            ValidateModel(book);

            Books.Add(book);

            return Task.FromResult(book);
        }

        public override Task<Book> UpdateBookAsync(Book book, CancellationToken cancellationToken)
        {
            ValidateModel(book);

            var savedBook = GetBookFromListByTitleAndAuthor(book, Books);

            savedBook.YearOfPublication = book.YearOfPublication;

            return Task.FromResult(book);
        }

        public override Task<bool> DeleteBookAsync(Book book, CancellationToken cancellationToken)
        {
            ValidateModel(book);

            var savedBook = GetBookFromListByTitleAndAuthor(book, Books);

            var result = Books.Remove(savedBook);

            return Task.FromResult(result);
        }
    }
}
