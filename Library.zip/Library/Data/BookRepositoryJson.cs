﻿using Library.Presentation;
using Newtonsoft.Json;

namespace Library.Data
{
    public class BookRepositoryJson : BookRepositoryBase
    {
        private const string Path = "..\\..\\..\\Data\\Books.json";

        public override async Task<List<Book>> GetBooksAsync(BookQuery query, CancellationToken cancellationToken)
        {
            ValidateQuery(query);

            var savedBooks = await GetSavedItems(cancellationToken);

            var result = new List<Book>();
            result.AddRange(savedBooks.Books);
            result = FilterBooksByQuery(query, result);

            return result;
        }

        public override async Task<Book> AddBookAsync(Book book, CancellationToken cancellationToken)
        {
            ValidateModel(book);

            var savedBooks = await GetSavedItems(cancellationToken);
            savedBooks.Books.Add(book);

            await SaveItems(savedBooks);

            return book;
        }

        public override async Task<Book> UpdateBookAsync(Book book, CancellationToken cancellationToken)
        {
            ValidateModel(book);

            var savedBooks = await GetSavedItems(cancellationToken);
            var savedBook = GetBookFromListByTitleAndAuthor(book, savedBooks.Books);

            savedBook.YearOfPublication = book.YearOfPublication;

            await SaveItems(savedBooks);

            return book;
        }

        public override async Task<bool> DeleteBookAsync(Book book, CancellationToken cancellationToken)
        {
            ValidateModel(book);

            var savedBooks = await GetSavedItems(cancellationToken);
            var savedBook = GetBookFromListByTitleAndAuthor(book, savedBooks.Books);

            var result = savedBooks.Books.Remove(savedBook);

            await SaveItems(savedBooks);

            return result;
        }

        private static async Task<BookCollection> GetSavedItems(CancellationToken cancellationToken)
        {
            using var stream = new StreamReader(Path);
            var jsonString = await stream.ReadToEndAsync(cancellationToken);

            var savedItems = JsonConvert.DeserializeObject<BookCollection>(jsonString);

            if (savedItems?.Books == null)
            {
                throw new Exception("No retrieved data");
            }

            return savedItems;
        }

        private static async Task SaveItems(BookCollection savedBooks)
        {
            var updatedJson = JsonConvert.SerializeObject(savedBooks);

            await using var stream = new StreamWriter(Path);
            await stream.WriteAsync(updatedJson);
        }
    }
}
