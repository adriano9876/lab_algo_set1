﻿namespace Library.Data
{
    public class Book
    {
        public Book(string author, string title, int yearOfPublication)
        {
            this.Author = author;
            this.Title = title;
            this.YearOfPublication = yearOfPublication;
        }

        public int Id { get; set; }

        public string Author { get; set; }

        public string Title { get; set; }

        public int YearOfPublication { get; set; }
    }

    public class BookCollection
    {
        public List<Book> Books { get; set; }
    }
}
