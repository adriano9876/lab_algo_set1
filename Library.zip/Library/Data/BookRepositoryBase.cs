﻿using Library.Presentation;

namespace Library.Data
{
    public abstract class BookRepositoryBase
    {
        public abstract Task<List<Book>> GetBooksAsync(BookQuery query, CancellationToken cancellationToken);

        public abstract Task<Book> AddBookAsync(Book book, CancellationToken cancellationToken);

        public abstract Task<Book> UpdateBookAsync(Book book, CancellationToken cancellationToken);

        public abstract Task<bool> DeleteBookAsync(Book book, CancellationToken cancellationToken);

        protected static void ValidateQuery(BookQuery query)
        {
            if (query == null)
            {
                throw new ArgumentNullException(nameof(query), "Invalid query");
            }
        }

        protected static void ValidateModel(Book book)
        {
            if (book == null)
            {
                throw new ArgumentNullException(nameof(book), "Invalid book");
            }
        }

        protected static List<Book> FilterBooksByQuery(BookQuery query, List<Book> result)
        {
            if (!string.IsNullOrWhiteSpace(query.Title))
            {
                result = result.Where(book => book.Title.ToLower().Trim() == query.Title.ToLower().Trim()).ToList();
            }

            if (!string.IsNullOrWhiteSpace(query.Author))
            {
                result = result.Where(book => book.Author.ToLower().Trim() == query.Author.ToLower().Trim()).ToList();
            }

            return result;
        }

        protected static Book GetBookFromListByTitleAndAuthor(Book book, List<Book> savedBooks)
        {
            var result = savedBooks.FirstOrDefault(
                savedBook => savedBook.Title.ToLower().Trim() == book.Title.ToLower().Trim()
                             && savedBook.Author.ToLower().Trim() == book.Author.ToLower().Trim());

            if (result == null)
            {
                throw new Exception("Book not found");
            }

            return result;
        }
    }
}
