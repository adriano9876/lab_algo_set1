﻿using Library.Business;
using Library.View;

namespace Library.Presentation
{
    public class ConsoleView
    {
        private readonly BookService bookService;
        private FlowChoice? flow;

        public ConsoleView(BookService bookService)
        {
            this.bookService = bookService;
        }

        public async Task OpenMenuAsync(CancellationToken cancellationToken)
        {
            try
            {
                do
                {
                    WriteMenuOptions();

                    var parsedFlow = GetAndValidateFlow();
                    if (parsedFlow == null)
                    {
                        continue;
                    }

                    this.flow = parsedFlow;
                    switch (this.flow)
                    {
                        case FlowChoice.GetBooks:
                            var query = GetBookQuery();
                            var books = await this.bookService.GetBooksAsync(query, cancellationToken);

                            if (books == null || books.Count == 0)
                            {
                                Console.WriteLine("No books saved.");
                            }
                            else
                            {
                                foreach (var book in books)
                                {
                                    Console.WriteLine($"{book.Author} - {book.Title} ({book.YearOfPublication})");
                                }
                            }

                            Console.WriteLine();
                            break;
                        case FlowChoice.AddBook:
                            var createCommand = GetBookCreateCommand();
                            if (createCommand == null)
                            {
                                continue;
                            }

                            await this.bookService.AddBookAsync(createCommand, cancellationToken);

                            Console.WriteLine("Book added successfully");
                            Console.WriteLine();
                            break;
                        case FlowChoice.UpdateBook:
                            var updateCommand = GetBookUpdateCommand();
                            await this.bookService.UpdateBookAsync(updateCommand, cancellationToken);

                            Console.WriteLine("Book updated successfully");
                            Console.WriteLine();
                            break;
                        case FlowChoice.DeleteBook:
                            var deleteCommand = GetBookDeleteCommand();
                            await this.bookService.DeleteBookAsync(deleteCommand, cancellationToken);

                            Console.WriteLine("Book deleted successfully");
                            Console.WriteLine();
                            break;
                        case FlowChoice.Exit:
                        case null:
                        default:
                            break;
                    }
                } while (this.flow != FlowChoice.Exit);

                Environment.Exit(0);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static BookDto GetBookUpdateCommand()
        {
            var (bookTitle, bookAuthor, yearOfPublication) = GetBaseParameters(false, true);

            return new BookDto(bookAuthor, bookTitle, yearOfPublication);
        }

        private static BookDto GetBookCreateCommand()
        {
            var (bookTitle, bookAuthor, yearOfPublication) = GetBaseParameters(false, true);

            return new BookDto(bookAuthor, bookTitle, yearOfPublication);
        }

        private static BookDto GetBookDeleteCommand()
        {
            var (bookTitle, bookAuthor, _) = GetBaseParameters(false, false);

            return new BookDto(bookAuthor, bookTitle, null);
        }

        private static (string bookTitle, string bookAuthor, int? yearofPublication) GetBaseParameters(bool isUpdate, bool isCreate)
        {
            var toBeUpdated = isUpdate ? " to be updated" : string.Empty;

            Console.Write($"Write book title{toBeUpdated}: ");
            var bookTitle = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(bookTitle))
            {
                Console.WriteLine("Invalid title.");
                return default;
            }

            Console.Write($"Write book author{toBeUpdated}: ");
            var bookAuthor = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(bookAuthor))
            {
                Console.WriteLine("Invalid author.");
                return default;
            }

            if (isUpdate || isCreate)
            {
                var newString = isUpdate ? " new" : string.Empty;

                Console.Write($"Write{newString} year of publication: ");
                var parseResult = int.TryParse(Console.ReadLine(), out var yearOfPublication);
                if (!parseResult || yearOfPublication == 0)
                {
                    Console.WriteLine("Invalid year of publication.");
                    return default;
                }

                return (bookTitle, bookAuthor, yearOfPublication);
            }

            return (bookTitle, bookAuthor, null);
        }

        private static BookQuery GetBookQuery()
        {
            Console.Write("Write book title (optional, you can press enter to search without title): ");
            var bookTitle = Console.ReadLine();

            Console.Write("Write book author (optional, you can press enter to search without author): ");
            var bookAuthor = Console.ReadLine();

            return new BookQuery(bookTitle, bookAuthor);
        }

        private static void WriteMenuOptions()
        {
            Console.WriteLine(Environment.NewLine);
            Console.WriteLine("======================== MENU ========================");
            Console.WriteLine("Choose between the following options:");

            foreach (var flow in Enum.GetValues<FlowChoice>())
            {
                Console.WriteLine($"{(int)flow}) {flow.ToString()}");
            }

            Console.WriteLine(Environment.NewLine);
        }

        private static FlowChoice? GetAndValidateFlow()
        {
            try
            {
                var flowParseResult = int.TryParse(Console.ReadLine(), out var parsedIntFlow);
                if (!flowParseResult)
                {
                    throw new ArgumentOutOfRangeException();
                }

                var parsedEnumFlow = (FlowChoice)parsedIntFlow;
                var enumValues = Enum.GetValues<FlowChoice>();
                if (!enumValues.Contains(parsedEnumFlow))
                {
                    throw new ArgumentOutOfRangeException();
                }

                return parsedEnumFlow;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Invalid choice: " + ex.Message);
            }

            return null;
        }
    }
}
