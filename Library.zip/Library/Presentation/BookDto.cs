﻿namespace Library.Presentation
{
    public class BookDto
    {
        public BookDto(string author, string title, int? yearOfPublication)
        {
            this.Author = author;
            this.Title = title;
            this.YearOfPublication = yearOfPublication;
        }

        public string Author { get; }

        public string Title { get; }

        public int? YearOfPublication { get; }
    }
}
