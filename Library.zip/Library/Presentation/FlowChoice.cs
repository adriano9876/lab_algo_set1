﻿namespace Library.View
{
    public enum FlowChoice
    {
        Exit,
        GetBooks,
        AddBook,
        UpdateBook,
        DeleteBook
    }
}
