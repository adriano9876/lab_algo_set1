﻿namespace Library.Presentation
{
    public class BookQuery
    {
        public BookQuery(string title, string author)
        {
            Title = title;
            Author = author;
        }

        public string Title { get; }

        public string Author { get; }
    }
}
