﻿using decathlon_02.Dto;
using decathlon_02.Model;

namespace decathlon_02.DataAccessLayer
{
    public interface IMagazzinoRepository
    {
        public Task<Product> AddProduct(Product toDb); 
        public Task<ICollection<Product>> GetAllProducts();
        public Task<Product> GetProductById(int id);


    }
}
