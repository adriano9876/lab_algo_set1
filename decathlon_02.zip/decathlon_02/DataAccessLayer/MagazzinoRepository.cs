﻿using decathlon_02.DataContext;
using decathlon_02.Model;
using Microsoft.EntityFrameworkCore;

namespace decathlon_02.DataAccessLayer
{
    public class MagazzinoRepository :IMagazzinoRepository 
    {
        private readonly DecathlonContext _context;

        public MagazzinoRepository(DecathlonContext context)
        {
            _context = context;
        }

        public async Task<Product> AddProduct(Product toDb)
        {
            _context.Products.Add(toDb);//.Entity;
            await _context.SaveChangesAsync();
            int a = 88;
            return toDb ;   
        }

        /* --- FUNZIONI IMPLEMENTAZIONE ----*/

        public async Task<ICollection<Product>> GetAllProducts()
        {
            var products = await _context.Products.Include(category => category.Category)
                .AsNoTracking().ToListAsync();
            return products;
        }

        public async Task<Product> GetProductById(int id)
        {
            var toRet = await _context.Products.Include(category => category.Category)
                .AsNoTracking().FirstOrDefaultAsync(p => p.Id == id);
            return toRet;
        }

    }
}
