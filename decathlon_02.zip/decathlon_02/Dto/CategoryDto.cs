﻿using decathlon_02.Model;

namespace decathlon_02.Dto
{
    public class CategoryDto
    {
        public int Id { get; set; }
        public string Name { get; set; }

        //public virtual ICollection<Product> Categories { get; set; }

    }
}
