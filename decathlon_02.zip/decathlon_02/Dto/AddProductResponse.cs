﻿using decathlon_02.Model;
using System.ComponentModel.DataAnnotations.Schema;

namespace decathlon_02.Dto
{
    public class AddProductResponse
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
        public DateOnly DateCreatedProduct { get; set; }
        public bool Availability { get; set; }
        public int Quantity { get; set; }
        public int CategoryId { get; set; }


    }
}
