﻿using decathlon_02.Dto;
using decathlon_02.Model;
using Microsoft.AspNetCore.Mvc;

namespace decathlon_02.BussinessLayer
{
    public interface IMagazzinoService
    {

        public Task<AddProductResponse> AddProduct(ProductDto dto);
        public  Task<ICollection<ProductDto>> GetAllProducts();
        public Task<ProductDto>  GetProductById(int id);
    }

}
