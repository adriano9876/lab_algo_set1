﻿using decathlon_02.DataAccessLayer;
using decathlon_02.Dto;
using decathlon_02.Model;

namespace decathlon_02.BussinessLayer
{
    public class MagazzinoService:IMagazzinoService
    {
        private readonly IMagazzinoRepository _repository;

        public MagazzinoService(IMagazzinoRepository repository)
        {
            _repository = repository;
        }

        public async Task<AddProductResponse> AddProduct(ProductDto dto)
        {
            Product toRepo = new Product
            {
                Name = dto.Name,
                Price = dto.Price,
                DateCreatedProduct = dto.DateCreatedProduct,
                Availability = dto.Availability,
                Quantity = dto.Quantity,
                CategoryId = dto.Category.Id,
                //Category = new Category { 
                //    Id = dto.Category.Id,
                //    Name = dto.Category.Name,        
                //}
            };

            var product = await _repository.AddProduct(toRepo);
            AddProductResponse retToController = new AddProductResponse
            {
                Id = product.Id,
                Name = product.Name,
                Price = product.Price,
                DateCreatedProduct = product.DateCreatedProduct,
                Availability = product.Availability,
                Quantity = product.Quantity,
              
            };
            return retToController;           
        }





        /* --- FUNZIONI IMPLEMENTAZIONE ----*/
        public async Task<ICollection<ProductDto>> GetAllProducts()
        {
            var dtoRetProducts = await _repository.GetAllProducts();
            List<ProductDto> products = dtoRetProducts.Select(p => new ProductDto
            {
                Name = p.Name,
                Id = p.Id,
                Price = p.Price,
                DateCreatedProduct = p.DateCreatedProduct,
                Availability = p.Availability,
                Category = new CategoryDto
                {
                    Name = p.Category.Name,
                    Id = p.Category.Id,
                },
                Quantity = p.Quantity
            }).ToList();

            return products;

        }

        public async Task<ProductDto> GetProductById(int id)
        {
            Product p = await _repository.GetProductById(id);
            if (p == null)
            {
                return null;
            }
            ProductDto toRet = new ProductDto
            {
                Id = p.Id,
                Name = p.Name,
                Price = p.Price,
                DateCreatedProduct = p.DateCreatedProduct,
                Availability = p.Availability,
                Quantity = p.Quantity,
                Category = new CategoryDto
                {
                    Name = p.Category.Name,
                    Id = p.Category.Id,
                }
            };
            return toRet ;
        }

        /* --- FUNZIONI IMPLEMENTAZIONE ----*/



    }


}
