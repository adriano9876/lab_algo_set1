﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace decathlon_02.Migrations
{
    /// <inheritdoc />
    public partial class decatlon_product_quantita : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "Quantity",
                table: "Users",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Quantity",
                table: "Users");
        }
    }
}
