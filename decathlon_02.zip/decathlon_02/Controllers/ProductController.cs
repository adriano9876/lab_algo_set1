﻿using decathlon_02.BussinessLayer;
using decathlon_02.Dto;
using decathlon_02.Model;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace decathlon_02.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly IMagazzinoService _magazzinoService;

        public ProductController(IMagazzinoService magazzinoService)
        {
            _magazzinoService = magazzinoService;
        }


        /* --- FUNZIONI IMPLEMENTAZIONE ----*/

        // GET: api/<ProductController>
        [HttpGet]
        [Route ("prodotti")]
        public async Task<ActionResult<ICollection<ProductDto>>> GetProduts()
        {
            var toRet = await _magazzinoService.GetAllProducts();

            return Ok(toRet);
        }


        // GET api/<ProductController>/5
        [HttpGet("prodotti/{id}")]
        public async Task <ActionResult<ProductDto>> GetByIdProduct(int id)
        {
            var toRet = await _magazzinoService.GetProductById(id);
            if (toRet == null)
            {
                return NotFound();
            }

            return Ok(toRet);
        }

        // POST api/<ProductController>
        [HttpPost]
        public async Task<ActionResult<AddProductResponse>> Post([FromBody] ProductDto dto )
        {
            var toRet = await _magazzinoService.AddProduct(dto);
            if (toRet == null)
            {
                return BadRequest();
            }
            return Ok(toRet); 
        }




        // PUT api/<ProductController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<ProductController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
