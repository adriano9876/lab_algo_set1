﻿using System.Text.Json.Serialization;

namespace decathlon_02.Model
{
    public class Category
    {
        public int Id { get; set; }
        public string Name { get; set; }

        /* ----- */


        /* ----- */
        [JsonIgnore]
        public virtual ICollection<Product> Categories { get; set; }



    }
}
