﻿using System.ComponentModel.DataAnnotations.Schema;

namespace decathlon_02.Model
{
    public class Product
    {
        public int Id { get; set; }
        public string Name { get; set; }

        [Column (TypeName = "Decimal(18,2)")]
        public decimal Price { get; set; }
        public DateOnly DateCreatedProduct { get; set; }
        public bool Availability { get; set; }
        public int Quantity { get; set; }


        /* ----- */
        public int CategoryId { get; set; }
        /* ----- */
        public virtual Category Category { get; set; }

    }
}
