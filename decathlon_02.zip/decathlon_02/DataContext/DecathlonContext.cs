﻿using decathlon_02.Model;
using Microsoft.EntityFrameworkCore;

namespace decathlon_02.DataContext
{
    public class DecathlonContext : DbContext
    {
        public DecathlonContext(DbContextOptions<DecathlonContext> options) : base(options) { }

        public virtual DbSet<Product> Products { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            modelBuilder.Entity<Category>().HasData(
            new Category() {
            Id = 1,
            Name = "bello"
            },
            new Category() {
            Id = 2,
            Name = "brutto"
            },
            new Category() {
            Id = 3,
            Name = "costoso"
            }                  
            ) ;

            modelBuilder.Entity<Product>().HasData(

            new Product()
            {
            Id = 1,
            Name = "samsung 10",
            Price = 1999,
            DateCreatedProduct = new DateOnly(2020, 1, 1),
            Availability = true,
            Quantity = 0,
            CategoryId = 1,
            },
            new Product()
            {
            Id = 2,
            Name = "iphone 10",
            Price = 2999,
            DateCreatedProduct = new DateOnly(2020, 1, 1),
            Availability = true,
            Quantity = 0,
            CategoryId = 1,
            },
            new Product()
            {
            Id = 3,
            Name = "nokia 10",
            Price = 3999,
            DateCreatedProduct = new DateOnly(2020, 1, 1),
            Availability = true,
            Quantity = 0,
            CategoryId = 2
            },
            new Product()
            {
            Id = 4,
            Name = "htc 10",
            Price = 4999,
            DateCreatedProduct = new DateOnly(2020, 1, 1),
            Availability = true,
            Quantity = 0,
            CategoryId = 2
            }
            );







        }

    }



}



