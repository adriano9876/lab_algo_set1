﻿
using Pegasus.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pegasus.DataAccessLayer
{
    public interface IPatientRepository
    {
        Patient GetPatient(string taxCode);
        MedicalRecord GetMedicalRecord(long medicalRecordNr);
        bool InsertPatient(Patient patient);
        bool InsertMedicalRecord(MedicalRecord medicalRecord);
        void RemoveMedicalRecord(long medicalRecordNr);
        List<Patient> GetAllPatients();
        void UpsertMedicalRecord(MedicalRecord medicalRecord);
        List<MedicalRecord> GetAllMedicalRecords();
    }
}
