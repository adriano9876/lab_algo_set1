﻿using Pegasus.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pegasus.DataAccessLayer
{
    public interface IStaffRepository<T> where T : StaffMember
    {
        T GetStaffMember(long staffId);
        void InsertStaffMember(T staffMember);
    }
}
