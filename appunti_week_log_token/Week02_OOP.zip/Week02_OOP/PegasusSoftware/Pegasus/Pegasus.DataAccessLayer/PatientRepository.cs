﻿using Pegasus.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pegasus.DataAccessLayer
{

    public class PatientRepository: IPatientRepository
    {
        private Dictionary<string, Patient> patients;
        private Dictionary<long, MedicalRecord> medicalRecords;

        public PatientRepository(Dictionary<string, Patient> patients, Dictionary<long, MedicalRecord> medicalRecords)
        {
            this.patients = patients;
            this.medicalRecords = medicalRecords;
        }
        public PatientRepository()
        {
            patients = new();
            medicalRecords = new();
        }
        public Patient GetPatient(string taxCode)
        {
            return patients[taxCode];
        }
        public MedicalRecord GetMedicalRecord(long medicalRecordNr)
        {
            return medicalRecords[medicalRecordNr];
        }
        public bool InsertPatient(Patient patient)
        {
            patients.Add(patient.TaxCode, patient);
            return true;
        }
        public bool InsertMedicalRecord(MedicalRecord medicalRecord)
        {
            medicalRecords.Add(medicalRecord.MedicalRecordNr, medicalRecord);
            return true;
        }
        public void UpsertMedicalRecord(MedicalRecord medicalRecord)
        {
            medicalRecords[medicalRecord.MedicalRecordNr] = medicalRecord;
        }

        public void RemoveMedicalRecord(long medicalRecordNr)
        {
            medicalRecords.Remove(medicalRecordNr);
        }

        public List<Patient> GetAllPatients()
        {
            return patients.Values.ToList();
        }

        public List<MedicalRecord> GetAllMedicalRecords()
        {
            return medicalRecords.Values.ToList();
        }
    }
}
