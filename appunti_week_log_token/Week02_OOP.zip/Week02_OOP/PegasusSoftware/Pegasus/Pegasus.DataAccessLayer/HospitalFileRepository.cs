﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace Pegasus.DataAccessLayer
{
    public class HospitalFileRepository<T,K>
    {
        private readonly string _filename;

        public HospitalFileRepository()
        {
            _filename = $"../../../../{typeof(T).Name}.json";
        }

        public Dictionary<K, T> GetAll()
        {
            using FileStream fileStream = new FileStream(_filename, FileMode.OpenOrCreate, FileAccess.Read);
            using StreamReader reader = new StreamReader(fileStream);

            string content = reader.ReadToEnd();
            if (!string.IsNullOrEmpty(content))
            {
                return JsonConvert.DeserializeObject<Dictionary<K, T>>(content) ?? new Dictionary<K, T>();
            }

            return new Dictionary<K, T>();
        }

        public void Save(Dictionary<K , T> entity)
        {
            using FileStream fileStream = new FileStream(_filename, FileMode.OpenOrCreate, FileAccess.Write);
            using StreamWriter writer = new StreamWriter(fileStream);

            string content = JsonConvert.SerializeObject(entity, new JsonSerializerSettings { Formatting = Formatting.Indented });
            writer.Write(content);
            writer.Flush();
            fileStream.SetLength(fileStream.Position); // Truncate the file to the current position
        }
    }
}
