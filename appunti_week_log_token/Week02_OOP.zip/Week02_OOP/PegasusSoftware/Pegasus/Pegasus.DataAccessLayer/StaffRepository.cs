﻿using Pegasus.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pegasus.DataAccessLayer
{
    public class StaffRepository<T> : IStaffRepository<T> where T: StaffMember
    {
        private Dictionary<long, T> staffMembers;
        public StaffRepository()
        {
            staffMembers = new();
        }

        public StaffRepository(Dictionary<long, T> staffMembers)
        {
            this.staffMembers = staffMembers;
        }

        public T GetStaffMember(long doctorId)
        {
            return staffMembers[doctorId];
        }

        public void InsertStaffMember(T staff)
        {
            staffMembers.Add(staff.StaffId, staff);
        }


    }
}
