﻿using Pegasus.DataAccessLayer;
using Pegasus.Entities;
using System.Text;

namespace Pegasus.BusinessLayer
{
    public class PatientService: IPatientService
    {
        private IPatientRepository _patientRepository;
        public PatientService(IPatientRepository patientRepository)
        {
            _patientRepository = patientRepository;
        }

        public Patient GetPatient(string taxCode)
        {
            return _patientRepository.GetPatient(taxCode);
        }

        public MedicalRecord GetMedicalRecordFromPatient(string taxCode)
        {
            var patient = _patientRepository.GetPatient(taxCode);
            return _patientRepository.GetMedicalRecord(patient.MedicalRecordNr);
        }
        public void UpsertDailyTherapy(string patientTaxCode, Medicine medicine, TimeOnly time)
        {
            var medicalRecord = GetMedicalRecordFromPatient(patientTaxCode);
            medicalRecord.DailyTherapy[time] = medicine;
        }
        public void InsertNewPatient(Patient patient)
        {
            var medicalRecord = new MedicalRecord(patient.MedicalRecordNr);

            var resultOperation1 = _patientRepository.InsertMedicalRecord(medicalRecord);
            if (resultOperation1)           
            {
                var resultOperation2 = _patientRepository.InsertPatient(patient);
                if (!resultOperation2)
                {
                    _patientRepository.RemoveMedicalRecord(medicalRecord.MedicalRecordNr);
                }
            }      
        }

        public string GetAllPatientsOverview()
        {
            var patients = _patientRepository.GetAllPatients();
            StringBuilder strBuilder = new();
            foreach (var patient in patients)
            {
                //errato! responsabilità?
                strBuilder.AppendLine(patient.ToString());
            }
            return strBuilder.ToString();
        }

        public void AdministrateTherapy(string patientTaxCode, Medicine medicine)
        {
            var medicalRecord = GetMedicalRecordFromPatient(patientTaxCode);
            medicalRecord.AdministrationLog.Add(DateTime.Now, medicine);
        }

    }
}
