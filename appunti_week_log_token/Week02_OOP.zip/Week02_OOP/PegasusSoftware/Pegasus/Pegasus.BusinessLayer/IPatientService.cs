﻿using Pegasus.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pegasus.BusinessLayer
{
    public interface IPatientService
    {
        public Patient GetPatient(string taxCode);
        public void InsertNewPatient(Patient patient);
        string GetAllPatientsOverview();
        MedicalRecord GetMedicalRecordFromPatient(string taxCode);
        void UpsertDailyTherapy(string patientTaxCode, Medicine medicine, TimeOnly time);
        void AdministrateTherapy(string patientTaxCode, Medicine medicine);
    }
}
