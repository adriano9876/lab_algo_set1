﻿using Pegasus.DataAccessLayer;
using Pegasus.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pegasus.BusinessLayer
{
    public class StaffService<T>: IStaffService<T> where T: StaffMember
    {
        private IStaffRepository<T> _staffRepository;
        public StaffService(IStaffRepository<T> staffRepository)
        {
            _staffRepository = staffRepository;
        }
        public T GetStaff(long id)
        {
            return _staffRepository.GetStaffMember(id);
        }
        public void InsertNewStaff(T staffMember)
        {
            _staffRepository.InsertStaffMember(staffMember);
        }
    }
}
