﻿using Pegasus.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pegasus.BusinessLayer
{
    public interface IStaffService<T>
    {
        public T GetStaff(long id);
        public void InsertNewStaff(T staff);
    }
}
