﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pegasus.Entities.Enums
{
    public enum PatientStatus
    {
        InCura,
        Dimesso,
        Deceduto
    }
}
