﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pegasus.Entities
{
    public class MedicalRecord
    {
        public long MedicalRecordNr { get; set; }
        public SortedList<TimeOnly, Medicine> DailyTherapy { get; set; }
        public SortedList<DateTime, Medicine> AdministrationLog { get; set; }
        public MedicalRecord(long medicalRecordNr)
        {
            DailyTherapy = new();
            AdministrationLog = new();
            MedicalRecordNr = medicalRecordNr;
        }
        //public void AssignMedicalRecordNr(long medicalRecordNr)
        //{
        //    if(MedicalRecordNr == -1)
        //    {
        //        MedicalRecordNr = medicalRecordNr;
        //    }
        //}
    }
}
