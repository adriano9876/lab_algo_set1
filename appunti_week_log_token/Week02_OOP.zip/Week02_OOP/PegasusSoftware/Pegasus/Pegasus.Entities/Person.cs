﻿namespace Pegasus.Entities
{
    public abstract class Person
    {
        public Person(string name, string surname, DateTime dateOfBirth, string taxCode)
        {
            Name = name;
            Surname = surname;
            DateOfBirth = dateOfBirth;
            TaxCode = taxCode;
        }

        public string Name { get; set; }
        public string Surname { get; set; }
        public DateTime DateOfBirth { get; private set; }
        public string TaxCode { get; private set; }

        public override string ToString()
        {
            return $"Nome: {Name} Cognome: {Surname} Codice fiscale: {TaxCode}";
        }
    }
}
