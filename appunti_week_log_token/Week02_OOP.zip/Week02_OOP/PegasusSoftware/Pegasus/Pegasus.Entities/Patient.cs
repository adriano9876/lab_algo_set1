﻿using Pegasus.Entities.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pegasus.Entities
{
    public class Patient : Person
    {
        public long MedicalRecordNr { get; set; }
        public Ward Ward { get; private set; }
        public PatientStatus PatientStatus { get; set; }
        public Patient(string name, string surname, DateTime dateOfBirth, string taxCode, int medicalRecordNr = -1) : base(name, surname, dateOfBirth, taxCode)
        {
            MedicalRecordNr = medicalRecordNr;
        }
        public override string ToString()
        {
            return base.ToString() + $"\nNumero di cartella clinica: {MedicalRecordNr}";
        }
        //public void ManualAssignMedicalRecordNumber (int medicalRecordNr)
        //{
        //    MedicalRecordNr = medicalRecordNr;
        //}
    }
}
