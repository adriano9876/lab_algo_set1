﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pegasus.Entities
{
    public abstract class StaffMember: Person
    {
        protected StaffMember(string name, string surname, DateTime dateOfBirth, string taxCode, decimal salary, long staffId) : base(name, surname, dateOfBirth, taxCode)
        {
            StaffId = staffId;
            Salary = salary;
        }

        public long StaffId { get; private set; }
        public decimal Salary { get; set; }

        //public void AssignStaffId(long staffId)
        //{
        //    if(StaffId == -1)
        //    {
        //        StaffId = staffId;
        //    }
        //}
    }
}
