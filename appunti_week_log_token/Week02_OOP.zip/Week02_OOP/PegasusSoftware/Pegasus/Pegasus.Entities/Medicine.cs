﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pegasus.Entities
{
    public class Medicine
    {
        public Medicine(string activeEngriedent, double dosage)
        {
            Random rnd = new Random();
            BarCode = rnd.Next(1000, 9999);
            ActiveEngriedent = activeEngriedent;
            Dosage = dosage;
        }

        public int BarCode { get; private set; }
        public string ActiveEngriedent { get; private set; }
        public double Dosage { get; set; }
    }
}
