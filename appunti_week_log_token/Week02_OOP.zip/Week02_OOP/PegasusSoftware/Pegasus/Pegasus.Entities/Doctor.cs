﻿using Pegasus.Entities.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pegasus.Entities
{
    public class Doctor: StaffMember 
    {
        public string Specialty { get; private set; }
        public Ward Ward { get; private set; }
        public Doctor(string name, string surname, DateTime dateOfBirth, string taxCode, decimal salary, string specialty, long staffId) : 
            base(name, surname, dateOfBirth, taxCode, salary, staffId)
        {
            Specialty = specialty;
        }
    }
}
