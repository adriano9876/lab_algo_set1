﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pegasus.Entities
{
    public class Administrator : StaffMember
    {
        public Administrator(string name, string surname, DateTime dateOfBirth, string taxCode, decimal salary, long staffId) : 
            base(name, surname, dateOfBirth, taxCode, salary, staffId)
        {
        }
    }
}
