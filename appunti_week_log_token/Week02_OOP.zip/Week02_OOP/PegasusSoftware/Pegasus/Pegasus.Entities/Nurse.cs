﻿using Pegasus.Entities.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pegasus.Entities
{
    public class Nurse: StaffMember
    {
        public Nurse(string name, string surname, DateTime dateOfBirth, string taxCode, decimal salary, PatientStatus instensityLevel, long staffId) : 
            base(name, surname, dateOfBirth, taxCode, salary, staffId)
        {
            IntensityLevel = instensityLevel;
        }

        public PatientStatus IntensityLevel { get; set; }
        public Ward Ward { get; private set; }
    }
}
