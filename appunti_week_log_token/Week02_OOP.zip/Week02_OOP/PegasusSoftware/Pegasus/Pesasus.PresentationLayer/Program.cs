﻿using Pegasus.BusinessLayer;
using Pegasus.DataAccessLayer;
using Pegasus.Entities;
using Pegasus.Entities.Enums;
using System.Text;

internal class Program
{
    private static IStaffService<Doctor> _doctorService;
    private static IStaffService<Nurse> _nurseService;
    private static IStaffService<Administrator> _administratorService;
    private static IPatientService _patientService;
    private static void Main(string[] args)
    {
        InitializeDependencyInv();
        bool running = true;
        while (running)
        {
            Console.Clear();
            Console.WriteLine("=== MENU PRINCIPALE ===");
            Console.WriteLine("Accedi al portale come:");
            Console.WriteLine("[m] Medico");
            Console.WriteLine("[i] Infermiere");
            Console.WriteLine("[admin] Amministratore");
            Console.Write("Scelta: ");

            string scelta = Console.ReadLine().ToLower().Trim();

            switch (scelta)
            {
                case "m":
                    var doctorId = InsertId();
                    var doctor = _doctorService.GetStaff(doctorId);
                    Console.WriteLine("Autenticato!");
                    bool continueDoc = true;
                    while (continueDoc)
                    {
                        DoctorMenu();
                    }              
                    Console.WriteLine(_patientService.GetAllPatientsOverview());
                    break;
                case "n":
                    var nurseId = InsertId();
                    var nurse = _nurseService.GetStaff(nurseId);
                    Console.WriteLine("Autenticato!");
                    bool continueNurse = true;
                    while (continueNurse)
                    {
                        DoctorMenu();
                    }

                    Console.WriteLine(_patientService.GetAllPatientsOverview());
                    break;
                case "admin":
                    AdminMenu();
                    break;
                default:
                    Console.WriteLine("Scelta non valida.");
                    Console.ReadKey();
                    break;
            }
            Console.WriteLine("Vuoi chiudere l'applicazione? y/n");
            var closeChoice = Console.ReadLine();
            if(closeChoice == "y")
            {
                running = false;
            }
        }
        //hospitalRepository.SaveAllOnFile();
    }

    private static bool DoctorMenu()
    {
        Console.WriteLine("Cosa vuoi fare? ");
        Console.WriteLine("[1] Lista di tutti i pazienti");
        Console.WriteLine("[2] Inserire o aggiornare un farmaco");
        Console.WriteLine("[3] Somministrare un farmaco");
        Console.WriteLine("[q] Uscire dal menù");
        var choice = Console.ReadLine().ToLower().Trim();
        switch (choice)
        {
            case "1":
                Console.WriteLine(_patientService.GetAllPatientsOverview());
                break;
            case "2":
                Console.WriteLine("Inserire il codice fiscale del paziente per cui si vuole cambiare la terapia giornaliera: ");
                string taxCode = Console.ReadLine();

                Console.WriteLine($"===Terapia attuale===");

                var patientMedicalRecord = _patientService.GetMedicalRecordFromPatient(taxCode);
                FormatDailyTherapyForOverview(patientMedicalRecord);

                Console.WriteLine("Inserire il principio attivo del nuovo farmaco: ");
                string activeIngredient = Console.ReadLine();

                Console.WriteLine("Inserire il dosaggio: ");
                double dosage = double.Parse(Console.ReadLine());
                Medicine medicine = new Medicine(activeIngredient, dosage);

                Console.WriteLine("Inserire l'orario di somministrazione: (formato hh:mm)");
                TimeOnly time = TimeOnly.Parse(Console.ReadLine());

                _patientService.UpsertDailyTherapy(taxCode, medicine, time);
                break;
            case "3":
                Console.WriteLine("Inserire il codice fiscale del paziente per cui si vuole somministrare una terapia");
                taxCode = Console.ReadLine();

                Console.WriteLine("Inserire il principio attivo del nuovo farmaco: ");
                activeIngredient = Console.ReadLine();

                Console.WriteLine("Inserire il dosaggio: ");
                dosage = double.Parse(Console.ReadLine());
                medicine = new Medicine(activeIngredient, dosage);

                _patientService.AdministrateTherapy(taxCode, medicine);
                break;
            case "q":
                return false;
            default:
                break;

        }
        return true;
    }

    private static void FormatDailyTherapyForOverview(MedicalRecord patientMedicalRecord)
    {
        StringBuilder strBuilder = new();
        foreach (var dailyMedicine in patientMedicalRecord.DailyTherapy)
        {
            strBuilder.AppendLine($"Time: {dailyMedicine.Key.ToShortTimeString()}, {dailyMedicine.Value.ActiveEngriedent} {dailyMedicine.Value.Dosage} mg");
        }
        Console.WriteLine(strBuilder.ToString());
    }

    private static long InsertId()
    {
        Console.WriteLine("Inserisci il tuo ID: ");
        return long.Parse(Console.ReadLine());
    }

    private static void AdminMenu()
    {
        Console.WriteLine("Cosa vuoi fare? ");
        Console.WriteLine("[1] Inserisci un nuovo medico");
        Console.WriteLine("[2] Inserisci un nuovo infermiere");
        var choice = Console.ReadLine().ToLower().Trim();
        switch (choice)
        {
            case "1":
                var doctor = RequestDoctorInformations();
                _doctorService.InsertNewStaff(doctor);
                Console.WriteLine($"Medico inserito!, id: {doctor.StaffId}");
                break;
            case "2":
                var patient = RequestPatientInformations();
                _patientService.InsertNewPatient(patient);
                Console.WriteLine($"Paziente inserito!, numero cartella clinica: {patient.MedicalRecordNr}");
                break;
        }

    }

    private static Patient RequestPatientInformations()
    {
        Console.WriteLine("=== INSERIMENTO NUOVO PAZIENTE ===");

        Console.Write("Nome: ");
        string name = Console.ReadLine();

        Console.Write("Cognome: ");
        string surname = Console.ReadLine();

        Console.Write("Data di nascita (dd/MM/yyyy): ");
        DateTime dateOfBirth;
        while (!DateTime.TryParse(Console.ReadLine(), out dateOfBirth))
        {
            Console.Write("Formato non valido. Inserisci di nuovo (dd/MM/yyyy): ");
        }

        Console.Write("Codice Fiscale: ");
        string taxCode = Console.ReadLine();

        Patient patient = new Patient(name, surname, dateOfBirth, taxCode);

        return patient;
    }
    private static Doctor RequestDoctorInformations()
    {
        Console.WriteLine("=== INSERIMENTO NUOVO MEDICO ===");

        Console.Write("Nome: ");
        string name = Console.ReadLine();

        Console.Write("Cognome: ");
        string surname = Console.ReadLine();

        Console.Write("Data di nascita (dd/MM/yyyy): ");
        DateTime dateOfBirth;
        while (!DateTime.TryParse(Console.ReadLine(), out dateOfBirth))
        {
            Console.Write("Formato non valido. Inserisci di nuovo (dd/MM/yyyy): ");
        }

        Console.Write("Codice Fiscale: ");
        string taxCode = Console.ReadLine();

        Console.Write("Stipendio: ");
        decimal salary;
        while (!decimal.TryParse(Console.ReadLine(), out salary))
        {
            Console.Write("Valore non valido. Inserisci uno stipendio valido: ");
        }

        Console.Write("Specializzazione: ");
        string specialty = Console.ReadLine();

        Console.WriteLine("Inserisci lo staff id: ");
        var staffId = long.Parse(Console.ReadLine());
        Doctor doctor = new Doctor(name, surname, dateOfBirth, taxCode, salary, specialty, staffId);

        return doctor;
    }



    private static void InitializeDependencyInv()
    {
        IPatientRepository patientRepository = new PatientRepository();
        IStaffRepository<Doctor> doctorRepository = new StaffRepository<Doctor>();
        IStaffRepository<Nurse> nurseRepository = new StaffRepository<Nurse>();
        IStaffRepository<Administrator> administratorRepository = new StaffRepository<Administrator>();

        _doctorService = new StaffService<Doctor>(doctorRepository);
        _nurseService = new StaffService<Nurse>(nurseRepository);
        _administratorService = new StaffService<Administrator>(administratorRepository);
        _patientService = new PatientService(patientRepository);
    }
}