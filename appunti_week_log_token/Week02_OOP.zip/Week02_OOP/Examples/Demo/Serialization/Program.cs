﻿using System.Text.Json;
using System.Xml;
using System.Xml.Serialization;

namespace Serialization
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Meteo meteoOggi = new Meteo()
            {
                Temperature = new List<float> { 23, 22.5f, 26.7f, 27.2f, 29.4f },
                Status = TipoMeteo.Sole,
                PercUmidità = 78,
                Uv = 7,
                DataMeteo = DateTime.Now
            };
            string meteoOggiXml;
            XmlSerializer serializer = new XmlSerializer(typeof(Meteo));
            var stringWriter = new StringWriter();
            //solo per indendare più carino
            XmlWriterSettings settings = new XmlWriterSettings
            {
                Indent = true,
                IndentChars = "\t",
                NewLineChars = "\n",
                NewLineHandling = NewLineHandling.Replace
            };

            using (var writer = XmlWriter.Create(stringWriter, settings))
            {
                serializer.Serialize(writer, meteoOggi);
                meteoOggiXml = stringWriter.ToString();
            }
            //Console.WriteLine(meteoOggiXml);
            //serializziamo in JSON
            var options = new JsonSerializerOptions { WriteIndented = true };
            var meteoJson = JsonSerializer.Serialize(meteoOggi, options);
            Console.WriteLine(meteoJson);
        }
    }
    public class Meteo
    {
        public List<float> Temperature { get; set; }
        public TipoMeteo Status { get; set; }
        public int PercUmidità { get; set; }
        public int Uv { get; set; }
        public DateTime DataMeteo{get; set;}
    }
    public enum TipoMeteo
    {
        Sole,
        Pioggia,
        Tempesta,
        Nebbia,
        Neve
    }
}
