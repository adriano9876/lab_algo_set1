﻿using System.Text;

namespace PrintD
{
    internal class Program
    {
        static void Main(string[] args)
        {
            bool parsed = int.TryParse(args[0], out int height);
            bool parsed2 = int.TryParse(args[1], out int width);
            string letter = Console.ReadLine();

            for (int i = 0; i < height; i++)
            {
                    if(i == 0 || i == height - 1)
                    {
                        Console.WriteLine(string.Concat(Enumerable.Repeat(letter, width-2)));
                    }
                    else if( i == 1 || i == height - 2)
                    {
                        Console.WriteLine(letter + new string(' ', width - 1) + letter);
                    }
                    else
                    {
                        Console.WriteLine(letter + new string(' ', width) + letter);
                    }
            }

        }
    }
}
