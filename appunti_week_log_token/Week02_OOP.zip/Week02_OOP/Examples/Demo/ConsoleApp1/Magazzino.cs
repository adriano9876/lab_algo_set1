﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class MagazzinoMedicine
    {
        List<string> medicine;
        public MagazzinoMedicine()
        {
            medicine = new();
        }

        public void AggiungiMedicina (string medicina)
        {
            medicine.Add(medicina);
        }
        public List<string> GetAllElements()
        {
            return medicine;
        }
    }
    public class MagazzinoLibri
    {
        List<string> libri;
        public MagazzinoLibri()
        {
            libri = new();
        }

        public void AggiungiMedicina(string libro)
        {
            libri.Add(libro);
        }
        public List<string> GetAllElements()
        {
            return libri;
        }
    }
}
