﻿namespace ConsoleApp1
{
    internal class Medicina
    {
    }
}