﻿namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Inserisci la tua età");
            var etàStr = Console.ReadLine();
            //var età = int.Parse(etàStr);
            int età;
            var parseSuccess = int.TryParse(etàStr, out età);
            if(parseSuccess && età > 18 )
            {
                Console.WriteLine("Maggiorenne");
            }

            var res = Cose(45, out double metà);
            Console.Read();
        }

        public static bool Cose(int num, out double metà)
        {
            metà = num / 2;
            return num % 2 == 0;
        }
    }
}
