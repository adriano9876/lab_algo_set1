﻿namespace Ex_ArrayLista
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
        }
    }

    public class ArrayLista<T>
    {
        private T[] _array;
        public ArrayLista()
        {
            _array = new T[10];
        }

        public ArrayLista(T[] array)
        {
            if(array.Length == 0)
            {
                this();
            }
            else
            {
                _array = array;
            }
        }
    }
}
