﻿namespace ExtensionMethod
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Inserisci un frase :)");
            var frase = Console.ReadLine();
            var parole = frase.SentenceSplitter();
            foreach(var parola in parole)
            {
                Console.WriteLine(parola);
            }
        }
    }
}
