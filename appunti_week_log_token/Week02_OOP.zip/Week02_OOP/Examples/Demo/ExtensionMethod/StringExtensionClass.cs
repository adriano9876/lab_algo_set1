﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtensionMethod
{
    public static class StringExtensionClass
    {
        public static string[] SentenceSplitter(this string sentence)
        {
            var words = sentence.Split(' ', ',', ';', '.', '\n', '\t', '\r', '?', '!'); //e chi più ne ha più ne metta
            return words;
        }
    }
}
