﻿namespace EccezioniExample
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Albero albero = new Albero();
            albero.Alberazione();

            Console.WriteLine("NON SONO ESPLODUTO");
        }
    }

    public class Albero
    {
        public void Alberazione()
        {
            //try
            //{
                Mattone.Mattonazione(out int num);
            //}
            //catch (DivideByZeroException dbzex)
            //{
            //    //codice che gestisce l'eccezione 
            //    Console.WriteLine("STO GESTENDO L'ECCEZIONIO");
            //}
            Console.WriteLine(num);
        }
    }
    
    public static class Mattone
    {
        public static void Mattonazione(out int num)
        {
            try
            {
                Utilities.SonoUtile();
            }
            catch(ArgumentException dbzex)
            {
                Console.WriteLine(dbzex.Message); 
            }
            finally
            {
                Console.WriteLine("Inserisci un numero");
                var strnum = Console.ReadLine();
                num = int.Parse(strnum);
            }

        }
    }

    public static class Utilities
    {
        public static void SonoUtile()
        {
            throw new DivideByZeroException();
        }
    }
}
