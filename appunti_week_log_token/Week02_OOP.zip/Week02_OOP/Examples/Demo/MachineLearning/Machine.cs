﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MachineLearning
{
    public class Machine
    {
        public event EventHandler MotoreFuoriGiri;
        public event EventHandler MotoreSpento;

        private int _numeroGiri;
        public bool EngineOn { get; set; }
        public Machine()
        {
            _numeroGiri = 0;
            EngineOn = false;
        }

        public void Start()
        {
            _numeroGiri = 800;
            EngineOn = true;
        }

        public void Accelerate()
        {
            if(EngineOn)
            {
                _numeroGiri += 100;
            }
        }

        public void Decelerate()

        {
            if (!EngineOn)
            {
                return;
            }
            _numeroGiri -= 100;
            if(_numeroGiri <= 300)
            {
                _numeroGiri = 0;
                EngineOn = false;
                OnMotoreSpento();
            }

        }

        private void OnMotoreSpento()
        {
            if (MotoreSpento != null)
            {
                MotoreSpento.Invoke(this, EventArgs.Empty);
            }
        }
    }
}
