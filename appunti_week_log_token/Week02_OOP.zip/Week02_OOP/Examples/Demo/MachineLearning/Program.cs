﻿namespace MachineLearning
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
            //public event TipoDelegato NomeEvento
            //delegato può essere Action Func Pred o EventHandler

            //public delegate void EventHandler(Object sender, EventArgs e);

            Machine tardis = new Machine();
            Machine pippo = new Machine();

            CarMonitor tardisMonitor = new(tardis);
            tardisMonitor.RegisterEvent(pippo);

            tardis.Start();

            while (true)
            {
                pippo.Decelerate();
            }
        }
    }
}
