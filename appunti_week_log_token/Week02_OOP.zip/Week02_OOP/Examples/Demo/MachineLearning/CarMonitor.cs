﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MachineLearning
{
    public class CarMonitor
    {
        //private Machine _toyota;
        public CarMonitor(Machine toyota)
        {
            //_toyota = toyota;
            toyota.MotoreSpento += HandleMotoreSpento;
        }

        private void HandleMotoreSpento(Object sender, EventArgs e)
        {
            Machine macchina = (Machine)sender;
            Console.WriteLine("Il motore si è spento, riavvio in corso");
            macchina.Start();
        }

        public void RegisterEvent(Machine machine)
        {
            machine.MotoreSpento += HandleMotoreSpento;
        }
    }
}
