﻿using System.Diagnostics.CodeAnalysis;

namespace ExceptionX
{
    public struct Point
    {
        public int x;
        public int y;
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Sto per bombare...\n\n");
            TestClass tsClass = new();

            tsClass.Method();


            //try
            //{
            //    tsClass.Method();
            //}
            //catch(Exception ex)
            //{
            //    Console.WriteLine( ex.ToString());
            //}
            //List<int> list = new List<int>();
            //list.Where(w => w % 2);

        }
    }
}
