﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionX
{
    public class TestClass
    {
        public string Member { get; set; }
        public TestClass(string member)
        {
            Member = member;
        }
        public TestClass()
        {
            
        }
        public void Method()
        {
            var c= Member.Split(',');
        }
    }
}
