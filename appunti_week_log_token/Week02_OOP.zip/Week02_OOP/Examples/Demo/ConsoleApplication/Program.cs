﻿namespace ConsoleApplication
{
    internal class Program
    {
        //cd source\repos\Academy5Week2\Test\ConsoleApplication
        //dotnet run param1 param2 param3
        static void Main(string[] args)
        {
            int i = 43;
            Console.WriteLine(i++);
            var f = i;
            Console.WriteLine(f);
            foreach(var arg in args)
            {
                Console.WriteLine(arg);
            }
        }
    }
}
