﻿using MoviesLinqPlayground;
using MoviesLinqPlayground.Exercises;

namespace Academy.Week3.Demo.Exercises
{
    internal class Linq
    {
        internal static void Start()
        {
            var db = new InMemoryDb();
            db.SeedSample();

            Console.WriteLine("MoviesLinqPlayground ready. Try calling exercises, e.g.:");

            // Examples
            var ex1 = Ex01.Titles_Method(db.Movies);
            Console.WriteLine("Ex01 titles (method): " + string.Join(", ", ex1));

            var ex8 = Ex08.UserMovieStars_Query(db.Users, db.Movies, db.Ratings);
            foreach (var row in ex8)
                Console.WriteLine($"Ex08 (query): {row}");

            Console.WriteLine("Done.");
        }
    }
}
