﻿using System.Collections.Concurrent;
using System.Diagnostics;
using System.Threading.Tasks;

namespace Academy.Week3.Demo.Exercises
{
    public sealed class HorseFinishedEventArgs : EventArgs
    {
        public HorseFinishedEventArgs(string name, TimeSpan elapsed)
        {
            Name = name;
            Elapsed = elapsed;
        }
        public string Name { get; }
        public TimeSpan Elapsed { get; }
    }

    public sealed class HorseFailedEventArgs : EventArgs
    {
        public HorseFailedEventArgs(string name) => Name = name;
        public string Name { get; }
    }

    /// <summary>
    /// Simulates a horse race using Tasks. Each horse:
    /// - Picks a random duration (1..10 seconds)
    /// - Has a 20% chance to fail early
    /// - Raises events on finish or failure
    /// </summary>
    public sealed class HorseRace
    {
        public HorseRace()
        {
        }

        public event EventHandler<HorseFinishedEventArgs>? HorseFinished;
        public event EventHandler<HorseFailedEventArgs>? HorseFailed;

        public async Task RunAsync(
            IEnumerable<string> horseNames,
            CancellationToken cancellationToken = default)
        {
            if (horseNames == null)
                throw new ArgumentNullException(nameof(horseNames));

            List<string> names = horseNames
                .Where(n => !string.IsNullOrWhiteSpace(n))
                .Select(n => n.Trim())
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToList();

            if (names.Count == 0)
                throw new ArgumentException("No valid horse names provided.", nameof(horseNames));

            var tasks = names.Select(name => Task.Run(async () =>
            {
                try
                {
                    cancellationToken.ThrowIfCancellationRequested();

                    int runSeconds = Random.Shared.Next(1, 11);      // 1..10
                    bool willFail = Random.Shared.NextDouble() < 0.20; // 20%

                    if (willFail)
                    {
                        // Fail at a random point before full duration
                        int failMs = runSeconds * 1000;
                        await Task.Delay(failMs, cancellationToken);
                        RaiseFailed(name);
                        return;
                    }

                    await Task.Delay(TimeSpan.FromSeconds(runSeconds), cancellationToken);

                    RaiseFinished(name, TimeSpan.FromSeconds(runSeconds));
                }
                catch (OperationCanceledException)
                {
                    // Consider cancellation as retirement (optional). Here we report as failure.
                    RaiseFailed(name + " (canceled)");
                }
            }, cancellationToken)).ToArray();

            await Task.WhenAll(tasks);
        }

        private void RaiseFinished(string name, TimeSpan elapsed) =>
            HorseFinished?.Invoke(this, new HorseFinishedEventArgs(name, elapsed));

        private void RaiseFailed(string name) =>
            HorseFailed?.Invoke(this, new HorseFailedEventArgs(name));
    }

    public static class HorseRaceDemo
    {
        public static async Task Run()
        {
            Console.WriteLine("=== Horse Race Simulation ===");
            Console.Write("Enter horse names separated by comma (leave empty for defaults): ");
            string? input = Console.ReadLine();

            var names = string.IsNullOrWhiteSpace(input)
                ? new[] { "Shadowfax", "Thunderbolt", "NightDancer", "WindRunner", "StormChaser" }
                : input.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);

            var race = new HorseRace();

            ConcurrentBag<(string Name, TimeSpan Time)> arrivalOrder =
                new ConcurrentBag<(string Name, TimeSpan Time)>();
            ConcurrentBag<string> retired =
                new ConcurrentBag<string>();

            int expected = names.Distinct(StringComparer.OrdinalIgnoreCase).Count();
            object gate = new();

            race.HorseFinished += (_, e) =>
            {
                arrivalOrder.Add((e.Name, e.Elapsed));
                Console.WriteLine($"[FINISH] {e.Name} finished in {e.Elapsed.TotalSeconds:F2}s");
            };

            race.HorseFailed += (_, e) =>
            {
                retired.Add(e.Name);
                Console.WriteLine($"[RETIRED] {e.Name} left the race.");
            };

            // Wait (blocking main thread for demo)
            await race.RunAsync(names);

            Console.WriteLine("\n=== FINAL RANKING ===");
            if (arrivalOrder.Count == 0)
                Console.WriteLine("No horse finished.");
            else
            {
                int pos = 1;
                foreach (var (name, time) in arrivalOrder.OrderBy(x => x.Time))
                    Console.WriteLine($"{pos++}. {name} - {time.TotalSeconds:F2}s");
            }

            Console.WriteLine("\n=== RETIRED ===");
            if (retired.Count == 0)
                Console.WriteLine("None");
            else
                retired.ToList().ForEach(r => Console.WriteLine(r));

            Console.WriteLine("\n=== SUMMARY (From RaceResult) ===");
            Console.WriteLine($"Finished: {arrivalOrder.Count}, Retired: {retired.Count}");
        }
    }
}