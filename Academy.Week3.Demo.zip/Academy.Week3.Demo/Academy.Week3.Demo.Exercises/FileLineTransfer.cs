﻿using System.Collections.Concurrent;

namespace Academy.Week3.Demo.Exercises
{
    internal class FileLineTransfer
    {
        public async Task Move(string sourceFile, string destinationFile, CancellationToken cancellationToken = default)
        {
            // Doing some basic validation
            if (string.IsNullOrWhiteSpace(sourceFile))
                throw new ArgumentException("Source file path is required.", nameof(sourceFile));
            if (string.IsNullOrWhiteSpace(destinationFile))
                throw new ArgumentException("Destination file path is required.", nameof(destinationFile));
            if (!File.Exists(sourceFile))
                throw new FileNotFoundException("Source file not found.", sourceFile);
            if (File.Exists(destinationFile))
                throw new ArgumentException("Destination file should not exist.", destinationFile);
            if (string.Equals(sourceFile, destinationFile, StringComparison.OrdinalIgnoreCase))
                throw new ArgumentException("Source and destination files must be different.");

            // Counting lines
            string[] lines = await
                File.ReadAllLinesAsync(sourceFile, cancellationToken);
            int lineCount = lines.Length;

            SemaphoreSlim readSem = new(1, 1);
            SemaphoreSlim writeSem = new(1, 1);

            List<int> processedLineIndexes =
                new(Enumerable.Range(1, lineCount));
            string[] destinationLines = new string[lineCount];

            List<Task> tasks = new();
            foreach (var line in lines)
            {
                tasks.Add(Task.Run(async () =>
                {
                    try
                    {
                        await readSem.WaitAsync(cancellationToken);
                        int index = Random.Shared.Next(1, processedLineIndexes.Count + 1);
                        string line = File.ReadLines(sourceFile).Skip(index).First();
                        processedLineIndexes.Remove(index);
                        readSem.Release();

                        await writeSem.WaitAsync(cancellationToken);
                        destinationLines[index - 1] = line;
                        writeSem.Release();
                    }
                    finally
                    {
                        if (readSem.CurrentCount == 0)
                            readSem.Release();
                        if (writeSem.CurrentCount == 0)
                            writeSem.Release();
                    }
                }, cancellationToken));
            }

            await Task.WhenAll(tasks);
            await File.WriteAllLinesAsync(destinationFile, destinationLines, cancellationToken);
        }
    }
}
