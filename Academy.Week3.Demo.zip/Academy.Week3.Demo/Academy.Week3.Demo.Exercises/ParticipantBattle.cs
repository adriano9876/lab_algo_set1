using System.Collections.Concurrent;

namespace Academy.Week3.Demo.Exercises
{
    public sealed class StageValueEventArgs : EventArgs
    {
        public StageValueEventArgs(int stage, string name, int strength, int value)
        {
            Stage = stage;
            Name = name;
            Strength = strength;
            Value = value;
        }
        public int Stage { get; }
        public string Name { get; }
        public int Strength { get; }
        public int Value { get; }
    }

    public sealed class ParticipantEliminatedEventArgs : EventArgs
    {
        public ParticipantEliminatedEventArgs(int stage, string name, int strength, int value)
        {
            Stage = stage;
            Name = name;
            Strength = strength;
            Value = value;
        }
        public int Stage { get; }
        public string Name { get; }
        public int Strength { get; }
        public int Value { get; }
    }

    public sealed class GameCompletedEventArgs : EventArgs
    {
        public GameCompletedEventArgs(string winnerName, int winnerStrength, IReadOnlyList<(string Name, int Strength, int Stage, int Value)> eliminations)
        {
            WinnerName = winnerName;
            WinnerStrength = winnerStrength;
            Eliminations = eliminations;
        }
        public string WinnerName { get; }
        public int WinnerStrength { get; }
        public IReadOnlyList<(string Name, int Strength, int Stage, int Value)> Eliminations { get; }
    }

    internal sealed class Participant
    {
        public Participant(string name, int strength)
        {
            Name = name;
            Strength = strength;
        }
        public string Name { get; }
        public int Strength { get; }
        public bool Eliminated { get; set; }
    }

    public sealed class ParticipantBattleGame
    {
        private readonly List<Participant> _participants = new();
        private readonly List<(string Name, int Strength, int Stage, int Value)> _eliminationOrder = new();

        public event EventHandler<StageValueEventArgs>? StageValueReported;
        public event EventHandler<ParticipantEliminatedEventArgs>? ParticipantEliminated;
        public event EventHandler<GameCompletedEventArgs>? GameCompleted;

        public IReadOnlyList<(string Name, int Strength, int Stage, int Value)> EliminationOrder => _eliminationOrder;

        public async Task RunAsync(IEnumerable<string> names, CancellationToken cancellationToken = default)
        {
            ArgumentNullException.ThrowIfNull(names);

            var distinct = names
                .Where(n => !string.IsNullOrWhiteSpace(n))
                .Select(n => n.Trim())
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToList();

            if (distinct.Count < 2)
                throw new ArgumentException("Provide at least two distinct participant names.", nameof(names));

            foreach (var n in distinct)
            {
                _participants.Add(new Participant(n, Random.Shared.Next(1, 101))); // 1..100
            }

            int stages = _participants.Count - 1;

            for (int stage = 1; stage <= stages; stage++)
            {
                cancellationToken.ThrowIfCancellationRequested();

                var alive = _participants.Where(p => !p.Eliminated).ToList();

                // Create one task per alive participant (reports its value for the stage)
                var tasks = alive.Select(p => Task.Run(() =>
                {
                    int value = Random.Shared.Next(0, p.Strength + 1);
                    StageValueReported?.Invoke(this,
                        new StageValueEventArgs(stage, p.Name, p.Strength, value));
                    return (Participant: p, Value: value);
                }, cancellationToken)).ToArray();

                var results = await Task.WhenAll(tasks);

                // Determine elimination (lowest value; tie-breaker: lower strength, then name)
                var eliminated = results
                    .OrderBy(r => r.Value)
                    .ThenBy(r => r.Participant.Strength)
                    .ThenBy(r => r.Participant.Name, StringComparer.OrdinalIgnoreCase)
                    .First();

                eliminated.Participant.Eliminated = true;

                _eliminationOrder.Add((eliminated.Participant.Name,
                                       eliminated.Participant.Strength,
                                       stage,
                                       eliminated.Value));

                // Give a bit of hype!
                await Task.Delay(1000, cancellationToken);
                Console.Write(".");
                await Task.Delay(1000, cancellationToken);
                Console.Write(".");
                await Task.Delay(1000, cancellationToken);
                Console.Write(".");
                await Task.Delay(1000, cancellationToken);
                Console.Write(".");
                await Task.Delay(1000, cancellationToken);

                ParticipantEliminated?.Invoke(this,
                    new ParticipantEliminatedEventArgs(stage,
                                                       eliminated.Participant.Name,
                                                       eliminated.Participant.Strength,
                                                       eliminated.Value));
            }

            var winner = _participants.Single(p => !p.Eliminated);
            GameCompleted?.Invoke(this,
                new GameCompletedEventArgs(winner.Name, winner.Strength, _eliminationOrder));
        }
    }

    public static class ParticipantBattleDemo
    {
        public static async Task Run()
        {
            Console.WriteLine("=== Participant Battle (Elimination Game) ===");
            Console.Write("Enter participant names separated by comma (leave empty for defaults): ");
            string? input = Console.ReadLine();

            var names = string.IsNullOrWhiteSpace(input)
                ? new[] { "Ares", "Zephyr", "Orion", "Lyra", "Nova" }
                : input.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);

            var game = new ParticipantBattleGame();

            var eliminationLog = new List<(string Name, int Strength, int Stage, int Value)>();

            game.StageValueReported += (_, e) =>
            {
                // First time we see name we capture strength (for header printing after we gather all)
                Console.WriteLine($"[Stage {e.Stage}] {e.Name} (STR {e.Strength}) reports {e.Value}");
            };

            game.ParticipantEliminated += (_, e) =>
            {
                eliminationLog.Add((e.Name, e.Strength, e.Stage, e.Value));
                Console.WriteLine($"[ELIMINATED @ Stage {e.Stage}] {e.Name} (STR {e.Strength}) with value {e.Value}");
            };

            game.GameCompleted += (_, e) =>
            {
                Console.WriteLine($"\n=== WINNER: {e.WinnerName} (STR {e.WinnerStrength}) ===");
            };

            await game.RunAsync(names);

            Console.WriteLine("\n=== ELIMINATION ORDER ===");
            if (eliminationLog.Count == 0)
                Console.WriteLine("None");
            else
            {
                foreach (var (name, strength, stage, value) in eliminationLog
                    .OrderBy(x => x.Stage))
                {
                    Console.WriteLine($"Stage {stage}: {name} (STR {strength}) eliminated with {value}");
                }
            }
        }
    }
}