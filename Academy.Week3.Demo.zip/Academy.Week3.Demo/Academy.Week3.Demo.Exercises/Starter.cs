﻿namespace Academy.Week3.Demo.Exercises
{
    public class Starter
    {
        public static void Demo()
        {
            //HorseRaceDemo.Run().GetAwaiter().GetResult();
            ParticipantBattleDemo.Run().GetAwaiter().GetResult();
        }
    }
}
