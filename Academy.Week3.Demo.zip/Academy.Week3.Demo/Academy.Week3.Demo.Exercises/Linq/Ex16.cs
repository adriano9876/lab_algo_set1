using System.Collections.Generic;
using System.Linq;
using MoviesLinqPlayground;

namespace MoviesLinqPlayground.Exercises
{
    public static class Ex16
    {
        public static IEnumerable<Movie> UnratedByUser_Method(IEnumerable<Movie> movies, IEnumerable<Rating> ratings, UserId userId)
        {
            var rated = ratings.Where(r => r.UserId.Equals(userId)).Select(r => r.MovieId).ToHashSet();
            return movies.Where(m => !rated.Contains(m.Id)).OrderByDescending(m => (int)m.Year);
        }

        public static IEnumerable<Movie> UnratedByUser_Query(IEnumerable<Movie> movies, IEnumerable<Rating> ratings, UserId userId)
            => from m in movies
               where !(from r in ratings where r.UserId.Equals(userId) select r.MovieId).Contains(m.Id)
               orderby (int)m.Year descending
               select m;
    }
}
