using System.Collections.Generic;
using System.Linq;
using MoviesLinqPlayground;

namespace MoviesLinqPlayground.Exercises
{
    public static class Ex14
    {
        public static IEnumerable<Movie> Page_Method(IEnumerable<Movie> movies, int pageIndex, int pageSize)
            => movies.OrderByDescending(m => (int)m.Year)
                     .ThenBy(m => m.Title)
                     .Skip(pageIndex * pageSize)
                     .Take(pageSize);

        public static IEnumerable<Movie> Page_Query(IEnumerable<Movie> movies, int pageIndex, int pageSize)
            => (from m in movies
                orderby (int)m.Year descending, m.Title
                select m)
                .Skip(pageIndex * pageSize)
                .Take(pageSize);
    }
}
