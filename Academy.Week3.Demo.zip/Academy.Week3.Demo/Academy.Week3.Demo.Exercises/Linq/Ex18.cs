using System.Collections.Generic;
using System.Linq;
using MoviesLinqPlayground;

namespace MoviesLinqPlayground.Exercises
{
    public static class Ex18
    {
        public static IEnumerable<object> AvgByUserCountry_Method(IEnumerable<User> users, IEnumerable<Rating> ratings)
            => ratings.Join(users, r => r.UserId, u => u.Id, (r, u) => new { u.Country, r.Stars })
                      .GroupBy(x => x.Country.Value)
                      .Select(g => new { Country = g.Key, Avg = g.Average(x => x.Stars.Value), Count = g.Count() })
                      .Where(x => x.Count >= 2)
                      .OrderByDescending(x => x.Avg);

        public static IEnumerable<object> AvgByUserCountry_Query(IEnumerable<User> users, IEnumerable<Rating> ratings)
            => from x in (from r in ratings
                          join u in users on r.UserId equals u.Id
                          select new { u.Country, r.Stars })
               group x by x.Country.Value into g
               let count = g.Count()
               where count >= 2
               orderby g.Average(x => x.Stars.Value) descending
               select new { Country = g.Key, Avg = g.Average(x => x.Stars.Value), Count = count };
    }
}
