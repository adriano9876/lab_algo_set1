using System.Collections.Generic;
using System.Linq;
using MoviesLinqPlayground;

namespace MoviesLinqPlayground.Exercises
{
    public static class Ex01
    {
        // Method syntax
        public static IEnumerable<string> Titles_Method(IEnumerable<Movie> movies)
            => movies.Select(m => m.Title).OrderBy(t => t);

        // Query syntax
        public static IEnumerable<string> Titles_Query(IEnumerable<Movie> movies)
            => (from m in movies
                orderby m.Title
                select m.Title);
    }
}
