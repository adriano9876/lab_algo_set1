using System.Collections.Generic;
using System.Linq;
using MoviesLinqPlayground;

namespace MoviesLinqPlayground.Exercises
{
    public static class Ex06
    {
        public static IEnumerable<object> Top3Longest_Method(IEnumerable<Movie> movies)
            => movies.OrderByDescending(m => (int)m.Duration)
                     .Take(3)
                     .Select(m => new { m.Title, Minutes = (int)m.Duration });

        public static IEnumerable<object> Top3Longest_Query(IEnumerable<Movie> movies)
            => (from m in movies
                orderby (int)m.Duration descending
                select new { m.Title, Minutes = (int)m.Duration }).Take(3);
    }
}
