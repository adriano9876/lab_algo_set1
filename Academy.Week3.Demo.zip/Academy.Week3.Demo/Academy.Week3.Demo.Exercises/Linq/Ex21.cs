using System.Collections.Generic;
using System.Linq;
using MoviesLinqPlayground;
using System;

namespace MoviesLinqPlayground.Exercises
{
    public static class Ex21
    {
        public static IEnumerable<Movie> SearchBySubstring_Method(IEnumerable<Movie> movies, string term)
            => movies.Where(m => m.Title.Contains(term, StringComparison.OrdinalIgnoreCase)
                               || m.Tags.Any(t => t.Contains(term, StringComparison.OrdinalIgnoreCase)))
                     .OrderBy(m => m.Title);

        public static IEnumerable<Movie> SearchBySubstring_Query(IEnumerable<Movie> movies, string term)
            => from m in movies
               where m.Title.Contains(term, StringComparison.OrdinalIgnoreCase)
                  || m.Tags.Any(t => t.Contains(term, StringComparison.OrdinalIgnoreCase))
               orderby m.Title
               select m;
    }
}
