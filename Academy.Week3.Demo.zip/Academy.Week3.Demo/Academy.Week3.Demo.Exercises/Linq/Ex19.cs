using System.Collections.Generic;
using System.Linq;
using MoviesLinqPlayground;

namespace MoviesLinqPlayground.Exercises
{
    public static class Ex19
    {
        public static IEnumerable<object> MoviesPerDecade_Method(IEnumerable<Movie> movies)
            => movies.GroupBy(m => ((int)m.Year / 10) * 10)
                     .Select(g => new { Decade = g.Key, Count = g.Count() })
                     .OrderBy(x => x.Decade);

        public static IEnumerable<object> MoviesPerDecade_Query(IEnumerable<Movie> movies)
            => from m in movies
               group m by ((int)m.Year / 10) * 10 into g
               orderby g.Key
               select new { Decade = g.Key, Count = g.Count() };
    }
}
