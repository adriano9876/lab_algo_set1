using System.Collections.Generic;
using System.Linq;
using MoviesLinqPlayground;

namespace MoviesLinqPlayground.Exercises
{
    public static class Ex10
    {
        public static IEnumerable<object> HarshRaters_Method(IEnumerable<User> users, IEnumerable<Rating> ratings)
            => ratings.GroupBy(r => r.UserId)
                      .Select(g => new { UserId = g.Key, Mean = g.Average(r => r.Stars.Value) })
                      .Where(x => x.Mean < 3.5m)
                      .Join(users, x => x.UserId, u => u.Id, (x, u) => new { User = u.Name, x.Mean });

        public static IEnumerable<object> HarshRaters_Query(IEnumerable<User> users, IEnumerable<Rating> ratings)
            => from r in ratings
               group r by r.UserId into g
               let mean = g.Average(r => r.Stars.Value)
               where mean < 3.5m
               join u in users on g.Key equals u.Id
               select new { User = u.Name, Mean = mean };
    }
}
