using System.Collections.Generic;
using System.Linq;
using MoviesLinqPlayground;

namespace MoviesLinqPlayground.Exercises
{
    public static class Ex20
    {
        public static IEnumerable<object> PerGenreCounts_Method(IEnumerable<Movie> movies)
            => movies.SelectMany(m => m.Genres)
                     .GroupBy(g => g)
                     .Select(g => new { Genre = g.Key, MovieCount = g.Count() })
                     .OrderByDescending(x => x.MovieCount)
                     .ThenBy(x => x.Genre);

        public static IEnumerable<object> PerGenreCounts_Query(IEnumerable<Movie> movies)
            => from m in movies
               from g in m.Genres
               group g by g into grp
               orderby grp.Count() descending, grp.Key
               select new { Genre = grp.Key, MovieCount = grp.Count() };
    }
}
