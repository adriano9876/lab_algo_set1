using System.Collections.Generic;
using System.Linq;
using MoviesLinqPlayground;

namespace MoviesLinqPlayground.Exercises
{
    public static class Ex17
    {
        public static IEnumerable<object> TopActiveUsers_Method(IEnumerable<User> users, IEnumerable<Rating> ratings, int topN = 3)
            => ratings.GroupBy(r => r.UserId)
                      .Join(users, g => g.Key, u => u.Id, (g, u) => new { User = u.Name, Count = g.Count() })
                      .OrderByDescending(x => x.Count)
                      .ThenBy(x => x.User)
                      .Take(topN);

        public static IEnumerable<object> TopActiveUsers_Query(IEnumerable<User> users, IEnumerable<Rating> ratings, int topN = 3)
            => (from r in ratings
                group r by r.UserId into g
                join u in users on g.Key equals u.Id
                orderby g.Count() descending, u.Name
                select new { User = u.Name, Count = g.Count() }).Take(topN);
    }
}
