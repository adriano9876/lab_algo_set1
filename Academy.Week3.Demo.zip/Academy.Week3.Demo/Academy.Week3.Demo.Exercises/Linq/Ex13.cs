using System.Collections.Generic;
using System.Linq;
using MoviesLinqPlayground;

namespace MoviesLinqPlayground.Exercises
{
    public static class Ex13
    {
        public static IEnumerable<object> PerGenreWinners_Method(IEnumerable<Movie> movies, IEnumerable<Rating> ratings)
        {
            var agg = ratings.GroupBy(r => r.MovieId)
                              .Select(g => new { MovieId = g.Key, Avg = g.Average(r => r.Stars.Value), Count = g.Count() })
                              .Where(a => a.Count >= 2)
                              .ToDictionary(a => a.MovieId, a => a);

            return movies.SelectMany(m => m.Genres.Select(g => new { Genre = g, Movie = m }))
                         .Where(x => agg.ContainsKey(x.Movie.Id))
                         .GroupBy(x => x.Genre)
                         .Select(g => g.Select(x => new { Genre = g.Key, Movie = x.Movie, Agg = agg[x.Movie.Id] })
                                       .OrderByDescending(x => x.Agg.Avg)
                                       .ThenByDescending(x => x.Agg.Count)
                                       .ThenBy(x => x.Movie.Title)
                                       .Select(x => new { Genre = x.Genre, Title = x.Movie.Title, Avg = x.Agg.Avg, Count = x.Agg.Count })
                                       .First());
        }

        public static IEnumerable<object> PerGenreWinners_Query(IEnumerable<Movie> movies, IEnumerable<Rating> ratings)
        {
            var agg = (from r in ratings
                       group r by r.MovieId into g
                       where g.Count() >= 2
                       select new { MovieId = g.Key, Avg = g.Average(r => r.Stars.Value), Count = g.Count() })
                      .ToDictionary(a => a.MovieId, a => a);

            return from mg in (from m in movies
                               from g in m.Genres
                               where agg.ContainsKey(m.Id)
                               select new { Genre = g, Movie = m, Agg = agg[m.Id] })
                   group mg by mg.Genre into grp
                   select grp.OrderByDescending(x => x.Agg.Avg)
                             .ThenByDescending(x => x.Agg.Count)
                             .ThenBy(x => x.Movie.Title)
                             .Select(x => new { Genre = grp.Key, Title = x.Movie.Title, Avg = x.Agg.Avg, Count = x.Agg.Count })
                             .First();
        }
    }
}
