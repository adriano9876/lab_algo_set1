using System.Collections.Generic;
using System.Linq;
using MoviesLinqPlayground;

namespace MoviesLinqPlayground.Exercises
{
    public static class Ex04
    {
        public static decimal? AverageForTitle_Method(IEnumerable<Movie> movies, IEnumerable<Rating> ratings, string title)
        {
            var mid = movies.FirstOrDefault(m => m.Title == title)?.Id;
            if (mid == null) return null;
            var stars = ratings.Where(r => r.MovieId.Equals(mid.Value)).Select(r => r.Stars.Value);
            return stars.Any() ? stars.Average() : (decimal?)null;
        }

        public static decimal? AverageForTitle_Query(IEnumerable<Movie> movies, IEnumerable<Rating> ratings, string title)
        {
            var values = from m in movies
                         where m.Title == title
                         join r in ratings on m.Id equals r.MovieId into mr
                         from r in mr.DefaultIfEmpty()
                         select r?.Stars.Value;

            var filtered = values.Where(v => v.HasValue).Select(v => v!.Value);
            return filtered.Any() ? filtered.Average() : (decimal?)null;
        }
    }
}
