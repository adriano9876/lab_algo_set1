using System.Collections.Generic;
using System.Linq;
using MoviesLinqPlayground;

namespace MoviesLinqPlayground.Exercises
{
    public static class Ex03
    {
        public static int RatingsCountForUser_Method(IEnumerable<User> users, IEnumerable<Rating> ratings, string userName)
        {
            var uid = users.FirstOrDefault(u => u.Name == userName)?.Id;
            if (uid == null) return 0;
            return ratings.Count(r => r.UserId.Equals(uid.Value));
        }

        public static int RatingsCountForUser_Query(IEnumerable<User> users, IEnumerable<Rating> ratings, string userName)
            => (from u in users
                where u.Name == userName
                join r in ratings on u.Id equals r.UserId
                select r).Count();
    }
}
