using System.Collections.Generic;
using System.Linq;
using MoviesLinqPlayground;

namespace MoviesLinqPlayground.Exercises
{
    public static class Ex09
    {
        public static IEnumerable<object> MovieAgg_Method(IEnumerable<Movie> movies, IEnumerable<Rating> ratings)
            => ratings.GroupBy(r => r.MovieId)
                      .Where(g => g.Count() >= 2)
                      .Join(movies, g => g.Key, m => m.Id, (g, m) => new { m.Title, AvgStars = g.Average(r => r.Stars.Value), Count = g.Count() })
                      .OrderByDescending(x => x.AvgStars)
                      .ThenByDescending(x => x.Count);

        public static IEnumerable<object> MovieAgg_Query(IEnumerable<Movie> movies, IEnumerable<Rating> ratings)
            => from r in ratings
               group r by r.MovieId into g
               where g.Count() >= 2
               join m in movies on g.Key equals m.Id
               orderby g.Average(r => r.Stars.Value) descending, g.Count() descending
               select new { m.Title, AvgStars = g.Average(r => r.Stars.Value), Count = g.Count() };
    }
}
