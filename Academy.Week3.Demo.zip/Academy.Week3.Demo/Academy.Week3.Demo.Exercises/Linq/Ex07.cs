using System.Collections.Generic;
using System.Linq;
using MoviesLinqPlayground;

namespace MoviesLinqPlayground.Exercises
{
    public static class Ex07
    {
        public static IEnumerable<string> RecentReviews_Method(IEnumerable<Rating> ratings)
            => ratings.Where(r => !string.IsNullOrWhiteSpace(r.Review))
                      .OrderByDescending(r => r.WatchedOn)
                      .Select(r => r.Review!);

        public static IEnumerable<string> RecentReviews_Query(IEnumerable<Rating> ratings)
            => from r in ratings
               where r.Review != null && r.Review.Trim() != ""
               orderby r.WatchedOn descending
               select r.Review!;
    }
}
