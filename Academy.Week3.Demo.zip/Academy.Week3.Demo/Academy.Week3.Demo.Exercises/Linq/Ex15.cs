using System.Collections.Generic;
using System.Linq;
using MoviesLinqPlayground;

namespace MoviesLinqPlayground.Exercises
{
    public static class Ex15
    {
        public static IEnumerable<object> MinMaxAvg_Method(IEnumerable<Movie> movies, IEnumerable<Rating> ratings)
            => ratings.GroupBy(r => r.MovieId)
                      .Where(g => g.Count() >= 2)
                      .Join(movies, g => g.Key, m => m.Id, (g, m) => new { m.Title, Min = g.Min(r => r.Stars.Value), Max = g.Max(r => r.Stars.Value), Avg = g.Average(r => r.Stars.Value) })
                      .OrderByDescending(x => x.Avg)
                      .ThenBy(x => x.Title);

        public static IEnumerable<object> MinMaxAvg_Query(IEnumerable<Movie> movies, IEnumerable<Rating> ratings)
            => from g in (from r in ratings
                           group r by r.MovieId into grp
                           where grp.Count() >= 2
                           select grp)
               join m in movies on g.Key equals m.Id
               orderby g.Average(r => r.Stars.Value) descending, m.Title
               select new { m.Title, Min = g.Min(r => r.Stars.Value), Max = g.Max(r => r.Stars.Value), Avg = g.Average(r => r.Stars.Value) };
    }
}
