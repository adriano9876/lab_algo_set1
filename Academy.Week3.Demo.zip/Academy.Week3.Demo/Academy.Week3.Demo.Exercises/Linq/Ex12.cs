using System.Collections.Generic;
using System.Linq;
using MoviesLinqPlayground;

namespace MoviesLinqPlayground.Exercises
{
    public static class Ex12
    {
        public static IEnumerable<Movie> NotRatedByItalians_Method(IEnumerable<User> users, IEnumerable<Movie> movies, IEnumerable<Rating> ratings)
        {
            var italianUserIds = users.Where(u => u.Country.Value == "IT").Select(u => u.Id).ToHashSet();
            var movieIdsRatedByItalians = ratings.Where(r => italianUserIds.Contains(r.UserId)).Select(r => r.MovieId).ToHashSet();
            return movies.Where(m => !movieIdsRatedByItalians.Contains(m.Id));
        }

        public static IEnumerable<Movie> NotRatedByItalians_Query(IEnumerable<User> users, IEnumerable<Movie> movies, IEnumerable<Rating> ratings)
            => from m in movies
               let hasItalian = (from r in ratings
                                 join u in users on r.UserId equals u.Id
                                 where r.MovieId.Equals(m.Id) && u.Country.Value == "IT"
                                 select r).Any()
               where !hasItalian
               select m;
    }
}
