using System.Collections.Generic;
using System.Linq;
using MoviesLinqPlayground;

namespace MoviesLinqPlayground.Exercises
{
    public static class Ex02
    {
        public static IEnumerable<object> After2000_Method(IEnumerable<Movie> movies)
            => movies.Where(m => (int)m.Year > 2000)
                      .Select(m => new { m.Title, Year = (int)m.Year });

        public static IEnumerable<object> After2000_Query(IEnumerable<Movie> movies)
            => from m in movies
               where (int)m.Year > 2000
               select new { m.Title, Year = (int)m.Year };
    }
}
