using System.Collections.Generic;
using System.Linq;
using MoviesLinqPlayground;

namespace MoviesLinqPlayground.Exercises
{
    public static class Ex08
    {
        public static IEnumerable<object> UserMovieStars_Method(IEnumerable<User> users, IEnumerable<Movie> movies, IEnumerable<Rating> ratings)
            => ratings.Join(users, r => r.UserId, u => u.Id, (r, u) => new { u.Name, r })
                      .Join(movies, ur => ur.r.MovieId, m => m.Id, (ur, m) => new { User = ur.Name, Movie = m.Title, Stars = ur.r.Stars.Value })
                      .OrderBy(x => x.User)
                      .ThenByDescending(x => x.Stars);

        public static IEnumerable<object> UserMovieStars_Query(IEnumerable<User> users, IEnumerable<Movie> movies, IEnumerable<Rating> ratings)
            => from r in ratings
               join u in users on r.UserId equals u.Id
               join m in movies on r.MovieId equals m.Id
               orderby u.Name, r.Stars.Value descending
               select new { User = u.Name, Movie = m.Title, Stars = r.Stars.Value };
    }
}
