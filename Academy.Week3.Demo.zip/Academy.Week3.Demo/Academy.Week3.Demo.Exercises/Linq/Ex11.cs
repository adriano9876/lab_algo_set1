using System.Collections.Generic;
using System.Linq;
using MoviesLinqPlayground;

namespace MoviesLinqPlayground.Exercises
{
    public static class Ex11
    {
        public static IEnumerable<object> TopTags_Method(IEnumerable<Movie> movies)
            => movies.SelectMany(m => m.Tags)
                     .Where(t => !string.IsNullOrWhiteSpace(t))
                     .Select(t => t.Trim().ToLowerInvariant())
                     .GroupBy(t => t)
                     .Select(g => new { Tag = g.Key, Count = g.Count() })
                     .OrderByDescending(x => x.Count)
                     .ThenBy(x => x.Tag)
                     .Take(5);

        public static IEnumerable<object> TopTags_Query(IEnumerable<Movie> movies)
            => (from m in movies
                from t in m.Tags
                let tag = t?.Trim().ToLowerInvariant()
                where !string.IsNullOrEmpty(tag)
                group tag by tag into g
                orderby g.Count() descending, g.Key
                select new { Tag = g.Key, Count = g.Count() }).Take(5);
    }
}
