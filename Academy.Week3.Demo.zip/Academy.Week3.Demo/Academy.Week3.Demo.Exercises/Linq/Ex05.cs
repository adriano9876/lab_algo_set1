using System.Collections.Generic;
using System.Linq;
using MoviesLinqPlayground;

namespace MoviesLinqPlayground.Exercises
{
    public static class Ex05
    {
        public static IEnumerable<Genre> DistinctGenres_Method(IEnumerable<Movie> movies)
            => movies.SelectMany(m => m.Genres).Distinct().OrderBy(g => g);

        public static IEnumerable<Genre> DistinctGenres_Query(IEnumerable<Movie> movies)
            => (from m in movies
                from g in m.Genres
                select g).Distinct().OrderBy(g => g);
    }
}
