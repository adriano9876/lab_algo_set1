namespace MoviesLinqPlayground
{
    // --- Value Objects (strongly typed) ---

    public readonly record struct MovieId(Guid Value)
    {
        public static MovieId New() => new(Guid.NewGuid());
        public override string ToString() => Value.ToString();
    }

    public readonly record struct UserId(Guid Value)
    {
        public static UserId New() => new(Guid.NewGuid());
        public override string ToString() => Value.ToString();
    }

    public readonly record struct Year
    {
        public int Value { get; }
        public Year(int value)
        {
            if (value < 1888 || value > DateTime.UtcNow.Year + 2)
                throw new ArgumentOutOfRangeException(nameof(value), "Year must be >= 1888 and plausible.");
            Value = value;
        }
        public override string ToString() => Value.ToString();
        public static implicit operator int(Year y) => y.Value;
        public static explicit operator Year(int v) => new(v);
    }

    public readonly record struct Minutes
    {
        public int Value { get; }
        public Minutes(int value)
        {
            if (value <= 0) throw new ArgumentOutOfRangeException(nameof(value), "Duration must be positive.");
            Value = value;
        }
        public override string ToString() => $"{Value} min";
        public static implicit operator int(Minutes m) => m.Value;
        public static explicit operator Minutes(int v) => new(v);
    }

    public readonly record struct Stars
    {
        public decimal Value { get; }
        public Stars(decimal value)
        {
            if (value < 0.5m || value > 5.0m || value * 2 != Math.Round(value * 2, 0))
                throw new ArgumentOutOfRangeException(nameof(value), "Stars must be between 0.5 and 5.0 in 0.5 increments.");
            Value = value;
        }
        public static implicit operator decimal(Stars s) => s.Value;
        public override string ToString() => $"{Value:0.0}★";
    }

    public readonly record struct CountryCode
    {
        public string Value { get; }
        public CountryCode(string value)
        {
            if (string.IsNullOrWhiteSpace(value) || value.Length != 2)
                throw new ArgumentException("Country code must be 2 letters (ISO-like).", nameof(value));
            Value = value.ToUpperInvariant();
        }
        public override string ToString() => Value;
    }

    // --- Enums ---

    public enum Genre
    {
        Action, Adventure, Animation, Comedy, Crime, Documentary, Drama,
        Fantasy, Horror, Mystery, Romance, SciFi, Thriller, Western
    }

    public enum ContentRating { G, PG, PG13, R, NC17, Unrated }

    // --- Entities ---

    public sealed class Movie
    {
        public MovieId Id { get; init; } = MovieId.New();
        public string Title { get; init; } = "";
        public Year Year { get; init; } = (Year)2000;
        public Minutes Duration { get; init; } = (Minutes)90;
        public HashSet<Genre> Genres { get; init; } = new();
        public ContentRating ContentRating { get; init; } = ContentRating.Unrated;
        public CountryCode Country { get; init; } = new("US");
        public string Director { get; init; } = "";
        public List<string> Cast { get; init; } = new();
        public HashSet<string> Tags { get; init; } = new(StringComparer.OrdinalIgnoreCase);

        public override string ToString() => $"{Title} ({(int)Year})";
    }

    public sealed class User
    {
        public UserId Id { get; init; } = UserId.New();
        public string Name { get; init; } = "";
        public DateTime JoinedOn { get; init; } = DateTime.UtcNow;
        public CountryCode Country { get; init; } = new("US");
        public int? BirthYear { get; init; }
        public HashSet<string> PreferredGenres { get; init; } = new(StringComparer.OrdinalIgnoreCase);

        public override string ToString() => $"{Name} [{Country}]";
    }

    public sealed class Rating
    {
        public UserId UserId { get; init; }
        public MovieId MovieId { get; init; }
        public Stars Stars { get; init; } = new(3.0m);
        public string? Review { get; init; }
        public bool ContainsSpoilers { get; init; }
        public DateTime WatchedOn { get; init; } = DateTime.UtcNow;
    }

    // --- Simple in-memory database ---

    public sealed class InMemoryDb
    {
        public List<Movie> Movies { get; } = new();
        public List<User> Users { get; } = new();
        public List<Rating> Ratings { get; } = new();

        public void SeedSample()
        {
            var u1 = new User { Name = "Alice", Country = new("US"), BirthYear = 1990 };
            var u2 = new User { Name = "Bob",   Country = new("IT"), BirthYear = 1984 };
            var u3 = new User { Name = "Carla", Country = new("FR"), BirthYear = 1995 };
            Users.AddRange(new[] { u1, u2, u3 });

            var m1 = new Movie
            {
                Title = "The Matrix",
                Year = (Year)1999,
                Duration = (Minutes)136,
                Genres = new() { Genre.Action, Genre.SciFi },
                ContentRating = ContentRating.R,
                Country = new("US"),
                Director = "Lana Wachowski",
                Cast = new() { "Keanu Reeves", "Carrie-Anne Moss" },
                Tags = new() { "cyberpunk", "ai" }
            };
            var m2 = new Movie
            {
                Title = "Spirited Away",
                Year = (Year)2001,
                Duration = (Minutes)125,
                Genres = new() { Genre.Animation, Genre.Fantasy },
                ContentRating = ContentRating.PG,
                Country = new("JP"),
                Director = "Hayao Miyazaki",
                Tags = new() { "ghibli", "spirits" }
            };
            var m3 = new Movie
            {
                Title = "Parasite",
                Year = (Year)2019,
                Duration = (Minutes)132,
                Genres = new() { Genre.Drama, Genre.Thriller },
                ContentRating = ContentRating.R,
                Country = new("KR"),
                Director = "Bong Joon-ho",
                Tags = new() { "class", "satire" }
            };
            var m4 = new Movie
            {
                Title = "The Godfather",
                Year = (Year)1972,
                Duration = (Minutes)175,
                Genres = new() { Genre.Crime, Genre.Drama },
                ContentRating = ContentRating.R,
                Country = new("US"),
                Director = "Francis Ford Coppola",
                Tags = new() { "mafia", "classic" }
            };
            var m5 = new Movie
            {
                Title = "La vita è bella",
                Year = (Year)1997,
                Duration = (Minutes)116,
                Genres = new() { Genre.Comedy, Genre.Drama },
                ContentRating = ContentRating.PG13,
                Country = new("IT"),
                Director = "Roberto Benigni",
                Tags = new() { "italy", "war", "family" }
            };
            Movies.AddRange(new[] { m1, m2, m3, m4, m5 });

            Ratings.AddRange(new[]
            {
                new Rating { UserId = u1.Id, MovieId = m1.Id, Stars = new(4.5m), WatchedOn = new DateTime(2023, 1, 12) },
                new Rating { UserId = u1.Id, MovieId = m2.Id, Stars = new(5.0m), Review = "Masterpiece", WatchedOn = new DateTime(2023, 2, 3) },
                new Rating { UserId = u2.Id, MovieId = m1.Id, Stars = new(4.0m), WatchedOn = new DateTime(2023, 1, 20) },
                new Rating { UserId = u2.Id, MovieId = m4.Id, Stars = new(5.0m), WatchedOn = new DateTime(2023, 3, 10) },
                new Rating { UserId = u2.Id, MovieId = m5.Id, Stars = new(4.5m), Review = "Toccante", WatchedOn = new DateTime(2023, 3, 15) },
                new Rating { UserId = u3.Id, MovieId = m3.Id, Stars = new(4.5m), WatchedOn = new DateTime(2023, 2, 14) },
                new Rating { UserId = u3.Id, MovieId = m2.Id, Stars = new(4.0m), WatchedOn = new DateTime(2023, 2, 18) },
                new Rating { UserId = u3.Id, MovieId = m4.Id, Stars = new(4.5m), WatchedOn = new DateTime(2023, 3, 20) },
            });
        }
    }
}
