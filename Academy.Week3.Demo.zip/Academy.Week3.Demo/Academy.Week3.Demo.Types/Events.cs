namespace Academy.Week3.Demo.Types
{
    // Custom EventArgs carrying iteration info
    public sealed class NumberGeneratedEventArgs : EventArgs
    {
        public int Iteration { get; }
        public DateTimeOffset Timestamp { get; }

        public NumberGeneratedEventArgs(int iteration, DateTimeOffset timestamp)
        {
            Iteration = iteration;
            Timestamp = timestamp;
        }

        public override string ToString()
        {
            return $"Iteration: {Iteration}, Timestamp: {Timestamp:HH:mm:ss.fff}";
        }
    }

    // Publisher: raises an event once per generated "number"/iteration.
    public class NumberGenerator
    {
        public event EventHandler<NumberGeneratedEventArgs>? NumberGenerated;

        // Generates 'count' iterations with a variable delay, then raises the event.
        public void Run()
        {
            var rnd = Random.Shared;

            NumberGenerated += OnNumberGenerated;

            for (int i = 1; i <= 10; i++)
            {
                int delay = rnd.Next(1000, 5000);
                Task.Delay(delay).ConfigureAwait(false).GetAwaiter().GetResult();

                NumberGenerated?.Invoke(this,
                    new NumberGeneratedEventArgs(i, DateTime.Now));
            }
        }

        private void OnNumberGenerated(object? sender, NumberGeneratedEventArgs args)
        {
            Console.WriteLine($"Event received: Iteration {args.Iteration} at {args.Timestamp:HH:mm:ss.fff}");
        }
    }
}