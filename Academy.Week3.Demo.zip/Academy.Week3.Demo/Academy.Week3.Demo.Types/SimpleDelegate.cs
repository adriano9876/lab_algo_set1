﻿namespace Academy.Week3.Demo.Types
{
    public delegate int Multiply(int a, int b);

    public static class MultiplyOperations
    {
        public static int MultiplyOperator(int a, int b) => a * b;
        public static int MultiplyWithSum(int a, int b)
        {
            int result = 0;

            foreach (int item in Enumerable.Range(1, b))
            {
                result += a;
            }

            return result;
        }

        public static int Multiply(this int a, int b, Multiply multiply) => multiply(a, b);
    }

    internal class SimpleDelegate
    {
        public static void Start()
        {
            int baseNumber = 5;
            int multiplier = 4;

            Console.WriteLine($"Using Operator {baseNumber}*{multiplier} = {baseNumber.Multiply(multiplier, MultiplyOperations.MultiplyOperator)}");
            Console.WriteLine($"Using Sum {baseNumber}*{multiplier} = {baseNumber.Multiply(multiplier, MultiplyOperations.MultiplyWithSum)}");
            Console.WriteLine($"Using Custom {baseNumber}*{multiplier} = {baseNumber.Multiply(multiplier, (a, b) => a * b)}");
        }
    }
}
