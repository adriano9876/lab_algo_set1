﻿namespace Academy.Week3.Demo.Types
{
    // 1. Positional record: concise immutable data carrier (init-only auto-properties)
    internal record Person(string FirstName, string LastName);
    internal record Point(int X, int Y);

    /*
     * record:
     *     reference type (class).
     *     record class supports inheritance (record A; record B : A;)
     */


    // 2. Nominal record with init-only properties
    internal record OrderItem
    {
        public int Id { get; init; }
        public string Product { get; init; } = string.Empty;
        public decimal UnitPrice { get; init; }
        public int Quantity { get; init; }
        public decimal LineTotal => UnitPrice * Quantity;
    }

    // 4. Record struct (value type) with value-based equality
    internal readonly record struct Money(decimal Amount, string Currency)
    {
        public Money Convert(decimal rate, string targetCurrency) =>
            new(Amount * rate, targetCurrency);
    }
    /*
     * readonly record struct: 
     *      compiler enforces that instance members do not mutate state (fields treated readonly).
     *      Use init-only or get-only properties for intended immutability.
     *      Value type (struct).
     *      Readonly prevents mutation of fields inside instance members (safer immutability)
     */

    internal class RecordDemo
    {
        internal static void Start()
        {
            var p1 = new Person("Ada", "Lovelace");
            var p2 = p1 with { LastName = "L." }; // non-destructive mutation
            Console.WriteLine(p1); // Person { FirstName = Ada, LastName = Lovelace }
            Console.WriteLine(p2); // Person { FirstName = Ada, LastName = L. }
            Console.WriteLine(p1 == new Person("Ada", "Lovelace")); // True (value equality)

            var item = new OrderItem
            {
                Id = 1,
                Product = "Book",
                UnitPrice = 12.5m,
                Quantity = 2
            };
            Console.WriteLine(item.LineTotal); // 25.0

            var pointA = new Point(3, 4);
            var pointB = new Point(3, 4);
            Console.WriteLine(pointA == pointB); // True

            var m1 = new Money(10m, "USD");
            var m2 = m1.Convert(0.9m, "EUR");
            //m2.Currency = "USD"; // Compile-time error: init-only
            Console.WriteLine($"{m1} -> {m2}");
            Money m3 = m2 with { Currency = "EUR" };
            Console.WriteLine(m2 == m3); // True


            // Immutability note:
            // p1.FirstName = "New"; // Compile-time error: init-only
        }
    }
}
