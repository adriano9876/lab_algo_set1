namespace Academy.Week3.Demo.Types
{
    public static class YieldDemo
    {
        public static void Start()
        {
            Console.WriteLine("Even numbers below 10:");
            foreach (var n in GetEvenNumbers(10))
            {
                Console.Write($"{n} ");
            }
            Console.WriteLine();

            Console.WriteLine("Numbers until first positive (stops at first > 0):");
            var data = new[] { -5, -2, 0, 3, 4, -1 };
            foreach (var n in TakeUntilPositive(data))
            {
                Console.Write($"{n} ");
            }
            Console.WriteLine();
        }

        // Demonstrates yield return: lazily produces even numbers < maxExclusive
        public static IEnumerable<int> GetEvenNumbers(int maxExclusive)
        {
            if (maxExclusive < 0) throw new ArgumentOutOfRangeException(nameof(maxExclusive));
            for (int i = 0; i < maxExclusive; i++)
            {
                if ((i & 1) == 0)
                {
                    yield return i;
                }
            }
        }

        // Demonstrates yield return + yield break:
        // Yields numbers until the first positive number appears, then stops.
        public static IEnumerable<int> TakeUntilPositive(IEnumerable<int> source)
        {
            if (source is null) throw new ArgumentNullException(nameof(source));
            foreach (var n in source)
            {
                if (n > 0)
                {
                    yield break; // Terminate sequence immediately
                }
                yield return n;
            }
        }
    }
}