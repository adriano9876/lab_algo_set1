﻿namespace Academy.Week3.Demo.Types
{
    // Domain model represented as a record (value-based equality, immutability by convention)
    public readonly record struct Star(
        string Name,
        double DistanceLy,          // Distance from Earth in light-years
        double AbsoluteMagnitude,   // Intrinsic brightness
        double ApparentMagnitude    // Perceived brightness from Earth
    );

    // Custom delegate describing a comparison between two stars.
    // Returns: < 0 (a before b), 0 (equal), > 0 (a after b)
    public delegate int StarComparison(Star a, Star b);

    // Static class containing reusable comparison methods (targets for the delegate).
    public static class StarComparisons
    {
        public static int ByDistance(Star a, Star b) =>
            a.DistanceLy.CompareTo(b.DistanceLy);

        public static int ByAbsoluteMagnitude(Star a, Star b) =>
            a.AbsoluteMagnitude.CompareTo(b.AbsoluteMagnitude);

        public static int ByApparentMagnitude(Star a, Star b) =>
            a.ApparentMagnitude.CompareTo(b.ApparentMagnitude);
    }

    public static class StarSorter
    {
        // Method that accepts the custom delegate
        public static void SortWithDelegate(this List<Star> stars, StarComparison comparison)
        {
            ArgumentNullException.ThrowIfNull(stars);
            ArgumentNullException.ThrowIfNull(comparison);

            // Adapt custom delegate to the built-in Comparison<Star>
            stars.Sort(new Comparison<Star>(comparison));
        }
    }

    internal static class DelegatesDemo
    {
        public static void Start()
        {
            var stars = new List<Star>
            {
                new("Sirius",        8.6,   1.42, -1.46),
                new("Betelgeuse",  642.5,  -5.85,  0.50),
                new("Rigel",       863.0,  -6.69,  0.12),
                new("Vega",         25.0,   0.58,  0.03),
                new("Proxima",       4.24, 15.60, 11.13)
            };

            Console.WriteLine("Original:");
            Dump(stars);

            // 1. Using custom delegate (method group)
            stars.SortWithDelegate(StarComparisons.ByDistance);
            Console.WriteLine("\nSorted by Distance (ly):");
            Dump(stars);

            // 2. Using another comparison method
            stars.SortWithDelegate(StarComparisons.ByAbsoluteMagnitude);
            Console.WriteLine("\nSorted by Absolute Magnitude (intrinsic brightness):");
            Dump(stars);

            // 3. Using lambda directly (no named method)
            StarSorter.SortWithDelegate(stars, (a, b) => a.ApparentMagnitude.CompareTo(b.ApparentMagnitude));
            Console.WriteLine("\nSorted by Apparent Magnitude (as seen from Earth):");
            Dump(stars);

            // 4. Using built-in List<T>.Sort with Comparison<Star>
            stars.Sort(StarComparisons.ByDistance);
            Console.WriteLine("\nBuilt-in Sort (method group) by Distance again:");
            Dump(stars);
        }

        private static void Dump(IEnumerable<Star> stars)
        {
            foreach (var s in stars)
            {
                Console.WriteLine($"{s.Name,-10} Dist={s.DistanceLy,7:0.##} ly  AbsMag={s.AbsoluteMagnitude,6:0.##}  AppMag={s.ApparentMagnitude,6:0.##}");
            }
        }
    }
}
