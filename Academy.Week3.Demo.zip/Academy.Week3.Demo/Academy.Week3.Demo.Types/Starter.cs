﻿namespace Academy.Week3.Demo.Types
{
    public class Starter
    {
        public static void Demo()
        {
            //RecordDemo.Start();
            //DelegatesDemo.Start();
            //SimpleDelegate.Start();
            //new NumberGenerator().Run();
            YieldDemo.Start();
        }
    }
}
