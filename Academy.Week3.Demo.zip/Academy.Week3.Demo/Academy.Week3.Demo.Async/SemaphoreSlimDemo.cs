using System.Collections.Concurrent;

namespace Academy.Week3.Demo.Async
{
    public static class SemaphoreSlimDemo
    {
        // Limit: at most 3 concurrent workers
        private static readonly SemaphoreSlim _pool = new(initialCount: 3, maxCount: 3);

        // Async "mutex" (1-at-a-time region)
        private static readonly SemaphoreSlim _sem = new(1, 1);

        public static async Task RunAsync(CancellationToken cancellationToken = default)
        {
            Console.WriteLine("=== SemaphoreSlim Demo ===");

            string[] items = Enumerable.Range(1, 10).Select(i => $"Item-{i:00}").ToArray();
            var results = new ConcurrentBag<string>();

            // Launch all tasks (simulate heavy work), pool controls how many run truly in parallel
            var tasks = items.Select(item => ProcessAsync(item, results, cancellationToken)).ToArray();

            await Task.WhenAll(tasks);

            Console.WriteLine("\nAll done. Results collected (order of completion):");
            foreach (var r in results)
                Console.WriteLine(r);
        }

        private static async Task ProcessAsync(string id, ConcurrentBag<string> results, CancellationToken ct)
        {
            // Acquire one slot from the concurrency pool
            await _pool.WaitAsync(ct);
            try
            {
                Console.WriteLine($"[POOL ENTER] {id} (avail_pool: {_pool.CurrentCount} of 3)");
                // Simulate variable work
                await Task.Delay(Random.Shared.Next(300, 900), ct);

                // Enter critical section (only one task at a time)
                await _sem.WaitAsync(ct);
                try
                {
                    // Critical region (e.g., writing to a shared file)
                    Console.WriteLine($"[SEM] {id} entered critical section");
                    results.Add($"{id} processed @ {DateTime.UtcNow:HH:mm:ss.fff}");
                    // Keep it short�avoid long blocking here
                }
                finally
                {
                    _sem.Release();
                }
            }
            finally
            {
                _pool.Release();
                Console.WriteLine($"[POOL EXIT ] {id} (avail_pool: {_pool.CurrentCount} of 3)");
            }
        }
    }
}