using System.ComponentModel;

namespace Academy.Week3.Demo.Async
{
    // Delegate for completion (still custom because we return a result)
    public delegate void Method1CompletedEventHandler(object sender, Method1CompletedEventArgs e);

    // Completed EventArgs (carries result + async status)
    public sealed class Method1CompletedEventArgs : AsyncCompletedEventArgs
    {
        private readonly int _result;
        internal Method1CompletedEventArgs(int result, Exception? error, bool cancelled, object? userState)
            : base(error, cancelled, userState) => _result = result;

        public int Result
        {
            get
            {
                RaiseExceptionIfNecessary();
                return _result;
            }
        }
    }

    // Simplified AsyncExample
    public class EapExample
    {
        private int _isBusy; // 0 = free, 1 = running (single operation demo)

        public EapExample()
        {
        }

        // Synchronous method
        public int Method1(string param)
        {
            if (param == null) throw new ArgumentNullException(nameof(param));
            Thread.Sleep(200); // Simulated work
            return param.Length;
        }

        // Events
        public event Method1CompletedEventHandler? Method1Completed;
        public event ProgressChangedEventHandler? Method1ProgressChanged;

        // Async overloads
        public void Method1Async(string param) => Method1Async(param, null);

        public void Method1Async(string param, object? userState)
        {
            if (param == null) throw new ArgumentNullException(nameof(param));
            if (Interlocked.Exchange(ref _isBusy, 1) == 1)
                throw new InvalidOperationException("Already running (demo allows only one concurrent operation).");

            Task.Run(async () =>
            {
                try
                {
                    // Simulate progress (5 steps)
                    for (int i = 1; i <= 5; i++)
                    {
                        await Task.Delay(150);

                        /* ERROR SIMULATION */
                        //if (i == 2) // Simulate an error at 40%
                        //    throw new InvalidOperationException("Simulated error during progress");
                        Method1ProgressChanged?
                            .Invoke(this, new ProgressChangedEventArgs(i * 20, userState));
                    }

                    int result = Method1(param);
                    Method1Completed?
                        .Invoke(this, new Method1CompletedEventArgs(result, null, false, userState));
                }
                catch (Exception ex)
                {
                    Method1Completed?
                        .Invoke(this, new Method1CompletedEventArgs(default, ex, false, userState));
                }
                finally
                {
                    Interlocked.Exchange(ref _isBusy, 0);
                }
            });
        }
    }
}