namespace Academy.Week3.Demo.Async
{
    /// <summary>
    /// Task-based Asynchronous Pattern (TAP) example using async/await.
    /// Prefer this over EAP for new development.
    /// </summary>
    public sealed class TapExample
    {
        /// <summary>
        /// Asynchronously simulates work and reports incremental progress.
        /// </summary>
        /// <param name="param">Input string (its Length becomes the result).</param>
        /// <param name="progress">Optional progress reporter (0..100).</param>
        /// <param name="cancellationToken">Cancellation token.</param>
        public async Task<int> Method1Async(
            string param,
            IProgress<int>? progress = null,
            CancellationToken cancellationToken = default)
        {
            if (param == null) throw new ArgumentNullException(nameof(param));

            // Simulate 5 progressive steps.
            const int steps = 5;
            for (int i = 1; i <= steps; i++)
            {
                cancellationToken.ThrowIfCancellationRequested();
                await Task.Delay(150, cancellationToken);

                // Example error trigger (uncomment to test failures)
                // if (i == 3) throw new InvalidOperationException("Simulated failure.");

                progress?.Report(i * 20);
            }

            // Simulated synchronous part (CPU-bound)
            await Task.Delay(50, cancellationToken); // pretend finalization
            return param.Length;
        }
    }
}