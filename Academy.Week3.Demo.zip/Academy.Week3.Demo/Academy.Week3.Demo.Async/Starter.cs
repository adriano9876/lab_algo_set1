﻿namespace Academy.Week3.Demo.Async
{
    public enum TplExample
    {
        ParallelFor,
        ParallelForEach,
        ForLocalVariables,
        ForWithoutLocals,
    }

    public class Starter
    {
        public static void StartEap()
        {
            Console.WriteLine("===== EAP demo =====\n");
            var asyncExample = new EapExample();
            using var done = new ManualResetEventSlim(false);

            asyncExample.Method1ProgressChanged += (s, e) =>
                Console.WriteLine($"[EAP] Progress: {e.ProgressPercentage}% (State={e.UserState ?? "null"})");

            asyncExample.Method1Completed += (s, e) =>
            {
                if (e.Error != null)
                    Console.WriteLine($"[EAP] Error: {e.Error.Message}");
                else
                    Console.WriteLine($"[EAP] Result: {e.Result}");
                done.Set();
            };

            Console.WriteLine("[EAP] Calling sync Method1...");
            int sync = asyncExample.Method1("Synchronous Call");
            Console.WriteLine($"[EAP] Sync result: {sync}\n");

            Console.WriteLine("[EAP] Starting Method1Async...");
            asyncExample.Method1Async("Hello EAP", userState: "EAP#1");

            done.Wait();
            Console.WriteLine();
        }

        public static async Task StartTapAsync()
        {
            Console.WriteLine("===== TAP demo (async/await) =====\n");

            var tap = new TapExample();
            using var cts = new CancellationTokenSource();
            var progress = new Progress<int>(p => Console.WriteLine($"[TAP] Progress: {p}%"));

            Console.WriteLine("Press 'c' quickly to cancel, any other key to continue running...\n");
            var keyTask = Task.Run(() =>
            {
                var key = Console.ReadKey(intercept: true);
                if (key.KeyChar is 'c' or 'C')
                {
                    Console.WriteLine("[TAP] Cancellation requested.\n");
                    cts.Cancel();
                }
                else
                {
                    Console.WriteLine($"[TAP] Continuing (pressed '{key.KeyChar}').\n");
                }
            });

            // Start the async operation (non-blocking)
            Task<int> operationTask =
                tap.Method1Async("Hello TAP Pattern", progress, cts.Token);

            try
            {
                await Task.WhenAll(operationTask, keyTask);
                int result = await operationTask; // already completed
                Console.WriteLine($"[TAP] Completed successfully. Result (string length) = {result}");
            }
            catch (OperationCanceledException)
            {
                Console.WriteLine("[TAP] Operation was cancelled.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[TAP] Error: {ex.Message}");
            }

            Console.WriteLine();
        }

        public static void StartTPL(TplExample tplExample)
        {
            switch (tplExample)
            {
                case TplExample.ParallelFor:
                    Console.WriteLine("===== TPL demo: Parallel.For =====\n");
                    TPL.ParallelFor(new[] { "C:\\repos\\" });
                    Console.WriteLine();
                    break;
                case TplExample.ParallelForEach:
                    Console.WriteLine("===== TPL demo: Parallel.ForEach =====\n");
                    TPL.ParallelForEach();
                    Console.WriteLine();
                    break;
                case TplExample.ForLocalVariables:
                    Console.WriteLine("===== TPL demo: For with thread-local variables =====\n");
                    TPL.ForLocalVariables();
                    Console.WriteLine();
                    break;
                case TplExample.ForWithoutLocals:
                    Console.WriteLine("===== TPL demo: For without thread-local variables =====\n");
                    TPL.ForWithoutLocals();
                    Console.WriteLine();
                    break;
                default:
                    throw new ArgumentOutOfRangeException(nameof(tplExample), tplExample, null);
            }
        }

        public static void StartSemaphoreSlim()
        {
            Console.WriteLine("===== SemaphoreSlim demo =====\n");
            SemaphoreSlimDemo.RunAsync().GetAwaiter().GetResult();
            Console.WriteLine();
        }
    }
}
