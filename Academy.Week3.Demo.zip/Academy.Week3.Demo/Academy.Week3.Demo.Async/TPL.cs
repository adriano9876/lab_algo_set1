﻿using System.Diagnostics;

namespace Academy.Week3.Demo.Async
{
    internal class TPL
    {
        public static void ParallelFor(string[] args)
        {
            long totalSize = 0;

            if (args.Length == 0)
            {
                Console.WriteLine("There are no command line arguments.");
                return;
            }
            if (!Directory.Exists(args[0]))
            {
                Console.WriteLine("The directory does not exist.");
                return;
            }

            String[] files = Directory.GetFiles(args[0]);
            Parallel.For(0, files.Length,
                         index => {
                             FileInfo fi = new FileInfo(files[index]);
                             long size = fi.Length;
                             Interlocked.Add(ref totalSize, size);
                         });
            Console.WriteLine($"Directory '{args[0]}':");
            Console.WriteLine("{0:N0} files, {1:N0} bytes", files.Length, totalSize);
        }

        public static void ParallelForEach()
        {
            // 2 million
            var limit = 2_000_000;
            var numbers = Enumerable.Range(0, limit).ToList();

            var watch = Stopwatch.StartNew();
            var primeNumbersFromForeach = Utilities.GetPrimeList(numbers);
            watch.Stop();

            var watchForParallel = Stopwatch.StartNew();
            var primeNumbersFromParallelForeach = Utilities.GetPrimeListWithParallel(numbers);
            watchForParallel.Stop();

            Console.WriteLine($"Classical foreach loop | Total prime numbers : {primeNumbersFromForeach.Count} | Time Taken : {watch.ElapsedMilliseconds} ms.");
            Console.WriteLine($"Parallel.ForEach loop  | Total prime numbers : {primeNumbersFromParallelForeach.Count} | Time Taken : {watchForParallel.ElapsedMilliseconds} ms.");

            Console.WriteLine("Press 'Enter' to exit.");
            Console.ReadLine();
        }

        /// <summary>
        /// This example shows how to use thread-local variables to store and retrieve
        /// state in each separate task that is created by a For loop.
        /// By using thread-local data, you can avoid the overhead of synchronizing a
        /// large number of accesses to shared state.
        /// Instead of writing to a shared resource on each iteration,
        /// you compute and store the value until all iterations for the task are complete.
        /// You can then write the final result once to the shared resource,
        /// or pass it to another method.
        /// </summary>
        public static void ForLocalVariables()
        {
            int[] nums = Enumerable.Range(0, 1_000_000).ToArray();
            long total = 0;

            // Use type parameter to make subtotal a long, not an int
            Parallel.For<long>(0, nums.Length, () => 0,
                (j, loop, subtotal) =>
                {
                    subtotal += nums[j];
                    return subtotal;
                },
                subtotal => Interlocked.Add(ref total, subtotal));

            Console.WriteLine($"The total is {total:N0}");
            Console.WriteLine("Press any key to exit");
            Console.ReadKey();
        }

        public static void ForWithoutLocals()
        {
            int[] nums = Enumerable.Range(0, 1_000_000).ToArray();
            long total = 0;

            Parallel.For(0, nums.Length,
                j =>
                {
                    Interlocked.Add(ref total, nums[j]);
                });
        }
    }
}
