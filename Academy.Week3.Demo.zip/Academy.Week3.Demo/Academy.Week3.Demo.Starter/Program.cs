﻿//using Academy.Week3.Demo.Async;

//using Academy.Week3.Demo.Types;

//using Academy.Week3.Demo.Exercises;

//using Academy.Week3.Demo.DependencyInjection;

using Academy.Week3.Demo.Types;

class Program
{
    static void Main()
    {
        Starter.Demo();

        //Starter.StartEap();

        //Starter.StartTapAsync().ConfigureAwait(false).GetAwaiter().GetResult();

        //Starter.StartTPL(TplExample.ForLocalVariables);

        //Starter.Demo();

        //Starter.StartSemaphoreSlim();

        //Starter.LoggerExercise();
    }
}