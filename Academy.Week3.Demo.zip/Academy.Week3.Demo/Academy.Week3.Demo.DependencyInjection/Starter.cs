﻿namespace Academy.Week3.Demo.DependencyInjection
{
    public class Starter
    {
        public static void RunScopes()
        {
            Scopes.Start();
        }

        public static void LoggerExercise()
        {
            LogDependencyInjection.Demo(LoggerType.File);
        }
    }
}
