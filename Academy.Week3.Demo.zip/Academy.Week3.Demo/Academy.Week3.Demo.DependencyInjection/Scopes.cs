﻿using Microsoft.Extensions.DependencyInjection;

namespace Academy.Week3.Demo.DependencyInjection
{
    internal interface IInterfaceA
    {
        public void MethodA();
    }

    internal interface IInterfaceB
    {
        public void MethodB();
    }

    internal class TypeA : IInterfaceA
    {
        public TypeA()
        {
            Console.WriteLine("Building A");
        }

        public void MethodA()
        {
            Console.WriteLine("I'm method A from type A");
        }
    }

    internal class TypeB : IInterfaceB
    {
        public TypeB()
        {
            Console.WriteLine("Building B");
        }

        public void MethodB()
        {
            Console.WriteLine("I'm method B from type B");
        }
    }

    internal class TypeC
    {
        private readonly IInterfaceA _a;
        private readonly IInterfaceB _b;

        public TypeC(IInterfaceA a, IInterfaceB b)
        {
            Console.WriteLine("Building C");
            _a = a;
            _b = b;
        }

        public void Call()
        {
            _a.MethodA();
            _b.MethodB();
        }
    }

    internal class Scopes
    {
        public static void Start()
        {
            ServiceCollection collection = new ServiceCollection();

            collection.AddScoped<IInterfaceA, TypeA>();
            collection.AddScoped<IInterfaceB, TypeB>();
            collection.AddScoped<TypeC>();

            //collection.AddSingleton<IInterfaceA, TypeA>();
            //collection.AddSingleton<IInterfaceB, TypeB>();
            //collection.AddScoped<TypeC>();

            //collection.AddSingleton<IInterfaceA, TypeA>();
            //collection.AddSingleton<IInterfaceB, TypeB>();
            //collection.AddSingleton<TypeC>();

            //collection.AddTransient<IInterfaceA, TypeA>();
            //collection.AddTransient<IInterfaceB, TypeB>();
            //collection.AddTransient<TypeC>();

            //collection.AddTransient<IInterfaceA, TypeA>();
            //collection.AddTransient<IInterfaceB, TypeB>();
            //collection.AddScoped<TypeC>();

            //collection.AddScoped<IInterfaceA, TypeA>();
            //collection.AddScoped<IInterfaceB, TypeB>();
            //collection.AddTransient<TypeC>();

            IServiceProvider serviceProvicer = collection.BuildServiceProvider();

            using (var scope = serviceProvicer.CreateScope())
            {
                TypeC? c = scope.ServiceProvider.GetService<TypeC>();

                if (c != null)
                {
                    c.Call();
                }

                TypeC? anotherC = scope.ServiceProvider.GetService<TypeC>();

                if (anotherC != null)
                {
                    anotherC.Call();
                }
            }

            using (var scope = serviceProvicer.CreateScope())
            {
                TypeC? c = scope.ServiceProvider.GetService<TypeC>();

                if (c != null)
                {
                    c.Call();
                }
            }
        }
    }
}
