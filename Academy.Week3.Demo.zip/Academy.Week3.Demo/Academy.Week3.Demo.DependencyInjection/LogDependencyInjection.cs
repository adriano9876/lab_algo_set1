using System;
using System.Diagnostics;
using System.IO;
using Microsoft.Extensions.DependencyInjection; // Requires package Microsoft.Extensions.DependencyInjection

namespace Academy.Week3.Demo.DependencyInjection
{
    // ILogger abstraction
    public interface ILogger
    {
        void Log(string message);
    }

    // Concrete logger implementations
    public sealed class ConsoleLogger : ILogger
    {
        public void Log(string message) =>
            Console.WriteLine($"[Console] {DateTime.Now:O} - {message}");
    }

    public sealed class DebugLogger : ILogger
    {
        public void Log(string message) =>
            Debug.WriteLine($"[Debug] {DateTime.Now:O} - {message}");
    }

    public sealed class FileLogger : ILogger
    {
        private readonly string _path;
        private static readonly object _lock = new();

        public FileLogger(string? path = null)
        {
            _path = string.IsNullOrWhiteSpace(path) ? "log.txt" : path;
        }

        public void Log(string message)
        {
            var line = $"[File] {DateTime.Now:O} - {message}{Environment.NewLine}";
            lock (_lock)
            {
                File.AppendAllText(_path, line);
            }
        }
    }

    // Service depending on ILogger via constructor injection
    public sealed class Application
    {
        private readonly ILogger _logger;

        public Application(ILogger logger) => _logger = logger;

        public void Run()
        {
            _logger.Log("Application starting.");
            for (int i = 1; i <= 3; i++)
            {
                _logger.Log($"Working on step {i}...");
            }
            _logger.Log("Application finished.");
        }
    }

    public enum LoggerType
    {
        Console,
        Debug,
        File
    }

    // Demo entry point using IServiceCollection / IServiceProvider
    public static class LogDependencyInjection
    {
        public static void Demo(LoggerType loggerType)
        {
            // 1. Create service collection
            var services = new ServiceCollection();

            // 2. Register chosen ILogger implementation (swap one line to change behavior)

            switch(loggerType)
            {
                case LoggerType.Console:
                    services.AddSingleton<ILogger, ConsoleLogger>();
                    break;
                case LoggerType.Debug:
                    services.AddSingleton<ILogger, DebugLogger>();
                    break;
                case LoggerType.File:
                    services.AddSingleton<ILogger>(sp => new FileLogger("log.txt"));
                    break;
                default:
                    throw new ArgumentOutOfRangeException(nameof(loggerType), loggerType, null);
            }

            // 3. Register the Application (transient for demo)
            services.AddTransient<Application>();

            // 4. Build provider
            using var provider = services.BuildServiceProvider();

            // 5. Resolve and run
            var app = provider.GetRequiredService<Application>();
            app.Run();

            // 6. (Optional) Use the same resolved logger directly
            var logger = provider.GetRequiredService<ILogger>();
            logger.Log("Extra log after Application.Run()");

            Console.WriteLine("DI container demo complete. Check Debug Output and/or log.txt.");
        }
    }
}