﻿using DataAccess;
using Entity;

namespace Business
{
    public static class Service
    {
        public static async Task<Station> GetStationAsync(string stationName)
        {
            var allStations = await Repository.GetAllStationsAsync();

            var departure = allStations.FirstOrDefault(s => s.Name == stationName);
            foreach (var s in allStations)
            {
                if (s.Name.ToLower().Trim() == stationName.ToLower().Trim())
                {
                    return s;
                }
            }

            return null;
        }

        public static async Task<string> GetDirectTrainsAsync(
            int departureStationId,
            int arrivalStationId)
        {
            var allTrips = await Repository.GetAllTripsAsync();

            var groupedTrips = GetGroupedTrips(allTrips);

            var validTrips = GetValidTrips(groupedTrips, departureStationId, arrivalStationId);
            //var validTrips2 = GetValidTrips2(groupedTrips, departureStationId, arrivalStationId);
            //var validTrips3 = GetValidTrips3(groupedTrips, departureStationId, arrivalStationId);

            return string.Join(", ", validTrips);
        }


        //var codeTrip1 = jsonTrips.Trips.GroupBy(trip => trip.Code)
        //    .Select(tripGroup => (tripGroup.Key, tripGroup.ToList()))
        //    .ToDictionary();
        private static Dictionary<string, List<Trip>> GetGroupedTrips(List<Trip> trips)
        {
            var codeTrip = new Dictionary<string, List<Trip>>();
            foreach (var trip in trips)
            {
                if (codeTrip.ContainsKey(trip.Code))
                {
                    codeTrip.TryGetValue(trip.Code, out var codeList);
                    codeList.Add(trip);
                }
                else
                {
                    codeTrip.Add(trip.Code, new List<Trip> { trip });
                }
            }

            return codeTrip;
        }

        private static List<string> GetValidTrips(
            Dictionary<string, List<Trip>> dictionary,
            int departureStationId,
            int arrivalStationId)
            => dictionary.Where(x => DoesListContainingBothStations(x.Value, departureStationId, arrivalStationId))
                .Select(x => x.Key).ToList();

        private static bool DoesListContainingBothStations(
            List<Trip> list,
            int departureStationId,
            int arrivalStationId)
        {
            var goesThroughDepartureStation = false;
            var goesThroughArrivalStation = false;

            foreach (var trip in list)
            {
                if (trip.From == departureStationId)
                {
                    goesThroughDepartureStation = true;
                }

                if (trip.To == arrivalStationId)
                {
                    goesThroughArrivalStation = true;
                }
            }

            return goesThroughArrivalStation && goesThroughDepartureStation;
        }

        private static List<string> GetValidTrips2(
            Dictionary<string, List<Trip>> dictionary,
            int departureStationId,
            int arrivalStationId)
            => dictionary.Where(x => x.Value.Any(y => y.From == departureStationId)
                                     && x.Value.Any(y => y.To == arrivalStationId))
                .Select(x => x.Key)
                .ToList();

        private static List<string> GetValidTrips3(
            Dictionary<string, List<Trip>> dictionary,
            int departureStationId,
            int arrivalStationId)
        {
            var departureTrips = dictionary.Where(x => x.Value.Any(y => y.From == departureStationId)).Select(x => x.Key);
            var arrivalTrips = dictionary.Where(x => x.Value.Any(y => y.To == arrivalStationId)).Select(x => x.Key);

            return departureTrips.Intersect(arrivalTrips).ToList();
        }
    }
}
