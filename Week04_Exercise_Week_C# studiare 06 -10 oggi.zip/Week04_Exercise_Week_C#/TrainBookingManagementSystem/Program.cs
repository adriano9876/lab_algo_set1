﻿using Business;

namespace TrainBookingManagementSystem
{
    public class Program
    {
        public static async Task Main(string[] args)
        {
            Console.WriteLine("Menu");
            Console.WriteLine("Create booking");

            var departureStationName = Console.ReadLine();
            var arrivalStationName = Console.ReadLine();

            var departureStation = await Service.GetStationAsync(departureStationName);
            if (departureStation == null)
            {
                Console.WriteLine("Departure station not found");
                return;
            }

            var arrivalStation = await Service.GetStationAsync(arrivalStationName);
            if (arrivalStation == null)
            {
                Console.WriteLine("Arrival station not found");
                return;
            }

            var result = await Service.GetDirectTrainsAsync(departureStation.Id, arrivalStation.Id);

            Console.WriteLine(result);
        }





    }







}