﻿namespace Entity
{
    public class Trip
    {
        public Trip(string code, int from, int to, bool isActive)
        {
            Code = code;
            From = from;
            To = to;
            IsActive = isActive;
        }

        public string Code { get; set; }

        public int From { get; set; }

        public int To { get; set; }

        public bool IsActive { get; set; }
    }
}
