﻿using Entity;

namespace DataAccess
{
    public class JsonTrips
    {
        public List<Trip> Trips { get; set; }
    }
}
