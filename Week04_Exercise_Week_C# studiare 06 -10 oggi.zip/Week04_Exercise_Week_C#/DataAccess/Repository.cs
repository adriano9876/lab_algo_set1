﻿using Entity;
using Newtonsoft.Json;

namespace DataAccess
{
    public static class Repository
    {
        public static async Task<List<Station>> GetAllStationsAsync()
        {
            var stationsPath = "..\\..\\..\\..\\DataAccess\\Data\\Stations.json";
            JsonStation jsonStation;
            using (var fileStream = new StreamReader(stationsPath))
            {
                var stations = await fileStream.ReadToEndAsync();
                jsonStation = JsonConvert.DeserializeObject<JsonStation>(stations);
            }

            return jsonStation.Stations;
        }

        public static async Task<List<Trip>> GetAllTripsAsync()
        {
            var tripsPath = "..\\..\\..\\..\\DataAccess\\Data\\Trips.json";
            JsonTrips jsonTrips;
            using (var fileStream = new StreamReader(tripsPath))
            {
                var trips = await fileStream.ReadToEndAsync();
                jsonTrips = JsonConvert.DeserializeObject<JsonTrips>(trips);
            }

            return jsonTrips.Trips;
        }
    }
}