﻿using Entity;

namespace DataAccess
{
    public class JsonStation
    {
        public List<Station> Stations { get; set; }
    }
}
