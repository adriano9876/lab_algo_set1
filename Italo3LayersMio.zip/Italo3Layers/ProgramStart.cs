﻿using Presentation;
using Business;
using DataAccess;
using Presentation;

using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
namespace Italo3Layers
{
    internal class ProgramStart
    {
        static void Main(string[] args)
        {
            /* questo container viene creato all'avvio */
            var applicationBuilder = Host.CreateApplicationBuilder();

    applicationBuilder.Services.AddSingleton<IBookingRepository,BookingRepository>();
    applicationBuilder.Services.AddSingleton<IBookingConverter,BookingConverter>();
    applicationBuilder.Services.AddSingleton<IBookingService,BookingService>();
    applicationBuilder.Services.AddSingleton<IConsoleView,ConsolView>();

            using var host = applicationBuilder.Build();
            using IServiceScope serviceScope = host.Services.CreateScope();
            var consoleView = serviceScope.ServiceProvider.GetService<IConsoleView>();
            if(consoleView != null)
            {
                consoleView.ShowMenu();
            }

            //Console.WriteLine("Ciao sei nella interfaccia di italo3layers");
            //IBookingRepository bookingRepository = new BookingRepository();
            //IBookingConverter bookingConverter = new BookingConverter();
            //IBookingService bookingService = new BookingService(bookingRepository,bookingConverter );
            //IConsoleView consoleView = new ConsolView(bookingService);
            //consoleView.ShowMenu();

            
       

           

        }




    }
}
