﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pegasus.Educational.altro
{
    public class Counter
    {
        public static int counter=0;

        public Counter()
        {
            counter++;
        }

    }
}
