﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pegasus.Educational.altro
{
    class Calculator
    {

        public string model;
        public string serial;
        

        public Calculator(string model, string serial)
        {
            this.model = model;
            this.serial = serial;
        }

        public Calculator()
        {

        }   
    
        public string PrintModel()
        {
            return $"Calcolatrice: {model} | Seriale: {serial}";
        }

        public int Calculate (int a, int b)
        {
            return a + b;
        }

        public int Calculate ( int a,int b, int c)
        {
            return a + b + c;
        }






    }

}


