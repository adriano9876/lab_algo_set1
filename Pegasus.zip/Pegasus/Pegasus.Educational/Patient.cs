﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pegasus.Educational
{
    public class Patient
    {
        public string name;
        public string surname;
        public string taxCode;
        public DateOnly dateOfBirth;
        public string medicalRecordId;

        public Patient(string name, string surname, string taxCode, DateOnly dateOfBirth, string medicalRecordId)
        {
            this.name = name;
            this.surname = surname;
            this.taxCode = taxCode;
            this.dateOfBirth = dateOfBirth;
            this.medicalRecordId = medicalRecordId;
        }


        public string GetOverViuwPatient()
        {
            return $"{name}{surname}";
        }
    }
}
