﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pegasus.Educational
{
    public class Medicine
    {
        public int barCode;
        public string activeIngredient;
        public double dosage;
        public MeasurementUnit measurementunit;



    }

    public enum MeasurementUnit
    {
        mcg,
        mg,
        g,
        ml
    }

}
