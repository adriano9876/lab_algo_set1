﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pegasus.Educational
{
    public class Doctor
    {
        string name;
        string surname;
        int registrationNumber;
        //bool? gender;
        string taxCode;
        DateOnly dateOfBirth;
        Seniority seniority;
        decimal salary;
        public Badge badge;

   public Doctor(string name, string surname,
       int registrationNumber, string taxCode, 
       DateOnly dateOfBirth, Seniority seniority, 
       decimal salary, Badge badge)
        {
            this.name = name;
            this.surname = surname;
            this.registrationNumber = registrationNumber;
            this.taxCode = taxCode;
            this.dateOfBirth = dateOfBirth;
            this.seniority = seniority;
            this.salary = salary;
            this.badge = badge;
        }


        public void IncreaseSalary(decimal increase)
        {
            salary  += increase;

        } 

        public string GetOverViewData()
        {
            return $"name: {name} | surname {surname} | seniority {seniority}" +
                $"accessLevel";
        }

        public void IncreaseSeniority()
        {
            if (seniority < Seniority.Senior)
            {
                seniority++;
            }
        }


    }
}
