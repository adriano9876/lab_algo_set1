﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pegasus.Educational
{
    public class Badge
    {
        public short accesses;
        public short accessLevel;

        public Badge(short accessLevel)
        {
            this.accessLevel = accessLevel;
        }

        public bool CanAccess(short requestToAccesLevel )
        {
            if(accessLevel >= requestToAccesLevel)
            {
                return true;
            }

            return false;
        }
        

    }
}
