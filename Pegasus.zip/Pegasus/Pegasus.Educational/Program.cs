﻿using System.Collections;

namespace Pegasus.Educational

{
    internal class Program
    {
        static void Main(string[] args)
        {
            //  int[] numeri = new int[5];
            //  Console.WriteLine("Inserisci un numero intero:");
            //  for (int i = 0; i < 5; i++)
            //  {
            //      string input = Console.ReadLine(); // Legge l'input come stringa
            //      if (int.TryParse(input, out int numero)) ; // Converte la stringa in
            //      //Console.WriteLine($"{numero}");
            //      numeri[i] = numero;
            //  }

            //  /*foreach(var tmp in numeri)
            //  {
            //      Console.WriteLine($"{tmp} \n->");
            //  }*/

            //  int[] arrayRisultato = new int[numeri.Length];
            //  int contatore = 0;
            //  for(int i=0; i<numeri.Length; i++)
            //  {
            //      for(int j=0; j<numeri.Length; j++)
            //      {
            //          if (numeri[i] == numeri[j])
            //          {
            //              contatore++;
            //          }
            //      }
            //      arrayRisultato[i] = contatore;
            //      contatore = 0;
            //  }

            //foreach(var tmp in arrayRisultato)
            //  {
            //      Console.WriteLine($"quantita = {tmp} \n");
            //  }
            //  int max_indice = 0;

            //  for(int i=0; i<arrayRisultato.Length; i++)
            //  {
            //      if (arrayRisultato[i] > max_indice)
            //      {

            //      }
            //  }

            /*Console.WriteLine("Hello, World!");
            Badge b1 = new Badge(3);
            Doctor doc1 = new Doctor("luca","luca2",1234,""
                ,new DateOnly(2000,1,1),Seniority.Junior,10,b1);
            Console.WriteLine(doc1.GetOverViewData());*/

            /*var c1 = new Calculator("casio", "ab1");
            var c2 = new Calculator("sharp", "zx2");

            int uno = c1.Calculate(1,22);
            int due = c2.Calculate(2,3);

            var c3 = new Calculator();
            var c4 = new Calculator();

            var co1 = new Counter();
            var co2 = new Counter();
            var co3 = new Counter();
            var co4 = new Counter();
            var co5 = new Counter();
            Console.WriteLine($"{ Counter.counter}");

        for (int i=0; i<7; i++)
            {
                Console.WriteLine($"{DaysWeek.[i]}\n");
            }*/


            /*Patient p1 = new Patient("luca","luca","XCVBNM1234",new DateOnly(2000,10,20),"123456P");
            Badge b1 = new Badge(3);
            Badge b2 = new Badge(3);
            Badge b3 = new Badge(3);
            Doctor doc1 = new Doctor("luca1", "luca1", 1234, ""    , new DateOnly(2000, 1, 1), Seniority.Junior, 10, b1);
            Doctor doc2 = new Doctor("luca2", "luca2", 2000, ""    , new DateOnly(2000, 2, 2), Seniority.Junior, 10, b2);
           
            Doctor[] doctors = new Doctor[2];
            doctors[0] = doc1;
            doctors[1] = doc2;

            //aggiungo un doctor al array

            Doctor doc3 = new Doctor("luca3", "luca3", 1000, "", new DateOnly(2000, 3, 3), Seniority.Junior, 10, b3);
            doctors[1] = doc3;
            foreach(var tmp in doctors)
            {
                Console.WriteLine($"{tmp.GetOverViewData}");
            }*/

            Badge b1 = new Badge(3);
            Badge b2 = new Badge(3);
            Badge b3 = new Badge(3);
            Doctor doc1 = new Doctor("luca1", "luca1", 1234, "", new DateOnly(2000, 1, 1), Seniority.Junior, 10, b1);
            Doctor doc2 = new Doctor("luca2", "luca2", 2000, "", new DateOnly(2000, 2, 2), Seniority.Junior, 10, b2);

            ArrayList arrayDoctors = new();
            arrayDoctors.Add(doc1);
            arrayDoctors.Add(doc2);

            ArrayList arrayDoctor2 = [doc1, doc2];
            Console.WriteLine($"{doc1}");

            foreach(var tmp in arrayDoctor2)
            {
                Console.WriteLine($"->{((Doctor)tmp).GetOverViewData()}");
            }

            for(int i=0; i<arrayDoctor2.Count; i++)
            {
                Console.WriteLine($"->{arrayDoctor2[i]}");
            }






        }
        static void printAllDoctors(ArrayList doctors)
        {

        }

        public static void IncreaseAuthorisationLv(Badge badge)
        {
            badge.accessLevel++;
        }
    }
}
