﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pegasus.Educational
{
    public static class Utils
    {
        static int doctorId;
        static Utils()
        {
            doctorId = 0;
        }

        public static int GeneratedoctorId()
        {
            return doctorId++;
        }
    }
}
