﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pegasus.Educational
{
    public class Medicine
    {
        public int barCode;
        public string ActiveIngredient { get; private set; }
        public double dosage;
        public MeasurementUnit measurementUnit;

        public Medicine(int barCode, string activeIngredient, double dosage, 
            MeasurementUnit measurementUnit)
        {
            this.barCode = barCode;
            ActiveIngredient = activeIngredient;
            this.dosage = dosage;
            this.measurementUnit = measurementUnit;
        }
    }

    public enum MeasurementUnit
    {
        mcg,
        mg,
        g,
        ml
    }
}
