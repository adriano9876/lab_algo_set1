﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pegasus.Educational
{
    public class StaffMember : Person
    {
        public int RegistrationNumber { get; private set; }
        public Seniority Seniority { get; private set; }
        private decimal salary;
        public Badge Badge { get; set; }
        public StaffMember(string name, string surname, string taxCode, DateOnly dateOfBirth, int registrationNumber, 
            Seniority seniority, decimal salary, Badge badge) : 
            base(name, surname, taxCode, dateOfBirth)
        {
            RegistrationNumber = registrationNumber;
            Seniority = seniority;
            this.salary = salary;
            Badge = badge;
        }

        public void IncreaseSalary(decimal increase)
        {
            salary += increase;
        }


        public void IncreaseSeniority()
        {
            if (Seniority < Seniority.Senior)
            {
                Seniority++;
            }
        }
    }
}
