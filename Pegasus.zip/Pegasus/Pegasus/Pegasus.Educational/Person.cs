﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.CompilerServices.RuntimeHelpers;
using System.Xml.Linq;

namespace Pegasus.Educational
{
    public class Person
    {
        public string Name { get; set; }
        public string Surname { get; set; }
        public string TaxCode { get; set; }
        public DateOnly DateOfBirth { get; private set; }
        public bool IsAvailable { get; private set; }

        public Person(string name, string surname, string taxCode, DateOnly dateOfBirth)
        {
            Name = name;
            Surname = surname;
            TaxCode = taxCode;
            DateOfBirth = dateOfBirth;
        }

        public bool UpdateAvailability()
        {
            IsAvailable = !IsAvailable;
            return IsAvailable;
        }

        public virtual string GetOverviewData()
        {
            return $"Nome: {Name} Cognome: {Surname} CF: {TaxCode}";
        }
    }
}
