﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pegasus.Educational
{
    public class Patient: Person
    {
        public int MedicalRecordId { get; private set; }
        public SortedList<TimeOnly, Medicine> DailyTherapy { get; set; }
        public SortedList<DateTime, Medicine> TherapyLogs { get; set; }

        public Patient(string name, string surname, string taxCode, DateOnly dateOfBirth, 
            int medicalRecordId): base(name, surname, taxCode, dateOfBirth)
        {
            MedicalRecordId = medicalRecordId;
            DailyTherapy = new SortedList<TimeOnly, Medicine>();
            TherapyLogs = new SortedList<DateTime, Medicine>();
        }

        public override string GetOverviewData()
        {
            return base.GetOverviewData() + " Medical record: " + MedicalRecordId;
        }
    }

}
