﻿using System.Collections;

namespace Pegasus.Educational
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Badge badgeDoc1 = new(3);
            Badge badgeDoc2 = new(3);
            Badge badgeDoc3 = new(1);

            Doctor doc1 = new Doctor("Pippo", "Paulo", Utils.GenerateDoctorId(), "PPPL",
                new DateOnly(1912, 12, 3), Seniority.Senior, 124567m, badgeDoc1);
            Doctor doc2 = new Doctor("Mario", "Rossi", Utils.GenerateDoctorId(), "MRRS",
                new DateOnly(1958, 1, 3), Seniority.Senior, 124001m, badgeDoc2);
            Doctor doc3 = new Doctor("Lucia", "Verdi", Utils.GenerateDoctorId(), "LCVR",
                new DateOnly(1990, 8, 24), Seniority.Senior, 12467m, badgeDoc3);

            Console.WriteLine(doc1.Badge);

            List<Doctor> doctors = new()
            {
                doc1, doc2, doc3
            };

            var patient1 = new Patient("Girolamo", "House", "GRLS", new DateOnly(1942, 1, 3), 1122);
            var patient2 = new Patient("Bloom", "Winx", "BLWN", new DateOnly(1966, 10, 23), 3344);

            List<Patient> patients = new List<Patient>()
            {
                patient1, patient2
            };

            Medicine diarrent = new Medicine(123456, "Loperamide", 10, MeasurementUnit.mg);
            Medicine felixFelicitas = new Medicine(9462, "Felisus", 100, MeasurementUnit.ml);

            AdministerTherapy(diarrent, patient2);
            UpsertTherapy(new TimeOnly(7, 10), felixFelicitas, patient1);
            UpsertTherapy(new TimeOnly(7, 10), diarrent, patient1);

            //Dictionary<string, Patient> patientsSpeed = new Dictionary<string, Patient>()
            //{
            //    [patient1.taxCode] = patient1,
            //    [patient2.taxCode] = patient2,
            //};
            Person person = new("persona", "generica", "prgn", new DateOnly(1999, 12, 9));
            //Console.WriteLine(doc1.GetOverviewData());
            //Console.WriteLine(person.GetOverviewData());
            //Console.WriteLine(patient1.GetOverviewData());

            var patientFinded1 = FindPatient(1122, patients);
            var patientFinded2 = FindPatient("TRLD", patients);
            var patientFinded3 = FindPatient("BLWN", patients);

            //Console.WriteLine(patientFinded1.GetOverviewData());
            //Console.WriteLine(patientFinded2.GetOverviewData());
            //Console.WriteLine(patientFinded3.GetOverviewData());

            //var res1 = TryFindPatient("GRLS", patients, out Patient findedPatient1, new DateOnly(1942, 1, 3));
            //var res2 = TryFindPatient("GRLS", patients, out Patient findedPatient2);

        }

        static bool TryFindPatient(string cf, List<Patient> patients, out Patient findedPatient, DateOnly dateOfBirth = default)
        {

            if(dateOfBirth == default)
            {
                findedPatient = FindPatient(cf, patients);
                return true;
            }
            foreach(var patient in patients)
            {
                if (patient.TaxCode == cf && patient.DateOfBirth == dateOfBirth)
                {
                    findedPatient = patient;
                    return true;
                }
            }
            findedPatient = null;
            return false;
        }
        static Patient FindPatient(int medicalRecordNr, List<Patient> patients)
        {
            foreach(var patient in patients)
            {
                if(patient.MedicalRecordId == medicalRecordNr)
                {
                    return patient;
                }
            }
            return null;
        }
        static Patient FindPatient(string cf, List<Patient> patients)
        {
            foreach (var patient in patients)
            {
                if (patient.TaxCode == cf)
                {
                    return patient;
                }
            }
            return null;
        }

        static void AdministerTherapy(Medicine medicine, Patient patient)
        {
            patient.TherapyLogs.Add(DateTime.Now, medicine);
        }

        static void UpsertTherapy(TimeOnly time, Medicine medicine, Patient patient)
        {
            patient.DailyTherapy[time] = medicine;
        }

        static Patient SpeedSearch(string cf, Dictionary<string, Patient> patients)
        {
            var succeed = patients.TryGetValue(cf, out Patient patient);
            if (succeed)
            {
                return patient;
            }
            return null;
        }


        static void IncreaseAuthorizationLvl(Badge badge)
        {
            badge.accessLevel++;
        }


    }
}
