﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pegasus.Educational
{
    public class Badge
    {
        public short accessesNr;
        public short accessLevel;

        public Badge(short accessLevel)
        {
            this.accessLevel = accessLevel;
        }

        public bool CanAccess(short requestedAccessLevel)
        {
            if (accessLevel >= requestedAccessLevel)
            {
                return true;
            }
            return false;
        }

    }
}
