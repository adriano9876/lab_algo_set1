﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pegasus.Educational
{
    public class Nurse : StaffMember
    {
        public Nurse(string name, string surname, string taxCode, DateOnly dateOfBirth, int registrationNumber, 
            Seniority seniority, decimal salary, Badge badge, UnitIntensity intensity) : 
            base(name, surname, taxCode, dateOfBirth, registrationNumber, seniority, salary, badge)
        {
            Intensity = intensity;
        }

        public UnitIntensity Intensity { get; set; } 
      
    }
    

    public enum UnitIntensity
    {
        
        Low,
        Mid,
        High
    }
}
