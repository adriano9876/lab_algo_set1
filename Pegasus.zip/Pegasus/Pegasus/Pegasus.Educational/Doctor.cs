﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pegasus.Educational
{
    public class Doctor : StaffMember
    {
     
        public Doctor(string name, string surname, int registrationNumber, 
            string taxCode, DateOnly dateOfBirth, Seniority seniority, 
            decimal salary, Badge badge): base(name, surname, taxCode, dateOfBirth, registrationNumber, seniority, salary, badge)
        {
        }
        public override string GetOverviewData()
        {
            return base.GetOverviewData() + " Reg number: " + RegistrationNumber;
        }
    }
}
