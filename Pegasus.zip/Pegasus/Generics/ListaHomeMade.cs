﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Generics
{
    public class ListaHomeMade<T>
    {
        T[] lista;
        int elemNow;
        int capacity;
        public ListaHomeMade()
        {
            lista = new T[capacity];
            elemNow = 0;
            capacity = 128;
        }

        public void addValue<T>(T elem)
        {
            if (elem != null)
            {
                lista[elemNow] = elem;
                elemNow++;
            }
        }


    }
}
