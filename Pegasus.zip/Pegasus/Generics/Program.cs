﻿namespace Generics
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Esercizi generici");
            List<String> list = new List<string>();
            list.Add("milano");
            list.Add("torino");
            list.Add("roma");
            list.Add("padova");
            list.Add("napoli");
            list.Add("puglia");
            list.Add("rimini");
            list.Add("forli");
            list.Add("avigliano");
            list.Add("giaveno");
            list.Add("barcellona");
            list.Add("siviglia");
            list.Remove("milano");
            list.Remove("torino");
            Console.WriteLine($"{list.Count}");
            //list.Add(2);

            var db = new Dictionary<string, string>();
            db.Add("chau","ciao1");
            db.Add("hola","ciao2");
           
            bool res=db.TryGetValue("hola",out string value);

            if (res) {
                Console.WriteLine($"{value}");
            }
            db["hola"] = "agiornato";




        }

        public void UserChoise()
        {

        }

        public static void Sorted<T>(List<T> list)
        {

            Console.Write($"\nORDINATO :)\n");

            list.Sort();
            //foreach (var tmp in list)
            //{
            //    Console.Write($"{tmp}\n");
            //}
        }

        public static void UnSorted<T>(List<T> list)
        {

            Console.Write($"\nreverse :)\n");
            list.Sort();
            list.Reverse();
            //foreach (var tmp in list)
            //{
            //    Console.Write($"{tmp}\n");
            //}
        }



    }
}
