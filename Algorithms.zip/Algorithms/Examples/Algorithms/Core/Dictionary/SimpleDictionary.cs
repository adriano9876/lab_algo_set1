﻿
namespace Algorithms.Core.Dictionary
{
    public class SimpleDictionary
    {
        private static int _arrayCapacity = 997;
        private static int _offset = 2;

        private struct Element
        {
            public int key;
            public string value;
            public bool isFree;
        }

        private Element[] Elements;

        public SimpleDictionary()
        {
            Elements = new Element[_arrayCapacity];
            for (int i = 0; i < _arrayCapacity; i++)
            {
                Elements[i].isFree = true;
            }
        }

        private int ComputeHashNumber(int key)
            => key % _arrayCapacity;


        private int IterationFunction(int iterationKey)
            => (iterationKey * _arrayCapacity) + _offset;

        public bool Add(int key, string value)
        {
            return false;
        }

        public string GetValue(int key)
        {
            return string.Empty;
        }

        public bool Remove(int key)
        {
            return false;
        }

        public bool Contains(int key)
        {
            return false;
        }

        public string this[int key]
        {
            get => GetValue(key);
        }

        public bool TryGetValue(int key, out string? value)
        {
            try
            {
                value = GetValue(key);
                return true;
            } catch (ArgumentException)
            {
                value = null;
                return false;
            }
        }

    }
}
