﻿namespace Algorithms.Core.Balls.Objects
{
    public enum Colour
    {
        Yellow,
        Green,
        Red,
    }
}
