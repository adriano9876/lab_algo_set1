﻿namespace Algorithms.Core.Balls.Objects
{
    public class Ball
    {
        public Colour Colour { get; }

        public Ball(Colour colour)
        {
            Colour = colour;
        }
    }
}
