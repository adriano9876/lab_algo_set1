﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Algorithms.Core.Stars
{
    public static class XmasHelper
    {
        public static string CreateXmasTreeWithStars(int numberOfRows)
        {
            return null;
        }
    }
}
