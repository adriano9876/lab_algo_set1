﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Algorithms.Core.Tree
{
    public static class NodeHelper
    {
        public static Node? FindLinear(this IEnumerable<Node> nodes, int number)
        {
            return nodes.First();
        }
    }
}
