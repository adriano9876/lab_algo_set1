﻿
public class Node
{
    public Node? Left { get; set; }
    public int Value { get; set; }
    public Node? Right { get; set; }

    public Node(int value)
    {
        this.Value = value;
        this.Right = null;
        this.Left = null;
    }

    public override bool Equals(object? other)
    {
        return other is Node node && this.Value == node.Value;
    }
}

