﻿
public class Tree
{
    public Node Root { get; }

    public Tree(Node root)
    {
        Root = root;
    }
}

