﻿
public static class TreeHelper
{

    public static void AddValue(this Tree tree, int value)
    {
        AddValue(tree.Root, value);
    }

    private static void AddValue(Node root, int value)
    {
        return;
    }

    public static Node? FindValue(this Tree tree, int value)
    {
        return FindValue(tree.Root, value);
    }

    public static Node? FindValue(Node root, int value)
    {
        // implement it iteratively or recursively
        return root;
    }
}


