﻿using Algorithms.Core.Bingo.Objects;
using System.Runtime.CompilerServices;

namespace Algorithms.Core.Bingo
{
    public static class BingoHelper
    {
        public static BingoBall? SearchBall(this BingoBall[] ballArray, int number)
        {
            return BinarySearchBall(ballArray, number, 0, ballArray.Length - 1);
        }

        public static BingoBall? SearchBallLinear(this BingoBall[] ballArray, int number)
        {
            return ballArray[0];
        }

        private static BingoBall? BinarySearchBall(BingoBall[] ballArray, int value, int start, int end)
        {
            return ballArray[0];
        }

    }
}
