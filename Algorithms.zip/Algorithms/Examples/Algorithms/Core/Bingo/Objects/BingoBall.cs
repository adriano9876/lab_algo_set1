﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Algorithms.Core.Bingo.Objects
{
    public class BingoBall
    {
        public int Number;

        public BingoBall(int number)
        {
            Number = number;           
        }
    }
}
