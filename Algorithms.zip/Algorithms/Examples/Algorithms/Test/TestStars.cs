﻿using Algorithms.Core.Stars;
using Logic.Test.Utilita;

namespace Algorithms.Test
{
    public class TestStars : TestBase
    {
        public void Test()
        {
            DisplayHelper.MostraTitolo("Exercises on Xmas Tree with stars");
            var dimensions = new List<int> { 5, 8, 10, 20 };

            foreach (var dimension in dimensions)
            {
                Console.WriteLine($"Print Xmas Tree with {dimension}");
                var printString = XmasHelper.CreateXmasTreeWithStars(dimension);
                Console.WriteLine(printString);
                CheckStarsPrint(printString, dimension);
            }
            DisplayHelper.MostraRisultati("Exercises on Xmas Tree with stars", numeroDiTestEffettuati, numeroDiTestCorretti);
        }

        private void CheckStarsPrint(string stars, int numberOfRows)
        {
            if (stars == null)
            {
                Console.WriteLine("No test could be run as implementation is missing.");
                UpdateStatistics(0 == 1);
                return;
            }
            stars = stars.TrimEnd('\n', '\r');
            var lines = stars.Split('\n');
            var firstLine = lines.First().TrimEnd();
            var secondLine = lines.Skip(1).First().TrimEnd();
            var thirdLine = lines.Skip(2).First().TrimEnd();
            var numberOfStarsOn1Line = firstLine.ToArray().Count(x => x == '*');
            var numberOfSpaceOn1Line = firstLine.ToArray().Count(x => x == ' ');
            UpdateStatistics(numberOfStarsOn1Line == 1);
            UpdateStatistics(numberOfSpaceOn1Line == numberOfRows-1);
            var numberOfStarsOn2Line = secondLine.ToArray().Count(x => x == '*');
            var numberOfSpaceOn2Line = secondLine.ToArray().Count(x => x == ' ');
            UpdateStatistics(numberOfStarsOn2Line == 3);
            UpdateStatistics(numberOfSpaceOn2Line == numberOfRows-2);
            var numberOfStarsOn3Line = thirdLine.ToArray().Count(x => x == '*');
            var numberOfSpaceOn3Line = thirdLine.ToArray().Count(x => x == ' ');
            UpdateStatistics(numberOfStarsOn3Line == 5);
            UpdateStatistics(numberOfSpaceOn3Line == numberOfRows-3);

            var beforeLastLine = lines.Skip(numberOfRows - 2).First().TrimEnd();
            var lastLine = lines.Last().TrimEnd();
            var numberOfStarsOnBeforeLastLine = beforeLastLine.ToArray().Count(x => x == '*');
            var numberOfSpacesOnBeforeLastLine = beforeLastLine.ToArray().Count(x => x == ' ');
            UpdateStatistics(numberOfStarsOnBeforeLastLine == (2 * numberOfRows - 3));
            UpdateStatistics(numberOfSpacesOnBeforeLastLine == 1);
            var numberOfStarsOnLastLine = lastLine.ToArray().Count(x => x == '*');
            var numberOfSpacesOnLastLine = lastLine.ToArray().Count(x => x == ' ');
            UpdateStatistics(numberOfStarsOnLastLine == (2 * numberOfRows - 1));
            UpdateStatistics(numberOfSpacesOnLastLine == 0);
        }
    }
}
