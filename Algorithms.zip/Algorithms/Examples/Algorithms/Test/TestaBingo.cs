﻿using Algorithms.Core.Bingo;
using Algorithms.Core.Bingo.Objects;
using Algorithms.Test.Utilita;
using Logic.Test.Utilita;

namespace Algorithms.Test
{
    public class TestaBingo : TestPerformanceBase
    {
        public TestaBingo()
        {
        }

        public void Test()
        {
            DisplayHelper.MostraTitolo("Exercises on Tombola");
            TestNumberResearch();      
            DisplayHelper.MostraRisultati("Exercises on Tombola", numeroDiTestEffettuati, numeroDiTestCorretti, numberOfPerformanceTestsExecuted, numberOfPerformanceTestsPassed);
        }

        private void TestNumberResearch()
        {
            var tombolaBoard = CreateManualArray();
            EseguiEAggiornaStatistiche("Classic Tombola", n => tombolaBoard.SearchBall(n), n => tombolaBoard.Where(b => b.Number == n).First(), 18);
            EseguiEAggiornaStatistiche("Classic Tombola", n => tombolaBoard.SearchBall(n), n => tombolaBoard.Where(b => b.Number == n).First(), 1);
            EseguiEAggiornaStatistiche("Classic Tombola", n => tombolaBoard.SearchBall(n), n => tombolaBoard.Where(b => b.Number == n).FirstOrDefault(), 2, (r1, r2) => r1 == r2);
            EseguiEAggiornaStatistiche("Classic Tombola", n => tombolaBoard.SearchBall(n), n => tombolaBoard.Where(b => b.Number == n).First(), 52);

            var dimensions = new List<int> { 99, 999, 9999, 99999 };
            foreach(var dimension in dimensions)
            {
                var bigTombola = CreateArray(dimension);
                ExecutePerformanceTestAndUpdateStatistics($"Big tombola, dim {dimension}", p => bigTombola.SearchBall(p), p => bigTombola.SearchBallLinear(p), 50, comparison: "Linear", factor: 3);
                ExecutePerformanceTestAndUpdateStatistics($"Big tombola, dim {dimension}", p => bigTombola.SearchBall(p), p => bigTombola.SearchBallLinear(p), 10000000, (r1,r2) => r1 == r2, comparison: "Linear");
                ExecutePerformanceTestAndUpdateStatistics($"Big tombola, dim {dimension}", p => bigTombola.SearchBall(p), p => bigTombola.SearchBallLinear(p), 49, (r1, r2) => r1 == r2, comparison: "Linear");
                ExecutePerformanceTestAndUpdateStatistics($"Big tombola, dim {dimension}", p => bigTombola.SearchBall(p), p => bigTombola.SearchBallLinear(p), dimension-1, (r1, r2) => r1 == r2, comparison: "Linear");

                ExecutePerformanceTestAndUpdateStatistics($"Big tombola, dim {dimension}", p => bigTombola.SearchBall(p), p => bigTombola.Where(b => b.Number == p).First(), 50, comparison: "Linq");
                ExecutePerformanceTestAndUpdateStatistics($"Big tombola, dim {dimension}", p => bigTombola.SearchBall(p), p => bigTombola.Where(b => b.Number == p).FirstOrDefault(), 10000000, (r1, r2) => r1 == r2, comparison: "Linq");
                ExecutePerformanceTestAndUpdateStatistics($"Big tombola, dim {dimension}", p => bigTombola.SearchBall(p), p => bigTombola.Where(b => b.Number == p).FirstOrDefault(), 49, (r1, r2) => r1 == r2, comparison: "Linq");
            }
        }

        private BingoBall[] CreateArray(int dimension)
        {
            // creates array without 49 value
            var array = new BingoBall[dimension];
            for(int i = 0; i < dimension; i++)
            {
                int value = i;
                if (i >= 49)
                {
                    value = value +1;
                }

                array[i] = new BingoBall(value);
            }
            return array;
        }

        private BingoBall[] CreateManualArray()
        {
            return new BingoBall[]
            {
                // sorted
                new BingoBall(1),
                new BingoBall(3),
                new BingoBall(6),
                new BingoBall(9),
                new BingoBall(12),
                new BingoBall(15),
                new BingoBall(18),
                new BingoBall(21),
                new BingoBall(24),
                new BingoBall(27),
                new BingoBall(30),
                new BingoBall(33),
                new BingoBall(36),
                new BingoBall(39),
                new BingoBall(42),
                new BingoBall(45),
                new BingoBall(48),
                new BingoBall(52),
            };
        }
    }
}
