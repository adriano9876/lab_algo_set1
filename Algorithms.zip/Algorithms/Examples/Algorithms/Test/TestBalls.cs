﻿using Algorithms.Core.Balls;
using Algorithms.Core.Balls.Objects;
using Algorithms.Test.Utilita;
using Logic.Test.Utilita;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Algorithms.Test
{
    public class TestBalls : TestPerformanceBase
    {
        public void Test()
        {
            DisplayHelper.MostraTitolo("Exercises on Balls");
            DoTestArraySorting();
            DisplayHelper.MostraRisultati("Exercises on Balls", numeroDiTestEffettuati, numeroDiTestCorretti, numberOfPerformanceTestsExecuted, numberOfPerformanceTestsPassed);
        }

        private void DoTestArraySorting()
        {
            int numberOfColours = 3;
            var ballArray = CreateSmallArray();
            var sortedArray = ballArray.SortBalls(numberOfColours);
            EseguiEAggiornaStatistiche("Small Array", p => CheckSorting(sortedArray), p => true, 1);

            List<int> dimensions = new List<int>() { 9, 99, 999, 9999, 99999, 999999 };
            foreach (var dimension in dimensions)
            {
                var array = CreateBigArray(dimension, numberOfColours);
                sortedArray = array.SortBalls(numberOfColours);

                ExecutePerformanceTestAndUpdateStatistics(
                    $"Array dim {dimension}",
                    p => array.SortBalls(numberOfColours),
                    p => array.OrderBy(b => b.Colour).ToArray(), 
                    0,
                    (r1, r2) => CheckSorting(r1),
                    factor: 0.9,
                    comparison: "Linq");
            }
        }

        private bool CheckSorting(Ball[] array)
        {
            Ball? lastValue = null;
            Ball? currentValue = null;
            foreach (var ball in array)
            {
                lastValue = currentValue;
                currentValue = ball;
                if (lastValue == null)
                {
                    continue;
                }

                if (lastValue.Colour > currentValue.Colour)
                {
                    return false;
                }
            }
            return true;
        }
 
        private Ball[] CreateSmallArray()
        {
            return new Ball[]
            {
                new Ball(Colour.Red),
                new Ball(Colour.Red),
                new Ball(Colour.Green),
                new Ball(Colour.Green),
                new Ball(Colour.Green),
                new Ball(Colour.Red),
                new Ball(Colour.Yellow),
                new Ball(Colour.Red),
                new Ball(Colour.Red),
                new Ball(Colour.Green),
                new Ball(Colour.Yellow),
                new Ball(Colour.Green),
                new Ball(Colour.Red),
                new Ball(Colour.Yellow),
                new Ball(Colour.Red),
                new Ball(Colour.Yellow),
                new Ball(Colour.Green),
                new Ball(Colour.Green),
            };
        }

        private Ball[] CreateBigArray(int numberOfElements, int numberOfColours)
        {
            var ballArray = new Ball[numberOfElements];
            for (int i = 0; i < numberOfElements; i++)
            {
                Random rnd = new Random();
                var colour = rnd.Next(0, numberOfColours -1);
                ballArray[i] = new Ball((Colour)colour);
            }

            return ballArray;
        }
    }
}
