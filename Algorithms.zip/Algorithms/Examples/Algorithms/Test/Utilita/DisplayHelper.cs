﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logic.Test.Utilita
{
    public class DisplayHelper
    {
        public static void MostraRisultati(string titolo, int testEffettuati, int testSuperati)
        {
            double percentualeDiSuccesso = testSuperati * 100 / testEffettuati;
            Console.WriteLine("\n\n-----------------------------------");
            Console.WriteLine(titolo);
            Console.WriteLine($"Test effettuati {testEffettuati}, test superati {testSuperati}");
            Console.WriteLine($"Percentuale di successo {percentualeDiSuccesso}%");
            Console.WriteLine("-----------------------------------\n\n");
        }

        public static void MostraRisultati(string titolo, int testEffettuati, int testSuperati, int testPerformanceEffettuati, int testPerformanceSuperati)
        {
            double percentualeDiSuccesso = testSuperati * 100 / testEffettuati;
            double percentualePerformanceDiSuccesso = testPerformanceSuperati * 100 / testPerformanceEffettuati;
            Console.WriteLine("\n\n-----------------------------------");
            Console.WriteLine(titolo);
            Console.WriteLine($"Integrity - test effettuati {testEffettuati}, test superati {testSuperati}");
            Console.WriteLine($"Performance - test effettuati {testPerformanceEffettuati}, test superati {testPerformanceSuperati}");
            Console.WriteLine($"Integrity - percentuale di successo {percentualeDiSuccesso}%");
            Console.WriteLine($"Performance - percentuale performance di successo {percentualePerformanceDiSuccesso}%");
            Console.WriteLine("-----------------------------------\n\n");
        }

        public static void MostraTitolo(string titolo)
        {
            Console.WriteLine("\n\n-----------------------------------");
            Console.WriteLine(titolo);
            Console.WriteLine("-----------------------------------\n\n");
        }
    }
}
