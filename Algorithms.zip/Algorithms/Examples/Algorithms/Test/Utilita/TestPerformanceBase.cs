﻿using Logic.Test.Utilita;
using System.Diagnostics;

namespace Algorithms.Test.Utilita
{
    public abstract class TestPerformanceBase : TestBase
    {
        protected int numberOfPerformanceTestsExecuted = 0;
        protected int numberOfPerformanceTestsPassed = 0;

        protected void UpdatePerformanceStatistics(bool areValuesSame)
        {
            numberOfPerformanceTestsExecuted++;
            numberOfPerformanceTestsPassed += (areValuesSame ? 1 : 0);
        }

        protected void ExecutePerformanceTestAndUpdateStatistics<P, R>(string title, Func<P, R> myFunc, Func<P, R> sistema, P value1, Func<R, R, bool> equals = null, double factor = 1, string comparison = "System")
        {
            var myFuncStopWatch = new Stopwatch();
            var systemStopWatch = new Stopwatch();
            myFuncStopWatch.Start();
            var myRet = myFunc(value1);
            myFuncStopWatch.Stop();
            systemStopWatch.Start();
            var sysRet = sistema(value1);
            systemStopWatch.Stop();
            var check = equals == null ? myRet.Equals(sysRet) : equals(myRet, sysRet);
            var successString = check ? "PASSED" : "FAILED";
            var displayValue2 = typeof(P).IsArray ? "array" : value1?.ToString();
            Console.WriteLine($"{title}, values: {displayValue2} - {successString}");
            UpdateStatistics(check);
            var performanceCheck = systemStopWatch.ElapsedTicks * factor > myFuncStopWatch.ElapsedTicks;
            var performanceSuccessString = performanceCheck ? "PASSED" : "FAILED";
            Console.WriteLine($"Performance, yours expected to be quicker than {factor}x {comparison} {systemStopWatch.ElapsedTicks} ticks. " +
                $"Yours {myFuncStopWatch.ElapsedTicks} ticks - {performanceSuccessString}");
            UpdatePerformanceStatistics(performanceCheck);
        }

        protected void ExecutePerformanceTestAndUpdateStatistics<E, P, R>(string title, Func<E, P, R> myFunc, Func<E, P, R> sistema, E value1, P value2, Func<R, R, bool> equals = null, double factor = 1, string comparison = "System")
        {
            var myFuncStopWatch = new Stopwatch();
            var systemStopWatch = new Stopwatch();
            myFuncStopWatch.Start();
            var myRet = myFunc(value1, value2);
            myFuncStopWatch.Stop();
            systemStopWatch.Start();
            var sysRet = sistema(value1, value2);
            systemStopWatch.Stop();
            var check = equals == null ? myRet.Equals(sysRet) : equals(myRet, sysRet);
            var successString = check ? "PASSED" : "FAILED";
            var displayValue1 = typeof(E).IsArray ? "array" : value1?.ToString();
            var displayValue2 = typeof(P).IsArray ? "array" : value2?.ToString();
            Console.WriteLine($"{title}, values: {displayValue1}, {displayValue2} - {successString}");
            UpdateStatistics(check);
            var performanceCheck = systemStopWatch.ElapsedMilliseconds * factor > myFuncStopWatch.ElapsedMilliseconds;
            var performanceSuccessString = performanceCheck ? "PASSED" : "FAILED";
            Console.WriteLine($"Performance, yours expected to be quicker than {factor}x {comparison} {systemStopWatch.ElapsedTicks}. " +
                $"Yours {myFuncStopWatch.ElapsedTicks} ticks - {performanceSuccessString}");
            UpdatePerformanceStatistics(performanceCheck);
        }
    }
}
