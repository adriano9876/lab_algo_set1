﻿using Algorithms.Core.Dictionary;
using Algorithms.Test.Utilita;
using Logic.Test.Utilita;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Algorithms.Test
{
    public class TestDictionary : TestPerformanceBase
    {
        public void Test()
        {
            DisplayHelper.MostraTitolo("Exercises on Simple Dictionary");
            ExecuteComparisonTest();
            ExecutePerformanceTest(50);
            ExecutePerformanceTest(250);
            ExecutePerformanceTest(500);
            DisplayHelper.MostraRisultati("Exercises on Simple Dictionary", numeroDiTestEffettuati, numeroDiTestCorretti, numberOfPerformanceTestsExecuted, numberOfPerformanceTestsPassed);
        }

        public void ExecuteComparisonTest()
        {
            var simple = new SimpleDictionary();
            var dictionary = new Dictionary<int, string>();
            dictionary.Add(1, "Ciao");
            dictionary.Add(48, "Baby");
            dictionary.Add(2, "Acqua");
            dictionary.Add(5, "X");
            dictionary.Add(29, "Y");
            dictionary.Add(33, "Z");
            dictionary.Add(9, "MSC");
            dictionary.Add(99999, "Technology");
            dictionary.Add(1012345, "A");

            simple.Add(1, "Ciao");
            simple.Add(48, "Baby");
            simple.Add(2, "Acqua");
            simple.Add(5, "X");
            simple.Add(29, "Y");
            simple.Add(33, "Z");
            simple.Add(9, "MSC");
            simple.Add(99999, "Technology");
            simple.Add(1012345, "A");

            EseguiEAggiornaStatistiche("Retrieve", p => simple[p], p => dictionary[p], 1);
            EseguiEAggiornaStatistiche("Retrieve", p => simple[p], p => dictionary[p], 48);
            EseguiEAggiornaStatistiche("Retrieve", p => simple[p], p => dictionary[p], 9);
            EseguiEAggiornaStatistiche("Retrieve", p => simple[p], p => dictionary[p], 29);
            EseguiEAggiornaStatistiche("Retrieve", p => simple[p], p => dictionary[p], 99999);
            EseguiEAggiornaStatistiche("Retrieve", p => simple[p], p => dictionary[p], 1012345);

            EseguiEAggiornaStatistiche("TryGetValue", p => simple.TryGetValue(p, out _), p => dictionary.TryGetValue(p, out _), 2);
            EseguiEAggiornaStatistiche("TryGetValue", p => simple.TryGetValue(p, out _), p => dictionary.TryGetValue(p, out _), 33);
            EseguiEAggiornaStatistiche("TryGetValue", p => simple.TryGetValue(p, out _), p => dictionary.TryGetValue(p, out _), 12);

            EseguiEAggiornaStatistiche("Remove", p => simple.Remove(p), p => dictionary.Remove(p), 1);
            EseguiEAggiornaStatistiche("Remove", p => simple.Remove(p), p => dictionary.Remove(p), 33);
            EseguiEAggiornaStatistiche("Remove", p => simple.Remove(p), p => dictionary.Remove(p), 12);
            EseguiEAggiornaStatistiche("Remove", p => simple.Remove(p), p => dictionary.Remove(p), 1012345);

            try
            {
                simple.GetValue(1);
                UpdateStatistics(1 == 0);
                Console.WriteLine("Retrieve: Exception not thrown - FAILED");
            }
            catch (ArgumentException)
            {
                UpdateStatistics(1 == 1);
                Console.WriteLine("Retrieve: Exception thrown - PASSED");
            }


            try
            {
                simple.GetValue(1012345);
                UpdateStatistics(1 == 0);
                Console.WriteLine("Retrieve: Exception not thrown - FAILED");
            }
            catch (ArgumentException)
            {
                UpdateStatistics(1 == 1);
                Console.WriteLine("Retrieve: Exception thrown - PASSED");
            }

            simple.Add(1, "New");
            dictionary.Add(1, "New");
            EseguiEAggiornaStatistiche("Retrieve", p => simple[p], p => dictionary[p], 1);

            EseguiEAggiornaStatistiche("Add, not valid", p => simple.Add(1, "NOT VALID"), p => false, 1);
            EseguiEAggiornaStatistiche("Retrieve", p => simple[p], p => dictionary[p], 1);

            try
            {
                simple.GetValue(109);
                UpdateStatistics(1 == 0);
                Console.WriteLine("Retrieve 109: Exception not thrown - FAILED");
            }
            catch (ArgumentException)
            {
                UpdateStatistics(1 == 1);
                Console.WriteLine("Retrieve 109: Exception thrown - PASSED");
            }
        }

        private void ExecutePerformanceTest(int numberOfElements)
        {
            var simple = new SimpleDictionary();
            var dictionary = new Dictionary<int, string>();
            var enumerator = Enumerable.Range(1, numberOfElements);
            foreach (var n in enumerator)
            {
                simple.Add(n, n.ToString());
                dictionary.Add(n, n.ToString());
            }

            ExecutePerformanceTestAndUpdateStatistics($"{numberOfElements} entries, retrieving", k => simple[k], k => dictionary[k], 1, factor: 2.0, comparison: "Dictionary");
            ExecutePerformanceTestAndUpdateStatistics($"{numberOfElements} entries, retrieving", k => simple[k], k => dictionary[k], 50, factor: 2.0, comparison: "Dictionary");
            ExecutePerformanceTestAndUpdateStatistics($"{numberOfElements} entries, retrieving", k => simple[k], k => dictionary[k], numberOfElements - 10, factor: 2.0, comparison: "Dictionary");
        }
    }
}
