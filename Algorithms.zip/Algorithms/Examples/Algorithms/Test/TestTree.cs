﻿using Algorithms.Core.Tree;
using Algorithms.Test.Utilita;
using Logic.Test.Utilita;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Algorithms.Test
{
    public class TestTree : TestPerformanceBase
    {
        public TestTree()
        {

        }

        public void Test()
        {
            DisplayHelper.MostraTitolo("Exercises on tree data structure");

            PerformTestsOnAddAndFind();
            var manualTree = GetAlreadyInitializedTree();
            PerformTestsOnTree(manualTree ,"Manual tree");
            var tree = GetBasicTree();
            PerformTestsOnTree(tree, "Small tree");
            TestPerformance(1000);
            TestPerformance(5000);
            TestPerformance(10000);

            DisplayHelper.MostraRisultati("Exercises on tree data structure", numeroDiTestEffettuati, numeroDiTestCorretti, numberOfPerformanceTestsExecuted, numberOfPerformanceTestsPassed);
        }

        private void PerformTestsOnAddAndFind()
        {
            var tree = new Tree(new Node(100));
            EseguiEAggiornaStatistiche("Tree, find root 100", p => tree.FindValue(p), p => new Node(p), 100, (n1, n2) => n1?.Value == n2?.Value);
            tree.AddValue(150);
            EseguiEAggiornaStatistiche("Tree, find left 150", p => tree.FindValue(p), p => new Node(p), 150, (n1, n2) => n1?.Value == n2?.Value);
            tree.AddValue(50);
            EseguiEAggiornaStatistiche("Tree, find right 50", p => tree.FindValue(p), p => new Node(p), 50, (n1, n2) => n1?.Value == n2?.Value);
        }

        private void PerformTestsOnTree(Tree tree, string treeName)
        {
            EseguiEAggiornaStatistiche($"{treeName}, research 20", p => tree.FindValue(p), p => new Node(p), 20, (n1, n2) => n1?.Value == n2?.Value);
            EseguiEAggiornaStatistiche($"{treeName}, research 10", p => tree.FindValue(p), p => new Node(p), 10, (n1, n2) => n1?.Value == n2?.Value);
            EseguiEAggiornaStatistiche($"{treeName}, research 15", p => tree.FindValue(p), p => new Node(p), 15, (n1, n2) => n1?.Value == n2?.Value);
            EseguiEAggiornaStatistiche($"{treeName}, research 50", p => tree.FindValue(p), p => new Node(p), 50, (n1, n2) => n1?.Value == n2?.Value);
            EseguiEAggiornaStatistiche($"{treeName}, research 9", p => tree.FindValue(p), p => new Node(p), 9, (n1, n2) => n1?.Value == n2?.Value);
            EseguiEAggiornaStatistiche($"{treeName}, research 11", p => tree.FindValue(p), p => null, 11, (n1, n2) => n1?.Value == n2?.Value);
            EseguiEAggiornaStatistiche($"{treeName}, research 1", p => tree.FindValue(p), p => null, 1, (n1, n2) => n1?.Value == n2?.Value);
        }

        private static Tree GetBasicTree()
        {
            var tree = new Tree(new Node(20));
            tree.AddValue(12);
            tree.AddValue(9);
            tree.AddValue(15);
            tree.AddValue(50);
            tree.AddValue(10);
            return tree;
        }

        private static Tree GetAlreadyInitializedTree()
        {
            // very simple way to initialize the tree.
            var root = new Node(20);
            var nodeA = new Node(12);
            var nodeB = new Node(9);
            var nodeC = new Node(15);
            var nodeD = new Node(36);
            var nodeE = new Node(50);
            var nodeF = new Node(10);

            root.Right = nodeA;
            root.Right.Right = nodeB;
            root.Right.Left = nodeC;
            root.Left = nodeD;
            root.Left.Left = nodeE;
            root.Right.Right.Left = nodeF;
            var manualTree = new Tree(root);
            return manualTree;
        }

        private void TestPerformance(int dimension)
        {
            List<int> numbers = Enumerable.Range(0, dimension).ToList();
            var balls = numbers.Select(s => new Node(s));

            // fills the tree in a semi-balanced way.
            int i = 1;
            int center = numbers.Count / 2;
            Tree tree = new Tree(new Node(numbers[center]));
            while (i < numbers.Count / 2)
            {
                var nodePlus = numbers[center + i];
                var nodeMinus = numbers[center - i];
                tree.AddValue(nodePlus);
                tree.AddValue(nodeMinus);
                i++;
            }

            ExecutePerformanceTestAndUpdateStatistics($"Tree, {dimension} elements", p => tree.FindValue(p), p => balls.Where(b => b.Value == p).First(), numbers[center], comparison: "Linq");
            ExecutePerformanceTestAndUpdateStatistics($"Tree, {dimension} elements", p => tree.FindValue(p), p => balls.Where(b => b.Value == p).First(), 50, comparison: "Linq");
            ExecutePerformanceTestAndUpdateStatistics($"Tree, {dimension} elements", p => tree.FindValue(p), p => balls.Where(b => b.Value == p).First(), dimension-1, (r1, r2) => r1?.Value == r2?.Value, comparison: "Linq");
            ExecutePerformanceTestAndUpdateStatistics($"Tree, {dimension} elements", p => tree.FindValue(p), p => balls.Where(b => b.Value == p).FirstOrDefault(), 5101, (r1, r2) => r1?.Value == r2?.Value, comparison: "Linq");
            ExecutePerformanceTestAndUpdateStatistics($"Tree, {dimension} elements", p => tree.FindValue(p), p => balls.Where(b => b.Value == p).First(), 912, comparison: "Linq");

            ExecutePerformanceTestAndUpdateStatistics($"Tree, {dimension} elements", p => tree.FindValue(p), p => balls.FindLinear(p), numbers[center], comparison: "Linear");
            ExecutePerformanceTestAndUpdateStatistics($"Tree, {dimension} elements", p => tree.FindValue(p), p => balls.FindLinear(p), 50, comparison: "Linear");
            ExecutePerformanceTestAndUpdateStatistics($"Tree, {dimension} elements", p => tree.FindValue(p), p => balls.FindLinear(p), dimension - 1, comparison: "Linear");
            ExecutePerformanceTestAndUpdateStatistics($"Tree, {dimension} elements", p => tree.FindValue(p), p => balls.FindLinear(p), 912, comparison: "Linear");
            ExecutePerformanceTestAndUpdateStatistics($"Tree, {dimension} elements", p => tree.FindValue(p), p => balls.FindLinear(p), 5101, (r1, r2) => r1?.Value == r2?.Value, comparison: "Linq");
            ExecutePerformanceTestAndUpdateStatistics($"Tree, {dimension} elements", p => tree.FindValue(p), p => balls.Where(b => b.Value == p).First(), 912, comparison: "Linq");
        }
    }
}
