﻿
namespace DependencyInjector
{
    public static class FabDependencyInjectorBetter
    {
        private static IDictionary<Type, Type> services = new Dictionary<Type, Type>();
        private static IDictionary<(Type, string), Type> keyedServices = new Dictionary<(Type, string), Type>();

        public static void Register<TInterface, TImplementation>() where TImplementation : TInterface
        {
            services.Add(typeof(TInterface), typeof(TImplementation));
        }
        public static void Register<TImplementation>()
        {
            services.Add(typeof(TImplementation), typeof(TImplementation));
        }

        public static void Register<TInterface, TImplementation>(string key) where TImplementation : TInterface
        {
            keyedServices.Add((typeof(TInterface), key), typeof(TImplementation));
        }

        public static T Resolve<T>()
        {
            var type = typeof(T);
            return (T)Get(type);
        }

        public static T Resolve<T>(string key)
        {
            var type = typeof(T);
            return (T)Get(type, key);
        }

        private static object Get(Type type, string key = null)
        {
            var target = ResolveType(type, key);
            var constructor = target.GetConstructors()[0];
            var parameters = constructor.GetParameters();

            List<object> resolvedParameters = new List<object>();

            foreach (var item in parameters)
            {
                resolvedParameters.Add(Get(item.ParameterType));
            }

            return constructor.Invoke(resolvedParameters.ToArray());
        }

        private static Type ResolveType(Type type, string key)
        {
            if (key == null)
            {
                if (services.Keys.Contains(type))
                {
                    return services[type];
                }

                throw new NotImplementedException();
            }
            else
            {
                if (keyedServices.Keys.Contains((type, key)))
                {
                    return keyedServices[(type, key)];
                }

                throw new NotImplementedException();
            }

        }
    }
}
