﻿
namespace DependencyInjector
{
    public static class FabDependencyInjector
    {
        private static IDictionary<Type, Type> services = new Dictionary<Type, Type>();

        public static void Register<TInterface, TImplementation>() where TImplementation : TInterface
        {
            services.Add(typeof(TInterface), typeof(TImplementation));
        }

        public static void Register<TImplementation>()
        {
            services.Add(typeof(TImplementation), typeof(TImplementation));
        }

        public static T Resolve<T>()
        {
            var type = typeof(T);
            return (T)Get(type);
        }

        private static object Get(Type type)
        {
            var target = ResolveType(type);
            var constructor = target.GetConstructors()[0];
            var parameters = constructor.GetParameters();

            List<object> resolvedParameters = new List<object>();

            foreach (var item in parameters)
            {
                resolvedParameters.Add(Get(item.ParameterType));
            }

            return constructor.Invoke(resolvedParameters.ToArray());
        }

        private static Type ResolveType(Type type)
        {
            if (services.Keys.Contains(type))
            {
                return services[type];
            }

            return type;
        }
    }
}
