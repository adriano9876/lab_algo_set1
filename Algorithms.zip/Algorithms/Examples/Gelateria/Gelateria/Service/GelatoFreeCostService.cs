﻿using Gelateria.Interface.Service;
using Gelateria.Object;

namespace Gelateria.Service
{
    public class GelatoFreeCostService : IGelatoCostService
    {
        public GelatoFreeCostService()
        {
        }

        public decimal ComputeCost(Gelato gelato)
        {
            return 0.0M;
        }
    }
}
