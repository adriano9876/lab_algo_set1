﻿using Gelateria.Interface.Service;
using Gelateria.Object;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gelateria.Service
{
    public class GelatoNumberOfBallsCostService : IGelatoCostService
    {
        public decimal ComputeCost(Gelato gelato)
        {
            return gelato.IceCreams.Count() * 1.5M;
        }
    }
}
