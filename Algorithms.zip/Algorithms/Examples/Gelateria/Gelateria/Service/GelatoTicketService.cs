﻿using Gelateria.Interface.Service;
using Gelateria.Object;

namespace Gelateria.Service
{
    public class GelatoTicketService : IGelatoTicketService
    {
        public GelatoTicketService()
        {
        }

        public void PrintTicket(GelatoAndTicket pricedGelato)
        {
            Console.WriteLine("---- TICKET ----");
            Console.WriteLine("Gelato with:");
            Console.WriteLine($"\t- cialda {pricedGelato.Cialda.CialdaName}");
            Console.WriteLine($"\t- {pricedGelato.IceCreams.Count()} palline");
            Console.WriteLine($"\tCost: {pricedGelato.Price} Euro");
            Console.WriteLine("--------------\n\n");

        }
    }
}
