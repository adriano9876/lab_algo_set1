﻿using Gelateria.Interface.Repository;
using Gelateria.Interface.Service;
using Gelateria.Object;
using System.Collections.Concurrent;

namespace Gelateria.Service
{
    public class GelatoMakingService : IGelatoMakingService
    {
        private readonly IIceCreamRepository iceCreamRepository;
        private readonly ICialdaRepository cialdaRepository;

        public GelatoMakingService(IIceCreamRepository iceCreamRepository, ICialdaRepository cialdaRepository)
        {
            this.iceCreamRepository = iceCreamRepository;
            this.cialdaRepository = cialdaRepository;
        }

        public Gelato Make(string chosenCialda, IEnumerable<string> chosenCreams)
        {
            var cialdas = cialdaRepository.GetAvailableCialdas()
                .ToDictionary(c => c.CialdaName, c => c);
            var creams = iceCreamRepository.GetAvailableIceCreams()
                .ToDictionary(i => i.FlavourName, i => i);

            if (!cialdas.TryGetValue(chosenCialda, out var cialda))
            {
                throw new ArgumentNullException(nameof(chosenCialda));
            }

            var addedCreams = GetChosenCreams(creams, chosenCreams);

            return new Gelato
            {
                Cialda = cialda,
                IceCreams = addedCreams,
            };
        }

        private IEnumerable<IceCream> GetChosenCreams(IDictionary<string, IceCream> availableCreams, IEnumerable<string> chosenCreams)
        {
            var addedCreams = new List<IceCream>();
            foreach (var chosenCream in chosenCreams)
            {
                if (availableCreams.ContainsKey(chosenCream))
                {
                    addedCreams.Add(availableCreams[chosenCream]);
                }
            }
            return addedCreams;
        }
    }
}
