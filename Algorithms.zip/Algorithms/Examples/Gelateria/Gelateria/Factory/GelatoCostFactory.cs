﻿using DependencyInjector;
using Gelateria.Interface.Factory;
using Gelateria.Interface.Service;

namespace Gelateria.Factory
{
    public class GelatoCostFactory : IGelatoCostFactory
    {
        public GelatoCostFactory()
        {
        }

        public IGelatoCostService Create(string strategy)
        {
            return FabDependencyInjectorBetter.Resolve<IGelatoCostService>(strategy);
        }
    }
}
