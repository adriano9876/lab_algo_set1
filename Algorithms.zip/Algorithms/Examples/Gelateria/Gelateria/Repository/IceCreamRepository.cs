﻿using Gelateria.Interface.Repository;
using Gelateria.Object;

namespace Gelateria.Repository
{
    public class IceCreamRepository : IIceCreamRepository
    {
        public IceCreamRepository()
        {

        }

        public IEnumerable<IceCream> GetAvailableIceCreams()
        {
            return new List<IceCream>
            {
                new IceCream
                {
                    FlavourName = "Cioccolato",
                    Colour = "Brown",
                    MilkPercentage = 50.0F,
                },
                new IceCream
                {
                    FlavourName = "Fondente",
                    Colour = "Black",
                    MilkPercentage = 10.0F,
                },
                new IceCream
                {
                    FlavourName = "Nocciola",
                    Colour = "Brown",
                    MilkPercentage = 50.0F,
                },
                new IceCream
                {
                    FlavourName = "Pistacchio",
                    Colour = "Green",
                    MilkPercentage = 60.0F,
                },
                new IceCream
                {
                    FlavourName = "Fragola",
                    Colour = "Red",
                    MilkPercentage = 40.0F,
                },
            };
        }
    }
}
