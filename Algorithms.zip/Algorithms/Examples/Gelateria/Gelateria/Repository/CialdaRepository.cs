﻿using Gelateria.Interface.Repository;
using Gelateria.Object;

namespace Gelateria.Repository
{
    public class CialdaRepository : ICialdaRepository
    {
        public CialdaRepository() { }

        public IEnumerable<Cialda> GetAvailableCialdas()
        {
            return new List<Cialda>
            {
                new Cialda
                {
                    CialdaName = "Croccante",
                    Colour = "Yellow",
                    ChocolateAroundIt = true,
                    Price = 2.0M
                },
                new Cialda
                {
                    CialdaName = "Classic",
                    Colour = "Orange",
                    ChocolateAroundIt = false,
                    Price = 1.0M
                },
            };
        }
    }
}
