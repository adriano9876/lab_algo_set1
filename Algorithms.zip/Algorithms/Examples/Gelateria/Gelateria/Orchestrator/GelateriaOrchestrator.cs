﻿using Gelateria.Interface.Factory;
using Gelateria.Interface.Service;
using Gelateria.Object;

namespace Gelateria.Orchestrator
{
    public class GelateriaOrchestrator
    {
        private readonly IGelatoMakingService gelatoCompositionService;
        private readonly IGelatoCostService gelatoCostService;
        private readonly IGelatoTicketService gelatoTicketService;
        private readonly IGelatoCostFactory costStrategyFactory;

        public GelateriaOrchestrator(IGelatoMakingService gelatoCompositionService, IGelatoCostService gelatoCostService, IGelatoTicketService gelatoTicketService, IGelatoCostFactory factory)
        {
            this.gelatoCompositionService = gelatoCompositionService;
            this.gelatoCostService = gelatoCostService;
            this.gelatoTicketService = gelatoTicketService;
            this.costStrategyFactory = factory;
        }

        public GelateriaOrchestrator(IGelatoMakingService gelatoCompositionService, IGelatoCostService gelatoCostService, IGelatoTicketService gelatoTicketService)
        {
            this.gelatoCompositionService = gelatoCompositionService;
            this.gelatoCostService = gelatoCostService;
            this.gelatoTicketService = gelatoTicketService;
        }

        public GelatoAndTicket AskForGelato(Choice choice, string costStrategy)
        {
            var costService = costStrategyFactory.Create(costStrategy);
            var gelato = gelatoCompositionService.Make(choice.CialdaName, choice.CreamsNames);
            var price = costService.ComputeCost(gelato);

            var gelatoWithPrice = new GelatoAndTicket
            {
                Cialda = gelato.Cialda,
                IceCreams = gelato.IceCreams,
                Price = price,
            };
            
            gelatoTicketService.PrintTicket(gelatoWithPrice);

            return gelatoWithPrice;
        }
    }
}
