﻿namespace Gelateria.Object
{
    public class Gelato
    {
        public Cialda Cialda { get; set; }
        public IEnumerable<IceCream> IceCreams { get; set; }        
    }
}