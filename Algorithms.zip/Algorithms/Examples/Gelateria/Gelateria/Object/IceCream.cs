﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gelateria.Object
{
    public class IceCream
    {
        public string FlavourName { get; set; }
        public float MilkPercentage { get; set; } 
        public string Colour { get; set; }
    }
}
