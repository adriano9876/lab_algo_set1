﻿namespace Gelateria.Object
{
    public class Cialda
    {
        public string CialdaName { get; set; }
        public string Colour { get; set; }
        public bool ChocolateAroundIt { get; set; }
        public decimal Price { get; set; }
    }
}