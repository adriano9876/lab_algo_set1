﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gelateria.Object
{
    public class GelatoAndTicket : Gelato
    {
        public decimal Price { get; set; }
    }
}
