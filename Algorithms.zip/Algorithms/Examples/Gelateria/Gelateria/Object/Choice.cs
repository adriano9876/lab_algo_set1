﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gelateria.Object
{
    public class Choice
    {
        public string CialdaName { get; set; }
        public IEnumerable<string> CreamsNames { get; set; }
        public string CustomerName { get; set; }
    }
}
