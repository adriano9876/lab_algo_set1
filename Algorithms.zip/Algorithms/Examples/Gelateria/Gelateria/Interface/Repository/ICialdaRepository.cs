﻿using Gelateria.Object;

namespace Gelateria.Interface.Repository
{
    public interface ICialdaRepository
    {
        IEnumerable<Cialda> GetAvailableCialdas();
    }
}