﻿using Gelateria.Object;

namespace Gelateria.Interface.Repository
{
    public interface IIceCreamRepository
    {
        IEnumerable<IceCream> GetAvailableIceCreams();
    }
}