﻿using Gelateria.Object;

namespace Gelateria.Interface.Service
{
    public interface IGelatoMakingService
    {
        Gelato Make(string chosenCialda, IEnumerable<string> chosenCreams);
    }
}