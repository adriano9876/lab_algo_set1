﻿using Gelateria.Object;

namespace Gelateria.Interface.Service
{
    public interface IGelatoTicketService
    {
        void PrintTicket(GelatoAndTicket pricedGelato);
    }
}