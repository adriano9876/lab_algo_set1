﻿using Gelateria.Object;

namespace Gelateria.Interface.Service
{
    public interface IGelatoCostService
    {
        decimal ComputeCost(Gelato gelato);
    }
}