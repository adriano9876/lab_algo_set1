﻿using Gelateria.Interface.Service;

namespace Gelateria.Interface.Factory
{
    public interface IGelatoCostFactory
    {
        IGelatoCostService Create(string strategy);
    }
}