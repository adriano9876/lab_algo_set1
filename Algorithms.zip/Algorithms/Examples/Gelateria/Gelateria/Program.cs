﻿using DependencyInjector;
using Gelateria.Factory;
using Gelateria.Interface.Factory;
using Gelateria.Interface.Repository;
using Gelateria.Interface.Service;
using Gelateria.Object;
using Gelateria.Orchestrator;
using Gelateria.Repository;
using Gelateria.Service;

namespace Gelateria
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to the FABolous Gelateria!\n\n");

            var choice = new Choice
            {
                CialdaName = "Croccante",
                CreamsNames = ["Nocciola", "Cioccolato", "Pistacchio"],
            };

            var gelateria = OpenGelateriaWithInjector();
            gelateria.AskForGelato(choice, "classic");
        }

        private static GelateriaOrchestrator OpenGelateriaClassic()
        {
            IIceCreamRepository creamRepo = new IceCreamRepository();
            ICialdaRepository cialdaRepo = new CialdaRepository();
            IGelatoMakingService gelatoMaking = new GelatoMakingService(creamRepo, cialdaRepo);
            IGelatoCostService gelatoCostService = new GelatoNumberOfBallsCostService();
            IGelatoTicketService gelatoTicketService = new GelatoTicketService();
            GelateriaOrchestrator gelateria = new GelateriaOrchestrator(gelatoMaking, gelatoCostService, gelatoTicketService);
            return gelateria;
        }

        private static GelateriaOrchestrator OpenGelateriaWithInjector()
        {
            FabDependencyInjectorBetter.Register<IIceCreamRepository, IceCreamRepository>();
            FabDependencyInjectorBetter.Register<ICialdaRepository, CialdaRepository>();
            FabDependencyInjectorBetter.Register<IGelatoMakingService, GelatoMakingService>();
            FabDependencyInjectorBetter.Register<IGelatoCostFactory, GelatoCostFactory>();
            FabDependencyInjectorBetter.Register<IGelatoCostService, GelatoFreeCostService>();
            FabDependencyInjectorBetter.Register<IGelatoCostService, GelatoFreeCostService>("free");
            FabDependencyInjectorBetter.Register<IGelatoCostService, GelatoNumberOfBallsCostService>("classic");
            FabDependencyInjectorBetter.Register<IGelatoTicketService, GelatoTicketService>();
            FabDependencyInjectorBetter.Register<GelateriaOrchestrator>();

            GelateriaOrchestrator gelateria = FabDependencyInjectorBetter.Resolve<GelateriaOrchestrator>();
            return gelateria;
        }
    }
}