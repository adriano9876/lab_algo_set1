﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using VisaCodeFirst.Dtos;
using VisaCodeFirst.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace VisaCodeFirst.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BrandTagsPaninoController : ControllerBase
    {
        private readonly VisaDbContext _context;

        public BrandTagsPaninoController(VisaDbContext context)
        {
            _context = context;
        }

        // GET: api/<BrandTagsPaninoController>
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/<BrandTagsPaninoController>/5
        [HttpGet("{id}")]
        public async Task<ActionResult<ICollection<BrandTagsPaninoDto>>> Get(int id)
        {
            var ris = await _context.Tags.Include(b => b.Brands).AsNoTracking().Where(x=>x.Id == id) .Select(b => b.Brands
            .Select(btp => new BrandTagsPaninoDto
            {
                NomeBrand = btp.NameBrand,
                NomeTag = b.TagName,

            })).SelectMany(a=>a).ToListAsync();

            return Ok(ris);

        }

        // POST api/<BrandTagsPaninoController>
        [HttpPost]
        public void Post([FromBody] string value)
        {
        }

        // PUT api/<BrandTagsPaninoController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<BrandTagsPaninoController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
