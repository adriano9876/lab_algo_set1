﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace VisaCodeFirst.Migrations
{
    /// <inheritdoc />
    public partial class visa009 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<decimal>(
                name: "CardAmount",
                table: "CreditCards",
                type: "decimal(18,2",
                nullable: false,
                defaultValue: 0m);

            migrationBuilder.InsertData(
                table: "Brands",
                columns: new[] { "Id", "DateCreated", "DateModified", "DescriptionBrand", "NameBrand" },
                values: new object[] { 1, null, null, "hai tanti soldi", "AMEX" });

            migrationBuilder.InsertData(
                table: "Tags",
                columns: new[] { "Id", "DateCreated", "DateModified", "TagName" },
                values: new object[] { 1, null, null, "costoso" });

            migrationBuilder.InsertData(
                table: "Users",
                columns: new[] { "Id", "DateCreated", "DateModified", "Name" },
                values: new object[] { 1, new DateOnly(2022, 2, 2), new DateOnly(2022, 2, 2), "stefanino" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Brands",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Tags",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Users",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DropColumn(
                name: "CardAmount",
                table: "CreditCards");
        }
    }
}
