﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace VisaCodeFirst.Migrations
{
    /// <inheritdoc />
    public partial class visa012 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "CreditCards",
                columns: new[] { "Id", "BrandId", "CardAmount", "CardNumber", "DateCreated", "DateModified", "NameCreditCard", "UserId" },
                values: new object[] { 1, 1, 1235.5m, 1234237, null, null, "Visa", 1 });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "CreditCards",
                keyColumn: "Id",
                keyValue: 1);
        }
    }
}
