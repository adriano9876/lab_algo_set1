﻿namespace VisaCodeFirst.Dtos
{
    public class BrandTagsPaninoDto
    {
        public string NomeBrand { get; set; }
        public string NomeTag { get; set; }


    }


}
