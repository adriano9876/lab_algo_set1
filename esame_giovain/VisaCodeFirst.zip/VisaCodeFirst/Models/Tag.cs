﻿namespace VisaCodeFirst.Models
{
    public class Tag
    {
        public int Id { get; set; }
        public string TagName { get; set; }
        public DateOnly? DateCreated { get; set; }
        public DateOnly? DateModified { get; set; }

        /*navigazione*/

        public virtual ICollection<Brand> Brands { get; set; } = new List<Brand>();
  


    }
}
