﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace VisaCodeFirst.Models
{
    public class CreditCard
    {
        public int Id { get; set; }

        [Required]
        public string NameCreditCard { get; set; }
        public int  CardNumber { get; set; }
   
        public decimal CardAmount { get; set; }
        public DateOnly? DateCreated { get; set; }
        public DateOnly? DateModified { get; set; }

        [Required]
        public int UserId { get; set; }
        public int BrandId { get; set; }
        /*navigazione*/
        public virtual User User { get; set; }
        public virtual Brand Brand { get; set; }


    }


}
