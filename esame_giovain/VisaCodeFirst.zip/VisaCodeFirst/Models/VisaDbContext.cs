﻿using Microsoft.EntityFrameworkCore;

namespace VisaCodeFirst.Models
{
    public class VisaDbContext : DbContext
    {
        public VisaDbContext(DbContextOptions<VisaDbContext> options) : base(options) { }

        public virtual DbSet<User> Users { get; set; }
        public virtual DbSet<CreditCard> CreditCards { get; set; }
        public virtual DbSet<Email> Emails { get; set; }
        public virtual DbSet<Brand> Brands { get; set; }
        public virtual DbSet<Tag> Tags { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //modelBuilder.Entity<CreditCard>()
            //    .HasOne(u => u.User)
            //    .WithMany (u => u.CreditCards)
            //    .HasForeignKey(u => u.UserId)
            //    .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<User>().HasData(new User()
            {
                Id = 1,
                Name = "stefanino",
                DateCreated = new DateOnly(2022, 2, 2),
                DateModified = new DateOnly(2022, 2, 2),

            });

            modelBuilder.Entity<CreditCard>().HasData(new CreditCard()
            {
                Id = 1,
                NameCreditCard = "Visa",
                CardNumber = 1234237,
                CardAmount = 1235.5M,
                UserId = 1,
                BrandId = 1,

            });

            modelBuilder.Entity<Tag>().HasData(new Tag()
            {
                Id = 1,
                TagName = "costoso"

            });

            modelBuilder.Entity<Brand>().HasData(new Brand()
            {
                Id = 1,
                NameBrand = "AMEX",
                DescriptionBrand = "hai tanti soldi"

            });



            modelBuilder.Entity<CreditCard>()
                .HasOne(c=> c.User)
                .WithMany(u => u.CreditCards)
                .HasForeignKey(c => c.UserId)
                .OnDelete(DeleteBehavior.Restrict);
            /* 1->1 */
            modelBuilder.Entity<Email>()
                .HasOne(e => e.User)
                .WithOne (u => u.Email )
                .HasForeignKey<Email>(e => e.UserId);

            modelBuilder.Entity<CreditCard>()
                .HasOne(c => c.Brand)
                .WithMany(b => b.CreditCards)
                .HasForeignKey(c => c.BrandId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Brand>()
                .HasMany(b => b.Tags)
                .WithMany(t => t.Brands)
                .UsingEntity("BrandTagsPanino");


            base.OnModelCreating(modelBuilder);
        }

    }


}
