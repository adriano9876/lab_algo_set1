﻿using System.ComponentModel.DataAnnotations;
using System.Runtime.InteropServices.Marshalling;

namespace VisaCodeFirst.Models
{
    public class User
    {
        public int Id { get; set; }
        [Required]
        public string Name { get; set; }
        public DateOnly? DateCreated { get; set; }
        public DateOnly? DateModified { get; set; }

        /*navigazione*/

        public virtual ICollection<CreditCard> CreditCards { get; set; } = new List<CreditCard>();
        public virtual Email Email { get; set; }

    }
}
