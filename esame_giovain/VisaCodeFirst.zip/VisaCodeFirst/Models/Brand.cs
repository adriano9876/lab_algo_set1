﻿using System.ComponentModel.DataAnnotations;

namespace VisaCodeFirst.Models
{
    public class Brand
    {
        public int Id { get; set; }
        [Required]
        public string NameBrand { get; set; }
        public string? DescriptionBrand { get; set; }
        public DateOnly? DateCreated { get; set; }
        public DateOnly? DateModified { get; set; }
        /*navigation*/
        public virtual ICollection<CreditCard> CreditCards { get; set; } = new List<CreditCard>();
        public virtual ICollection<Tag> Tags { get; set; } = new List<Tag>();

    }
}
