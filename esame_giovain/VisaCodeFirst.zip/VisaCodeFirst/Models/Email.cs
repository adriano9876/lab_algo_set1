﻿using System.ComponentModel.DataAnnotations;

namespace VisaCodeFirst.Models
{
    public class Email
    {
        public int Id { get; set; }

        [Required]
        public string EmailAdress { get; set; }
        public DateOnly? DateCreated { get; set; }
        public DateOnly? DateModified { get; set; }

        [Required]
        public int UserId { get; set; }
        /* navigazione */
        public virtual User User { get; set; }
        
    }
}
