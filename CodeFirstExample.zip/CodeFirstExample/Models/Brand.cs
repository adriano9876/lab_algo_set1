﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeFirstExample.Models
{
    public class Brand
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Name2 { get; set; }
        public List<Product> Products { get; set; } = new();
                
        public Country CountryId { get; set; }

    }
}
