﻿using Business.FolderConverters;
using Business.Services;
using DataAccess;
using ItaloThreeLayers.DataAccess;
using ItaloThreeLayers.Presentation;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Presentation;

namespace ItaloThreeLayers
{
    public static class Program
    {
        public static void Main()
        {
            var applicationBuilder = Host.CreateApplicationBuilder();
            //applicationBuilder.Services.AddSingleton<IBookingRepository, BookingRepository>();
            applicationBuilder.Services.AddSingleton<IBookingRepository, BookingJsonRepository>();
            applicationBuilder.Services.AddSingleton<IBookingConverter, BookingConverter>();
            applicationBuilder.Services.AddSingleton<IBookingService, BookingService>();
            applicationBuilder.Services.AddSingleton<IConsoleView, ConsoleView>();

            using var host = applicationBuilder.Build();
            using IServiceScope serviceScope = host.Services.CreateScope();

            var consoleView = serviceScope.ServiceProvider.GetService<IConsoleView>();
            if (consoleView != null)
            {
                consoleView.ShowMenu();
            }

            //Console.WriteLine("Ciao sei nella interfaccia di italo3layers");
            //IBookingRepository bookingRepository = new BookingRepository();
            //IBookingConverter bookingConverter = new BookingConverter();
            //IBookingService bookingService = new BookingService(bookingRepository,bookingConverter );
            //IConsoleView consoleView = new ConsolView(bookingService);
            //consoleView.ShowMenu();

        }
    }
}