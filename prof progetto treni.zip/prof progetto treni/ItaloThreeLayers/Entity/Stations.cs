﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
    public class Stations
    {
        public int Id { get; set; }
        public String NomeStazione { get; set;}
        public String Paese { get; set; }

        public Stations(int id, string nomeStazione, string paese   )
        {
            Id = id;
            NomeStazione = nomeStazione;
            Paese = paese;
        }

    }
}
