﻿using Business.FolderDto;
using Business.Services;
using ItaloThreeLayers.Presentation;

namespace Presentation
{
    public class ConsoleView : IConsoleView
    {
        private readonly IBookingService bookingService;

        public ConsoleView(IBookingService bookingService)
        {
            if (bookingService == null)
            {
                throw new ArgumentNullException(nameof(bookingService), "No service found");
            }

            this.bookingService = bookingService;
        }

        public void ShowMenu()
        {
            var exit = false;

            do
            {
                Console.WriteLine("=================== Menu ===================");
                Console.WriteLine("0) Exit");
                Console.WriteLine("1) Create booking ");
                Console.WriteLine("2) Get all bookings ");
                Console.WriteLine("3) Update booking ");
                Console.WriteLine("4) Delete booking ");

                var chosenFunctionality = Console.ReadLine();
                switch (chosenFunctionality)
                {
                    case "0":
                        exit = true;
                        break;
                    case "1":
                        DoCreateFlow();
                        break;
                    case "2":
                        DoGetFlow();
                        break;
                    case "3":
                        DoUpdateFlow();
                        break;
                    case "4":
                        DoDeleteFlow();
                        break;
                    default:
                        Console.WriteLine("Invalid choice");
                        break;
                }

            } while (!exit);

            Environment.Exit(0);
        }

        private void DoDeleteFlow()
        {
            Console.WriteLine("Inserisci un Id da cancellare Da questi in Lista:");
            DoGetFlow();
         
            if (!int.TryParse(Console.ReadLine(), out var id) && id > 0)
            {
                Console.WriteLine("Invalid id");
                return;
            }
            bool del = this.bookingService.DeleteById(id);
            Console.WriteLine("elemento Eliminato : "+del);
            //throw new NotImplementedException();
        }

        private void DoUpdateFlow()
        {
            Console.Write("Specify booking id: ");
            if (!int.TryParse(Console.ReadLine(), out var id) && id > 0)
            {
                Console.WriteLine("Invalid id");
                return;
            }

            var (departure, arrival, name, surname) = GetSaveParameters();
            var updateCommand = new UpdateBookingCommand
            {
                Id = id,
                DepartureStation = departure,
                ArrivalStation = arrival,
                Name = name,
                Surname = surname
            };

            var updatedDto = this.bookingService.UpdateBooking(updateCommand);
            this.ShowDto(updatedDto);
        }

        private void DoGetFlow()
        {
            var dtoList = this.bookingService.GetAllBookings();
            foreach (var dto in dtoList)
            {
                this.ShowDto(dto);
            }
        }

        private void DoCreateFlow()
        {
            var (departure, arrival, name, surname) = GetSaveParameters();
            var command = new CreateBookingCommand
            {
                DepartureStation = departure,
                ArrivalStation = arrival,
                Name = name,
                Surname = surname
            };

            var createdBookingDto = this.bookingService.CreateBooking(command);
            if (createdBookingDto == null)
            {
                Console.WriteLine("Error while saving the booking");
                return;
            }

            Console.WriteLine("Booking saved successfully:");
            this.ShowDto(createdBookingDto);
        }

        private static (string departure, string arrival, string name, string surname) GetSaveParameters()
        {
            Console.Write("Insert departure station: ");
            var departure = Console.ReadLine();

            Console.Write("Insert arrival station: ");
            var arrival = Console.ReadLine();

            Console.Write("Insert passenger name: ");
            var name = Console.ReadLine();

            Console.Write("Insert passenger surname: ");
            var surname = Console.ReadLine();

            return (departure, arrival, name, surname);
        }

        private void ShowDto(BookingDto dto)
        {
            Console.WriteLine($"{dto.Id}) {dto.DepartureStation} - {dto.ArrivalStation} for {dto.Surname} {dto.Name}");
        }
    }
}
