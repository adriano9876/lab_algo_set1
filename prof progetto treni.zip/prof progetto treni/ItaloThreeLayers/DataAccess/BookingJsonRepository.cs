﻿using ItaloThreeLayers.DataAccess;
using ItaloThreeLayers.Entity;
using Newtonsoft.Json;

namespace DataAccess
{
    public class BookingJsonRepository : IBookingRepository
    {
        private const string Path = "..\\..\\..\\..\\DataAccess\\Bookings.json";

        public Booking CreateBooking(Booking booking)
        {
            if (booking == null)
            {
                throw new ArgumentNullException(nameof(booking), "Invalid booking");
            }

            var savedBookings = this.GetSavedBookings();

            this.AddBooking(savedBookings, booking);

            this.SaveBookings(savedBookings);

            return booking;
        }

        public Booking UpdateBooking(Booking inputModel)
        {
            List<Booking> toMod = GetAllBookings();
            Booking bookingToMod = toMod.Find(val=>val.Id==inputModel.Id);
            if (bookingToMod != null)
            {
                bookingToMod.Surname = inputModel.Surname;
                bookingToMod.Name = inputModel.Name;
                bookingToMod.DepartureStation = inputModel.DepartureStation;
                bookingToMod.ArrivalStation = inputModel.ArrivalStation;

            }
            JsonBooking j1 = new();
            j1.Bookings = toMod;
            SaveBookings(j1);
            return bookingToMod;

            //throw new NotImplementedException();
        }

        public List<Booking> GetAllBookings()
        {
            var savedBookings = this.GetSavedBookings();
            if (savedBookings?.Bookings == null)
            {
                throw new ArgumentNullException(nameof(savedBookings), "Invalid saved bookings");
            }

            return savedBookings.Bookings;
        }

        private JsonBooking GetSavedBookings()
        {
            JsonBooking jsonBooking;

            if (!File.Exists(Path))
            {
                jsonBooking = new JsonBooking();
            }
            else
            {
                string savedBookings;
                using (var sr = new StreamReader(Path))
                {
                    savedBookings = sr.ReadToEnd();
                }

                jsonBooking = JsonConvert.DeserializeObject<JsonBooking>(savedBookings);
            }

            return jsonBooking;
        }

        private void AddBooking(JsonBooking jsonBooking, Booking booking)
        {
            if (jsonBooking?.Bookings == null)
            {
                throw new ArgumentNullException(nameof(jsonBooking), "Invalid saved bookings");
            }

            var lastSavedId = jsonBooking.Bookings.Count == 0 ? 0 : jsonBooking.Bookings.Max(b => b.Id);

            booking.Id = lastSavedId + 1;

            jsonBooking.Bookings.Add(booking);
        }

        private void SaveBookings(JsonBooking jsonBooking)
        {
            if (jsonBooking?.Bookings == null)
            {
                throw new ArgumentNullException(nameof(jsonBooking), "Invalid saved bookings");
            }

            var jsonBookings = JsonConvert.SerializeObject(jsonBooking);

            using (var sw = new StreamWriter(Path, false))
            {
                sw.Write(jsonBookings);
            }
        }
        /* fatto */
        public bool DeleteById(int id)
        {
            List<Booking> lista = GetAllBookings();
            Booking toDel = lista.Find(item=>item.Id==id);
            if (toDel == null)
            {
                return false;
            }
            lista.Remove(toDel);
            JsonBooking jsonBooking = new JsonBooking();
            jsonBooking.Bookings = lista;
            SaveBookings(jsonBooking);
            return true;
            //throw new NotImplementedException();
        }
    }
}
