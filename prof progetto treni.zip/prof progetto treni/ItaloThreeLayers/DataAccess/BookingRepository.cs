﻿using ItaloThreeLayers.Entity;

namespace ItaloThreeLayers.DataAccess
{
    public class BookingRepository : IBookingRepository
    {
        private List<Booking> Bookings { get; } = new List<Booking>();

        public Booking CreateBooking(Booking booking)
        {
            if (booking == null)
            {
                throw new ArgumentNullException(nameof(booking), "Invalid booking");
            }

            booking.Id = GetNewId();

            Bookings.Add(booking);

            return booking;
        }

        public bool DeleteById(int id)
        {
            Booking toDel = Bookings.Find(n => n.Id == id);
            if (toDel == null)
            {
                return false;
            }
            Bookings.Remove(toDel);
            return true;
            throw new NotImplementedException();
        }

        public List<Booking> GetAllBookings()
        {
            return Bookings;
        }

        public Booking UpdateBooking(Booking inputModel)
        {
            var bookingToBeUpdated = Bookings.FirstOrDefault(b => b.Id == inputModel.Id);
            if (bookingToBeUpdated == null)
            {
                throw new InvalidOperationException("Id not found");
            }

            bookingToBeUpdated.DepartureStation = inputModel.DepartureStation;
            bookingToBeUpdated.ArrivalStation = inputModel.ArrivalStation;
            bookingToBeUpdated.Name = inputModel.Name;
            bookingToBeUpdated.Surname = inputModel.Surname;

            return bookingToBeUpdated;
        }

        private int GetNewId()
        {
            if (Bookings.Count == 0)
            {
                return 1;
            }

            var id = Bookings.Max(booking => booking.Id);

            return id + 1;
        }
    }
}
