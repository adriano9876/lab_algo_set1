﻿using ItaloThreeLayers.Entity;

namespace ItaloThreeLayers.DataAccess
{
    public interface IBookingRepository
    {
        Booking CreateBooking(Booking booking);
        bool DeleteById(int id);
        List<Booking> GetAllBookings();

        Booking UpdateBooking(Booking inputModel);
    }
}
