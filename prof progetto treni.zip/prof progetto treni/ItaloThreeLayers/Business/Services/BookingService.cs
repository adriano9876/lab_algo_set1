﻿using Business.FolderCommand;
using Business.FolderConverters;
using Business.FolderDto;
using ItaloThreeLayers.DataAccess;
using ItaloThreeLayers.Entity;

namespace Business.Services
{
    public class BookingService : IBookingService
    {
        private readonly IBookingRepository bookingRepository;
        private readonly IBookingConverter bookingConverter;

        public BookingService(
            IBookingRepository bookingRepository,
            IBookingConverter bookingConverter)
        {
            if (bookingRepository == null)
            {
                throw new ArgumentNullException(nameof(bookingRepository), "No repository found");
            }

            if (bookingConverter == null)
            {
                throw new ArgumentNullException(nameof(bookingConverter), "No converter found");
            }

            this.bookingRepository = bookingRepository;
            this.bookingConverter = bookingConverter;
        }

        public BookingDto CreateBooking(CreateBookingCommand command)
        {
            if (command == null)
            {
                throw new ArgumentNullException(nameof(command), "Invalid command");
            }

            var inputModel = new Booking(
                default,
                command.DepartureStation,
                command.ArrivalStation,
                command.Name,
                command.Surname);

            var model = bookingRepository.CreateBooking(inputModel);

            var dto = bookingConverter.GetDto(model);

            return dto;
        }

        public bool DeleteById(int id)
        {
            bool delete = bookingRepository.DeleteById(id);
            return delete;
            //throw new NotImplementedException();
        }

        public List<BookingDto> GetAllBookings()
        {
            var savedBookings = bookingRepository.GetAllBookings();

            //return savedBookings.Select(booking => this.bookingConverter.GetDto(booking)).ToList();
            var bookingsDto = new List<BookingDto>();

            foreach (var savedBooking in savedBookings)
            {
                var dto = bookingConverter.GetDto(savedBooking);
                bookingsDto.Add(dto);
            }

            return bookingsDto;
        }

        public BookingDto UpdateBooking(UpdateBookingCommand updateCommand)
        {
            var inputModel = new Booking(
                updateCommand.Id,
                updateCommand.DepartureStation,
                updateCommand.ArrivalStation,
                updateCommand.Name,
                updateCommand.Surname);

            var updatedModel = bookingRepository.UpdateBooking(inputModel);

            return bookingConverter.GetDto(updatedModel);
        }
    }


}
