﻿using Business.FolderCommand;
using Business.FolderDto;

namespace Business.Services
{
    public interface IBookingService
    {
        BookingDto CreateBooking(CreateBookingCommand command);
        bool DeleteById(int id);
        List<BookingDto> GetAllBookings();

        BookingDto UpdateBooking(UpdateBookingCommand updateCommand);
    }
}
