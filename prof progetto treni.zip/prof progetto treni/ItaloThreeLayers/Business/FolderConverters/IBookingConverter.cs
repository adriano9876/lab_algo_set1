﻿using Business.FolderDto;
using ItaloThreeLayers.Entity;

namespace Business.FolderConverters
{
    public interface IBookingConverter
    {
        BookingDto GetDto(Booking booking);

        Booking GetModel(BookingDto bookingDto);
    }
}
