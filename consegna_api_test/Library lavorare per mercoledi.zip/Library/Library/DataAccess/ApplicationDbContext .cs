﻿using Microsoft.EntityFrameworkCore;
using Library.Models;

namespace Library.DataAccess
{

	public class ApplicationDbContext : DbContext
	{
		public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
			: base(options) { }

		public DbSet<Autore> Autori { get; set; }
		public DbSet<Genere> Generi { get; set; }
		public DbSet<Libro> Libri { get; set; }

		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			base.OnModelCreating(modelBuilder);

			modelBuilder.Entity<Genere>()
				.HasIndex(g => g.Nome)
				.IsUnique();

			modelBuilder.Entity<Libro>()
				.HasIndex(l => l.Titolo);

			modelBuilder.Entity<Autore>()
				.HasMany(a => a.Libri)
				.WithOne(l => l.Autore)
				.HasForeignKey(l => l.AutoreId)
				.OnDelete(DeleteBehavior.Cascade);

			modelBuilder.Entity<Genere>()
				.HasMany(g => g.Libri)
				.WithOne(l => l.Genere)
				.HasForeignKey(l => l.GenereId)
				.OnDelete(DeleteBehavior.Restrict);

			modelBuilder.Entity<Autore>().HasData(
				new Autore { Id = 1, Nome = "Dante Alighieri", DataDiNascita = new DateTime(1265, 5, 29), LuogoDiNascita = "Firenze, Italia" },
				new Autore { Id = 2, Nome = "Giovanni Boccaccio", DataDiNascita = new DateTime(1313, 6, 16), LuogoDiNascita = "Certaldo, Italia" }
			);

			modelBuilder.Entity<Genere>().HasData(
				new Genere { Id = 1, Nome = "Commedia" },
				new Genere { Id = 2, Nome = "Narrativa" }
			);

			modelBuilder.Entity<Libro>().HasData(
				new Libro
				{
					Id = 1,
					AutoreId = 1,
					Titolo = "Divina Commedia",
					DataDiProduzione = new DateTime(1321, 1, 1),
					GenereId = 1
				},
				new Libro
				{
					Id = 2,
					AutoreId = 2,
					Titolo = "Decameron",
					DataDiProduzione = new DateTime(1353, 1, 1),
					GenereId = 2
				}
			);
		}
	}
}
