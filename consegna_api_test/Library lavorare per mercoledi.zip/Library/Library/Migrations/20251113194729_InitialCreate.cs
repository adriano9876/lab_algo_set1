﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace Library.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Autori",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nome = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    DataDiNascita = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LuogoDiNascita = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Autori", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Generi",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nome = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Generi", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Libri",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AutoreId = table.Column<int>(type: "int", nullable: false),
                    Titolo = table.Column<string>(type: "nvarchar(400)", maxLength: 400, nullable: false),
                    DataDiProduzione = table.Column<DateTime>(type: "datetime2", nullable: true),
                    GenereId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Libri", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Libri_Autori_AutoreId",
                        column: x => x.AutoreId,
                        principalTable: "Autori",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Libri_Generi_GenereId",
                        column: x => x.GenereId,
                        principalTable: "Generi",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.InsertData(
                table: "Autori",
                columns: new[] { "Id", "DataDiNascita", "LuogoDiNascita", "Nome" },
                values: new object[,]
                {
                    { 1, new DateTime(1265, 5, 29, 0, 0, 0, 0, DateTimeKind.Unspecified), "Firenze, Italia", "Dante Alighieri" },
                    { 2, new DateTime(1313, 6, 16, 0, 0, 0, 0, DateTimeKind.Unspecified), "Certaldo, Italia", "Giovanni Boccaccio" }
                });

            migrationBuilder.InsertData(
                table: "Generi",
                columns: new[] { "Id", "Nome" },
                values: new object[,]
                {
                    { 1, "Commedia" },
                    { 2, "Narrativa" }
                });

            migrationBuilder.InsertData(
                table: "Libri",
                columns: new[] { "Id", "AutoreId", "DataDiProduzione", "GenereId", "Titolo" },
                values: new object[,]
                {
                    { 1, 1, new DateTime(1321, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), 1, "Divina Commedia" },
                    { 2, 2, new DateTime(1353, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), 2, "Decameron" }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Generi_Nome",
                table: "Generi",
                column: "Nome",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Libri_AutoreId",
                table: "Libri",
                column: "AutoreId");

            migrationBuilder.CreateIndex(
                name: "IX_Libri_GenereId",
                table: "Libri",
                column: "GenereId");

            migrationBuilder.CreateIndex(
                name: "IX_Libri_Titolo",
                table: "Libri",
                column: "Titolo");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Libri");

            migrationBuilder.DropTable(
                name: "Autori");

            migrationBuilder.DropTable(
                name: "Generi");
        }
    }
}
