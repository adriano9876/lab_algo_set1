﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Library.Models
{
	public class Libro
	{
		public int Id { get; set; }

		[Required]
		public int AutoreId { get; set; }
		public Autore Autore { get; set; }

		[Required, MaxLength(400)]
		public string Titolo { get; set; }

		public DateTime? DataDiProduzione { get; set; }

		[Required]
		public int GenereId { get; set; }
		public Genere Genere { get; set; }
	}


}
