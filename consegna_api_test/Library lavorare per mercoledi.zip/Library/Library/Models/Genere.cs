﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Library.Models
{


	public class Genere
	{
		public int Id { get; set; }

		[Required, MaxLength(100)]
		public string Nome { get; set; }

		public ICollection<Libro> Libri { get; set; } = new List<Libro>();
	}
}
