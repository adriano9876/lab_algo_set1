﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Library.Models
{
	public class Autore
	{
		public int Id { get; set; }

		[Required, MaxLength(200)]
		public string Nome { get; set; }

		public DateTime? DataDiNascita { get; set; }

		[MaxLength(200)]
		public string LuogoDiNascita { get; set; }

		public ICollection<Libro> Libri { get; set; } = new List<Libro>();
	}

}
