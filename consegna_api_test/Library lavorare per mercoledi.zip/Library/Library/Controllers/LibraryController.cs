using Microsoft.AspNetCore.Mvc;

namespace Library.Controllers
{
	[ApiController]
	[Route("api/library")]
	public class LibraryController : ControllerBase
	{

		// =====================================================
		// Library Controller
		// =====================================================

		// I metodi di seguito sono dei placeholder.
		// Bisogner�:
		// 1. Definire la tipologia di chiamata (GET, POST, PUT, DELETE)
		// 1. Definire la firma dei metodi in base alla logica scelta
		// 2. Gestire l'iniezione dei servizi necessari 
		// 3. Implementare la logica di business e la gestione degli input/output
		// 
		// How to set up the project:
		// 1. Inizializza la connection string al localdb modificandola in appsettings.json
		//    es.: 
		//    "ConnectionStrings": {
		//        "DefaultConnection": "Server=(localdb)\\mssqllocaldb;Database=LibraryDb;Trusted_Connection=True;TrustServerCertificate=True;"
		//    }
		// 2. Applica la migration esistente al database:
		//    dotnet ef database update
		// =====================================================

		// Implementare un middleware che logga le seguenti informazioni a console:
		/*
		 * 1. Tipologia di richiesta (GET, POST, PUT, DELETE)
		 * 2. Endpoint chiamato
		 * 3. Timestamp della richiesta
		 * 4. Stato della risposta (200, 404, 500, ecc.)
		 */

		public LibraryController()
		{
			// TODO: Iniettare i servizi necessari
		}


		/* 
		 * Titolo : Aggiung un libro
		 * Obiettivo: Aggiungere un libro per un autore gi� esistente.
		 * Input atteso: JSON body
		 * {
		 *    "AutoreID": 1,
		 *    "Titolo": "Titolo del libro",
		 *    "DataDiProduzione": "2025-01-01",
		 *    "GenereNome": "Fantasy"
		 * }
		 */

		//[Http???("")]
		public IActionResult AddLibro()
		{
			// TODO: Implementare logica di aggiunta libro
			return Ok("Metodo AddLibro da implementare");
		}


		/*
         * Obiettivo: Restituire tutti i libri che contengono una parola nel titolo
         * Input atteso: Query string
         * GET /api/library/libro/search?query=Parola
         */
		//[Http???("")]
		public IActionResult SearchLibro()
		{
			// TODO: Implementare logica ricerca libri
			return Ok("Metodo SearchLibro da implementare");
		}

		/*
         * Obiettivo: Modificare un libro esistente
         * Input atteso: 
         * - URL: /api/library/libro/{id}
         * - Body: JSON opzionale con campi da aggiornare
         *   {
         *      "Titolo": "Nuovo titolo",
         *      "DataDiProduzione": "2025-02-01"
         *   }
         */
		//[Http???("")]
		public IActionResult UpdateLibro()
		{
			// TODO: Implementare logica aggiornamento libro
			return Ok("Metodo UpdateLibro da implementare");
		}

		/*
		* Obiettivo: Restituire libri filtrando gli autori per nazione di nascita
		* Input atteso: Body JSON
		* {
		*    "Nazione": "Italia"
		* }
		*/

		//[Http???("")]
		public IActionResult LibriPerNazione()
		{
			// TODO: Implementare logica filtraggio libri
			return Ok("Metodo LibriPerNazione da implementare");
		}

		/*
         * Obiettivo: Eliminare un libro di genere "Commedia" dell'autore pi� vecchio
         */
		//[Http???("")]
		public IActionResult DeleteCommediaAutoreVecchio()
		{
			// TODO: Implementare logica cancellazione libro
			return Ok("Metodo DeleteCommediaAutoreVecchio da implementare");
		}

		/*
		* Obiettivo: Modificare l'autore di un libro (gestione co-autori)
		* Input: /api/library/libro/{libroId}/cambia-autore
		* Body:
		* {
		*    "NuovoAutoreId": 5,
		* }
		* 
		*/
		//[Http???("")]
		public IActionResult ModificaAutore()
		{
			// TODO: Implementare logica cancellazione libro
			return Ok("Metodo ModificaAutore da implementare");
		}


		/*
		* Obiettivo: Creare una copia di un libro con modifiche
		* Input: POST /api/library/libro/duplica
		* Body:
		* {
		*	 "LibroIdEsistente": 3,
		*    "NuovoTitolo": "Titolo Edizione Speciale",
		*    "NuovaData": "2025-06-01",
		*    "NuovoGenere": "Fantasy",
		*    "MantieniAutore": true
		* }
		*/
		//[Http???("")]
		public IActionResult CreaUnaCopia()
		{
			// TODO: Implementare logica
			return Ok("Metodo CreaUnaCopia da implementare");
		}


	}
}
