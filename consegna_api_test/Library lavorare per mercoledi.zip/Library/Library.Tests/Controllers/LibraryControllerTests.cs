﻿using Library.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.Tests.Controllers
{
    public class LibraryControllerTests
    {
        // =====================================================
        // Library Controller Tests
        // =====================================================

        // I metodi di seguito sono dei placeholder per gli Unit Test.
        // Come da Best Practice, il nome del metodo indica il metodo
        // oggetto del test ed il risultato atteso.
        // 
        // Implementare gli step di Arrange, Act ed Assert.
        // Utilizzare Moq per la risoluzione delle dipendenze del Controller.
        // 
        // E' richiesto di coprire con Unit Test anche ulteriori classi
        // che implementano la logica di business seguendo gli stessi criteri
        // adottati per il Controller: nome del metodo parlante, step di Assert
        // significativi e coerenti col nome del metodo, coperatura dei vari
        // scenari (non solo happy flow) ed utilizzo di Moq per le dipendenze.
        // =====================================================

        private readonly LibraryController _controller;

        public LibraryControllerTests()
        {
            _controller = new LibraryController();
        }

        [Fact]
        public void AddLibro_ReturnsOkResult()
        {
            // Arrange

            // Act
            var result = _controller.AddLibro();

            // Assert
        }

        [Fact]
        public void AddLibro_ReturnsBadRequestResult()
        {
            // Arrange

            // Act
            var result = _controller.AddLibro();

            // Assert
        }

        [Fact]
        public void SearchLibro_ReturnsOkResult()
        {
            // Arrange

            // Act
            var result = _controller.SearchLibro();

            // Assert
        }

        [Fact]
        public void SearchLibro_ReturnsBadRequestResult()
        {
            // Arrange

            // Act
            var result = _controller.SearchLibro();

            // Assert
        }

        [Fact]
        public void UpdateLibro_ReturnsOkResult()
        {
            // Arrange

            // Act
            var result = _controller.UpdateLibro();

            // Assert
        }

        [Fact]
        public void UpdateLibro_ReturnsBadRequestResult()
        {
            // Arrange

            // Act
            var result = _controller.UpdateLibro();

            // Assert
        }

        [Fact]
        public void UpdateLibro_ReturnsNotFoundResult()
        {
            // Arrange

            // Act
            var result = _controller.UpdateLibro();

            // Assert
        }

        [Fact]
        public void LibriPerNazione_ReturnsOkResult()
        {
            // Arrange

            // Act
            var result = _controller.LibriPerNazione();

            // Assert
        }

        [Fact]
        public void LibriPerNazione_ReturnsBadRequestResult()
        {
            // Arrange

            // Act
            var result = _controller.LibriPerNazione();

            // Assert
        }

        [Fact]
        public void DeleteCommediaAutoreVecchio_ReturnsOkResult()
        {
            // Arrange

            // Act
            var result = _controller.DeleteCommediaAutoreVecchio();

            // Assert
        }
    }
}
