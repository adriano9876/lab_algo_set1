﻿using Library._3.Repositories;
using Library.BussinesService;
using Library.Controllers;
using Library.Tests.Controllers;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.Tests.Services
{
    public  class LibraryServiceTests
    {
        private readonly Mock<ILibraryRepository> _repoMock;
        private readonly LibraryService _service;

        public LibraryServiceTests( )
        {
            _repoMock = new Mock<ILibraryRepository>();
            _service = new LibraryService(_repoMock.Object);

        }





    }

}




