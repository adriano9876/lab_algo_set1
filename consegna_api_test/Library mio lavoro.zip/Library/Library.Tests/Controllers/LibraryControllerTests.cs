﻿using Library.BussinesService;
using Library.Controllers;
using Library.Dto.Request;
using Library.Dto.Response;
using Library.Models;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Library.Tests.Controllers
{
    public class LibraryControllerTests
    {
        // =====================================================
        // Library Controller Tests
        // =====================================================

        // I metodi di seguito sono dei placeholder per gli Unit Test.
        // Come da Best Practice, il nome del metodo indica il metodo
        // oggetto del test ed il risultato atteso.
        // 
        // Implementare gli step di Arrange, Act ed Assert.
        // Utilizzare Moq per la risoluzione delle dipendenze del Controller.
        // 
        // E' richiesto di coprire con Unit Test anche ulteriori classi
        // che implementano la logica di business seguendo gli stessi criteri
        // adottati per il Controller: nome del metodo parlante, step di Assert
        // significativi e coerenti col nome del metodo, coperatura dei vari
        // scenari (non solo happy flow) ed utilizzo di Moq per le dipendenze.
        // =====================================================

        private readonly LibraryController _controller;
        private readonly Mock<ILibraryService> _serviceMock;

        public LibraryControllerTests()
        {
            _serviceMock = new Mock<ILibraryService>();
            _controller = new LibraryController(_serviceMock.Object);

        }

        [Fact]
        public async Task AddLibro_ReturnsOkResult()
        {
            // Arrange


            // Act


            // Assert        
        }

        [Fact]
        public async void AddLibro_ReturnsBadRequestResult()
        {
            //Arrange
            var libroDto = new LibroAddDto
            {
                AutoreId = 20,
                Genere = "fantasy",
                Titolo = "lotr",
                DataDiProduzione = new DateOnly(2020, 2, 2)
            };
           
            // Act
            var result = await _controller.AddLibro(libroDto);

            // Assert
            Assert.IsType<BadRequestResult>(result);
        }




        [Fact]
        public async Task SearchLibro_ReturnsOkResult()
        {
            // Arrange
            var titolo = "harry";
            var libri = new List <LibroSearchDto> {            
            new LibroSearchDto {Autore ="luca", DataDiProduzione = new DateTime(2020,1,1), Titolo ="harry" },
            new LibroSearchDto {Autore ="sara", DataDiProduzione = new DateTime(2020,1,2), Titolo ="harry"}
            };
            _serviceMock.Setup(f => f.SearchLibroService("harry")).ReturnsAsync(libri);

            // Act
            var result = _controller.SearchLibro(titolo);

            // Assert
            var ok = Assert.IsType<OkObjectResult>(result.Result);
            var Risposta = Assert.IsAssignableFrom<IEnumerable<LibroSearchDto>>(ok.Value);
            Assert.Equal(2, libri.Count());
            _serviceMock.Verify(s => s.SearchLibroService(titolo), Times.Once);
                

        }

        //[Fact]
        //public void SearchLibro_ReturnsBadRequestResult()
        //{
        // Arrange
   

        // Act


        // Assert
        //}

        [Fact]
        public async Task UpdateLibro_ReturnsOkResult()
        {
            // Arrange
            var libro = 1;
            var libromod = new LibroModDto { Id=1 ,DataDiProduzione = new DateTime(2020,1,1), Titolo= "wiki" };

            _serviceMock.Setup(f => f.ModifyLibro(libromod, 1)).ReturnsAsync(true);
            // Act
            var result = _controller.UpdateLibro(1,libromod);

            // Assert
            Assert.IsType<OkObjectResult>(result.Result); 
            _serviceMock.Verify(f => f.ModifyLibro(libromod, libro), Times.Once);

        }

        [Fact]
        public async Task UpdateLibro_ReturnsBadRequestResult()
        {
            // Arrange
            var librodto = new LibroModDto {Id=1,DataDiProduzione=null,Titolo ="ciao" };
            _serviceMock.Setup(s => s.ModifyLibro(librodto,2) ).ReturnsAsync(false);

            // Act
            var result = _controller.UpdateLibro(1,librodto ); 

            // Assert
            Assert.IsType<BadRequestResult>(result);
        }

        //[Fact]
        //public void UpdateLibro_ReturnsNotFoundResult()
        //{
        //    // Arrange

        //    // Act
        //    var result = _controller.UpdateLibro();

        //    // Assert
        //}

        [Fact]
        public async Task LibriPerNazione_ReturnsOkResult()
        {
            // Arrange
            List<LibroDtoNazioni> libri = new List <LibroDtoNazioni>
            {
                new LibroDtoNazioni {
                Autore = "sara",
                Titolo = "nuovo mondo",
                DataDiProduzione = new DateTime(2000,1,1) 
                }
            };

            _serviceMock.Setup( f => f.LibriPerNazione("francia") ).ReturnsAsync(libri);

            // Act
            var result = _controller.LibriPerNazione("francia");

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var returnLibri = Assert.IsAssignableFrom<IEnumerable<LibroDtoNazioni>>(okResult.Value);
            Assert.Single(returnLibri);

        }

        [Fact]
        public void LibriPerNazione_ReturnsBadRequestResult()
        {
            // Arrange
            var libri = new LibroDtoNazioni
            {
                Autore = "giulia",
                DataDiProduzione = new DateTime(2020, 2, 1),
                Titolo = "hola"
            };

            // Act
            var result = _controller.LibriPerNazione("germania");

            // Assert
            Assert.IsType<BadRequestResult>(result);
        }

        [Fact]
        public async Task DeleteCommediaAutoreVecchio_ReturnsOkResult()
        {
            // Arrange
            
            _serviceMock.Setup(s => s.DeleteCommediaLibro()).ReturnsAsync(false);

            // Act
            var result = _controller.DeleteCommediaAutoreVecchio();

            // Assert
            Assert.IsType<NoContentResult>(result);
        }

    }//
}
