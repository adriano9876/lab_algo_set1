﻿namespace Library._0.Middleware
{
    public class LogMiddleware
    {
            private readonly RequestDelegate _next;
            private readonly ILogger<LogMiddleware> _logger;

        public LogMiddleware(RequestDelegate next, ILogger<LogMiddleware> logger)
        {
            _next = next;
            _logger = logger;
        }



        public async Task Invoke(HttpContext context)
        {       
              await _next(context);
            _logger.LogInformation(
                $"{context.Request.Method} / " +
                $"{context.GetEndpoint} / " +
                $"{DateTime.Now} / " +
                $"{ context.Response.StatusCode } " ); 

        }
    }

}

