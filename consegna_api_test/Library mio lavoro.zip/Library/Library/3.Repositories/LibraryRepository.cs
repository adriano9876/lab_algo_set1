﻿using Library.DataAccess;
using Library.Dto.Request;
using Library.Models;
using Microsoft.EntityFrameworkCore;
using System.Data;

namespace Library._3.Repositories
{
    public class LibraryRepository:ILibraryRepository
    {
        private readonly ApplicationDbContext _context;


        public LibraryRepository(ApplicationDbContext context)
        {

            _context = context;

        }

        public async Task<int> Addlibro(Libro libro)
        {
            Libro toDb = new Libro();
            var autore = _context.Autori
                .AsNoTracking()
                .SingleOrDefault(a => a.Id == libro.Autore.Id);
            var genere = _context.Generi.AsNoTracking()
                .SingleOrDefaultAsync(g => libro.Genere.Nome == g.Nome);

            if (autore == null)
            {
                return -1;
            }

            if (genere != null)
            {
                toDb.AutoreId=autore.Id;               
                toDb.GenereId=genere.Id;
                toDb.Titolo = libro.Titolo;
                toDb.DataDiProduzione = libro.DataDiProduzione;
                _context.Libri.Add(libro);
                _context.SaveChanges();
                return toDb.Id; 
            }
            else
            {
                toDb.AutoreId = autore.Id;              
                toDb.Titolo = libro.Titolo;
                toDb.DataDiProduzione = libro.DataDiProduzione;
                _context.Libri.Add(libro);
                _context.SaveChanges();
                return toDb.Id;
            }
        
        }

        public async Task<bool> CreaUnaCopia(LibroDuplicatoDto libroDtoDuplicato)
        {
            //Libro libroDaCopiare = _context.Libri
            //                .AsNoTracking()
            //                .SingleOrDefaultAsync() ;
            //Libro copia = new Libro
            //{

            //};

            return true;
           
        }

        public async Task<bool> DeleteCommediaLibroRepo()
        {
            var ris = await _context.Libri.AsNoTracking()
                        .Include(l => l.Autore)
                        .Include(l => l.Genere)
                        .Where(l => l.Genere.Nome == "Commedia")
                        .OrderByDescending(l => l.Autore.DataDiNascita)
                        .FirstAsync();
            if (ris!=null)            {
                _context.Libri.Remove(ris);
                _context.SaveChanges();
                return true;
            }

            return false;                        
   
        }

        public async Task<List<Libro>> LibriPerNazioneRepo(string nazione)
        {
            var ris = await _context.Libri.AsNoTracking()
                .Include(l => l.Autore).ToListAsync();
                return ris;      
        }

        public async Task<bool> ModificaAutoreRepo(int libroId, int nuovoAutoreId)
        {
            var ris = await _context.Libri.AsNoTracking()
                .SingleOrDefaultAsync(l => l.Id==libroId );
            if (ris == null)
            {
                return false;
            }
            ris.AutoreId = nuovoAutoreId;
            return true;
            
        }

        public async Task<ICollection<Libro>> SearchLibroRepo(string parola)
        {
            var ret = await _context.Libri.AsNoTracking()
                .Include(l=> l.Autore)
                .Include(l=>l.Genere)
                .Where(l=> l.Genere.Nome.Contains(parola))// == parola )
                .ToListAsync();
            return ret;
        }

        public async Task<bool> UpdateLibro(Libro libro,int id)
        {
            var libroTrovato = await _context.Libri
                .AsNoTracking()
                .SingleOrDefaultAsync(l => l.Id == libro.Id);
            if (libroTrovato == null)
            {
                return false;
            }

            libroTrovato.Titolo = libro.Titolo;
            libroTrovato.DataDiProduzione = libro.DataDiProduzione;
            await _context.SaveChangesAsync();
            return true;
        }
    }//

}
