﻿using Library.Dto.Request;
using Library.Models;

namespace Library._3.Repositories
{
    public interface ILibraryRepository
    {
        public Task<int> Addlibro(Libro libro);
        public Task<bool> CreaUnaCopia(LibroDuplicatoDto libroDtoDuplicato);
        public Task<bool> DeleteCommediaLibroRepo();
        public Task<List<Libro>> LibriPerNazioneRepo (string nazione);
        public Task<bool> ModificaAutoreRepo(int libroId, int nuovoAutoreId);
        public Task<ICollection<Libro>> SearchLibroRepo(string parola);
        public Task<bool> UpdateLibro(Libro libro,int id);

        

    }//
}
