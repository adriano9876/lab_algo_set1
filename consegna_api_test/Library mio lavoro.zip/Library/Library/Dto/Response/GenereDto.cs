﻿using Library.Models;
using System.ComponentModel.DataAnnotations;

namespace Library.Dto.Response
{
    public class GenereDto
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public ICollection<LibroDto> Libri { get; set; }

    }//

}
