﻿using Library.Models;
using System.ComponentModel.DataAnnotations;

namespace Library.Dto.Response
{
    public class AutoreDto
    {     
      
        public string Nome { get; set; }
        public DateTime? DataDiNascita { get; set; }   
        public string LuogoDiNascita { get; set; }
        public ICollection<LibroDto> Libri { get; set; }

    }//


}
