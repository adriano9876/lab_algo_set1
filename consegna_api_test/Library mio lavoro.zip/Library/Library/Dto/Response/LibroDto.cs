﻿using Library.Models;
using System.ComponentModel.DataAnnotations;

namespace Library.Dto.Response
{
    public class LibroDto
    {         
        public int AutoreId { get; set; }
        public AutoreDto Autore { get; set; }  
        public string Titolo { get; set; }
        public DateTime? DataDiProduzione { get; set; }
        public int GenereId { get; set; }
        public GenereDto Genere { get; set; }


    }//
}
