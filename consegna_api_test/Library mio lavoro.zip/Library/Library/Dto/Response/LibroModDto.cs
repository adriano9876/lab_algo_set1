﻿namespace Library.Dto.Response
{
    public class LibroModDto
    {
        public int Id { get; set; }
        public string Titolo { get; set; }
        public DateTime? DataDiProduzione { get; set; }


    }

}
