﻿using Library.Models;
using System.ComponentModel.DataAnnotations;

namespace Library.Dto.Response
{
    public class LibroSearchDto
    {      
       
        public string Autore { get; set; }
        public string Titolo { get; set; }
        public DateTime DataDiProduzione { get; set; }
        public string Genere { get; set; }

    }//
}
