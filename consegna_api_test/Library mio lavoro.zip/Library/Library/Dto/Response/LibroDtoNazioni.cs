﻿namespace Library.Dto.Response
{
    public class LibroDtoNazioni
    {
 
        public string Autore { get; set; }
        public string Titolo { get; set; }
        public DateTime? DataDiProduzione { get; set; }


    }

}
