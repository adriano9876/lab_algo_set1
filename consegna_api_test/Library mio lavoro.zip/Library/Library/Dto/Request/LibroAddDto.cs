﻿using Library.Dto.Response;

namespace Library.Dto.Request
{
    public class LibroAddDto
    {
        public int AutoreId { get; set; }
        public DateOnly DataDiProduzione { get; set; }
        public string Titolo { get; set; }
        public string Genere { get; set; }


    }//

}
