﻿namespace Library.Dto.Request
{
    public class LibroDuplicatoDto
    {
        public int LibroIdEsistente { get; set; }
        public string NuovoTitolo { get; set; }
        public DateOnly NuovaData { get; set; }
        public string NuovoGenere {  get; set; }
        public string MantieniAutore { get; set; }



    }
}
