using Library.BussinesService;
using Library.DataAccess;
using Library.Dto.Request;
using Library.Dto.Response;
using Library.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Library.Controllers
{
	[ApiController]
	[Route("api/library")]
	public class LibraryController : ControllerBase
	{

		// =====================================================
		// Library Controller
		// =====================================================

		// I metodi di seguito sono dei placeholder.
		// Bisogner�:
		// 1. Definire la tipologia di chiamata (GET, POST, PUT, DELETE)
		// 1. Definire la firma dei metodi in base alla logica scelta
		// 2. Gestire l'iniezione dei servizi necessari 
		// 3. Implementare la logica di business e la gestione degli input/output
		// 
		// How to set up the project:
		// 1. Inizializza la connection string al localdb modificandola in appsettings.json
		//    es.: 
		//    "ConnectionStrings": {
		//        "DefaultConnection": "Server=(localdb)\\mssqllocaldb;Database=LibraryDb;Trusted_Connection=True;TrustServerCertificate=True;"
		//    }
		// 2. Applica la migration esistente al database:
		//    dotnet ef database update
		// =====================================================

		// Implementare un middleware che logga le seguenti informazioni a console:
		/*
		 * 1. Tipologia di richiesta (GET, POST, PUT, DELETE)
		 * 2. Endpoint chiamato
		 * 3. Timestamp della richiesta
		 * 4. Stato della risposta (200, 404, 500, ecc.)
		 */

		private readonly ApplicationDbContext _context; /*solo per testing*/
		private readonly ILibraryService _serviceLibrary;
        public LibraryController(ApplicationDbContext context, ILibraryService serviceLibrary)
		{
			_context = context;
			_serviceLibrary = serviceLibrary;			
		}

        public LibraryController( ILibraryService serviceLibrary)        {
            
            _serviceLibrary = serviceLibrary;
        }

        /* 
		 * Titolo : Aggiung un libro
		 * Obiettivo: Aggiungere un libro per un autore gi� esistente.
		 * Input atteso: JSON body
		 * {
		 *    "AutoreID": 1,
		 *    "Titolo": "Titolo del libro",
		 *    "DataDiProduzione": "2025-01-01",
		 *    "GenereNome": "Fantasy"
		 * }
		 */

        [HttpPost()]
		public async Task<ActionResult<int>> AddLibro([FromBody] LibroAddDto libroAddDto)
		{
			var ret = await _serviceLibrary.Addlibro(libroAddDto);

			if (ret == -1)
			{
				return BadRequest(ret);
			}

			return Ok(ret);
		}


		/*
         * Obiettivo: Restituire tutti i libri che contengono una parola nel titolo
         * Input atteso: Query string
         * GET /api/library/libro/search?query=Parola
         */
		[HttpGet(" /api/library/libro/search/{parola}")]
		public async Task<ActionResult<ICollection<LibroSearchDto>>> SearchLibro(string parola)
		{
			List<LibroSearchDto> retLibro = (List<LibroSearchDto>)await _serviceLibrary.SearchLibroService(parola);
			if(retLibro == null || retLibro.Count == 0)
			{
				return NotFound();
			}

			return Ok(retLibro);
		}



		//      /*
		//       * Obiettivo: Modificare un libro esistente
		//       * Input atteso: 
		//       * - URL: /api/library/libro/{id}
		//       * - Body: JSON opzionale con campi da aggiornare
		//       *   {
		//       *      "Titolo": "Nuovo titolo",
		//       *      "DataDiProduzione": "2025-02-01"
		//       *   }
		//       */


		[HttpPut("/api/library/libro/{id}")]
		public async Task<ActionResult> UpdateLibro(int id, LibroModDto libroTomod)
		{
			if (id != libroTomod.Id)
			{
				return BadRequest();
			}
			var ris = _serviceLibrary.ModifyLibro(libroTomod, id);

			return Ok();
		}

		/*
		* Obiettivo: Restituire libri filtrando gli autori per nazione di nascita
		* Input atteso: Body JSON
		* {
		*    "Nazione": "Italia"
		* }
		*/

		[HttpPost("/api/{nazione}")] 
		public async Task<ActionResult<ICollection<LibroDtoNazioni>>> LibriPerNazione(string nazione)
		{
			var ris = await _serviceLibrary.LibriPerNazione(nazione);								
			return Ok(ris);
		}

		//OK
		/* Obiettivo: Eliminare un libro di genere "Commedia" dell'autore pi� vecchio   */
		[HttpDelete("api/delete/commedia")]
		public async Task<ActionResult> DeleteCommediaAutoreVecchio()
		{
			var ris = await _serviceLibrary.DeleteCommediaLibro();
			if (ris == false)			{
				return BadRequest();
			}
			return Ok();

		}

		/*
		* Obiettivo: Modificare l'autore di un libro (gestione co-autori)
		* Input: /api/library/libro/{libroId}/cambia-autore
		* Body:
		* {
		*    "NuovoAutoreId": 5,
		* }
		* 
		*/
		[HttpPut("/api/library/libro/{libroId}/cambia-autore")]
		public async Task<ActionResult> ModificaAutore(int libroId,[FromBody] int nuovoAutoreId)
		{
			var ris = await  _serviceLibrary.ModificaAutore(libroId,nuovoAutoreId);
			return Ok();
		}


		/*
		* Obiettivo: Creare una copia di un libro con modifiche
		* Input: POST /api/library/libro/duplica
		* Body:
		* {
		*	 "LibroIdEsistente": 3,
		*    "NuovoTitolo": "Titolo Edizione Speciale",
		*    "NuovaData": "2025-06-01",
		*    "NuovoGenere": "Fantasy",
		*    "MantieniAutore": true
		* }
		*/
		//toDO
		[HttpPost("/api/library/libro/duplica")]
		public async Task<ActionResult<bool>> CreaUnaCopia([FromBody] LibroDuplicatoDto libroDtoDuplicato )
		{
			var ris = await _serviceLibrary.CreaUnaCopia(libroDtoDuplicato);

			return Ok();
		}


	}
}
