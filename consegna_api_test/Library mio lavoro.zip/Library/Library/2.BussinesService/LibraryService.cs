﻿using Library._3.Repositories;
using Library.Dto.Request;
using Library.Dto.Response;
using Library.Models;

namespace Library.BussinesService
{
    public class LibraryService:ILibraryService
    {
        private readonly ILibraryRepository _repositoryLibrary;

        public LibraryService(ILibraryRepository repositoryLibrary)
        {
            _repositoryLibrary = repositoryLibrary;
        }

        public Task<int> Addlibro(LibroAddDto libro)
        {
            Libro toRepo = new Libro
            {
                Titolo = libro.Titolo,
                AutoreId = libro.AutoreId,
                Genere = new Genere { Nome = libro.Genere },
                DataDiProduzione = DateTime.Now,

            };
            var ris = _repositoryLibrary.Addlibro(toRepo);
            
            return ris;
        }

        public async Task<bool> CreaUnaCopia(LibroDuplicatoDto libroDtoDuplicato)
        {
            
            var ris = await _repositoryLibrary.CreaUnaCopia(libroDtoDuplicato);
            return true;
            
        }

        public async Task<bool> DeleteCommediaLibro()
        {
            var ris = await _repositoryLibrary.DeleteCommediaLibroRepo();
            return ris;
        
        }

        public async Task<List<LibroDtoNazioni>> LibriPerNazione(string nazione)
        {
            List<Libro> libri = await _repositoryLibrary.LibriPerNazioneRepo(nazione);

            var libriDto = libri
                .Where (l=>l.Autore.LuogoDiNascita.Contains(nazione)) //==nazione)
                .Select(l=> new LibroDtoNazioni
                {
                    Autore = l.Autore.Nome,
                    DataDiProduzione = l.DataDiProduzione,                  
                    Titolo = l.Titolo,
                })
                .ToList();
         
            return libriDto;
        }

        public async Task<bool> ModificaAutore(int libroId, int nuovoAutoreId)
        {
            var ris = await _repositoryLibrary.ModificaAutoreRepo(libroId, nuovoAutoreId);

            return true;
        }

        public async Task<bool> ModifyLibro(LibroModDto libro, int id)
        {
            if (libro.Id != id)
            {
                return false;
            }
            var toMod = new Libro
            {
                Id = id,
                Titolo = libro.Titolo,
                DataDiProduzione = libro.DataDiProduzione
            };
            var ris =await _repositoryLibrary.UpdateLibro(toMod,id);
            return ris;

        }

        public async Task<ICollection<LibroSearchDto>> SearchLibroService(string parola)
        {
            List<Libro> libri = (List<Libro>)await _repositoryLibrary.SearchLibroRepo(parola);
                        
            if (libri == null) {
                return null;
            }

            List<LibroSearchDto> toRet = libri.Select(l => new LibroSearchDto
            {
                Autore = l.Autore.Nome,
                Titolo = l.Titolo,
                DataDiProduzione = l.DataDiProduzione.Value,
                Genere = l.Genere.Nome
            }).ToList();

            return toRet;
        }


    
    }//

}
