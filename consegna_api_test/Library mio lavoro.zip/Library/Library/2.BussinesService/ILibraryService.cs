﻿using Library.Dto.Request;
using Library.Dto.Response;
using Library.Models;

namespace Library.BussinesService
{
    public interface ILibraryService
    {
        public Task<ICollection<LibroSearchDto>> SearchLibroService(string parola);
        public Task<int> Addlibro(LibroAddDto libro);
        public Task<bool> ModifyLibro(LibroModDto libro, int id);
        public Task<List<LibroDtoNazioni>> LibriPerNazione(string nazione);
        public Task<bool> DeleteCommediaLibro();
        public Task<bool> ModificaAutore(int libroId, int nuovoAutoreId);
        public Task<bool> CreaUnaCopia(LibroDuplicatoDto libroDtoDuplicato);


    }//

}
