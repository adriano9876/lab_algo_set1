using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Msc.HealthCheck.AspNetCore.Core.ResponseWriter;
using Msc.HealthCheck.Core.Registry;
using Week9.Observability.Service;

namespace Week9.Observability.Controllers
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            builder.Services

                .AddHealthChecks()

                // example: my code has as a dependency the "www.google.com", so I have to "test" this dependency to say if my service is ready to serve requests
                .AddUrlGroup(
                    uri: new Uri("https://www.google.com"),
                    name: "checkGoogle",
                    failureStatus: HealthStatus.Degraded
                )

                // CUSTOM CODE TO CHECK (are we in the 2025?)
                .AddCheck(
                    name: "checkCustomCode",
                    () =>
                    {
                        Console.WriteLine("checkCustomCode Check invocated");

                        bool isOk = DateTime.UtcNow.Year.ToString() == "2025";

                        // HERE: return result
                        if (isOk)
                        {
                            return HealthCheckResult.Healthy("checkCustomCode OK");
                        }
                        else
                        {
                            return HealthCheckResult.Unhealthy("checkCustomCode KO");
                        }
                    }
                )

                // test the component itself when "ready" probe is invoked [MANDATORY IN MSC CONTEXT]
                .AddCheck("Self", () =>
                {
                    Console.WriteLine("Self Health Check invocated");
                    return HealthCheckResult.Healthy();
                });


            // Add services to the container.
            builder.Services.AddSingleton<IWeatherForecastService, WeatherForecastService>();

            builder.Services.AddControllers();
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseHttpsRedirection();

            app.UseAuthorization();

            app.MapControllers();


            app.MapHealthChecks("/health/live", new HealthCheckOptions
            {
                // this Predicate is to "filter" the Health Checks registered above
                // in this case I filter everything --> So when I call the "/health/live" endpoint, ANY Health Checks is runned
                Predicate = _ => false
            });

            app.MapHealthChecks("/health/ready", new HealthCheckOptions
            {
                // this Predicate is to "filter" the Health Checks registered above
                // in this case I don't filter anything --> So when I call the "/health/ready" endpoint, EVERY Health Checks is runned
                Predicate = _ => true
            });


            app.Run();
        }
    }
}