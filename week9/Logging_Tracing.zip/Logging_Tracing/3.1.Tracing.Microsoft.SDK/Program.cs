using OpenTelemetry;
using OpenTelemetry.Resources;
using OpenTelemetry.Trace;
using System.Diagnostics;
using Week9.Observability.Service;

namespace Week9.Observability.Controllers
{
    public class Program
    {
        public static void Main(string[] args)
        {

            // ------------------ TEST ACTIVITY WHEN LOCAL DEV ------------------ //
#if DEBUG
            var listener = new ActivityListener
            {
                ShouldListenTo = _ => true,
                Sample = (ref ActivityCreationOptions<ActivityContext> _) => ActivitySamplingResult.AllData,
            };
            ActivitySource.AddActivityListener(listener);
#endif

            var builder = WebApplication.CreateBuilder(args);

            builder.Services
                .AddOpenTelemetry()
                .WithTracing(tracing =>
                {
                    tracing
                        .AddSource(Tracing.ActivitySource.Name)     // <-- must match your ActivitySource name
                        .SetResourceBuilder(ResourceBuilder.CreateDefault().AddService("WeatherForecastService"))
                        .AddAspNetCoreInstrumentation()
                        .AddConsoleExporter();                      // <-- this shows spans in console
                });

            // Add services to the container.
            builder.Services.AddSingleton<IWeatherForecastService, WeatherForecastService>();

            builder.Services.AddControllers();
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseHttpsRedirection();

            app.UseAuthorization();


            app.MapControllers();

            app.Run();
        }
    }
}