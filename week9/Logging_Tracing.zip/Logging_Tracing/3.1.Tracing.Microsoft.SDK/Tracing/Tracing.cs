﻿using System.Diagnostics;

namespace Week9.Observability.Service
{
    public static class Tracing
    {
        public static ActivitySource ActivitySource = new ActivitySource("myapp.controller");
    }
}
