﻿using System.Diagnostics;
using Week9.Observability.Controllers;

namespace Week9.Observability.Service
{
    public class WeatherForecastService : IWeatherForecastService
    {

        private readonly ILogger<WeatherForecastController> _logger;

        public WeatherForecastService(ILogger<WeatherForecastController> logger)
        {

            _logger = logger;
        }

        private static readonly string[] Summaries = new[]
        {
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };

        public IList<WeatherForecast> GetWeatherForecastPlusDays(int year, int month, int day, int plusDays)
        {
            using (var activity = Tracing.ActivitySource.StartActivity("weatherforecast SERVICE requested"))
            {
                try
                {
                    DateTime datetimeReceived = new DateTime(year, month, day);
                    DateTime datetimeReceivedPlusDays = datetimeReceived.AddDays(plusDays);

                    _logger.LogInformation($"WeatherForecast requested for days between {datetimeReceived} and {datetimeReceivedPlusDays}");

                    activity.SetStatus(ActivityStatusCode.Ok);

                    return Enumerable.Range(0, plusDays).Select(index => new WeatherForecast
                    {
                        Date = DateOnly.FromDateTime(datetimeReceived.AddDays(index)),
                        TemperatureC = Random.Shared.Next(-20, 55),
                        Summary = Summaries[Random.Shared.Next(Summaries.Length)]
                    }).ToList();

                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, $"Error creating a DateTime using year: {year}, month: {month}, day: {day}");

                    activity.SetStatus(ActivityStatusCode.Error);

                    throw;
                }
            }
        }
    }
}
