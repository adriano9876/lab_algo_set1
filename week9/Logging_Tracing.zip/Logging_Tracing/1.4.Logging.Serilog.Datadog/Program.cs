using Serilog;
using Serilog.Sinks.Datadog.Logs;
using Week9.Observability.Controllers.Service;

namespace Week9.Observability.Controllers
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            builder.Services.AddSingleton<IWeatherForecastService, WeatherForecastService>();

            builder.Services.AddControllers();
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();



            // add structured log console visualizer
            builder
               .Logging
               // Remove all the Logging Providers before adding the ones that i want
               // to be sure to use only the ones added by me and not automatically added by ASP.NET
               .ClearProviders();

            // create configuration for Serilog
            var configSerilog = new LoggerConfiguration()
                .WriteTo.Console() // <- SINK CONSOLE added to Serilog
                .WriteTo.DatadogLogs  // <- SINK DATADOG added to Serilog (so Serilog will push both on Console and Datadog)
                (
                    apiKey: "__TO_REPLACE__",
                    service: "academy.week9.datadog",
                    configuration: new DatadogConfiguration()
                    {
                        Url = "https://http-intake.logs.datadoghq.eu",
                        Port = 10516
                    }
                )
                .CreateLogger();

            builder.Services.AddSerilog(configSerilog); // <-- This method, provided by Serilog Nuget, add Serilog as Logging Provider of ILOGGER with the proper configuration



            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseHttpsRedirection();

            app.UseAuthorization();


            app.MapControllers();

            app.Run();
        }
    }
}