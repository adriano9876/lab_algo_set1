using Microsoft.AspNetCore.Mvc;
using Week9.Observability.Controllers.Service;

namespace Week9.Observability.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        private readonly ILogger<WeatherForecastController> _logger;

        private readonly IWeatherForecastService _weatherForecastService;

        public WeatherForecastController(ILogger<WeatherForecastController> logger, IWeatherForecastService weatherForecastService)
        {
            _logger = logger;
            _weatherForecastService = weatherForecastService;
        }

        [HttpGet(Name = "GetWeatherForecastPlusDays")]
        public IEnumerable<WeatherForecast> GetWeatherForecastPlusDays(int year, int month, int day, int plusDays)
        {
            // CORRECT - but use template with params instead
            _logger.LogInformation("Requested received at {0}", DateTime.UtcNow);


            IList<WeatherForecast> results = _weatherForecastService.GetWeatherForecastPlusDays(year, month, day, plusDays);

            return results;
        }
    }
}