using Datadog.Trace;
using Datadog.Trace.Configuration;
using System.Diagnostics;
using Week9.Observability.Service;

namespace Week9.Observability.Controllers
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);


            var settings = TracerSettings.FromDefaultSources();
            settings.ServiceName = "academy.week9.datadog";
            settings.Environment = "dev";
            settings.ServiceVersion = "0.0.1";
            settings.GlobalTags = new Dictionary<string, string>() { { "team", "academy" }, { "component", "myapp.controller" } };
            settings.AgentUri = new Uri("http://__TO_REPLACE__:8126"); // <-- First replace with real value
            Tracer.Configure(settings);

            // Add services to the container.
            builder.Services.AddSingleton<IWeatherForecastService, WeatherForecastService>();

            builder.Services.AddControllers();
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseHttpsRedirection();

            app.UseAuthorization();


            app.MapControllers();

            app.Run();
        }
    }
}