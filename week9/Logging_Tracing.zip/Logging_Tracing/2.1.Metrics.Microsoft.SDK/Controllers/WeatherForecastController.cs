using Microsoft.AspNetCore.Mvc;
using System.Diagnostics.Metrics;
using System.Threading;
using Week9.Observability.Controllers.Service;

namespace Week9.Observability.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        private readonly ILogger<WeatherForecastController> _logger;

        private readonly IWeatherForecastService _weatherForecastService;

        private readonly IMeterFactory _meterFactory;
        private readonly Counter<int> _counterRequestTotal;
        private readonly Counter<int> _counterRequestSuccess;
        private readonly Counter<int> _counterRequestError;

        public WeatherForecastController(ILogger<WeatherForecastController> logger, IMeterFactory meterFactory, IWeatherForecastService weatherForecastService)
        {
            _logger = logger;
            _weatherForecastService = weatherForecastService;


            _meterFactory = meterFactory;
            var meter = meterFactory.Create("myapp.controller.metrics");
            _counterRequestTotal = meter.CreateCounter<int>("weatherforecast.requested.total");
            _counterRequestSuccess = meter.CreateCounter<int>("weatherforecast.requested.success");
            _counterRequestError = meter.CreateCounter<int>("weatherforecast.requested.error");
        }

        [HttpGet(Name = "GetWeatherForecastPlusDays")]
        public IEnumerable<WeatherForecast> GetWeatherForecastPlusDays(int year, int month, int day, int plusDays)
        {
            Meter meter = _meterFactory.Create("myapp.controller.metrics");

            _logger.LogInformation("Requested received at {0}", DateTime.UtcNow);

            _counterRequestTotal.Add(1);

            IList<WeatherForecast> results = new List<WeatherForecast>();
            try
            {
                results = _weatherForecastService.GetWeatherForecastPlusDays(year, month, day, plusDays);

                _counterRequestSuccess.Add(1);
            }
            catch (Exception)
            {
                _counterRequestError.Add(1);
            }
            return results;
        }
    }
}