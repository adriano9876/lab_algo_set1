using Serilog;
using Serilog.Events;
using Serilog.Sinks.Datadog.Logs;
using StatsdClient;
using Week9.Observability.Controllers.Service;

namespace Week9.Observability.Controllers
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            builder.Services.AddSingleton<IWeatherForecastService, WeatherForecastService>();

            builder.Services.AddControllers();
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();



            // add structured log console visualizer
            builder
               .Logging
               // Remove all the Logging Providers before adding the ones that i want
               // to be sure to use only the ones added by me and not automatically added by ASP.NET
               .ClearProviders();

            // create configuration for Serilog
            var configSerilog = new LoggerConfiguration()
                .MinimumLevel.Information() // <- Only logs AT OR ABOVE this logLevel will be emitted
                .MinimumLevel.Override("Microsoft", LogEventLevel.Warning) // suppress ASP.NET Core info logs
                .MinimumLevel.Override("System", LogEventLevel.Warning)    // suppress system logs
                .WriteTo.Console() // <- SINK CONSOLE added to Serilog
                .CreateLogger();

            builder.Services.AddSerilog(configSerilog); // <-- This method, provided by Serilog Nuget, add Serilog as Logging Provider of ILOGGER with the proper configuration



            builder.Services.AddSingleton<IDogStatsd>(sp =>
            {
                var statsdService = new DogStatsdService();
                var dogstatsdConfig = new StatsdConfig
                {
                    StatsdServerName = "__TO_REPLACE__",
                    StatsdPort = 8125,
                    ServiceName = "academy.week9.datadog"
                };
                statsdService.Configure(dogstatsdConfig);

                return statsdService;
            });


            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseHttpsRedirection();

            app.UseAuthorization();


            app.MapControllers();

            app.Run();
        }
    }
}