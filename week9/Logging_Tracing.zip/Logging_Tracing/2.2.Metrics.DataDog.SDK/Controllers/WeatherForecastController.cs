using Microsoft.AspNetCore.Mvc;
using StatsdClient;
using System.Diagnostics.Metrics;
using Week9.Observability.Controllers.Service;

namespace Week9.Observability.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        private readonly ILogger<WeatherForecastController> _logger;

        private readonly IWeatherForecastService _weatherForecastService;
        private readonly IDogStatsd _dogStatsd;

        public WeatherForecastController(ILogger<WeatherForecastController> logger, IDogStatsd dogStatsd, IWeatherForecastService weatherForecastService)
        {
            _logger = logger;
            _weatherForecastService = weatherForecastService;
            _dogStatsd = dogStatsd;
        }

        [HttpGet(Name = "GetWeatherForecastPlusDays")]
        public IEnumerable<WeatherForecast> GetWeatherForecastPlusDays(int year, int month, int day, int plusDays)
        {
            _logger.LogInformation("Requested received at {0}", DateTime.UtcNow);

            _dogStatsd.Counter("weatherforecast.requested.total", 1);

            IList<WeatherForecast> results = new List<WeatherForecast>();
            try
            {
                results = _weatherForecastService.GetWeatherForecastPlusDays(year, month, day, plusDays);

                _dogStatsd.Counter("weatherforecast.requested.success", 1);
            }
            catch (Exception)
            {
                _dogStatsd.Counter("weatherforecast.requested.error", 1);
            }
            return results;
        }
    }
}