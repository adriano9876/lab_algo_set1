using Week9.Observability.Controllers.Service;

namespace Week9.Observability.Controllers
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            builder.Services.AddSingleton<IWeatherForecastService, WeatherForecastService>();

            builder.Services.AddControllers();
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();



            // add structured log console visualizer
            builder
               .Logging
               // Remove all the Logging Providers before adding the ones that i want
               // to be sure to use only the ones added by me and not automatically added by ASP.NET
               .ClearProviders()
               .AddSimpleConsole() // <-- to see the "plain string" log
               .AddJsonConsole // <-- add another logging provider to see STRUCTURED log
               (
                    c => c.JsonWriterOptions = new() { Indented = true } // <-- I specify an setting of this logging provider (to see the STRUCTURED log well formatted)
               );



            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseHttpsRedirection();

            app.UseAuthorization();


            app.MapControllers();

            app.Run();
        }
    }
}