﻿namespace Week9.Observability.Controllers.Service
{
    public interface IWeatherForecastService
    {
        IList<WeatherForecast> GetWeatherForecastPlusDays(int year, int month, int day, int plusDays);
    }
}