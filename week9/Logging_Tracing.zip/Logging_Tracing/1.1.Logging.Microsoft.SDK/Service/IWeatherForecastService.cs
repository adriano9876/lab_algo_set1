﻿namespace Week9.Observability.Service
{
    public interface IWeatherForecastService
    {
        IList<WeatherForecast> GetWeatherForecastPlusDays(int year, int month, int day, int plusDays);
    }
}