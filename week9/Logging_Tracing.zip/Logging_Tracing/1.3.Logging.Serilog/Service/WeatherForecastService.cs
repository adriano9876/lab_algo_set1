﻿namespace Week9.Observability.Controllers.Service
{
    public class WeatherForecastService : IWeatherForecastService
    {

        private readonly ILogger<WeatherForecastController> _logger;

        public WeatherForecastService(ILogger<WeatherForecastController> logger)
        {

            _logger = logger;
        }

        private static readonly string[] Summaries = new[]
        {
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };

        public IList<WeatherForecast> GetWeatherForecastPlusDays(int year, int month, int day, int plusDays)
        {
            DateTime datetimeReceived;
            try
            {
                datetimeReceived = new DateTime(year, month, day);
            }
            catch (ArgumentOutOfRangeException ex)
            {
                // CORRECT - but use template with params instead
                _logger.LogError(ex, $"Error creating a DateTime using year: {year}, month: {month}, day: {day}");

                throw;
            }

            DateTime datetimeReceivedPlusDays = datetimeReceived.AddDays(plusDays);

            // CORRECT - but use template with params instead
            _logger.LogInformation("WeatherForecast requested for days between {0} and {1}", datetimeReceived, datetimeReceivedPlusDays);

            return Enumerable.Range(0, plusDays).Select(index => new WeatherForecast
            {
                Date = DateOnly.FromDateTime(datetimeReceived.AddDays(index)),
                TemperatureC = Random.Shared.Next(-20, 55),
                Summary = Summaries[Random.Shared.Next(Summaries.Length)]
            }).ToList();
        }
    }
}
