﻿using Algorithms.Core.Balls.Objects;

namespace Algorithms.Core.Balls
{
    public static class BallsHelper
    {
        public static Ball[] SortBalls(this Ball[] sourceArray, int numberOfColours)
        {
            return new Ball[1];
        }

    }
}
