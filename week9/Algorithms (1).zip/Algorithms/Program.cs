﻿// See https://aka.ms/new-console-template for more information
using Algorithms.Test;

int chapter = 6;
TestChapter(chapter, true);


void TestChapter(int chapter, bool executeAll = false)
{
    switch (chapter)
    {
        case 6:
            TestStars testStars = new TestStars();
            testStars.Test();
            break;
        case 7:
            TestBalls testBalls = new TestBalls();
            testBalls.Test();
            break;
        case 8:
            TestTree testTree = new TestTree();
            testTree.Test();
            break;
        case 9:
            TestaBingo testTombola = new TestaBingo();
            testTombola.Test();
            break;
        case 10:
            TestDictionary testDictionary = new TestDictionary();
            testDictionary.Test(); 
            break;
        default:
            if (executeAll)
                Console.WriteLine("Fine capitoli.");
            else
                Console.WriteLine("Inserisci un numero di capitolo valido");
            return;
    }

    if (executeAll)
    {
        TestChapter(chapter + 1, true);
    }
}

