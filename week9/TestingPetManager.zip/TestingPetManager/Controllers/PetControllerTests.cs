﻿using Microsoft.AspNetCore.Mvc;
using Moq;
using PetManager.Controllers;
using PetManager.PetManager.Business;
using PetManager.PetManager.Business.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestingPetManager.Controllers
{
    public class PetControllerTests
    {
        private readonly Mock<IPetService> _serviceMock;
        private readonly PetController _controller;

        public PetControllerTests()
        {
            _serviceMock = new Mock<IPetService>();
            _controller = new PetController(_serviceMock.Object);
        }

        [Fact]
        public async void GetById_ExistingId_ReturnsOkResult()
        {
            // Arrange
            //var contact = new Contact { Id = 1, Name = "Mario", Surname = "Rossi", PhoneNumber = "123", Email = "mario@rossi.it" };
            var pet = new PetResponse
            {
                Id = 1,
                Name = "cane",
                Description = "bello",
                Weight = 1.1,
                CategoryId = 1,
                OwnerId = 1,

            };
            _serviceMock.Setup(s => s.GetPetByIdAsync(1)).ReturnsAsync(pet);

            // Act
            var result = await _controller.GetPetById(1);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var returnContact = Assert.IsType<PetResponse>(okResult.Value);
            Assert.Equal(1, returnContact.Id);
        }


        [Fact]
        public async Task GetAll_ReturnsOkResult_WithListOfContacts()
        {
            // Arrange
            var listaPets = new List<PetResponse>
            {
                new PetResponse { Id = 1, Name = "lupo", OwnerId =1,CategoryId =1,Description="bello" ,Weight=1.1},
                new PetResponse { Id = 2, Name = "ardilla", OwnerId =1,CategoryId =1,Description="bello" ,Weight=1.1}
            };
             _serviceMock.Setup(s => s.GetAllPetsAsync()).ReturnsAsync(listaPets);

            // Act
            var result = await _controller.GetAllPets();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var returnPets = Assert.IsAssignableFrom<IEnumerable<PetResponse>>(okResult.Value);
            Assert.Equal(listaPets, returnPets);
        }





    }
}
