﻿namespace PetManager.PetManager.DataAccess.Model
{
    public class Owner : BaseEntity
    {
        public string Name { get; set; }
        public string Surname { get; set; }

        public List<Pet> Pets { get; set; } = new List<Pet>();

    }
}
