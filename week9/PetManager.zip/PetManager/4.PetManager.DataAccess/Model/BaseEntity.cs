﻿namespace PetManager.PetManager.DataAccess.Model
{
    public class BaseEntity
    {
        public int Id { get; set; }

    }
}
