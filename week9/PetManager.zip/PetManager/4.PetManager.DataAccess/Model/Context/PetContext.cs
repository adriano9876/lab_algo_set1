﻿using Microsoft.EntityFrameworkCore;

namespace PetManager.PetManager.DataAccess.Model.Context
{
    public class PetContext : DbContext
    {
        public PetContext(DbContextOptions<PetContext> options): base(options) { }

        public DbSet<Pet> Pets { get; set; }
        public DbSet<Owner> Owners { get; set; }
        public DbSet<Category> Categories { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Pet>()
                .HasOne(a => a.Category)
                .WithMany(a => a.Pets)
                .HasForeignKey(a => a.CategoryId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Owner>()
                .HasMany(a => a.Pets)
                .WithOne(a => a.Owner)
                .HasForeignKey(a => a.OwnerId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Category>()
                .HasData(
                new Category { Id = 1, Name = "Cane" },
                new Category { Id = 2, Name = "Gatto" },
                new Category { Id = 3, Name = "Criceto" }
                );


            modelBuilder.Entity<Owner>()
                .HasData(
                new Owner { Id = 1, Name = "Adreina", Surname = "Tritto" },
                new Owner { Id = 2, Name = "Tommaso", Surname = "Trevisan" },
                new Owner { Id = 3, Name = "Federico", Surname = "Pariolino" }
                );

            modelBuilder.Entity<Pet>()
                .HasData(
                new Pet { Id = 1, Name = "Pippo", Description = "bel cane", Weight = 8.8, CategoryId = 1, OwnerId = 1 , Tag = "tag_bello" },
                new Pet { Id = 2, Name = "Birba", Description = "bel gatto", Weight = 5.8, CategoryId = 2, OwnerId = 2,  Tag= "tag_brutto"},
                new Pet { Id = 3, Name = "Eddy 2.0", Description = "bel criceto", Weight = 0.4, CategoryId = 3, OwnerId = 3 , Tag = "tag_bello" }
                );

        }
    }
}
