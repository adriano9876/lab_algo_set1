﻿namespace PetManager.PetManager.DataAccess.Model
{
    public class Category : BaseEntity
    {
        public string Name { get; set; }
        public List<Pet> Pets { get; set; } = new List<Pet>();
    }
}
