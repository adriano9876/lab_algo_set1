﻿using System.ComponentModel.DataAnnotations;

namespace PetManager.PetManager.DataAccess.Model
{
    public class Pet : BaseEntity
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public double Weight { get; set; }
        public virtual Category Category { get; set; }
        public int CategoryId { get; set; }
        [Required]
        public string Tag { get; set; }
        
        public int OwnerId { get; set; }
        public virtual Owner Owner { get; set; }

    }
}
