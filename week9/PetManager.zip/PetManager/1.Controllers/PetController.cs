﻿using Microsoft.AspNetCore.Mvc;
using PetManager.PetManager.Business;
using PetManager.PetManager.Business.Dto;

namespace PetManager.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class PetController : Controller
    {
        private readonly IPetService _petService;
        public PetController(IPetService petService)
        {
            _petService = petService;
        }

        [HttpGet]
        public async Task<ActionResult<List<PetResponse>>> GetAllPets()
        {
            var pets = await _petService.GetAllPetsAsync();
            return Ok(pets);
        }

        [HttpGet]
        [Route("GetPetById")]
        public async Task<ActionResult<PetResponse>> GetPetById(int id)
        {
            var pet = await _petService.GetPetByIdAsync(id);
            return Ok(pet);
        }

        [HttpPost]
        [Route("Create Pet")]
        public async Task<ActionResult<PetResponse>> CreatePet(PetRequest pet)
        {
            var p = await _petService.CreatePetAsync(pet);
            return Ok(pet); 
        }

        [HttpPut]
        [Route("Update Pet")]
        public async Task<ActionResult> UpdatePet(PetRequest pet, int id)
        {
            var result = await _petService.UpdatePetAsync(pet, id);
            if (result)
            {
                return Ok(result);
            }
            else
            {
                return BadRequest("Error");
            }
        }

        [HttpDelete]
        public async Task<ActionResult> DeletePet(int id)
        {
            var result = await _petService.DeletePetAsync(id);
            if (result)
            {
                return Ok(result);
            }
            else
            {
                return BadRequest("Error");
            }
        }
    }
}
