﻿using Microsoft.EntityFrameworkCore;
using PetManager.PetManager.DataAccess.Model;
using PetManager.PetManager.DataAccess.Model.Context;
using System.Threading.Tasks;

namespace PetManager.PetManager.Repository.Impl
{
    public class DatabaseRepository : IDatabaseRepository
    {
        private readonly PetContext _context;
        public DatabaseRepository(PetContext petContext)
        {
            _context = petContext;
        }
        public async Task<Pet> CreatePetAsync(Pet pet)
        {
            var newPet = _context.Pets.Add(pet).Entity;
            await _context.SaveChangesAsync();
            return newPet;

        }

        public async Task<bool> DeletePetAsync(int id)
        {
            var pet = await _context.Pets.FindAsync(id);
            if(pet == null) return false;
            _context.Pets.Remove(pet);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<List<Pet>> GetAllPetsAsync()
        {
            var pets = await _context.Pets.AsNoTracking().Include(c=>c.Category).ToListAsync();
            return pets;
        }

        public async Task<Pet> GetPetByIdAsync(int id)
        {
            var pet = await _context.Pets.AsNoTracking().SingleOrDefaultAsync(x => x.Id == id);
            return pet;
        }

        public async Task<bool> UpdatePetAsync(Pet pet, int id)
        {
            var petFind = await _context.Pets.FindAsync(id);
            if(petFind == null) return false;
            petFind.Name = pet.Name;
            petFind.CategoryId = pet.CategoryId;
            petFind.OwnerId = pet.OwnerId;
            petFind.Description = pet.Description;
            await _context.SaveChangesAsync();
            return true;

        }
    }
}
