﻿using PetManager.PetManager.DataAccess.Model;

namespace PetManager.PetManager.Repository
{
    public interface IDatabaseRepository
    {
        public Task<Pet> CreatePetAsync(Pet pet);
        public Task<bool> UpdatePetAsync(Pet pet, int id);
        public Task<bool> DeletePetAsync(int id);
        public Task<Pet> GetPetByIdAsync(int id);
        public Task<List<Pet>> GetAllPetsAsync();
        
    }
}
