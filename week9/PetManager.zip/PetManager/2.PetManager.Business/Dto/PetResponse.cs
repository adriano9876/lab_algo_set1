﻿using PetManager._2.PetManager.Business.Dto;
using PetManager.PetManager.DataAccess.Model;

namespace PetManager.PetManager.Business.Dto
{
    public class PetResponse
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public double Weight { get; set; }
        public int CategoryId { get; set; }

        public int OwnerId { get; set; }

        public CategoryResponse Category { get; set; }
        public string TagResponse { get; set; }

        

    }
}
