﻿namespace PetManager._2.PetManager.Business.Dto
{
    public class CategoryResponse
    {
        public string Name { get; set; }
    }
}
