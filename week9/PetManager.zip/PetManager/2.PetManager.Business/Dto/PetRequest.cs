﻿namespace PetManager.PetManager.Business.Dto
{
    public class PetRequest
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public double Weight { get; set; }
        public int CategoryId { get; set; }
        public int OwnerId { get; set; }
    }
}
