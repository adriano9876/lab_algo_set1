﻿using PetManager._2.PetManager.Business.Dto;
using PetManager.PetManager.Business.Dto;
using PetManager.PetManager.DataAccess.Model;
using PetManager.PetManager.Repository;

namespace PetManager.PetManager.Business.Impl
{
    public class PetService : IPetService
    {
        private readonly IDatabaseRepository _repository;
        public PetService(IDatabaseRepository repository)
        {
            _repository = repository;
        }
        public async Task<PetResponse> CreatePetAsync(PetRequest petDto)
        {
            var pet = await _repository.CreatePetAsync(new Pet
            {
                Name = petDto.Name,
                Description = petDto.Description,
                OwnerId = petDto.OwnerId,
                CategoryId = petDto.CategoryId,
                Weight = petDto.Weight
            });
            return new PetResponse
            {
                Id = pet.Id,
                Name = pet.Name,
                Description = pet.Description,
                OwnerId = pet.OwnerId,
                CategoryId = pet.CategoryId
            };
        }

        public async Task<bool> DeletePetAsync(int id)
        {
            var result = await _repository.DeletePetAsync(id);
            return result;
        }

        public async Task<List<PetResponse>> GetAllPetsAsync()
        {
            var pets = await _repository.GetAllPetsAsync();
            return pets.Select(x => new PetResponse
            {
                Name = x.Name,
                Description = x.Description,
                OwnerId = x.OwnerId,
                CategoryId = x.CategoryId,
                Weight = x.Weight,
                Id = x.Id,
                Category = new CategoryResponse 
                {
                    Name = x.Category.Name,
                }
            }).ToList(); 
        }

        public async Task<PetResponse> GetPetByIdAsync(int id)
        {
            var pet = await _repository.GetPetByIdAsync(id);
            return new PetResponse
            {
                Id = pet.Id,
                Name = pet.Name,
                Description = pet.Description,
                OwnerId = pet.OwnerId,
                CategoryId = pet.CategoryId,
                Weight = pet.Weight
            };
        }

        public async Task<bool> UpdatePetAsync(PetRequest petDto, int id)
        {
            return await _repository.UpdatePetAsync(new Pet
            {
                Name = petDto.Name,
                Description = petDto.Description,
                OwnerId = petDto.OwnerId,
                CategoryId = petDto.CategoryId,
                Weight = petDto.Weight
            }, id);
        }

        public static string Randomcoso(string nome, string categoria)
        {


            return "";
        }



    }
}
