﻿using PetManager.PetManager.Business.Dto;
using PetManager.PetManager.DataAccess.Model;

namespace PetManager.PetManager.Business
{
    public interface IPetService
    {
        public Task<PetResponse> CreatePetAsync(PetRequest pet);
        public Task<bool> UpdatePetAsync(PetRequest pet, int id);
        public Task<bool> DeletePetAsync(int id);
        public Task<PetResponse> GetPetByIdAsync(int id);
        public Task<List<PetResponse>> GetAllPetsAsync();
    }
}
