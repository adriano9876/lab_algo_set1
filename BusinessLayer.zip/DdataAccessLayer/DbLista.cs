﻿using EntitiesLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DdataAccessLayer
{
    
    public  class DbLista
    {        
 
        public List<Paziente> listaPazienti;
        public  List<Medico> listaMedici;
        public List<Amministratore> listaAmministratore;
        

        public DbLista( List<Paziente> listaPazienti, 
            List<Medico> listaMedici, List<Amministratore> listaAmministratore)
        {
            
            this.listaPazienti = new List<Paziente>();
            this.listaMedici = new List<Medico>();
            this.listaAmministratore = new List<Amministratore>();
            
        }
    }
}
