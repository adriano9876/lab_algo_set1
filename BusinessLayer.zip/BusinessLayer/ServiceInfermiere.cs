﻿using EntitiesLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DdataAccessLayer
{
    public class ServiceInfermiere : ITerapiaSomministrazione
    {
        public bool SomministraTerapia(string terapia)
        {
            throw new NotImplementedException();
        }
    }
}
