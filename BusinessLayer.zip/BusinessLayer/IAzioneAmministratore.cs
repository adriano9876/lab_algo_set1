﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace EntitiesLayer
{
    public interface IAzioneAmministratore
    {
        /*CRUD*/
        public bool InseriscoNewPaziente();
        public bool InseriscoNewMedico();
        public bool InseriscoNewInfermiere();
        public bool ModificoDatiPazieteNome();

      
        public bool UpdateDbListaPazienti();
        public bool UpdateDbListaMedici();
        public bool UpdateStipendio();
    
        
       
        



    }
}
