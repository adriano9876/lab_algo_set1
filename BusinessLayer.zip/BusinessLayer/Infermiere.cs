﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntitiesLayer
{
    public class Infermiere : Lavoratore
    {
        public Reparto Reparto { get; set; }

        public Infermiere(string name, string cf, decimal stipendio, Reparto reparto) :
            base(name, cf, stipendio)
        {
            Reparto = reparto;
        }

 
    }
}
