﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer
{
    public interface IMedico
    {
        public bool AggiungiTerapia();
        
        public bool ModificaTerapia();

        public bool RimuoviTerapia();

        public bool SpostarePaziente();



    }
}
