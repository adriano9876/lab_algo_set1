﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DdataAccessLayer
{
    class ServiceMedico : IMedico
    {
        public bool AggiungiTerapia()
        {
            throw new NotImplementedException();
        }

        public bool ModificaTerapia()
        {
            throw new NotImplementedException();
        }

        public bool RimuoviTerapia()
        {
            throw new NotImplementedException();
        }

        public bool SpostarePaziente()
        {
            throw new NotImplementedException();
        }
    }
}
