﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntitiesLayer
{
    public interface ITerapiaSomministrazione
    {
        public bool SomministraTerapia(string terapia);
    }
}
