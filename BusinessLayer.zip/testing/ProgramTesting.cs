﻿using System.Diagnostics;

namespace testing
{
    internal class ProgramTesting
    {
        static void Main(string[] args)
        {

            //Console.WriteLine(dizionario.TryGetValue("them",out string  ok_valore));//errore try ottengo il valore
            //dizionario.TryGetValue("lorogfg", out string valore_dalla_Key);
            //Console.WriteLine("Test");
            //Stopwatch orologio = new Stopwatch();
            //orologio.Start();
            //string parola_input = Console.ReadLine();
            //Console.WriteLine(tempo_scaduto(parola_input, orologio));

            //orologio.Stop();
            //Console.WriteLine(orologio.ElapsedMilliseconds);
            //Console.WriteLine(orologio.Stop +" finito il tempo"); 
            Console.WriteLine("otto % "+ otto_percento());


        }

        static bool otto_percento()
        {
            Random random = new Random();
            int n = random.Next(1, 101); // Generates a random integer
            //Console.WriteLine("valore random : "+n);
            if(n<=99 && n >= 0)
            {
                return true;
            }
            return false;
        }

        public static string GeneraParolaCasuale(int lunghezza)
        {
            const string caratteri = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
            Random random = new Random();
            char[] parola = new char[lunghezza];

            for (int i = 0; i < lunghezza; i++)
            {
                parola[i] = caratteri[random.Next(caratteri.Length)];
            }

            return new string(parola);
        }




        public static bool tempo_scaduto(string parola, Stopwatch o1)
        {
            long tempo = parola.Length * 1000;
            if (o1.ElapsedMilliseconds < tempo)
            {
                return true;
            }

            return false;
        }
    }
}
