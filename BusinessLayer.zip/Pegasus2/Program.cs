﻿using EntitiesLayer;
namespace Pegasus2

{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Inizio Pegasus 2  Progetazione");
           
            Amministratore a1 = new Amministratore("tomas", "T001MSC", 10000);
            Medico m1 = new Medico("stefano", "S002MSC", 2000, Specilizzazione.NeuroChirurgo, Reparto.Neurologia);

            Console.Write("sono hr inserisco un paziente");
            
        }



    }






}
