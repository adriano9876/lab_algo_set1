﻿namespace EntitiesLayer
{
    public class Paziente : Persona
    {

        public int NumeroCartellaClinica { get; set; }
        public Reparto Reparto { get; set; }
        public Paziente(string name, string cf, int numeroCartellaClinica, Reparto reparto) :
            base(name, cf)
        {
            NumeroCartellaClinica = numeroCartellaClinica;
            Reparto = reparto;
        }

    }
}