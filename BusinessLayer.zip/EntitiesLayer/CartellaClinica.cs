﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntitiesLayer
{
    class CartellaClinica
    {
        public int NumeroCartellaClinica { get;private set; }
        
        
        public List<string> Terapia { get; set; }
        public List<string> Patologia { get; set; }
        public List<DateTime> RegistroSomministrazione { get; set; }
        
        public StatoPaziente StatoPaziente { get; set; }

        public CartellaClinica(int numeroCartellaClinica)
        {
            Terapia = new List<string>();
            Patologia = new List<string>();
            NumeroCartellaClinica = numeroCartellaClinica;
            Terapia = new List<string>();
            StatoPaziente = StatoPaziente.Invita;
        }
    }



}
