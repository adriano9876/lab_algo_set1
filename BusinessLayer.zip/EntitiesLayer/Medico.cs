﻿using BusinessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntitiesLayer
{
    public class Medico : Lavoratore , IMedico, ITerapiaSomministrazione
    {
        public Specilizzazione Specilizzazione { get; set; }
        public Reparto Reparto { get; set; }

        public Medico(string name, string cf, decimal stipendio,
            Specilizzazione specilizzazione, Reparto reparto) : base(name, cf, stipendio)
        {
            Specilizzazione = specilizzazione;
            Reparto = reparto;
        }

        public bool AggiungiTerapia()
        {
            return false;
        }
        public bool ModificaTerapia()
        {

            return false;
        }
        public bool RimuoviTerapia()
        {

            return false;
        }

        bool IMedico.SpostarePaziente()
        {
            throw new NotImplementedException();
        }

        public bool SomministraTerapia(string terapia)
        {
            throw new NotImplementedException();
        }
    }
    public enum Specilizzazione
    {
        CardioChilurgo,
        Dermatologo,
        NeuroChirurgo,
        Pediatra

    }
}

