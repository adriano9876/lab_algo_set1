﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntitiesLayer
{
    public class Amministratore : Lavoratore 
    {
        public Amministratore(string name, string cf, decimal stipendio) : 
            base(name, cf, stipendio)
        {
           
        }

    }
}
