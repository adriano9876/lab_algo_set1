﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntitiesLayer
{
    public class Lavoratore: Persona
    {


        public decimal Stipendio { get; set; }
        

        public Lavoratore(string name, string cf, decimal stipendio) :
            base(name, cf)
        {
            Stipendio = stipendio;           

        }


    }

}
