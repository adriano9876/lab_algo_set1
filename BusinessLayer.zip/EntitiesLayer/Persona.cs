﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntitiesLayer
{
    public class Persona
    {
        public string Name { set; get; }
        public string CodiceFiscale { set; get; }

        public Persona(string name, string cf)
        {
            Name = name;
            CodiceFiscale = cf;
        }
    }
}
