﻿

using System;
using System.Diagnostics;

namespace Exercise_c_the_writer_game
{
    internal class Program
    {
        static void Main(string[] args)
        {

            /*Carico dizionario*/
            Dictionary<string,string> dizionario= Utilities.LoadDictionary("C:\\Users\\e-adriano.garaffa\\Documents\\Pegasus2\\Exercise_c_the writer_game\\words-it-en.csv");
            /*Utente scelige lingua inglese o italiano*/
            int linguaScelta = -1;
            int punti = 0;
            Console.WriteLine("Inserisci un numero intero per scegliere la lingua: 1 italiano / 2 inglese / 3 italiano->inglese / 4 inglese->italiano");
            string input = Console.ReadLine();
            int.TryParse(input, out int numero);
            linguaScelta = numero;
            if (linguaScelta == 1)
            {
                Console.WriteLine("hai scelto 1 come lingua italiana ");
            }
            if (linguaScelta == 2)
            {
                Console.WriteLine("hai scelto 2 come lingua inglese ");
            }
            Random random = new Random();
            int numeroCasuale;
            Random random_otto = new Random();
            /*Ciclo dove prende le parole*/
            bool uscita_tutto_tempo = true;
            bool error_word = true;
            
            do
            {
                Stopwatch orologio = new Stopwatch();
                numeroCasuale = random.Next() % dizionario.Count - 1;

                string parola_mostrata;
                string parola_input;
                bool calcolo_otto_percento = Punti.otto_percento();
                if (linguaScelta == 1)
                {
                    if (calcolo_otto_percento)
                    {
                        parola_mostrata = Punti.GeneraParolaCasuale(5);
                    }
                    else
                    {
                        parola_mostrata = dizionario.ElementAt(numeroCasuale).Key;
                    }
                        
                    Console.WriteLine("Scrivi questa parola : " + parola_mostrata);
                    orologio.Start();
                    parola_input = Console.ReadLine();
                    uscita_tutto_tempo = Punti.tempo_scaduto(parola_mostrata, orologio);
                    if (parola_mostrata.Equals(parola_input))
                    {
                        int valore_punti = Punti.PointsWord(parola_mostrata);
                        punti += valore_punti;

                    }
                    if (parola_mostrata.Equals(parola_input) == false)
                    {
                        error_word = false;
                        Console.WriteLine("Parola diversa ,hai perso ");
                    }

                    if (uscita_tutto_tempo == false)
                    {
                        Console.WriteLine("Tempo Scaduto, hai perso");
                    }
                }
                
                if (linguaScelta == 2)
                {
                    if (calcolo_otto_percento)
                    {
                        parola_mostrata = Punti.GeneraParolaCasuale(5);
                    }
                    else
                    {
                        parola_mostrata = dizionario.ElementAt(numeroCasuale).Value;
                    }

                    Console.WriteLine("Scrivi questa parola : " + parola_mostrata);
                    orologio.Start();
                    parola_input = Console.ReadLine();
                    uscita_tutto_tempo = Punti.tempo_scaduto(parola_mostrata, orologio);
                    if (parola_mostrata.Equals(parola_input))
                    {
                        int valore_punti = Punti.PointsWord(parola_mostrata);
                        punti += valore_punti;

                    }
                    if (parola_mostrata.Equals(parola_input) == false)
                    {
                        error_word = false;
                        Console.WriteLine("Parola diversa ,hai perso ");
                    }

                    if (uscita_tutto_tempo == false)
                    {
                        Console.WriteLine("Tempo Scaduto, hai perso");
                    }
                }

                if (linguaScelta == 3)
                {
                   
                    parola_mostrata = dizionario.ElementAt(numeroCasuale).Key;
                    string parola_in_inglese = dizionario.ElementAt(numeroCasuale).Value;
                    Console.WriteLine(parola_in_inglese);
                    Console.WriteLine("Scrivi questa parola in inglese : " + parola_mostrata);
                    orologio.Start();
                    parola_input = Console.ReadLine();
                    uscita_tutto_tempo = Punti.tempo_scaduto(parola_in_inglese, orologio);
                    if (parola_in_inglese.Equals(parola_input))
                    {
                        int valore_punti = Punti.PointsWord(parola_in_inglese);
                        punti += valore_punti;

                    }
                    if (parola_in_inglese.Equals(parola_input) == false)
                    {
                        error_word = false;
                        Console.WriteLine("Parola diversa ,hai perso ");
                    }

                    if (uscita_tutto_tempo == false)
                    {
                        Console.WriteLine("Tempo Scaduto, hai perso");
                    }
                }

                if (linguaScelta == 4)
                {

                    parola_mostrata = dizionario.ElementAt(numeroCasuale).Value;
                    string parola_in_italiano = dizionario.ElementAt(numeroCasuale).Key;
                    Console.WriteLine(parola_in_italiano);
                    Console.WriteLine("Scrivi questa parola in inglese : " + parola_mostrata);
                    orologio.Start();
                    parola_input = Console.ReadLine();
                    uscita_tutto_tempo = Punti.tempo_scaduto(parola_in_italiano, orologio);
                    if (parola_in_italiano.Equals(parola_input))
                    {
                        int valore_punti = Punti.PointsWord(parola_in_italiano);
                        punti += valore_punti;

                    }
                    if (parola_in_italiano.Equals(parola_input) == false)
                    {
                        error_word = false;
                        Console.WriteLine("Parola diversa ,hai perso ");
                    }

                    if (uscita_tutto_tempo == false)
                    {
                        Console.WriteLine("Tempo Scaduto, hai perso");
                    }
                }



            } while (uscita_tutto_tempo && uscita_tutto_tempo && error_word);

            Console.WriteLine("gioco finito, ha fatto "+punti+ " punti");

        }
    }
}
