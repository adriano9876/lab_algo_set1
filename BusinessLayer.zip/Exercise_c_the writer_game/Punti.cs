﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_c_the_writer_game
{
    public class Punti
    {
        public int Quantita { get; set; }

        public Punti()
        {
            Quantita = 0;
        }

        public static int PointsWord(string parola )
        {
            if (parola.Length < 5)
            {
                return 1;
            }
            if(parola.Length>=5 && parola.Length <= 7)
            {
                return 2;
            }
            if(parola.Length >=8 && parola.Length <= 10)
            {
                return 3;
            } 
            return 4;
        }

        public static bool otto_percento()
        {
            Random random = new Random();
            int n = random.Next(1, 101); // Generates a random integer
            //Console.WriteLine("valore random : "+n);
            if (n <= 8 && n >= 0)
            {
                return true;
            }
            return false;
        }

        public static bool tempo_scaduto(string parola, Stopwatch o1)
        {
            long tempo = parola.Length * 1000;
            if (o1.ElapsedMilliseconds < tempo)
            {
                return true;
            }

            return false;
        }

        public static string GeneraParolaCasuale(int lunghezza)
        {
            const string caratteri = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
            Random random = new Random();
            char[] parola = new char[lunghezza];

            for (int i = 0; i < lunghezza; i++)
            {
                parola[i] = caratteri[random.Next(caratteri.Length)];
            }

            return new string(parola);
        }

    }
}
