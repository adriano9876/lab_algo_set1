﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_c_the_writer_game
{
    public static class Utilities
    {
        /// <summary>
        /// Loads translations from file located in <paramref name="fileName"/> and parse it in a dictionary.
        /// </summary>
        /// <param name="fileName">The absolute path of the file (including filename).</param>
        /// <returns>A dictionary having the word as key and the translation as value.</returns>
        /// <exception cref="FileNotFoundException">The file does not exist.</exception>
        public static Dictionary<string, string> LoadDictionary(string fileName)
        {
            if (!File.Exists(fileName))
            {
                throw new FileNotFoundException(fileName);
            }

            var lines =
                 File
                 .ReadLines(fileName)
                 .GroupBy(x => x.Split(',')[0].Trim())
                 .Select(g => new
                 {
                     SRC = g.Key,
                     DST = g.First().Split(',')[1].Trim(),
                 });

            return lines.ToDictionary(line => line.SRC, line => line.DST);
        }
    }
}
