﻿namespace CodeFirstExample.Data;

using CodeFirstExample.Models;
using Microsoft.EntityFrameworkCore;

public class CodeFirstDbContext : DbContext
{
    public CodeFirstDbContext(DbContextOptions<CodeFirstDbContext> options)
        : base(options)
    {
    }

    public DbSet<Product> Products { get; set; }
    public DbSet<Warehouse> Warehouses { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        // Seed dei magazzini
        modelBuilder.Entity<Warehouse>().HasData(
            new Warehouse { Id = 1, Location = "Torino" },
            new Warehouse { Id = 2, Location = "Genova" }
        );

        // Seed dei prodotti
        modelBuilder.Entity<Product>().HasData(
            new Product { Id = 1, Name = "Monitor", Price = 199.99M, WarehouseId = 1 },
            new Product { Id = 2, Name = "Tastiera", Price = 49.99M, WarehouseId = 1 },
            new Product { Id = 3, Name = "Stampante", Price = 129.50M, WarehouseId = 2 }
        );
    }
}

