using ExamProject.Data;
using ExamProject.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ExamProject.Controllers;

[Route("api/[controller]")]
[ApiController]
public class StoreController : ControllerBase
{
    private readonly AppDbContext _context;

    public StoreController(AppDbContext context)
    {
        _context = context;
    }

    // -----------------------------------------------------------------
    // TASK 2.1: GetProductById (10 Points)
    // Implement this method
    // -----------------------------------------------------------------
    [HttpGet("{id}")]
    public async Task<ActionResult<Product>> GetProductById(int id)
    {
        // STUDENT TODO:
        // 1. Find the product by id.
        // 2. Use Eager Loading (Include/ThenInclude) to load Category AND Tags.
        // 3. If not found, return NotFound().
        // 4. Return the product.

        throw new NotImplementedException();
    }

    // -----------------------------------------------------------------
    // TASK 2.2: SearchProducts (10 Points)
    // Implement this method
    // -----------------------------------------------------------------
    [HttpGet("search")]
    public async Task<ActionResult<IEnumerable<Product>>> SearchProducts(
        [FromQuery] string? searchTerm,
        [FromQuery] decimal? minPrice)
    {
        // STUDENT TODO:
        // 1. Start with IQueryable: var query = _context.Products.AsQueryable();
        // 2. If searchTerm is provided, add a .Where() clause to check Name OR Description.
        // 3. If minPrice is provided, add a .Where() clause to check Price.
        // 4. Use .AsNoTracking() for optimization.
        // 5. Execute the query with .ToListAsync() and return the results.

        throw new NotImplementedException();
    }

    // -----------------------------------------------------------------
    // TASK 2.3: GetCategoryStatistics (10 Points)
    // Implement this method
    // -----------------------------------------------------------------
    [HttpGet("statistics")]
    public async Task<IActionResult> GetCategoryStatistics()
    {
        // STUDENT TODO:
        // 1. Query the Categories.
        // 2. Use .Select() to project the results into a new anonymous object (or DTO).
        // 3. The new object should have:
        //    - CategoryName (from category.Name)
        //    - ProductCount (using category.Products.Count())
        // 4. Execute and return the list.

        throw new NotImplementedException();
    }

    // -----------------------------------------------------------------
    // TASK 3: CreateProduct (15 Points)
    // Implement this method
    // -----------------------------------------------------------------
    [HttpPost]
    public async Task<ActionResult<Product>> CreateProduct(Product product)
    {
        // STUDENT TODO:
        // 1. Add the 'product' entity to the DbContext.
        // 2. Save the changes to the database.
        // 3. Return a 201 Created response using CreatedAtAction.
        //    Hint: nameof(GetProductById)

        throw new NotImplementedException();
    }
}