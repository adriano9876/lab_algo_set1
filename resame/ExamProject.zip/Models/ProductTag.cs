namespace ExamProject.Models;

// Explicit Join Entity for the N:N relationship
public class ProductTag
{
    // Composite Primary Key (configured in DbContext)
    public int ProductId { get; set; }
    public Product Product { get; set; }

    public int TagId { get; set; }
    public Tag Tag { get; set; }
}