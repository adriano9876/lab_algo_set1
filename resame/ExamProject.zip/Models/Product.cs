using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace ExamProject.Models;

public class Product
{
    [Key]
    public int ProductId { get; set; }
    public string Name { get; set; }
    public string? Description { get; set; }

    [Column(TypeName = "decimal(18, 2)")]
    public decimal Price { get; set; }
    public DateTime DateAdded { get; set; }
    public bool IsAvailable { get; set; }

    // Foreign Key for 1:N relationship
    public int CategoryId { get; set; }
    // Navigation property (1:N)
    public Category Category { get; set; }

    [JsonIgnore]
    // Navigation property for N:N relationship
    public ICollection<ProductTag> ProductTags { get; set; } = new List<ProductTag>();
}