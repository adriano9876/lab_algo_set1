using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace ExamProject.Models;

public class Category
{
    [Key]
    public int CategoryId { get; set; }
    public string Name { get; set; }

    [JsonIgnore]
    // Navigation property for 1:N relationship
    public ICollection<Product> Products { get; set; } = new List<Product>();
}