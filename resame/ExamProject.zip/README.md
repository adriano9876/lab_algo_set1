# EF Core Code First & LINQ Exam Project

You are provided with a .NET 8 Web API skeleton. The data model (`Models/`) and DbContext (`Data/AppDbContext.cs`) are already defined and include data seeding.

Your task is to implement the API endpoints by writing the correct EF Core and LINQ queries.

**This guide assumes you are using the Package Manager Console (PMC) in Visual Studio.**

## Domain Model

* **Category (1)** <-> **(N) Product**
* **Product (N)** <-> **(N) Tag** (Using an explicit join entity: `ProductTag`)

## Task 1: Setup and Database Creation (5 Points)

1. Open the **Package Manager Console** (PMC) in Visual Studio (View -> Other Windows -> Package Manager Console).
2. Ensure your API project (e.g., "ExamProject") is selected as the "Default project".
3. Add the initial migration:
   ```powershell
   PM> Add-Migration InitialCreate
   ```
4. Apply the migration to create the SQLite database (`exam.db`) and insert the seed data:
   ```powershell
   PM> Update-Database
   ```
5. Run the application (F5 or `dotnet run`) and verify you can access the Swagger UI.

## Task 2: LINQ Implementation (30 Points)

Open `Controllers/StoreController.cs` and complete the implementation for the following endpoints.

1. **`GetProductById(int id)` (10 Points)**

   * Find a single `Product` by its `ProductId`.
   * You **must** use **Eager Loading** to include its associated `Category` and all of its `Tags` (hint: use `.Include()` and `.ThenInclude()`).
   * If not found, return `NotFound()`.
2. **`SearchProducts(string searchTerm, decimal? minPrice)` (10 Points)**

   * Find all products that match the criteria.
   * If `searchTerm` is provided, filter products where the `Name` OR `Description` contains the term (case-insensitive).
   * If `minPrice` is provided, filter products where `Price` is greater than or equal to `minPrice`.
   * The query must be optimized: use **`.AsNoTracking()`** as these are read-only results.
   * Return the list of matching products.
3. **`GetCategoryStatistics()` (10 Points)**

   * You must return a list of anonymous objects (or a DTO) that contains:
     * `CategoryName`
     * `ProductCount` (the total number of products in that category)
   * This requires **projection** (`.Select()`) and **grouping/aggregation**.

## Task 3: Code First (Write Operation) (15 Points)

Implement the body of the `CreateProduct(Product product)` endpoint.

* Add the new `Product` entity to the `DbContext`.
* Save the changes to the database.
* Return a `CreatedAtAction` response pointing to the `GetProductById` endpoint, passing the new product's ID.
