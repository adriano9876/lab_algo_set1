﻿using ExamProject.Models;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace ExamProject.Dtos
{
    public class ProductDto
    {
        public int ProductId { get; set; }
        public string Name { get; set; }
        public string? Description { get; set; }

        public decimal Price { get; set; }
        public DateTime DateAdded { get; set; }

        public string CategoryName { get; set; }
        public bool IsAvailable { get; set; }
        public int CategoryId { get; set; }
        public Category Category { get; set; }
        public IEnumerable <string> ProductTags { get; set; }// = new List<ProductTag>();


    }

    /*
         public async Task<ActionResult<IEnumerable<Product>>> GetProductsByWarehouse(int id)
    {
        var warehouseExists = await _context.Warehouses.AnyAsync(w => w.Id == id);
        if (!warehouseExists)
            return NotFound();

        var products = await _context.Products
            .Where(p => p.WarehouseId == id)
            .ToListAsync();

        return products;
    }
     
     
     */




    /*
      public async Task<ActionResult<ICollection<BrandTagsPaninoDto>>> Get(int id)
        {
            var ris = await _context.Tags.Include(b => b.Brands).AsNoTracking()
            .Where(x=>x.Id == id) .Select(b => b.Brands
            .Select(btp => new BrandTagsPaninoDto
            {
                NomeBrand = btp.NameBrand,
                NomeTag = b.TagName,

            })).SelectMany(a=>a).ToListAsync();

            return Ok(ris);

        }
     
     */


    /*
     
     public async Task<ActionResult<UserDto>> GetUser(int id)
        {
            var u = await _context.Users.FindAsync(id);

            if (u == null)
            {   
                throw new ArgumentNullException(nameof(u));                
            }
            UserDto toRet = new UserDto()
            {
                Id = u.Id,
                Name = u.Name,
                Description = u.Description,
            };

            return toRet;
        }
     */



}
