using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace ExamProject.Models;

public class Tag
{
    [Key]
    public int TagId { get; set; }
    public string Name { get; set; }

    [JsonIgnore]
    // Navigation property for N:N relationship
    public ICollection<ProductTag> ProductTags { get; set; } = new List<ProductTag>();
}