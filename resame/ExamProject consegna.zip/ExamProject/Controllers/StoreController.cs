using ExamProject.Data;
using ExamProject.Dtos;
using ExamProject.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ExamProject.Controllers;

[Route("api/[controller]")]
[ApiController]
public class StoreController : ControllerBase
{
    private readonly AppDbContext _context;

    public StoreController(AppDbContext context)
    {
        _context = context;
    }

    // -----------------------------------------------------------------
    // TASK 2.1: GetProductById (10 Points)
    // Implement this method
    // -----------------------------------------------------------------
    [HttpGet("{id}")]
    public async Task<ActionResult<Product>> GetProductById(int id) 
    {
        var productDto = await _context.Products
            .Include(p => p.Category)
            .Include(p => p.ProductTags)
            .ThenInclude(pt => pt.Tag)
            .AsNoTracking()
            .FirstOrDefaultAsync(p => p.ProductId == id);
        if (productDto == null)
        {
            return NotFound();
        }

        return Ok(productDto);
        //throw new NotImplementedException();
        //var p = await _context.Products
        //    .Include(p => p.Category)
        //    .Include(p => p.ProductTags)
        //    .ThenInclude(pt => pt.Tag)
        //    .Where(p => p.ProductId == id)
        //    .AsNoTracking()
        //    .Select(x => new ProductDto
        //    {
        //        ProductId = x.ProductId,
        //        Name = x.Name,
        //        Description = x.Description,
        //        Price =x.Price,
        //        IsAvailable = x.IsAvailable ,
        //        CategoryId = x.CategoryId,
        //        CategoryName = x.Category.Name,  


        //    }).FirstOrDefaultAsync() ;
        // STUDENT TODO:
        // 1. Find the product by id.
        // 2. Use Eager Loading (Include/ThenInclude) to load Category AND Tags.
        // 3. If not found, return NotFound().
        // 4. Return the product.

    }




    // -----------------------------------------------------------------
    // TASK 2.2: SearchProducts (10 Points)
    // Implement this method
    // -----------------------------------------------------------------
    [HttpGet("search")]
    public async Task<ActionResult<IEnumerable<Product>>> SearchProducts(
        [FromQuery] string? searchTerm,
        [FromQuery] decimal? minPrice)
    {
        // STUDENT TODO:
        // 1. Start with IQueryable: var query = _context.Products.AsQueryable();
        // 2. If searchTerm is provided, add a .Where() clause to check Name OR Description.
        // 3. If minPrice is provided, add a .Where() clause to check Price.
        // 4. Use .AsNoTracking() for optimization.
        // 5. Execute the query with .ToListAsync() and return the results.
        var query = _context.Products
                    .Include(p => p.Category)
                    .Include(p => p.ProductTags)
                    .ThenInclude(pt => pt.Tag)
                    .AsQueryable();
        if (!string.IsNullOrEmpty(searchTerm))
        {
            query = query.Where(p => p.Name.Contains(searchTerm)
            || (p.Description != null 
            &&  p.Description.Contains(searchTerm)));
        }
        if (minPrice.HasValue)
        {
            query = query.Where(p=> p.Price >= minPrice.Value);
        }

        var retProducts = await query.AsNoTracking().ToListAsync();
        return Ok(retProducts);

        throw new NotImplementedException();
    }

    // -----------------------------------------------------------------
    // TASK 2.3: GetCategoryStatistics (10 Points)
    // Implement this method
    // -----------------------------------------------------------------
    [HttpGet("statistics")]
    public async Task<IActionResult> GetCategoryStatistics() // ok
    {
        // STUDENT TODO:
        // 1. Query the Categories.
        // 2. Use .Select() to project the results into a new anonymous object (or DTO).
        // 3. The new object should have:
        //    - CategoryName (from category.Name)
        //    - ProductCount (using category.Products.Count())
        // 4. Execute and return the list.
        var statisticsRet = await _context.Categories.Select(c => new
        {
            CategoryName = c.Name,
            ProductsCount = c.Products.Count
        }).ToListAsync();

        return Ok(statisticsRet);

        //throw new NotImplementedException();
    }

    // -----------------------------------------------------------------
    // TASK 3: CreateProduct (15 Points)
    // Implement this method
    // -----------------------------------------------------------------
    [HttpPost]
    public async Task<ActionResult<Product>> CreateProduct(Product product)
    {
        // STUDENT TODO:
        // 1. Add the 'product' entity to the DbContext.
        // 2. Save the changes to the database.
        // 3. Return a 201 Created response using CreatedAtAction.
        //    Hint: nameof(GetProductById)

        var productCreated = _context.Products.Add(new Product()
        {
            Name = product.Name,
            Description = product.Description,
            Price = product.Price,
            IsAvailable = product.IsAvailable,
            CategoryId = product.CategoryId,
            DateAdded = DateTime.UtcNow
           
        }).Entity;

        await _context.SaveChangesAsync();
        return Ok(productCreated);
        //throw new NotImplementedException();
    }
}