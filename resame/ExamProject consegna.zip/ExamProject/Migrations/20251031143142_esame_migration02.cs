﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ExamProject.Migrations
{
    /// <inheritdoc />
    public partial class esame_migration02 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 1,
                column: "DateAdded",
                value: new DateTime(2025, 10, 31, 14, 31, 42, 412, DateTimeKind.Utc).AddTicks(587));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 2,
                column: "DateAdded",
                value: new DateTime(2025, 10, 31, 14, 31, 42, 412, DateTimeKind.Utc).AddTicks(592));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 3,
                column: "DateAdded",
                value: new DateTime(2025, 10, 31, 14, 31, 42, 412, DateTimeKind.Utc).AddTicks(594));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 4,
                column: "DateAdded",
                value: new DateTime(2025, 10, 31, 14, 31, 42, 412, DateTimeKind.Utc).AddTicks(597));
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 1,
                column: "DateAdded",
                value: new DateTime(2025, 10, 31, 14, 30, 37, 72, DateTimeKind.Utc).AddTicks(913));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 2,
                column: "DateAdded",
                value: new DateTime(2025, 10, 31, 14, 30, 37, 72, DateTimeKind.Utc).AddTicks(917));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 3,
                column: "DateAdded",
                value: new DateTime(2025, 10, 31, 14, 30, 37, 72, DateTimeKind.Utc).AddTicks(919));

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 4,
                column: "DateAdded",
                value: new DateTime(2025, 10, 31, 14, 30, 37, 72, DateTimeKind.Utc).AddTicks(921));
        }
    }
}
