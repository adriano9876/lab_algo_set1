using ExamProject.Models;
using Microsoft.EntityFrameworkCore;

namespace ExamProject.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    // Register entities as DbSets
    public DbSet<Product> Products { get; set; }
    public DbSet<Category> Categories { get; set; }
    public DbSet<Tag> Tags { get; set; }
    public DbSet<ProductTag> ProductTags { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        // Configure the N:N explicit join entity
        // Set the composite primary key for ProductTag
        modelBuilder.Entity<ProductTag>()
            .HasKey(pt => new { pt.ProductId, pt.TagId });

        // Configure the 1:N relationship from Product to ProductTag
        modelBuilder.Entity<ProductTag>()
            .HasOne(pt => pt.Product)
            .WithMany(p => p.ProductTags)
            .HasForeignKey(pt => pt.ProductId);

        // Configure the 1:N relationship from Tag to ProductTag
        modelBuilder.Entity<ProductTag>()
            .HasOne(pt => pt.Tag)
            .WithMany(t => t.ProductTags)
            .HasForeignKey(pt => pt.TagId);

        // --- DATA SEEDING ---
        // Seed Categories
        modelBuilder.Entity<Category>().HasData(
            new Category { CategoryId = 1, Name = "Electronics" },
            new Category { CategoryId = 2, Name = "Books" }
        );

        // Seed Tags
        modelBuilder.Entity<Tag>().HasData(
            new Tag { TagId = 1, Name = "Featured" },
            new Tag { TagId = 2, Name = "On Sale" },
            new Tag { TagId = 3, Name = "New" }
        );

        // Seed Products
        modelBuilder.Entity<Product>().HasData(
            new Product { ProductId = 1, Name = "Laptop", Description = "High-end laptop", Price = 1200.00m, DateAdded = DateTime.UtcNow, IsAvailable = true, CategoryId = 1 },
            new Product { ProductId = 2, Name = "Wireless Mouse", Description = "Ergonomic mouse", Price = 45.50m, DateAdded = DateTime.UtcNow, IsAvailable = true, CategoryId = 1 },
            new Product { ProductId = 3, Name = "EF Core Guide", Description = "A book about EF Core", Price = 29.99m, DateAdded = DateTime.UtcNow, IsAvailable = true, CategoryId = 2 },
            new Product { ProductId = 4, Name = "Headphones", Description = "Noise cancelling", Price = 150.00m, DateAdded = DateTime.UtcNow, IsAvailable = false, CategoryId = 1 }
        );

        // Seed the N:N relationship
        modelBuilder.Entity<ProductTag>().HasData(
            new ProductTag { ProductId = 1, TagId = 1 }, // Laptop is Featured
            new ProductTag { ProductId = 1, TagId = 3 }, // Laptop is New
            new ProductTag { ProductId = 3, TagId = 2 }  // Book is On Sale
        );
    }
}