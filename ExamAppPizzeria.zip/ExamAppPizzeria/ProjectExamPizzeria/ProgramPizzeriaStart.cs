﻿using Business.ConverterFolder;
using Business.Servicefolder;
using DataAccess.PizzeDataAccessMio;
using Entity;
using VistaUser;

namespace ProjectExamPizzeria
{
    internal class ProgramPizzeriaStart
    {
        static void Main(string[] args)
        {

            /*
             Progetto Adriano Garrafa:
                - fatto solo le funzionalita del menu
                - fatto il salvataggio in ram e poi in disco se richiesto
                - non ho fatto con asyn il salvataggio
                - ho fatto la iniezione manualmente  
             */

            IPizzaConverter pizzaConverter = new PizzaConverter();
            IPizzaRepository pizzaRepository = new PizzaRepository();
            IPizzaService pizzaService = new PizzaService(pizzaConverter,pizzaRepository);
            IShowDati showDati = new ShowDati(pizzaService);
            /* inizione fatte a mano ok */
            showDati.ShowAll();
            Console.Write("TUTTO OK YEAHH !!!");
        }



    }
}
