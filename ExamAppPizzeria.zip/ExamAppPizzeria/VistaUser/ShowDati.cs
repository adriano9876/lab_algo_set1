﻿using Business.CommadFolder;
using Business.ConverterFolder;
using Business.DtoFolder;
using Business.Servicefolder;
using DataAccess.PizzeDataAccessMio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VistaUser
{
    public class ShowDati : IShowDati
    {
        private readonly IPizzaService pizzaService;

        public ShowDati(IPizzaService pizzaService)        {
            this.pizzaService = pizzaService;
        }

        public void ShowAll()
        {


            bool exit = false;

            do
            {
                Console.WriteLine("Scegli tra queste alternative");
                Console.WriteLine("0 : per uscire");// to do
                Console.WriteLine("1 : Visualizza tutte le Pizze"); // ok 
                Console.WriteLine("2 : Aggiungi Una nuova Pizza"); // ok
                Console.WriteLine("3 : Modifica un Pizza (Scegli il nome)");// to do
                Console.WriteLine("4 : Elimina Una Pizza (Scegli il nome)");// to do
                Console.WriteLine("5 : Visualizza tutte le Pizze di un certo ordine");


                string sceltaUser = Console.ReadLine();
                switch (sceltaUser)
                {
                    case "0":
                        Console.WriteLine("Scegli se salvare in disco (1) o non salvare (2) i dati lavorati");
                        string valore = Console.ReadLine();
                        if (valore == "1")
                        {
                            pizzaService.SaveInDiskAll();
                        }
                        exit = true;
                        break; 
                    case "1":
                        List<PizzaDto> pizzeDtoToUser=  pizzaService.ShowAllPizze();
                        PrintVideoPizzeDto(pizzeDtoToUser);
                        break;                    
                    case "2":
                        Console.WriteLine("Inserisci il nome della Pizza:");
                        string namePizza =  Console.ReadLine();
                        Console.WriteLine("Inserisci il prezzo della Pizza:");
                        string  pricePizza  = Console.ReadLine();
                        decimal pricePizzaDecimal = Decimal.Parse(pricePizza);
                        PizzaCommand pizzaToService= new PizzaCommand(namePizza,pricePizzaDecimal);
                        pizzaService.AddPizzaToMemory(pizzaToService);
                        break; 
                    case "3":
                        Console.WriteLine("Scegli una delle pizze in elenco");
                        List<PizzaDto> mostraIn3 = pizzaService.ShowAllPizze();
                        PrintVideoPizzeDto(mostraIn3);
                        string pizzaToMod = Console.ReadLine();
                        Console.WriteLine("Scegli con quanto cambiare il prezzo");
                        string prezzo = Console.ReadLine();
                        PizzaCommand pizzaToMod2= new PizzaCommand(pizzaToMod,
                            Decimal.Parse(prezzo)
                            );
                        pizzaService.ModifyPricePizza(pizzaToMod2);

                        break;     
                    case "4":
                        Console.WriteLine("Scegli una delle pizze in elenco");
                        List<PizzaDto> mostrare = pizzaService.ShowAllPizze();
                        PrintVideoPizzeDto(mostrare);
                        string pizzaToDel = Console.ReadLine();
                        pizzaService.DeleteThisPizzaInRam(pizzaToDel);

                        break;;     
                    case "5":
                        break;
                    default:
                        Console.WriteLine("Scegli bene");
                        break;

                }
                Console.WriteLine("-------------------------------------");


            } while (!exit);

            Console.WriteLine("CIAO");
            //throw new NotImplementedException();
        }
        public static void PrintVideoPizzeDto(List<PizzaDto> lista)
        {
            if (lista.Count == 0)
            {
                Console.WriteLine("Nessuna pizza nel database");
            }
            foreach (var item in lista)
            {
                Console.WriteLine($"Pizza: {item.Name} | Prezzo: {item.Price}");
            }
            Console.WriteLine();
        }
    }

}
