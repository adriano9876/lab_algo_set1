﻿using Business.ConverterFolder;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VistaUser
{
    public interface IShowDati
    {    
        public void ShowAll();
    }
}
