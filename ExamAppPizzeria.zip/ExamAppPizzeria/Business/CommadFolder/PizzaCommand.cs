﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business.CommadFolder
{
    public class PizzaCommand
    {
        public string Name { get; set; }
        public decimal Price { get; set; }

        public PizzaCommand(string name, decimal price)
        {
            Name = name;
            Price = price;
        }

        public PizzaCommand()
        {

        }

        public override string ToString()
        {
            return $"Pizza nome: {Name} -> Prezzo {Price} ";
        }

    }
}
