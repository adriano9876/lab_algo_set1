﻿using Business.DtoFolder;
using Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business.ConverterFolder
{
    public interface IPizzaConverter
    {
        public PizzaDto ConvertoPizzaToPizzaDto(Pizza pizza);
        public Pizza ConvertoPizzadtoToPizza(PizzaDto pizza);
    }
}
