﻿using Business.DtoFolder;
using Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business.ConverterFolder
{
    public class PizzaConverter : IPizzaConverter
    {
        public Pizza ConvertoPizzadtoToPizza(PizzaDto pizza)
        {
            return new Pizza(pizza.Name,pizza.Price);
            //throw new NotImplementedException();
        }

        public PizzaDto ConvertoPizzaToPizzaDto(Pizza pizza)
        {
            return new PizzaDto(pizza.Name,pizza.Price);
            //throw new NotImplementedException();
        }
    }
}
