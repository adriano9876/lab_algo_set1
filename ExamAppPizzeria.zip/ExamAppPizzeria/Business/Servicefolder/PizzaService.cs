﻿using Business.CommadFolder;
using Business.ConverterFolder;
using Business.DtoFolder;
using DataAccess.PizzeDataAccessMio;
using Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business.Servicefolder
{
    public class PizzaService:IPizzaService
    {
        private readonly IPizzaConverter pizzaConverter;
        private readonly IPizzaRepository pizzaRepository;

        public PizzaService(IPizzaConverter pizzaConverter, IPizzaRepository pizzaRepository)
        {
            this.pizzaConverter = pizzaConverter;
            this.pizzaRepository = pizzaRepository;
        }



        public void AddPizzaToMemory(PizzaCommand pizzaToService)
        {
            Pizza pizzaToRepo = new Pizza(pizzaToService.Name, pizzaToService.Price);
            pizzaRepository.SavePizzaInRam(pizzaToRepo);

            //throw new NotImplementedException();
        }

        public void DeleteThisPizzaInRam(string pizzaToDel)
        {
            pizzaRepository.DeletePizzaFromRam(pizzaToDel);
            //throw new NotImplementedException();
        }

        public void ModifyPricePizza(PizzaCommand pizzaToMod2)
        {
            Pizza toRepo = new Pizza(pizzaToMod2.Name,  pizzaToMod2.Price);
            pizzaRepository.ModifyPizzaInRam(toRepo);
            //throw new NotImplementedException();
        }

        public void SaveInDiskAll()
        {
            pizzaRepository.SaveInDiskAll();
            //throw new NotImplementedException();
        }

        public List<PizzaDto> ShowAllPizze()
        {
            List<Pizza> listaPizze = pizzaRepository.GetPizzeFromRam();
            List<PizzaDto> listaPizzeDto = new List<PizzaDto>();
           
            foreach(var item in listaPizze)
            {
                PizzaDto tmp = pizzaConverter.ConvertoPizzaToPizzaDto(item);
                listaPizzeDto.Add(tmp);
            }
            return listaPizzeDto;
            //throw new NotImplementedException();
        }
    }
}
