﻿using Business.CommadFolder;
using Business.ConverterFolder;
using Business.DtoFolder;
using DataAccess.PizzeDataAccessMio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business.Servicefolder
{
    public interface IPizzaService
    {
        public void AddPizzaToMemory(PizzaCommand pizzaToService);
        void DeleteThisPizzaInRam(string pizzaToDel);
        void ModifyPricePizza(PizzaCommand pizzaToMod2);
        void SaveInDiskAll();
        public  List<PizzaDto>ShowAllPizze();
    }


}
