﻿using Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.PizzeDataAccessMio
{
    
    public interface IPizzaRepository
    {
        public void SavePizzaInRam(Pizza pizza);
        public List<Pizza> GetPizzeFromRam();
        void DeletePizzaFromRam(string pizzaName);
        void SaveInDiskAll();
        void ModifyPizzaInRam(Pizza toRepo);
    }
}
