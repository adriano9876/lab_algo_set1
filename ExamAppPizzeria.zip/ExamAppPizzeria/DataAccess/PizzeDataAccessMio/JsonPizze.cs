﻿using Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.PizzeDataAccessMio
{
    public class JsonPizze

    {
        public List<Pizza> PizzaList { get; set; }
        public JsonPizze()
        {
            PizzaList = new List<Pizza>();
        }

    }
}
