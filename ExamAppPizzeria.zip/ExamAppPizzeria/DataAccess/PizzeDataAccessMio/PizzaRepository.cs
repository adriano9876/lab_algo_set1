﻿using Entity;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.PizzeDataAccessMio
{
    public class PizzaRepository:IPizzaRepository
    {
       
        private static string path_pizze = "..\\..\\..\\..\\DataAccess\\JsondataBase\\Pizze.json";
        private List<Pizza> DataBaseRamPizze { get; set; } = GetFromDiskRaffinato();//this.GetFromDiskRaffinato();//new List<Pizza>(); 

        public void SavePizzaInRam(Pizza pizza)
        {
            DataBaseRamPizze.Add(pizza);
        }

        public List<Pizza> GetPizzeFromRam()
        {
            return DataBaseRamPizze;
        }

        public static List<Pizza> GetFromDiskRaffinato()
        {
            string grezzo = GetStringJsonPizzeFromDisk();
            JsonPizze jsonPizze = JsonConvert.DeserializeObject<JsonPizze>(grezzo);

            return jsonPizze.PizzaList;
        }

        public static void SaveStringJsonToPizzaToDisk(string stringPizze)
        {
            if(stringPizze == null)
            {
                throw new ArgumentNullException(nameof(stringPizze), "stringPizza error is null in PizzaRepository ");
            }

            using (var sw = new StreamWriter(path_pizze,false))
            {
                sw.Write(stringPizze);
            }
               
        }
        public static string GetStringJsonPizzeFromDisk()
        {
            string listaPizze = "";
            using (var rs = new StreamReader(path_pizze))
            {
                listaPizze = rs.ReadToEnd();
            }
            return listaPizze;
        }

        public void DeletePizzaFromRam(string pizzaName)
        {
            Pizza del = DataBaseRamPizze.SingleOrDefault(n=>n.Name==pizzaName);
            DataBaseRamPizze.Remove(del);
            //throw new NotImplementedException();
        }

        public void SaveInDiskAll()
        {
            JsonPizze toSerialize = new();
            toSerialize.PizzaList = DataBaseRamPizze;
            string toDisk = JsonConvert.SerializeObject(toSerialize);
            SaveStringJsonToPizzaToDisk(toDisk);

            //throw new NotImplementedException();
        }

        public void ModifyPizzaInRam(Pizza toRepo)
        {
            Pizza perModifica = DataBaseRamPizze.SingleOrDefault(n => n.Name == toRepo.Name);
            perModifica.Price = toRepo.Price;
            //throw new NotImplementedException();
        }
    }






}
