﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
    public class Pizza
    {
        public string Name { get; set; }
        public decimal Price { get; set; }

        public Pizza(string name, decimal price)
        {
            Name = name;
            Price = price;
        }

        public Pizza()
        {
            
        }

        public override string ToString()
        {
            return $"Pizza nome: {Name} -> Prezzo {Price} ";
        }
    }
}
