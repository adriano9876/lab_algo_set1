﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
    public class Order
    {
        public int IdOrdine { get; set; }
        public decimal TotalCost { get; set; }





    }

}
